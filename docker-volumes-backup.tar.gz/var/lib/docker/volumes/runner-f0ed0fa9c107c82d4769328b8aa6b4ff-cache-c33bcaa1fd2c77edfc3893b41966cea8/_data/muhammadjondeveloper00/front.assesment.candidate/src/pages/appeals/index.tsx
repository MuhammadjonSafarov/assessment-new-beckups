import {
  Col,
  Row,
  Breadcrumb,
  Flex,
  Typography,
  Button,
  Modal,
  Form,
  Input,
  Select,
  Table,
  ConfigProvider,
  Skeleton,
  Dropdown,
  MenuProps,
  DatePicker,
} from "antd";
import MainLayout from "@/components/layout/MainLayout";
import React, { useCallback, useEffect, useState } from "react";
import { useRouter } from "next/router";
import { axiosServer } from "@/plugins/axiosServer";
import { useAppSelector } from "@/hooks/hooks";

const { Column } = Table;
import {
  ArrowLeftOutlined,
  DeleteFilled,
  DownOutlined,
  EditOutlined,
  HomeOutlined,
  PlusOutlined,
  QuestionCircleOutlined,
} from "@ant-design/icons";
import useTranslation from "next-translate/useTranslation";
import { cannotEmptyRules } from "@/helpers/validationRules";
import { toast } from "react-toastify";
import { OperatorType, PavilionDataType, SessionDataType } from "@/dto/AppDTO";
import { dateFormatLong } from "@/helpers/typeChange";
import Link from "next/link";
import { Option } from "rc-select";
import dayjs from "dayjs";
export default function Apelatsiya() {
  const { Title } = Typography;
  const router = useRouter();
  const { locale } = router;
  const { t } = useTranslation("lang");
  const [form] = Form.useForm();
  const values: any = Form.useWatch([], form);
  const [dataItem, setDataItem] = useState<OperatorType[]>([]);
  const [openModal, setOpenModal] = useState(false);

  const [loading, setLoading] = useState(false);
  const [formBtnLoading, setFormBtnLoading] = useState(false);
  const [editLineId, setEditLineId] = useState(0);
  const [totalItem, setTotalItem] = useState(1);
  const [testTypeList, setTestTypeList] = useState<SessionDataType[]>([]);
  const [pavilionList, setPavilionList] = useState<PavilionDataType[]>([]);
  const layout = {
    labelCol: { span: 8 },
    wrapperCol: { span: 16 },
  };
  // console.log(666666, filter.current);
  const [query, setquery] = useState({
    page: 0,
    limit: 10,
    search: {},
  });
  const formTemplate = {
    examType: "",
    testTypeId: undefined,
    examFormat: "",
    maxCountCandidate: undefined,
    pavilionId: undefined,
    startDate: "",
    cost: undefined,
  };
  const templateChange = {
    testTypeId: undefined,
    examFormat: "",
    maxCountCandidate: undefined,
    pavilionId: undefined,
    cost: undefined,
    startDate: "",
  };
  const [isButtonDisabled, setIsButtonDisabled] = useState(false);
  const [initialValuesItem, setIsInitialValues] = useState<any>({ isRent: false });
  const cannotEmpty = cannotEmptyRules();
  const [modal, contextHolder] = Modal.useModal();
  const userInfo = useAppSelector((state) => state.user); // hooks/hooks.ts qo'shilgandan keyin shundoq ishlatsa buladi
  const breadcrumbItem = [
    {
      href: `/${locale}`,
      title: <HomeOutlined />,
    },
    {
      href: "",
      title: "Apelatsiya",
    },
  ];
  const confirmModal = (id: number) => {
    modal.confirm({
      title: "",
      icon: <QuestionCircleOutlined style={{ marginTop: "10px" }} />,
      content: <h3>{t("deleteConfirmation")}</h3>,
      okText: t("form.yes"),
      cancelText: t("form.no"),
      onOk() {
        deleteLine(id);
      },
      onCancel() {
        // console.log("Cancel");
      },
      okButtonProps: {
        style: {
          backgroundColor: "#ff4d4f",
          color: "white",
          border: "none",
        },
      },
    });
  };
  // Define the function to load pavilion data
  const loadData = useCallback(async () => {
    setLoading(true);
    // console.log(88888, filter?.current);
    await axiosServer(router.locale, false, userInfo?.token)
      // .post(`/api/v1/user/list-search?isListOperators=true`, query)
      .post(`/api/v1/session/list-search`, query)
      .then((res: any) => {
        setLoading(false);
        setTotalItem(res?.data?.total || 1);
        setDataItem(res?.data?.list || []); // Update the state with the fetched data
      })
      .catch(() => {
        setDataItem([]);
        setLoading(false);
      });
  }, [router.locale, query]);

  const loadTestTypeList = () => {
    const permissionQuery = {
      page: 0,
      limit: 5000,
      search: {},
    };
    axiosServer(router.locale, false, userInfo?.token)
      .post(`/api/v1/test-type/list-search`, permissionQuery)
      .then((res: any) => {
        // setTotalItem(res?.data?.total || 1);
        setTestTypeList(res?.data?.list || []);
      })
      .catch(() => "");
  };
  const loadPavilionList = () => {
    const permissionQuery = {
      page: 0,
      limit: 5000,
      search: {},
    };
    axiosServer(router.locale, false, userInfo?.token)
      .post(`/api/v1/pavilion/list-search`, permissionQuery)
      .then((res: any) => {
        // setTotalItem(res?.data?.total || 1);
        setPavilionList(res?.data?.list || []);
      })
      .catch(() => "");
  };
  useEffect(() => {
    loadData();

    loadTestTypeList();
    loadPavilionList();
  }, [router.locale, query]);

  useEffect(() => {
    const timeout = setTimeout(() => {
      form
        .validateFields({ validateOnly: true })
        .then(() => setIsButtonDisabled(true))
        .catch(() => setIsButtonDisabled(false));
    }, 300);

    // console.log(555);
    return () => clearTimeout(timeout);
  }, [form, values]);
  const handleOk = async () => {
    const values = form.getFieldsValue();
    values.startDate = dayjs(values.startDate).format("YYYY-MM-DDTHH:mm:ss[Z]") || undefined;
    if (editLineId) {
      setFormBtnLoading(true);
      await axiosServer(router.locale, false, userInfo?.token)
        .put(`/api/v1/session/${editLineId}`, values)
        .then(() => {
          setEditLineId(0);
          toast.success(`${t("toast.successfully")}`);
          form.setFieldsValue(formTemplate);
          setFormBtnLoading(false);
          setOpenModal(false);
          loadData();
        })
        .catch(() => {
          setFormBtnLoading(false);
        });
    } else {
      await axiosServer(router.locale, false, userInfo?.token)
        .post("/api/v1/session", values)
        .then(() => {
          toast.success(`${t("toast.successfully")}`);
          form.setFieldsValue(formTemplate);
          setOpenModal(false);
          loadData();
        })
        .catch(() => "");
    }
  };
  const editItemModal = async (id: number) => {
    form.setFieldsValue(formTemplate);
    // console.log("eeeeee", values);
    if (id) {
      setEditLineId(id);
      setOpenModal(true);
      setFormBtnLoading(true);
      await axiosServer(router.locale, false, userInfo?.token)
        .get(`/api/v1/session/${id}`)
        .then((res: any) => {
          setFormBtnLoading(false);
          if (res) {
            const data = {
              examType: res?.examType,
              testTypeId: res?.testType?.id,
              examFormat: res?.examFormat,
              maxCountCandidate: res?.maxCountCandidate,
              pavilionId: res?.pavilion?.id,
              startDate: res.startDate ? dayjs(res.startDate, "YYYY-MM-DD HH:mm:ss") : undefined,
              cost: res?.cost,
            };
            setIsInitialValues(data);
            form.setFieldsValue(data);
            // setTimeout(() => {
            //   form.validateFields({ validateOnly: true })
            //     .then(() => setIsButtonDisabled(true))
            //     .catch(() => setIsButtonDisabled(false));
            // }, 500);
          }
        })
        .catch(() => {
          setFormBtnLoading(false);
        });
    }
  };

  const deleteItemModal = (id: number) => {
    if (!id) return;
    confirmModal(id);

    // console.log("Delete Itemmm", id);
  };
  const deleteLine = async (id: number) => {
    if (!id) return;
    await axiosServer(router.locale, false, userInfo?.token)
      .delete(`/api/v1/session/${id}`)
      .then(() => {
        toast.success(`${t("toast.successfully")}`);
        loadData();
      })
      .catch(() => "");
  };
  const closeModal = () => {
    setEditLineId(0);
    form.setFieldsValue(formTemplate);
    setOpenModal(false);
  };

  // Handle pagination changes
  const handlePaginationChange = (page: number, pageSize: number) => {
    const limintChange = page - 1 === query.page;
    setquery((prevQuery) => ({
      ...prevQuery,
      page: limintChange ? 0 : page - 1, // Update page to 5
      limit: pageSize, // Update limit to 3
    }));
  };

  const openCreateModal = () => {
    setOpenModal(true);
    // Explicitly set initial values for a new pavilion if required
    form.setFieldsValue(formTemplate);
  };

  const handleChange = (id: number) => {
    if (!id) return;
    const selectedOption: SessionDataType | undefined = testTypeList.find(
      (option: SessionDataType) => option.id === id,
    );
    form.setFieldsValue({
      maxCountCandidate: selectedOption?.maxCandidates,
      cost: selectedOption?.defaultPaymentAmount,
    });
  };
  const items: MenuProps["items"] = [
    {
      key: "1",
      label: (
        <div onClick={openCreateModal}>
          <PlusOutlined /> Sessiya yaratish
        </div>
      ),
    },
    {
      key: "2",
      label: (
        <Link href="/sessions/b2b/create" locale={locale}>
          <PlusOutlined /> B2B sessiya qo'shish
        </Link>
      ),
    },
    {
      key: "3",
      label: (
        <div>
          <PlusOutlined /> Integratsiya seansini yarating
        </div>
      ),
    },
  ];
  return (
    <MainLayout>
      <Row className="pavilion-box ass-style">
        <Col span={24}>
          <div>
            <Breadcrumb items={breadcrumbItem} />
          </div>
        </Col>
        <Col style={{ display: "none" }} span={24} className="add-pavilion-box">
          <Flex justify={"space-between"}>
            <Flex align={"center"}>
              <ArrowLeftOutlined style={{ marginRight: "16px", fontSize: "16px" }} />
              <Title level={4} className="m-0">
                {/*{t("test.list")}*/}Seanslar moduli
              </Title>
            </Flex>

            <Flex align={"end"}>
              <Dropdown menu={{ items }} placement="bottom">
                <Button type="primary" ghost>
                  Harakatlar <DownOutlined />
                </Button>
              </Dropdown>
            </Flex>
          </Flex>
        </Col>
      </Row>
      <Row style={{ display: "none" }}>
        <Col span={24}>
          <ConfigProvider
            //@ts-ignore
            locale={{
              Pagination: {
                items_per_page: "/" + t("table.page"), // Sahifa hajmi matnini o'zgartirish
              },
            }}
          >
            <Table<OperatorType>
              className="ass-table"
              dataSource={loading ? [] : dataItem}
              rowKey={(record): React.Key => record.id}
              pagination={{
                current: query.page + 1,
                pageSize: query.limit,
                total: totalItem,
                onChange: handlePaginationChange,
                showSizeChanger: true,
                pageSizeOptions: ["10", "20", "50"], // Customize the available page sizes
              }}
              loading={loading}
              locale={{
                emptyText: loading ? <Skeleton active paragraph={{ rows: 5 }} /> : t("empty"),
              }}
            >
              <Column title="#" dataIndex="id" key="id" />
              <Column
                title="examType"
                dataIndex="examType"
                key="examType"
                render={(examType: any) => (
                  <div>
                    <span className="ml-2">{examType}</span>
                  </div>
                )}
              />

              <Column
                title="maxCountCandidate"
                dataIndex="maxCountCandidate"
                key="maxCountCandidate"
              />

              <Column
                title="startDate"
                dataIndex="startDate"
                key="startDate"
                render={(date: string) => (date?.length ? dateFormatLong(date) : "")}
              />
              <Column title="cost" dataIndex="cost" key="cost" />
              <Column
                title={`${t("table.header.actions")}`}
                dataIndex="id"
                key="id"
                render={(id: number) => (
                  <div>
                    <Button
                      onClick={() => editItemModal(id)}
                      className="bg-primary color-white ml-2"
                      shape="round"
                    >
                      <EditOutlined />
                    </Button>
                    <Button
                      danger
                      onClick={() => deleteItemModal(id)}
                      className="ml-2"
                      shape="round"
                    >
                      <DeleteFilled />
                    </Button>
                  </div>
                )}
              />
            </Table>
          </ConfigProvider>
        </Col>
      </Row>
      <Row className="ass-style">
        <Modal
          className="ass-style ass-modal"
          centered
          open={openModal}
          title="Seans yaratish oynasi"
          onOk={handleOk}
          onCancel={closeModal}
          footer={[
            <Button key="close" onClick={closeModal}>
              {t("form.close")}
            </Button>,
            <Button
              key="create"
              className={!isButtonDisabled ? "" : "base-bg color-white"}
              disabled={!isButtonDisabled}
              onClick={handleOk}
              loading={formBtnLoading}
            >
              {t("form.create")}
            </Button>,
          ]}
        >
          <div className="ass-modal-body">
            <Skeleton loading={formBtnLoading} active paragraph={{ rows: 5 }}>
              <Form
                {...layout}
                initialValues={initialValuesItem}
                form={form}
                name="control-hooks"
                style={{ width: "650px", marginTop: "20px" }}
                autoComplete="off"
              >
                <Row>
                  <Col span={24} className="pavilion-input">
                    <Form.Item
                      className="user-form-input"
                      name="examType"
                      label="Imtihon turi"
                      rules={cannotEmpty}
                    >
                      <Select
                        onChange={() => form.setFieldsValue(templateChange)}
                        placeholder={t("form.status")}
                      >
                        <Option value="RETAKE">Qayta olish</Option>
                        <Option value="EXAM">Imtihon</Option>
                      </Select>
                    </Form.Item>
                  </Col>
                  <Col span={24} className="pavilion-input">
                    {values?.examType && (
                      <Form.Item
                        className="user-form-input"
                        name="testTypeId"
                        label="Seans turi"
                        rules={cannotEmpty}
                      >
                        <Select placeholder="Seans turini tanlang" onChange={handleChange}>
                          {/* Optionsni map qilish */}
                          {testTypeList.map((option) => (
                            <Select.Option key={option?.id} value={option?.id}>
                              {option?.titleRu}
                            </Select.Option>
                          ))}
                        </Select>
                      </Form.Item>
                    )}
                  </Col>
                  <Col span={24} className="pavilion-input">
                    {values?.testTypeId && values?.examType === "RETAKE" && (
                      <Form.Item
                        className="user-form-input"
                        name="examFormat"
                        label="Imtihon formati"
                        rules={cannotEmpty}
                      >
                        <Select placeholder="Imtihon formatini tanlang">
                          <Option value="COMPUTER">Kompyuterda</Option>
                          <Option value="WRITE">Yozma ravishda</Option>
                        </Select>
                      </Form.Item>
                    )}
                  </Col>
                  <Col span={24} className="pavilion-input">
                    {values?.testTypeId && (
                      <Form.Item
                        className="user-form-input"
                        name="maxCountCandidate"
                        label="Maksimal miqdor"
                        rules={cannotEmpty}
                      >
                        <Input
                          type="number"
                          min={0}
                          placeholder={t("form.enterPaymentAmount")}
                          onChange={(e) =>
                            form.setFieldsValue({
                              reissueAmount: e?.target?.value ? Number(e?.target?.value) : 0,
                            })
                          }
                        />
                      </Form.Item>
                    )}
                  </Col>
                  <Col span={24} className="pavilion-input">
                    {values?.testTypeId && (
                      <Form.Item
                        className="user-form-input"
                        name="cost"
                        label="Narxi"
                        rules={cannotEmpty}
                      >
                        <Input
                          type="number"
                          min={0}
                          placeholder={t("form.enterPaymentAmount")}
                          onChange={(e) =>
                            form.setFieldsValue({
                              reissueAmount: e?.target?.value ? Number(e?.target?.value) : 0,
                            })
                          }
                        />
                      </Form.Item>
                    )}
                  </Col>

                  <Col span={24} className="pavilion-input">
                    {values?.testTypeId && (
                      <Form.Item
                        className="user-form-input"
                        name="pavilionId"
                        label="Pavilyon"
                        rules={cannotEmpty}
                      >
                        <Select placeholder="Seans turini tanlang">
                          {/* Optionsni map qilish */}
                          {pavilionList.map((option) => (
                            <Select.Option key={option?.id} value={option?.id}>
                              {option?.nameRu}
                            </Select.Option>
                          ))}
                        </Select>
                      </Form.Item>
                    )}
                  </Col>
                  <Col span={24} className="pavilion-input">
                    {values?.testTypeId && values?.examType === "EXAM" && (
                      <Form.Item
                        className="user-form-input"
                        name="startDate"
                        label="Date"
                        rules={cannotEmpty}
                      >
                        <DatePicker
                          format="YYYY-MM-DD HH:mm:ss"
                          showTime={{ defaultValue: dayjs("00:00:00", "HH:mm:ss") }}
                          value={dayjs("2024-12-03 14:30:00", "YYYY-MM-DD HH:mm:ss")}
                        />
                      </Form.Item>
                    )}
                  </Col>
                </Row>
              </Form>
            </Skeleton>
          </div>
        </Modal>
      </Row>

      <Row>
        <Col span={24}>{contextHolder}</Col>
      </Row>
    </MainLayout>
  );
}
