// import { increment } from "../reducers/counter";
// import { useAppDispatch, useAppSelector } from "../hooks/hooks";
import { useEffect } from "react";
import { toast } from "react-toastify";

export default function Tests() {
  // const counter = useSelector((state: RootState) => state.counter.value); // Bu xolat hooks/hooks.ts qo'shilmasidan oldin ishlayotgan edi.
  // const counter = useAppSelector((state) => state?.counter?.value); // hooks/hooks.ts qo'shilgandan keyin shundoq ishlatsa buladi
  // const dispatch = useDispatch();  Bu xolat hooks/hooks.ts qo'shilmasidan oldin ishlayotgan edi.
  // const dispatch = useAppDispatch(); // hooks/hooks.ts qo'shilgandan keyin shundoq ishlatsa buladi
  function handleInc() {
    // dispatch(increment());
  }
  function handleDic() {
    // dispatch(decrement(1)); //
  }
  useEffect(() => {
    setTimeout(() => {
      toast.success("Успешно");
    }, 1000);
  });
  return (
    <div>
      <button onClick={handleInc}>+</button>
      {/*<h1>Test : {counter}</h1>*/}11
      <button onClick={handleDic}>-</button>
    </div>
  );
}
