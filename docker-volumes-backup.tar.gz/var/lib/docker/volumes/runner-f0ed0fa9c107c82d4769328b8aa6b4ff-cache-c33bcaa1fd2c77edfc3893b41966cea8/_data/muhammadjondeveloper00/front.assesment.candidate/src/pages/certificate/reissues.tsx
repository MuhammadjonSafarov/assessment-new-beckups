import { Col, Row } from "antd";
import MainLayout from "@/components/layout/MainLayout";

export default function Reissues() {
  return (
    <MainLayout>
      <Row className="">
        <Col span={24}>Reissues</Col>
      </Row>
    </MainLayout>
  );
}
