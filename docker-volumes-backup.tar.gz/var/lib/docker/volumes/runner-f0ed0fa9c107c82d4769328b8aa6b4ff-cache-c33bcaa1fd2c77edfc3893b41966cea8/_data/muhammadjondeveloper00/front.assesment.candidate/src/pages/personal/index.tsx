import { Col, Row, Typography, Tabs, Card, Dropdown, Space, Image, Button } from "antd";
import MainLayout from "@/components/layout/MainLayout";
import React, { useCallback, useEffect, useState } from "react";
import { useRouter } from "next/router";
import { axiosServer } from "@/plugins/axiosServer";
import { useAppSelector } from "@/hooks/hooks";
import type { TabsProps } from "antd";
import FileUpload from "@/components/widgets/FileUpload";

import { UserOutlined, DownOutlined } from "@ant-design/icons";
// import useTranslation from "next-translate/useTranslation";
import type { MenuProps } from "antd";
import { dateFormatLong, formatPhoneNumber } from "@/helpers/typeChange";
export default function CandidatesPage() {
  const router = useRouter();
  // const { t } = useTranslation("lang");
  const [dataItem, setDataItem] = useState<any>();
  // console.log(666666, filter.current);
  const { Paragraph } = Typography;
  const pasportChange = (act: any) => {
    if (act) {
      loadData();
    }
  };
  const userInfo = useAppSelector((state) => state.user); // hooks/hooks.ts qo'shilgandan keyin shundoq ishlatsa buladi

  const itemsFirst: MenuProps["items"] = [
    {
      key: "1",
      label: (
        <div>
          <FileUpload type="pasport" handlechange={pasportChange} />
        </div>
      ),
    },
  ];
  const itemsSecond: MenuProps["items"] = [
    {
      key: "1",
      label: (
        <div>
          <FileUpload type="selfi" handlechange={pasportChange} />
        </div>
      ),
    },
  ];
  const loadData = useCallback(async () => {
    // console.log(88888, filter?.current);
    // const lastUrl = filter?.current || "ALL";
    await axiosServer(router.locale, true, userInfo?.token)
      .get(`/api/v1/user/me`)
      .then((res: any) => {
        setDataItem(res?.data || {}); // Update the state with the fetched data
      })
      .catch(() => {
        // console.log("error")
      });
  }, [router.locale]);
  useEffect(() => {
    loadData();
  }, [router.locale]);

  // Handle pagination changes

  const onChange = (key: string) => {
    // console.log(`Selected Tab: ${key}`);
    return key;
  };
  const items: TabsProps["items"] = [
    {
      key: "1",
      label: (
        <h1 style={{ color: "black" }}>
          <UserOutlined className="mr-3" /> Shaxsiy ma'lumotlar
        </h1>
      ),
      children: (
        <Row>
          <Col span={14}>
            <Row>
              <Col span={12}>
                <Card
                  title="Pasport"
                  extra={
                    <Dropdown menu={{ items: itemsFirst }}>
                      <a onClick={(e) => e.preventDefault()}>
                        <Space>
                          Suratni o'zgartirish
                          <DownOutlined />
                        </Space>
                      </a>
                    </Dropdown>
                  }
                  style={{ width: 300 }}
                  cover={
                    dataItem?.passportFile?.url ? (
                      <Image
                        style={{ padding: "8px" }}
                        src={`${process.env.NEXT_PUBLIC_IMAGES_URL}/${dataItem?.passportFile?.url}`}
                        alt="empty"
                        preview
                      />
                    ) : (
                      <Image
                        style={{ padding: "8px" }}
                        src="/images/no-image.jpg"
                        alt="empty"
                        preview
                      />
                    )
                  }
                ></Card>
              </Col>
              <Col span={12}>
                <Card
                  title="Selfi"
                  extra={
                    <Dropdown menu={{ items: itemsSecond }}>
                      <a onClick={(e) => e.preventDefault()}>
                        <Space>
                          Pasportni yuklash
                          <DownOutlined />
                        </Space>
                      </a>
                    </Dropdown>
                  }
                  style={{ width: 300 }}
                  cover={
                    dataItem?.file?.url ? (
                      <Image
                        style={{ padding: "8px" }}
                        src={`${process.env.NEXT_PUBLIC_IMAGES_URL}/${dataItem?.file?.url}`}
                        alt="empty"
                        preview
                      />
                    ) : (
                      <Image
                        style={{ padding: "8px" }}
                        src="/images/no-image.jpg"
                        alt="empty"
                        preview
                      />
                    )
                  }
                ></Card>
              </Col>
            </Row>
          </Col>
          <Col span={10}>
            <Card
              title="Shaxsiy ma'lumotlar"
              extra={<Button type="primary">Tahrirlash</Button>}
              style={{ minWidth: 300 }}
            >
              <div>
                <span style={{ color: "gray" }}>Ism</span>
                <h3>{dataItem?.firstName}</h3>
              </div>
              <div>
                <span style={{ color: "gray" }}>Familiya</span>
                <h3>{dataItem?.lastName}</h3>
              </div>
              {dataItem?.middleName && (
                <div>
                  <span style={{ color: "gray" }}>Otasini ismi</span>
                  <h3>{dataItem?.middleName}</h3>
                </div>
              )}
              {dataItem?.userMyIdData?.profile?.common_data?.pinfl && (
                <div>
                  <span style={{ color: "gray" }}>JShShIR</span>
                  <h3>
                    <Paragraph copyable>
                      {dataItem?.userMyIdData?.profile?.common_data?.pinfl}
                    </Paragraph>
                  </h3>
                </div>
              )}
              <div>
                <span style={{ color: "gray" }}>Telefon raqami</span>
                <h3>
                  <Paragraph copyable>{formatPhoneNumber(dataItem?.phone)}</Paragraph>
                </h3>
              </div>
              {dataItem?.userMyIdData?.profile?.doc_data?.pass_data && (
                <div>
                  <span style={{ color: "gray" }}>Pasport</span>
                  <h3>
                    <Paragraph copyable>
                      {dataItem?.userMyIdData?.profile?.doc_data?.pass_data}
                    </Paragraph>
                  </h3>
                </div>
              )}
              {dataItem?.userMyIdData?.profile?.common_data?.birth_date && (
                <div>
                  <span style={{ color: "gray" }}>Tug'ilgan sana</span>
                  <h3>{dataItem?.userMyIdData?.profile?.common_data?.birth_date}</h3>
                </div>
              )}
              {dataItem?.userMyIdData?.profile?.address?.permanent_registration?.region && (
                <div>
                  <span style={{ color: "gray" }}>Manzil</span>
                  <h3>
                    {dataItem?.userMyIdData?.profile?.address?.permanent_registration?.region}{" "}
                    {", "}
                    {dataItem?.userMyIdData?.profile?.address?.permanent_registration?.district}
                  </h3>
                </div>
              )}

              <div>
                <span style={{ color: "gray" }}>Ro'yxatga otilgan sana</span>
                <h3>{dateFormatLong(dataItem?.createdDate)}</h3>
              </div>
            </Card>
          </Col>
        </Row>
      ),
    },
  ];

  return (
    <MainLayout>
      <Row>
        <Col span={24}>
          <Tabs type="card" items={items} onChange={onChange} />
        </Col>
      </Row>
    </MainLayout>
  );
}
