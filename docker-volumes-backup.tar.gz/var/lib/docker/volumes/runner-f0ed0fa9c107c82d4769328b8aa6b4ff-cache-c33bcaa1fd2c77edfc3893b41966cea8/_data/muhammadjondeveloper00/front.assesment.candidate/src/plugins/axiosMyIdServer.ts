import axios, { AxiosError } from "axios";
import { toast } from "react-toastify";
// import { setRefreshToken, setToken, setUserData } from "../reducers/AuthReducer";

export const axiosMyIdServer = (
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  locale = "",
  full = false,
  uToken = "",
  // dispatch = (val: any) => val,
  routerPush = async (val: any) => await val,
  type = "",
) => {
  const instance = axios.create({
    baseURL: process.env.PUBLIC_API_SERVER_URL || "",
    // baseURL: "/api", // from proxy
    headers: {
      // language: locale ? locale : "ru",
      Authorization: uToken ? `Bearer ${uToken}` : "",
      "Content-Type": type === "myId" ? "PARAMS" : "application/json",
      "Content-Language": "uz",
    },
  });
  instance.interceptors.response.use(
    (res) => {
      // console.log(res.request._header)
      return full ? res : res.data;
    },
    ({ code, message, response }: AxiosError<any>) => {
      if (response) {
        if (response.status === 422) {
          const fields = response.data && response.data.fields ? response.data.fields : [];
          const txt = fields.length > 0 ? fields[0].value : message;
          toast.warn(txt);
        } else if (response.status === 404) {
          const mm =
            response.data && response.data.message ? response.data.message : "404. Page not found";
          toast.warn(mm);
        } else if (response.status === 401) {
          // dispatch(setToken({ token: undefined }));
          // dispatch(setRefreshToken({ refreshToken: undefined }));
          // dispatch(setUserData({ userData: undefined }));
          routerPush("/").then(() => "");
        } else if (response.status === 400) {
          const txt = response.data && response.data.message ? response.data.message : message;
          toast.warn(txt);
        } else if (response.status === 500) {
          const txt = "500 Error!";
          toast.warn(txt);
        } else if (response.status === 405) {
          const txt = "Not Allowed!";
          toast.warn(txt);
        } else if (response.status === 403) {
          const txt = "Forbidden!";
          toast.warn(txt);
        } else if (response.status === 0) {
          const txt = "No connection with the server!";
          toast.warn(txt);
        }
      }
      return Promise.reject({ message: code + " - " + message, data: response?.data });
    },
  );
  return instance;
};
