import { Col, Flex, Row, Button, Form, Input, DatePicker, Badge } from "antd";
import { Image, Typography } from "antd";
import { LockOutlined, UserOutlined } from "@ant-design/icons";
import { useRouter } from "next/router";
import LanguageSelect from "@/components/widgets/LanguageSelect";
import { useCallback, useEffect, useRef, useState } from "react";
import { axiosServer } from "@/plugins/axiosServer";
import useTranslation from "next-translate/useTranslation";
import {
  cannotEmptyRules,
  useUserNameRules,
  emptyEmailRules,
  getPassportSerial,
  phoneLengthRules,
} from "@/helpers/validationRules";
import { toast } from "react-toastify";
import dayjs from "dayjs";

export default function Signup() {
  const { Title } = Typography;
  const router = useRouter();
  // const { locale } = router;
  const { t } = useTranslation("lang");
  const [form] = Form.useForm();
  const values: any = Form.useWatch([], form);
  // const [initialValuesItem, setIsInitialValues] = useState<any>({ isRent: false });

  const [isButtonDisabled, setIsButtonDisabled] = useState(false);
  const [seconds, setSeconds] = useState(60); // 1 daqiqa (60 soniya)
  const [isRunning, setIsRunning] = useState(false); // Timerning holati
  const userInfo = useRef<number | undefined>();
  const [step, setStep] = useState(1);
  const [smsCode, setSmsCode] = useState("");

  const cannotEmpty = cannotEmptyRules();

  const userNameRules = useUserNameRules();
  const emptyRules = cannotEmptyRules();
  const emptyEmail = emptyEmailRules();
  const emptyPhone = phoneLengthRules();
  const emptyPassportSerial = getPassportSerial();
  // const usePasswordRules = useUserPasswordRules();
  const startTimer = () => {
    setSeconds(60);
    setIsRunning(true); // Timerni boshlash
  };
  const onFinish = (values: any) => {
    if (values?.username && values?.password && values?.confirmPassword && values?.phone) {
      const data = {
        username: values?.username,
        password: values?.password,
        phone: `998${values.phone}`,
      };

      // data.phone = `998${data.phone}`;
      loginAction(data)
        .then(async (res: any) => {
          if (res) {
            setStep(2);
            startTimer();
            userInfo.current = res.data?.id;
            // toast.success(`${t("toast.successfully")}`);
            // router.push("/login");
            // router
            //   .push(`/signup/myId`)
            //   .then(() => "")
            //   .catch(() => "");
          }
        })
        .catch(() => "");
    }
  };
  const onFinishSecond = (values: any) => {
    if (
      values?.firstName &&
      values?.lastName &&
      values?.email &&
      values?.birthDate &&
      values?.passportSerial
    ) {
      const data = { ...values };
      data.birthDate = data?.birthDate ? dayjs(data.birthDate).format("DD-MM-YYYY") : undefined;

      data.passportNumber = data.passportSerial.slice(2);
      data.passportSerial = data.passportSerial.slice(0, 2);

      data.phone = `998${data.phone}`;
      loginActionSecond(data)
        .then(async (res: any) => {
          if (res) {
            toast.success(`${t("toast.successfully")}`);
            router.push("/login");

            // router
            //   .push(`/signup/myId`)
            //   .then(() => "")
            //   .catch(() => "");
          }
        })
        .catch(() => "");
    }
  };

  const loginAction = useCallback((values: any) => {
    return axiosServer(router.locale, true).post("/api/v1/register", values);
  }, []);
  const loginActionSecond = useCallback((values: any) => {
    return axiosServer(router.locale, true).post(`/api/v1/attach-data/${userInfo.current}`, values);
  }, []);
  useEffect(() => {
    form
      .validateFields({ validateOnly: true })
      .then(() => setIsButtonDisabled(true))
      .catch(() => setIsButtonDisabled(false));
  }, [form, values]);

  const chageSmsCode = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e?.target?.value;

    // Faqat raqamlarni qabul qilish
    if (/^\d*$/.test(value)) {
      setSmsCode(value);
    }
  };
  const createUser = async () => {
    if (!userInfo?.current || !smsCode) return;
    await axiosServer(router.locale, true, "")
      .post(`/api/v1/white/check-eskiz-code/${userInfo.current}/${smsCode}`)
      .then(() => {
        toast.success(`${t("toast.successfully")}`);

        router.replace(`/signup?step=3&userId=${userInfo.current}`);
        setStep(3);
      })
      .catch(() => "");
  };
  useEffect(() => {
    try {
      let intervalId: number | null = null;

      // Agar timer ishlayotgan bo'lsa, intervalni boshlash
      if (isRunning && seconds > 0) {
        intervalId = window.setInterval(() => {
          setSeconds((prevSeconds) => prevSeconds - 1);
        }, 1000);
      } else if (seconds === 0) {
        setIsRunning(false); // Timer tugasa, uni to'xtatish
      }

      // Component unmount bo'lsa yoki timer to'xtatilsa, intervalni to'xtatish
      return () => {
        if (intervalId) {
          clearInterval(intervalId);
        }
      };
    } catch (e) {
      // console.error(e);
    }
  }, [isRunning, seconds]); // `isRunning` va `seconds` o'zgarishi bilan yana ishlaydi

  // const resetTimer = () => {
  //   setSeconds(60); // Timerni qayta tiklash
  //   setIsRunning(false); // Timerni to'xtatish
  // };
  const returnSmsCode = async () => {
    if (!userInfo?.current) return;
    await axiosServer(router.locale, true, "")
      .post(`/api/v1/white/retry-eskiz-code/${userInfo.current}`)
      .then(() => {
        startTimer();
      })
      .catch(() => "");
  };
  useEffect(() => {
    if (!router.isReady) return;
    const step = router?.query?.step ? Number(router?.query?.step) : 1;
    const userId = router?.query?.userId ? Number(router?.query?.userId) : undefined;
    if (step) setStep(step);
    if (userId) {
      userInfo.current = userId;
    }
  }, [router.locale, router.isReady]);
  const redirectSignup = () => {
    router
      .push(`/login`)
      .then(() => {
        //
      })
      .catch(() => {
        //
      });
  };
  return (
    <>
      <Row className="login-form vertical-center ">
        <Col span={24}>
          <Row>
            <Col span={24}>
              <Flex justify={"center"} className="login-form-logo-box">
                <Image className="logo" src="/images/Main-Logo.svg" alt="empty" preview={false} />
              </Flex>
            </Col>
          </Row>
          <Row>
            <Col xs={20} md={15} lg={10} xl={7} xxl={5} style={{ margin: "0 auto" }}>
              <Flex className="login-text-box" justify={"space-between"} align={"center"}>
                <Title className="login-title" level={2} style={{ margin: "0" }}>
                  {t("registration")}
                </Title>
                <LanguageSelect />
              </Flex>

              {step === 1 && (
                <Form
                  form={form}
                  name="login"
                  // initialValues={initialValuesItem}
                  style={{ width: "100%", marginTop: "20px" }}
                  onFinish={onFinish}
                >
                  <Form.Item name="username" rules={userNameRules}>
                    <Input prefix={<UserOutlined />} placeholder={t("auth.login")} />
                  </Form.Item>
                  <Form.Item name="phone" rules={emptyPhone}>
                    <Input addonBefore={"+998"} type="number" placeholder="phone" />
                  </Form.Item>
                  {/*<Form.Item name="password" rules={usePasswordRules}>*/}
                  <Form.Item name="password" rules={cannotEmpty}>
                    <Input
                      prefix={<LockOutlined />}
                      type="password"
                      placeholder={t("auth.password")}
                    />
                  </Form.Item>
                  <Form.Item
                    name="confirmPassword"
                    hasFeedback
                    rules={[
                      { required: true, message: t("validation:notEmpty") },
                      ({ getFieldValue }) => ({
                        validator(_, value) {
                          if (!value || getFieldValue("password") === value) {
                            return Promise.resolve();
                          }
                          return Promise.reject(new Error(t("auth.passwordsNotMatch"))); // Xato xabar
                        },
                      }),
                    ]}
                  >
                    <Input
                      prefix={<LockOutlined />}
                      type="password"
                      placeholder={t("auth.confirmPassword")}
                    />
                  </Form.Item>
                  <Form.Item>
                    <Button
                      block
                      className={!isButtonDisabled ? "" : "base-bg color-white"}
                      disabled={!isButtonDisabled}
                      htmlType="submit"
                    >
                      {t("auth.next")}
                    </Button>
                  </Form.Item>
                </Form>
              )}
              {step === 2 && (
                <div className="mt-3">
                  <Flex className="sms-box" justify="center">
                    {/*<Space direction="vertical" align="center" style={{ marginTop: "20px" }}>*/}
                    {/* OTP Input */}
                    <div>
                      <Input
                        value={smsCode}
                        onChange={chageSmsCode}
                        maxLength={6} // Maksimal 6 ta raqam
                        placeholder="Enter sms code"
                        style={{
                          width: "240px",
                          textAlign: "center",
                          fontSize: "20px",
                        }}
                      />
                      <div className="mt-1 mr-1" style={{ textAlign: "right" }}>
                        <Badge count={`00:${seconds}`} showZero color="#0B7590" />
                      </div>
                      <div style={{ textAlign: "center", cursor: "pointer" }}>
                        {seconds ? (
                          <span style={{ color: "#D9D9D9" }}>Qaytadan yuborish</span>
                        ) : (
                          <span onClick={returnSmsCode} style={{ color: "#0B7590" }}>
                            Qaytadan yuborish
                          </span>
                        )}
                      </div>
                    </div>

                    {/*</Space>*/}
                  </Flex>
                  <Button
                    block
                    className={smsCode.length !== 6 ? "mt-4 mb-4" : "base-bg color-white mt-4 mb-4"}
                    disabled={smsCode.length !== 6}
                    onClick={createUser}
                  >
                    {t("auth.next")}
                  </Button>
                </div>
              )}
              {step === 3 && (
                <Form
                  form={form}
                  name="login"
                  // initialValues={initialValuesItem}
                  style={{ width: "100%", marginTop: "20px" }}
                  onFinish={onFinishSecond}
                >
                  <Form.Item name="firstName" rules={emptyRules}>
                    <Input placeholder="firstName" />
                  </Form.Item>
                  <Form.Item name="lastName" rules={emptyRules}>
                    <Input placeholder="lastName" />
                  </Form.Item>
                  <Form.Item name="middleName">
                    <Input placeholder="middleName" />
                  </Form.Item>
                  <Form.Item name="email" rules={emptyEmail}>
                    <Input placeholder="email" />
                  </Form.Item>
                  <Form.Item name="passportSerial" rules={emptyPassportSerial}>
                    <Input placeholder="AA1234567" />
                  </Form.Item>
                  <Form.Item name="birthDate" rules={emptyRules}>
                    <DatePicker
                      className="w-full"
                      format={{
                        format: "DD-MM-YYYY",
                        type: "mask",
                      }}
                      placeholder="birthDate"
                    />
                  </Form.Item>
                  {/*<Form.Item name="password" rules={usePasswordRules}>*/}

                  <Form.Item>
                    <Button
                      block
                      className={!isButtonDisabled ? "" : "base-bg color-white"}
                      disabled={!isButtonDisabled}
                      htmlType="submit"
                    >
                      {t("auth.next")}
                    </Button>
                  </Form.Item>
                </Form>
              )}
              <div>
                <Button onClick={redirectSignup} className="mb-4" block>
                  {t("auth.submit")}
                </Button>
              </div>
            </Col>
          </Row>
        </Col>
      </Row>
    </>
  );
}
