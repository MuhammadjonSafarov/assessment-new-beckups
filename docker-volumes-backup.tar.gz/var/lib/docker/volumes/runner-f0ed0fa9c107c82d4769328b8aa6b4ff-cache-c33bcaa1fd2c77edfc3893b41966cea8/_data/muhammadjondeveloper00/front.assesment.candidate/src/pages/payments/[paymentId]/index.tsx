import { Col, Row, Button, List, Image, Flex } from "antd";
import MainLayout from "@/components/layout/MainLayout";
import React, { useCallback, useEffect, useRef, useState } from "react";
import { useRouter } from "next/router";
import { axiosServer } from "@/plugins/axiosServer";
import { useAppSelector } from "@/hooks/hooks";

// import useTranslation from "next-translate/useTranslation";
import { PavilionDataType, PaymentType, UniversalDTO } from "@/dto/AppDTO";
import { dateFormatLong } from "@/helpers/typeChange";
import { propertyReturn } from "@/helpers/propertyReturn";
export default function Payments() {
  const router = useRouter();
  const { locale } = router;
  // const timeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const paymentId = router?.query?.paymentId;
  // const { t } = useTranslation("lang");
  const [dataItem, setDataItem] = useState<PaymentType>();
  const formRef = useRef<HTMLFormElement>(null);
  const [orderId, setOrderId] = useState<string>("");
  const [loading, setLoading] = useState(false);

  const userInfo = useAppSelector((state) => state.user); // hooks/hooks.ts qo'shilgandan keyin shundoq ishlatsa buladi
  // Define the function to load pavilion data
  const loadData = useCallback(async () => {
    if (!paymentId) return;
    await axiosServer(router.locale, true, userInfo?.token)
      // .post(`/api/v1/user/list-search?isListOperators=true`, query)
      .get(`/api/v1/user-application/${paymentId}`)
      .then((res: any) => {
        setDataItem(res?.data || []); // Update the state with the fetched data
        loadPayCome(res);
      })
      .catch(() => "");
  }, [router.locale]);

  const loadPayCome = async (item: any) => {
    if (item?.data?.session?.cost) {
      try {
        await axiosServer(router.locale, true, userInfo?.token)
          // .post(`/api/v1/user/list-search?isListOperators=true`, query)

          .post(
            `/api/v1/order-paycom?orderSum=${
              item?.data?.session?.cost * 100
            }&userApplicationId=${paymentId}`,
          )
          .then((res: any) => {
            // console.log(77777, res.data.id);
            if (res && res.data?.id) {
              setOrderId(res.data?.id);
            }
          })
          .catch(() => "");
      } catch (error) {
        setLoading(false); // Shu yerda qayta bosish mumkin bo‘ladi
      }
    }
  };

  useEffect(() => {
    loadData();
  }, [router.locale]);
  // const redirectPayment = () => {
  //   if (timeoutRef.current) {
  //     clearTimeout(timeoutRef.current);
  //   }
  //   timeoutRef.current = setTimeout(() => {
  //     formRef.current?.submit();
  //     setLoading(false); // Shu yerda qayta bosish mumkin bo‘ladi
  //   }, 500);
  // };
  // const handleSubmit = async () => {
  //   if (loading) return; // Bir necha marta bosilishining oldini olish
  //   setLoading(true);
  //   redirectPayment();
  // };
  return (
    <MainLayout>
      <Row className="pavilion-box ass-style">
        <Col span={24}>
          <div>
            {/*<Breadcrumb items={breadcrumbItem} />*/}
            {/*<form method="POST" action="https://checkout.paycom.uz">*/}
            {/*  <input type="hidden" name="merchant" value="601799952668b113c43f956c" />*/}
            {/*  <input type="hidden" name="amount" value="12500000" />*/}
            {/*  <input type="hidden" name="account[id]" value="478550" />*/}
            {/*  <input*/}
            {/*    type="hidden"*/}
            {/*    name="callback"*/}
            {/*    value="https://clients.ahost.uz/viewinvoice.php?id=478550"*/}
            {/*  />*/}
            {/*  <button*/}
            {/*    type="submit"*/}
            {/*    className="btn btn-success"*/}
            {/*    onClick="$(this).addClass('disabled')"*/}
            {/*  >*/}
            {/*    Toʻlash*/}
            {/*  </button>*/}
            {/*</form>*/}
            <h1 style={{ textAlign: "center" }}>To'lov ma'lumotlari</h1>
          </div>
        </Col>
        <Col span={24} className="add-pavilion-box">
          <List bordered>
            <List.Item>
              <span style={{ fontWeight: "bold" }}>Manzil: </span>
              {dataItem?.session?.pavilion && locale
                ? dataItem?.session?.pavilion[
                    propertyReturn(locale, "address") as keyof PavilionDataType
                  ]
                : ""}
            </List.Item>
            <List.Item>
              <span style={{ fontWeight: "bold" }}>Ilova yaratilgan sana: </span>
              {/*{dataItem?.createdDate}*/}
              {dataItem?.createdDate ? dateFormatLong(dataItem.createdDate) : ""}
            </List.Item>
            <List.Item>
              <span style={{ fontWeight: "bold" }}>Turi: </span>
              {dataItem?.session?.examType === "EXAM" ? "Test" : "Qayta topshirish"}
            </List.Item>
            <List.Item>
              <div>
                <span style={{ fontWeight: "bold" }}>To'lov miqdori: </span>
                <span className="payment-type">{dataItem?.session?.cost}</span>
              </div>
            </List.Item>
            <List.Item>
              <span style={{ fontWeight: "bold" }}>Tolash muddati: </span>
              {dataItem?.paymentTermDate ? dateFormatLong(dataItem.paymentTermDate) : ""}
            </List.Item>
            <List.Item>
              <div>
                <span style={{ fontWeight: "bold" }}>Holat: </span>
                <Button
                  color={dataItem?.paymentStatus === "PAID" ? "primary" : "danger"}
                  variant="outlined"
                  className="ml-2"
                >
                  {dataItem?.paymentStatus === "OUT_OF_TERM_DATE" && "Muddati tugagan"}
                  {dataItem?.paymentStatus === "UNPAID" && "To'lanmagan"}
                  {dataItem?.paymentStatus === "PAID" && "To'langan"}
                </Button>
              </div>
            </List.Item>
            <List.Item>
              <span style={{ fontWeight: "bold" }}>Imtihon turi: </span>

              {dataItem?.session?.testType && locale
                ? dataItem?.session?.testType[propertyReturn(locale, "title") as keyof UniversalDTO]
                : ""}
            </List.Item>
            <List.Item>
              <span style={{ fontWeight: "bold" }}>Imtihon boshlanish vaqti: </span>
              {dataItem?.session?.startDate ? dateFormatLong(dataItem?.session?.startDate) : ""}
            </List.Item>
          </List>
        </Col>
        <Col span={24} className="mt-3 mb-3">
          {dataItem?.paymentStatus === "UNPAID" && (
            <Flex justify={"center"}>
              {/*<form id="form-payme" method="POST" action="https://checkout.paycom.uz/">*/}
              {/*  <input type="hidden" name="merchant" value="587f72c72cac0d162c722ae2" />*/}
              {/*  <input type="hidden" name="account[order_id]" value="197" />*/}
              {/*  <input type="hidden" name="amount" value="500" />*/}
              {/*  <input type="hidden" name="lang" value="ru" />*/}
              {/*  <input type="hidden" name="button" data-type="svg" value="colored" />*/}
              {/*  <div id="button-container"></div>*/}
              {/*</form>*/}
              <form ref={formRef} method="POST" action="https://checkout.paycom.uz/">
                <input type="hidden" name="merchant" value="61c3130769d939457396e858" />
                <input type="hidden" name="account[order_id]" value={orderId} />

                <input
                  type="hidden"
                  name="amount"
                  value={dataItem?.session.cost ? (dataItem?.session.cost * 100).toString() : ""}
                />
                <input type="hidden" name="lang" value="ru" />
                {/*<input*/}
                {/*  type="hidden"*/}
                {/*  name="callback"*/}
                {/*  value="https://cabinet.assessment.uz/cabinet/payments/6780bbcae9f0908b85d93fa6"*/}
                {/*/>*/}
                {/*<input type="hidden" name="button" data-type="svg" value="colored" />*/}
                <input
                  type="hidden"
                  name="callback"
                  value={`https://candidat.assessment.uz/payments/${paymentId}`}
                />
                {/*<img _ngcontent-tkp-c191="" src="/assets/images/btn_colored_ru.png" alt="payme" />*/}
                <button
                  className={loading ? "btn-payme-loading" : "btn-payme"}
                  type="submit"
                  onClick={() => setLoading(true)}
                >
                  <Image
                    className="payme-logo"
                    src="/images/btn_colored_ru.png"
                    alt="payme"
                    width={300}
                    preview={false}
                    style={{ cursor: "pointer" }}
                  />
                </button>
              </form>
            </Flex>
          )}
        </Col>
      </Row>
    </MainLayout>
  );
}
