import { Col, Row, Flex, Typography, Button, Table, ConfigProvider, Skeleton } from "antd";
import MainLayout from "@/components/layout/MainLayout";
import React, { useCallback, useEffect, useState } from "react";
import { useRouter } from "next/router";
import { axiosServer } from "@/plugins/axiosServer";
import { useAppSelector } from "@/hooks/hooks";

const { Column } = Table;
import { ArrowLeftOutlined } from "@ant-design/icons";
import useTranslation from "next-translate/useTranslation";
import { OperatorType } from "@/dto/AppDTO";
import { dateFormatLong } from "@/helpers/typeChange";
import Link from "next/link";
export default function MyTests() {
  const { Title } = Typography;
  const router = useRouter();
  const { locale } = router;
  const { t } = useTranslation("lang");
  const [dataItem, setDataItem] = useState<OperatorType[]>([]);

  const [loading, setLoading] = useState(false);
  const [totalItem, setTotalItem] = useState(1);
  // console.log(666666, filter.current);
  const [query, setquery] = useState({
    page: 0,
    limit: 10,
    search: {
      value: "PAID",
    },
  });
  const userInfo = useAppSelector((state) => state.user); // hooks/hooks.ts qo'shilgandan keyin shundoq ishlatsa buladi
  // Define the function to load pavilion data
  const loadData = useCallback(async () => {
    setLoading(true);
    // console.log(88888, filter?.current);
    if (!userInfo?.id) return;
    await axiosServer(router.locale, false, userInfo?.token)
      // .post(`/api/v1/user/list-search?isListOperators=true`, query)
      .post(`/api/v1/user-application/list-search/${userInfo?.id}`, query)
      .then((res: any) => {
        setLoading(false);
        setTotalItem(res?.data?.total || 1);
        setDataItem(res?.data?.list || []); // Update the state with the fetched data
      })
      .catch(() => {
        setDataItem([]);
        setLoading(false);
      });
  }, [router.locale, query]);

  useEffect(() => {
    loadData();
  }, [router.locale, query]);

  // Handle pagination changes
  const handlePaginationChange = (page: number, pageSize: number) => {
    const limintChange = page - 1 === query.page;
    setquery((prevQuery) => ({
      ...prevQuery,
      page: limintChange ? 0 : page - 1, // Update page to 5
      limit: pageSize, // Update limit to 3
    }));
  };

  return (
    <MainLayout>
      <Row className="pavilion-box ass-style">
        <Col span={24}>
          <div>
            {/*<Breadcrumb items={breadcrumbItem} />*/}
            <h1> To'lovlar</h1>
          </div>
        </Col>
        <Col style={{ display: "none" }} span={24} className="add-pavilion-box">
          <Flex justify={"space-between"}>
            <Flex align={"center"}>
              <ArrowLeftOutlined style={{ marginRight: "16px", fontSize: "16px" }} />
              <Title level={4} className="m-0">
                {/*{t("test.list")}*/}Seanslar moduli
              </Title>
            </Flex>
          </Flex>
        </Col>
      </Row>
      <Row>
        <Col span={24}>
          <ConfigProvider
            //@ts-ignore
            locale={{
              Pagination: {
                items_per_page: "/" + t("table.page"), // Sahifa hajmi matnini o'zgartirish
              },
            }}
          >
            <Table<OperatorType>
              className="ass-table"
              dataSource={loading ? [] : dataItem}
              rowKey={(record): React.Key => record.id}
              pagination={{
                current: query.page + 1,
                pageSize: query.limit,
                total: totalItem,
                onChange: handlePaginationChange,
                showSizeChanger: true,
                pageSizeOptions: ["10", "20", "50"], // Customize the available page sizes
              }}
              loading={loading}
              locale={{
                emptyText: loading ? <Skeleton active paragraph={{ rows: 5 }} /> : t("empty"),
              }}
            >
              <Column title="#" dataIndex="id" key="id" />
              <Column
                title="To'lov miqdori"
                key="cost"
                render={(item: any) => (
                  <div>
                    <span className="ml-2">{item?.session?.cost}</span>
                  </div>
                )}
              />

              <Column
                title="Turi"
                key="examType"
                render={(item: any) => (
                  <div>
                    <span className={item?.session?.examType ? "ml-2 payment-type" : "ml-2"}>
                      {item?.session?.examType === "RETAKE" && "Qayta topshirish"}
                      {item?.session?.examType === "EXAM" && "Imtihon"}
                    </span>
                  </div>
                )}
              />

              <Column
                title="Ilova yaratilgan sana"
                dataIndex="createdDate"
                key="createdDate"
                render={(date: string) => (date?.length ? dateFormatLong(date) : "")}
              />
              <Column
                title="To'lash muddati"
                dataIndex="paymentTermDate"
                key="paymentTermDate"
                render={(date: string) => (date?.length ? dateFormatLong(date) : "")}
              />
              <Column
                title="Holat"
                dataIndex="paymentStatus"
                key="paymentStatus"
                render={(paymentStatus: string) => (
                  <div>
                    <Button
                      color={paymentStatus === "PAID" ? "primary" : "danger"}
                      variant="outlined"
                      className="ml-2"
                      loading={paymentStatus === "UNPAID"}
                    >
                      {paymentStatus === "OUT_OF_TERM_DATE" && "Muddati tugagan"}
                      {paymentStatus === "UNPAID" && "To'lanmagan"}
                      {paymentStatus === "PAID" && "To'langan"}
                    </Button>
                  </div>
                )}
              />
              <Column
                title={`${t("table.header.actions")}`}
                dataIndex="id"
                key="id"
                render={(id: number) => (
                  <div>
                    <Link
                      href={`/my-tests/${id}`}
                      locale={locale}
                      className="bg-primary color-white ml-2"
                      style={{ padding: "4px 15px" }}
                    >
                      Kirish
                    </Link>
                  </div>
                )}
              />
            </Table>
          </ConfigProvider>
        </Col>
      </Row>
    </MainLayout>
  );
}
