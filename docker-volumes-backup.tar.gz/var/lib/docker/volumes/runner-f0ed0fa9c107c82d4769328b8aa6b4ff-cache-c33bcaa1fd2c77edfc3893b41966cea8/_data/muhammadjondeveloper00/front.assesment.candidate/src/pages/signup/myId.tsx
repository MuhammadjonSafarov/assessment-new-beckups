import MyId from "@/components/myId";
import { useRouter } from "next/router";

export default function SignupMyId() {
  const router = useRouter();
  const getUserData = (data: any) => {
    // console.log("Parent component function ishladi!", data);
    router.push(`/login?${data}`); // Agar token yo'q bo'lsa, foydalanuvchini login sahifasiga yo'naltirish
  };
  return (
    <>
      <MyId myIdSuccess={getUserData} />
    </>
  );
}
