import { UploadOutlined } from "@ant-design/icons";
import type { UploadProps } from "antd";
import { Button, Upload } from "antd";
import { axiosServer } from "@/plugins/axiosServer";
import { useRouter } from "next/router";
import { useAppSelector } from "@/hooks/hooks";
import { toast } from "react-toastify";
import useTranslation from "next-translate/useTranslation";
interface FileUploadProps {
  type: string;
  handlechange: (act: any) => void;
}
const FileUpload: React.FC<FileUploadProps> = ({ type, handlechange }) => {
  const router = useRouter();
  const userInfo = useAppSelector((state) => state.user); // hooks/hooks.ts qo'shilgandan keyin shundoq ishlatsa buladi
  const { t } = useTranslation("lang");

  const props: UploadProps = {
    customRequest: async ({ file, onSuccess, onError }) => {
      const formData = new FormData();
      formData.append("file", file);
      const userId = userInfo?.id || null;
      if (!userId) return;
      const fileUrl =
        type === "pasport"
          ? `/api/v1/user/attach-passport-file?id=${userId}`
          : type === "selfi"
          ? `/api/v1/user/attach-file?id=${userId}`
          : "/api/v1/file";
      try {
        await axiosServer(router.locale, false, userInfo?.token)
          .post(`${fileUrl}`, formData)
          .then((res: any) => {
            if (res?.id) {
              // @ts-ignore
              onSuccess(res);
              toast.success(`${t("toast.successfully")}`);
              handlechange(true);
            } else {
              // @ts-ignore
              onError(new Error("Upload failed"));
              handlechange(false);
            }
          });
      } catch (error) {
        // @ts-ignore
        onError(error);
      }
    },
  };

  return (
    <Upload {...props}>
      <Button icon={<UploadOutlined />}>Upload</Button>
    </Upload>
  );
};

export default FileUpload;
