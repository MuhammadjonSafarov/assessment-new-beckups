import { Col, Row, Breadcrumb, Flex, Typography } from "antd";
import MainLayout from "@/components/layout/MainLayout";
import React from "react";
import { useRouter } from "next/router";

import { ArrowLeftOutlined, HomeOutlined } from "@ant-design/icons";

export default function Offert() {
  const { Title } = Typography;
  const router = useRouter();
  const { locale } = router;

  // console.log(666666, filter.current);

  const breadcrumbItem = [
    {
      href: `/${locale}`,
      title: <HomeOutlined />,
    },
    {
      href: "",
      title: "Oferta",
    },
  ];
  // Define the function to load pavilion data

  return (
    <MainLayout>
      <Row className="pavilion-box ass-style">
        <Col span={24}>
          <div>
            <Breadcrumb items={breadcrumbItem} />
          </div>
        </Col>

        <Col span={24} className="add-pavilion-box">
          <Flex justify={"space-between"}>
            <Flex align={"center"}>
              <ArrowLeftOutlined style={{ marginRight: "16px", fontSize: "16px" }} />
              <Title level={4} className="m-0">
                {/*{t("test.list")}*/}Oferta sahifasi
              </Title>
            </Flex>
          </Flex>
        </Col>
      </Row>

      <Row style={{ display: "none" }}>
        <Col span={24}>q</Col>
      </Row>
    </MainLayout>
  );
}
