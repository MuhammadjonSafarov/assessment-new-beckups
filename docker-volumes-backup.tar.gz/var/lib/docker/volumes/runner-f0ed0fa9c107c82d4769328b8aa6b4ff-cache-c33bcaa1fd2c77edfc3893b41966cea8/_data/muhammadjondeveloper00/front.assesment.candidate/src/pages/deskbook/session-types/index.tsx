import { Col, Row, Flex, Form, Card, Select, Button } from "antd";
import MainLayout from "@/components/layout/MainLayout";
import React, { useCallback, useEffect, useRef, useState } from "react";
import dynamic from "next/dynamic";
import { useRouter } from "next/router";
import { axiosServer } from "@/plugins/axiosServer";
import { useAppSelector } from "@/hooks/hooks";

import useTranslation from "next-translate/useTranslation";
import { SessionDataType } from "@/dto/AppDTO";
import { propertyReturn } from "@/helpers/propertyReturn";
import { assessmentFileProxyUrl } from "@/helpers/assessmentAssetUrl";

import { cannotEmptyRules } from "@/helpers/validationRules";
import { toast } from "react-toastify";
const OfferAcceptanceModal = dynamic(() => import("@/components/deskbook/OfferAcceptanceModal"), {
  ssr: false,
});
const { Meta } = Card;
export default function SessionTypes() {
  const { Option } = Select;
  const [form] = Form.useForm();
  const [formBtnLoading, setFormBtnLoading] = useState(false);

  const router = useRouter();
  const { locale } = router;
  const oneTestItem = useRef<any>();
  const cannotEmpty = cannotEmptyRules();

  const [testPavilionList, setTestPavilionList] = useState([]);
  const [testSessionList, setTestSessionList] = useState([]);

  const { t } = useTranslation("lang");
  const [dataItem, setDataItem] = useState<SessionDataType[]>([]);
  const [initialValuesItem, setIsInitialValues] = useState<any>({ isRent: false });
  const [offerModalOpen, setOfferModalOpen] = useState(false);
  const [offerPendingItem, setOfferPendingItem] = useState<any>(null);

  const userInfo = useAppSelector((state) => state.user); // hooks/hooks.ts qo'shilgandan keyin shundoq ishlatsa buladi

  // Define the function to load pavilion data
  const loadSessionLists = useCallback(async () => {
    const query = {
      page: 0,
      limit: 10,
      search: {
        examTypes: ["EXAM"],
      },
    };
    await axiosServer(router.locale, false, userInfo?.token)
      // .post("/api/v1/session/list-search", query)
      .post("/api/v1/test-type/list-search-group-tt", query)
      .then((res: any) => {
        setDataItem(res?.data?.list || []); // Update the state with the fetched data
      })
      .catch(() => {
        setDataItem([]);
      });
  }, [router.locale]);

  const redirectSessionRegister = (item: any) => {
    if (!item?.id) return;
    router.push({
      pathname: `/deskbook/session-types/register`,
      query: {
        name: item && locale ? item[propertyReturn(locale, "title") as keyof typeof item] : "",
        id: item?.id || "",
      },
    });
  };

  const handleSessionTypeClick = (item: any) => {
    if (item?.offerFileDto?.url) {
      setOfferPendingItem(item);
      setOfferModalOpen(true);
      return;
    }
    redirectSessionRegister(item);
  };

  const offerPdfUrl = offerPendingItem?.offerFileDto?.url
    ? assessmentFileProxyUrl(offerPendingItem.offerFileDto.url)
    : "";

  const loadTestPavilion = async (id: any) => {
    if (!id) return;
    await axiosServer(router.locale, true, userInfo?.token)
      .get(`/api/v1/pavilion/test-type/${id}`)
      .then((res: any) => {
        setTestPavilionList(res?.data?.list || []); // Update the state with the fetched data
      })
      .catch(() => {
        setTestPavilionList([]);
      });
  };
  const loadTestSession = async (id: any) => {
    if (!id) return;
    await axiosServer(router.locale, true, userInfo?.token)
      .get(`/api/v1/session/${oneTestItem.current.id}/${id}`)
      .then((res: any) => {
        setTestSessionList(res?.data?.list || []); // Update the state with the fetched data
      })
      .catch(() => {
        setTestSessionList([]);
      });
  };
  const pavilionChange = (id: number) => {
    setIsInitialValues({ sessionId: null });
    form.setFieldsValue({ sessionId: null });
    setIsInitialValues(id);
    if (!id) return;
    setTestSessionList([]);
    loadTestSession(id);
  };

  useEffect(() => {
    loadSessionLists();
  }, [router.locale]);
  useEffect(() => {
    const query = router?.query; // 'name' va 'id' query parametrlari
    oneTestItem.current = query;
    if (query?.id) {
      loadTestPavilion(query?.id);
    }
  }, [router.isReady]);

  const onFinish = async (values: any) => {
    setFormBtnLoading(true);
    const data = { sessionId: values?.sessionId, userId: userInfo?.id };
    if (data.sessionId && data?.userId) {
      await axiosServer(router.locale, true, userInfo?.token)
        .post(`/api/v1/user-application`, data)
        .then(() => {
          setFormBtnLoading(false);
          setIsInitialValues({ pavilionId: null, sessionId: null });
          form.setFieldsValue({ pavilionId: null, sessionId: null });
          // setTestSessionList(res?.data?.list || []); // Update the state with the fetched data
          toast.success(`${t("toast.successfully")}`);
        })
        .catch(() => {
          setFormBtnLoading(false);
        });
    }
  };

  return (
    <MainLayout>
      <Row className="pavilion-box">
        <Col span={24}>
          <div>{/*<Breadcrumb items={breadcrumbItem} />*/}</div>
          <div>Imtihonga roʻyxatdan oʻtish</div>
        </Col>
        <Col span={24}>
          {oneTestItem?.current?.name && oneTestItem?.current?.id ? (
            <Row className="mt-4">
              <Col span={24}>
                <h1 className="text-center">{oneTestItem?.current?.name}</h1>
                <Row>
                  <Form
                    onFinish={onFinish}
                    initialValues={initialValuesItem}
                    form={form}
                    layout="vertical"
                    name="pavilion"
                    style={{ width: "100%", marginTop: "20px" }}
                    autoComplete="off"
                  >
                    <Row style={{ display: "flex", justifyContent: "center" }}>
                      <Col xs={24} sm={12} md={12} lg={12} xl={12}>
                        <Row>
                          <Col span={24} className="pavilion-input">
                            <Form.Item
                              name="pavilionId"
                              label="Imtihon bo'lish joyini tanlang"
                              rules={cannotEmpty}
                            >
                              <Select showSearch allowClear onChange={pavilionChange}>
                                {testPavilionList?.length &&
                                  testPavilionList?.map((item: any, index: number) => (
                                    <Option key={index} value={item.id}>
                                      {item?.nameUz}
                                    </Option>
                                  ))}
                              </Select>
                            </Form.Item>
                          </Col>
                          <Col span={24} className="pavilion-input">
                            <Form.Item name="sessionId" label="Vaqtni tanlang" rules={cannotEmpty}>
                              <Select allowClear>
                                {testSessionList?.length &&
                                  testSessionList?.map((item: any, index: number) => (
                                    <Option key={index} value={item.id}>
                                      {item?.startDate}
                                    </Option>
                                  ))}
                              </Select>
                            </Form.Item>
                          </Col>
                          <Flex className="w-full" justify={"center"}>
                            <Button
                              key="create"
                              className={"base-bg color-white"}
                              htmlType="submit"
                              loading={formBtnLoading}
                            >
                              Ro'yxatdan o'tishni tasdiqlang
                            </Button>
                          </Flex>
                        </Row>
                      </Col>
                    </Row>
                  </Form>
                </Row>
              </Col>
            </Row>
          ) : (
            <Row>
              <Col span={24}>
                <h1 className="mt-4 mb-3">Sinov turini tanlang</h1>
              </Col>
              <Col span={24}>
                <Row>
                  {dataItem.length
                    ? dataItem.map((item: any, index: number) => (
                        <Col
                          key={index}
                          xs={24}
                          md={11}
                          xl={7}
                          style={{ padding: "10px 25px", marginTop: "8px" }} // mt-2 = 8px (approx)
                        >
                          <Card
                            style={{ height: "500px", padding: "10px" }}
                            onClick={() => handleSessionTypeClick(item)}
                            hoverable
                            className="session-types-card"
                            cover={
                              <img
                                alt="example"
                                src={
                                  item?.fileDto?.url
                                    ? process.env.NEXT_PUBLIC_IMAGES_URL + item?.fileDto?.url
                                    : ""
                                }
                              />
                            }
                          >
                            <Meta
                              title={
                                item && locale
                                  ? item[propertyReturn(locale, "title") as keyof typeof item]
                                  : ""
                              }
                              description={
                                item && locale
                                  ? item[propertyReturn(locale, "partner") as keyof typeof item]
                                  : ""
                              }
                            />
                          </Card>
                          {/*<Col key={index} xs={24} sm={24} md={11} xl={7}>*/}
                          {/*  <Flex justify={"center"}>*/}
                          {/*    <Card*/}
                          {/*      style={{*/}
                          {/*        width: 340,*/}
                          {/*        height: 500,*/}
                          {/*        backgroundImage: `url(${*/}
                          {/*          item?.testType?.fileDto?.url*/}
                          {/*            ? process.env.NEXT_PUBLIC_IMAGES_URL +*/}
                          {/*              item?.testType.fileDto?.url*/}
                          {/*            : ""*/}
                          {/*        })`,*/}
                          {/*        backgroundSize: "cover",*/}
                          {/*        backgroundPosition: "center",*/}
                          {/*      }}*/}
                          {/*      onClick={() => redirectSessionRegister(item)}*/}
                          {/*    >*/}
                          {/*      <p>*/}
                          {/*        {item?.testType?.fileDto?.url ? (*/}
                          {/*          <h4 className="text-center">*/}
                          {/*            {item?.testType && locale*/}
                          {/*              ? item.testType[*/}
                          {/*                  propertyReturn(*/}
                          {/*                    locale,*/}
                          {/*                    "title",*/}
                          {/*                  ) as keyof typeof item.testType*/}
                          {/*                ]*/}
                          {/*              : ""}*/}
                          {/*          </h4>*/}
                          {/*        ) : (*/}
                          {/*          ""*/}
                          {/*        )}*/}
                          {/*      </p>*/}
                          {/*    </Card>*/}
                          {/*  </Flex>*/}
                          {/*</Col>*/}
                        </Col>
                      ))
                    : ""}
                </Row>
              </Col>
            </Row>
          )}
        </Col>
      </Row>
      <OfferAcceptanceModal
        open={offerModalOpen}
        pdfUrl={offerPdfUrl}
        onClose={() => {
          setOfferModalOpen(false);
          setOfferPendingItem(null);
        }}
        onConfirm={() => {
          if (offerPendingItem) redirectSessionRegister(offerPendingItem);
        }}
      />
    </MainLayout>
  );
}
