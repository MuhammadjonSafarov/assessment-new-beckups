import { Col, Row, Button, List } from "antd";
import MainLayout from "@/components/layout/MainLayout";
import React, { useCallback, useEffect, useState } from "react";
import { useRouter } from "next/router";
import { axiosServer } from "@/plugins/axiosServer";
import { useAppSelector } from "@/hooks/hooks";

// import useTranslation from "next-translate/useTranslation";
import { PavilionDataType, PaymentType, UniversalDTO } from "@/dto/AppDTO";
import { dateFormatLong } from "@/helpers/typeChange";
import { propertyReturn } from "@/helpers/propertyReturn";
export default function Payments() {
  const router = useRouter();
  const { locale } = router;
  // const { t } = useTranslation("lang");
  const [dataItem, setDataItem] = useState<PaymentType>();

  const userInfo = useAppSelector((state) => state.user); // hooks/hooks.ts qo'shilgandan keyin shundoq ishlatsa buladi
  // Define the function to load pavilion data
  const loadData = useCallback(async () => {
    const testId = router?.query?.testId;
    if (!testId) return;
    await axiosServer(router.locale, true, userInfo?.token)
      // .post(`/api/v1/user/list-search?isListOperators=true`, query)
      .get(`/api/v1/user-application/${testId}`)
      .then((res: any) => {
        setDataItem(res?.data || []); // Update the state with the fetched data
      })
      .catch(() => "");
  }, [router.locale]);

  useEffect(() => {
    loadData();
  }, [router.locale]);

  return (
    <MainLayout>
      <Row className="pavilion-box ass-style">
        <Col span={24}>
          <div>
            {/*<Breadcrumb items={breadcrumbItem} />*/}
            <h1 style={{ textAlign: "center" }}>Test ma'lumotlari</h1>
          </div>
        </Col>
        <Col span={24} className="add-pavilion-box">
          <List bordered>
            <List.Item>
              <span style={{ fontWeight: "bold" }}>Manzil: </span>
              {dataItem?.session?.pavilion && locale
                ? dataItem?.session?.pavilion[
                    propertyReturn(locale, "address") as keyof PavilionDataType
                  ]
                : ""}
            </List.Item>
            <List.Item>
              <span style={{ fontWeight: "bold" }}>Ilova yaratilgan sana: </span>
              {/*{dataItem?.createdDate}*/}
              {dataItem?.createdDate ? dateFormatLong(dataItem.createdDate) : ""}
            </List.Item>
            <List.Item>
              <span style={{ fontWeight: "bold" }}>Turi: </span>
              {dataItem?.session?.examType === "EXAM" ? "Test" : "Qayta topshirish"}
            </List.Item>
            <List.Item>
              <div>
                <span style={{ fontWeight: "bold" }}>To'lov miqdori: </span>
                <span className="payment-type">{dataItem?.session?.cost}</span>
              </div>
            </List.Item>
            <List.Item>
              <span style={{ fontWeight: "bold" }}>Tolash muddati: </span>
              {dataItem?.paymentTermDate ? dateFormatLong(dataItem.paymentTermDate) : ""}
            </List.Item>
            <List.Item>
              <div>
                <span style={{ fontWeight: "bold" }}>Holat: </span>
                <Button
                  color={dataItem?.paymentStatus === "PAID" ? "primary" : "danger"}
                  variant="outlined"
                  className="ml-2"
                >
                  {dataItem?.paymentStatus === "OUT_OF_TERM_DATE" && "Muddati tugagan"}
                  {dataItem?.paymentStatus === "UNPAID" && "To'lanmagan"}
                  {dataItem?.paymentStatus === "PAID" && "To'langan"}
                </Button>
              </div>
            </List.Item>
            <List.Item>
              <span style={{ fontWeight: "bold" }}>Imtihon turi: </span>

              {dataItem?.session?.testType && locale
                ? dataItem?.session?.testType[propertyReturn(locale, "title") as keyof UniversalDTO]
                : ""}
            </List.Item>
            <List.Item>
              <span style={{ fontWeight: "bold" }}>Imtihon boshlanish vaqti: </span>
              {dataItem?.session?.startDate ? dateFormatLong(dataItem?.session?.startDate) : ""}
            </List.Item>
          </List>
        </Col>
      </Row>
    </MainLayout>
  );
}
