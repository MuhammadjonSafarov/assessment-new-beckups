import { Rule } from "antd/es/form";

// validationRules.js
import useTranslation from "next-translate/useTranslation";

export const useUserNameRules = () => {
  const { t } = useTranslation();

  return [
    { required: true, message: t("validation:loginUserNameRequired") },
    { min: 4, message: t("validation:loginUserNameMinLength") },
  ];
};
export const useUserPasswordRules = () => {
  const { t } = useTranslation();

  return [
    { required: true, message: t("validation:loginPasswordRequired") },
    { min: 6, message: t("validation:loginPasswordMinLength") },
  ];
};

export const cannotEmptyRules = () => {
  const { t } = useTranslation();
  return [{ required: true, message: t("validation:notEmpty") }];
};
export const phoneLengthRules = () => {
  const { t } = useTranslation();
  return [
    { required: true, message: t("validation:number") },
    { min: 9, max: 9, message: t(`validation:phone`) },
  ];
};
export const emptyEmailRules = (): Rule[] => {
  // const { t } = useTranslation();
  return [
    { required: true, message: "Iltimos, email manzilini kiriting!" },
    { type: "email", message: "To'g'ri email manzilini kiriting!" },
  ];
};
export const passportNumberRules = () => {
  // const { t } = useTranslation();
  return [
    { required: true, message: "Passport raqamini kiriting!" },
    { min: 14, max: 14, message: "14 ta raqamdan iborat bo'lishi kerak!" },
  ];
};
export const getPassportSerial = (): Rule[] => [
  {
    required: true,
    message: "Qiymatni kiriting!",
  },
  {
    pattern: /^[A-Z]{2}\d{7}$/,
    message: "Qiymat to'g'ri formatda bo'lishi kerak (AB1234567).",
  },
];

// export const getPassportSerial = (): Rule[] => [
//   {
//     required: true,
//     message: "Qiymatni kiriting!",
//   },
//   {
//     validator: (_, value) => {
//       const pattern = /^[A-Z]{2}\d{7}$/; // 2 harf + 7 raqam
//       if (!value || pattern.test(value)) {
//         return Promise.resolve();
//       }
//       return Promise.reject(new Error("Qiymat to'g'ri formatda bo'lishi kerak (AB1234567)."));
//     },
//   },
// ];

// export const confirmPasswordCheck = (password: string, confirmPassword: string) => {
//   const { t } = useTranslation();
//   return [{ required: true, message: t("validation:notEmpty") }];
// };
