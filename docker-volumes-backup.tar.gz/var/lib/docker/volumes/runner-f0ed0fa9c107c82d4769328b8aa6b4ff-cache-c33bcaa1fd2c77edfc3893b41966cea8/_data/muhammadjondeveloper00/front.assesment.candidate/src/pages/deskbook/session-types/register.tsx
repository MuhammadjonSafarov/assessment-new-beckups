import { Col, Row, Flex, Form, Select, Button } from "antd";
import MainLayout from "@/components/layout/MainLayout";
import React, { useEffect, useRef, useState } from "react";
import { useRouter } from "next/router";
import { axiosServer } from "@/plugins/axiosServer";
import { useAppSelector } from "@/hooks/hooks";

import useTranslation from "next-translate/useTranslation";

import { cannotEmptyRules } from "@/helpers/validationRules";
import { toast } from "react-toastify";

export default function TestRegister() {
  const { Option } = Select;
  const [form] = Form.useForm();
  const [formBtnLoading, setFormBtnLoading] = useState(false);

  const router = useRouter();
  const oneTestItem = useRef<any>();
  const cannotEmpty = cannotEmptyRules();

  const [testPavilionList, setTestPavilionList] = useState([]);
  const [testSessionList, setTestSessionList] = useState([]);

  const { t } = useTranslation("lang");
  const [initialValuesItem, setIsInitialValues] = useState<any>({ isRent: false });

  const userInfo = useAppSelector((state) => state.user); // hooks/hooks.ts qo'shilgandan keyin shundoq ishlatsa buladi

  // Define the function to load pavilion data

  const loadTestPavilion = async (id: any) => {
    if (!id) return;
    await axiosServer(router.locale, true, userInfo?.token)
      .get(`/api/v1/pavilion/test-type/${id}/EXAM`)
      .then((res: any) => {
        setTestPavilionList(res?.data || []); // Update the state with the fetched data
      })
      .catch(() => {
        setTestPavilionList([]);
      });
  };
  const loadTestSession = async (id: any) => {
    if (!id) return;
    await axiosServer(router.locale, true, userInfo?.token)
      .get(`/api/v1/session/${oneTestItem.current.id}/${id}/EXAM`)
      .then((res: any) => {
        setTestSessionList(res?.data || []); // Update the state with the fetched data
      })
      .catch(() => {
        setTestSessionList([]);
      });
  };
  const pavilionChange = (id: number) => {
    setIsInitialValues({ sessionId: null });
    form.setFieldsValue({ sessionId: null });
    setIsInitialValues(id);
    if (!id) return;
    setTestSessionList([]);
    loadTestSession(id);
  };

  useEffect(() => {
    const query = router?.query; // 'name' va 'id' query parametrlari
    oneTestItem.current = query;
    if (query?.id) {
      loadTestPavilion(query?.id);
    }
  }, [router.isReady]);

  const onFinish = async (values: any) => {
    setFormBtnLoading(true);
    const data = { sessionId: values?.sessionId, userId: userInfo?.id };
    if (data.sessionId && data?.userId) {
      await axiosServer(router.locale, true, userInfo?.token)
        .post(`/api/v1/user-application`, data)
        .then((response) => {
          setFormBtnLoading(false);
          setIsInitialValues({ pavilionId: null, sessionId: null });
          form.setFieldsValue({ pavilionId: null, sessionId: null });
          // setTestSessionList(res?.data?.list || []); // Update the state with the fetched data
          toast.success(`${t("toast.successfully")}`);
          // console.log(111111, response.data.id);
          if (response?.data?.id) {
            router.push(`/payments/${response.data.id}`);
          }
        })
        .catch(() => {
          setFormBtnLoading(false);
        });
    }
  };

  return (
    <MainLayout>
      <Row className="pavilion-box">
        <Col span={24}>
          <div>{/*<Breadcrumb items={breadcrumbItem} />*/}</div>
          <div>Imtihonga roʻyxatdan oʻtish</div>
        </Col>
        <Col span={24}>
          {oneTestItem?.current?.name && oneTestItem?.current?.id && (
            <Row className="mt-4">
              <Col span={24}>
                <h1 className="text-center">{oneTestItem?.current?.name}</h1>
                <Row>
                  <Form
                    onFinish={onFinish}
                    initialValues={initialValuesItem}
                    form={form}
                    layout="vertical"
                    name="pavilion"
                    style={{ width: "100%", marginTop: "20px" }}
                    autoComplete="off"
                  >
                    <Row style={{ display: "flex", justifyContent: "center" }}>
                      <Col xs={24} sm={12} md={12} lg={12} xl={12}>
                        <Row>
                          <Col span={24} className="pavilion-input">
                            <Form.Item
                              name="pavilionId"
                              label="Imtihon bo'lish joyini tanlang"
                              rules={cannotEmpty}
                            >
                              <Select showSearch allowClear onChange={pavilionChange}>
                                {testPavilionList?.length &&
                                  testPavilionList?.map((item: any, index: number) => (
                                    <Option key={index} value={item.id}>
                                      {item?.nameUz}
                                    </Option>
                                  ))}
                              </Select>
                            </Form.Item>
                          </Col>
                          <Col span={24} className="pavilion-input">
                            <Form.Item name="sessionId" label="Vaqtni tanlang" rules={cannotEmpty}>
                              <Select allowClear>
                                {testSessionList?.length &&
                                  testSessionList?.map((item: any, index: number) => (
                                    <Option key={index} value={item.id}>
                                      {item?.startDate}
                                    </Option>
                                  ))}
                              </Select>
                            </Form.Item>
                          </Col>
                          <Flex className="w-full" justify={"center"}>
                            <Button
                              key="create"
                              className={"base-bg color-white"}
                              htmlType="submit"
                              loading={formBtnLoading}
                            >
                              Ro'yxatdan o'tishni tasdiqlang
                            </Button>
                          </Flex>
                        </Row>
                      </Col>
                    </Row>
                  </Form>
                </Row>
              </Col>
            </Row>
          )}
        </Col>
      </Row>
    </MainLayout>
  );
}
