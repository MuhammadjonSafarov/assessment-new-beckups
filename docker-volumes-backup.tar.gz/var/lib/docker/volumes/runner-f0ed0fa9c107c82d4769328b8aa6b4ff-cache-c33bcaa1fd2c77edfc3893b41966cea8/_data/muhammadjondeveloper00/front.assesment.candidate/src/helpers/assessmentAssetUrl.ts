/**
 * Statik fayllar (PDF, rasm) api.assessment.uz da CORS yo'q bo'lsa, brauzer fetch bloklanadi.
 * react-pdf shu sababli ishlamaydi. Next.js rewrite orqali bir xil origin dan yuklash.
 */
export function assessmentFileProxyUrl(apiRelativePath: string): string {
  if (!apiRelativePath || typeof apiRelativePath !== "string") return "";
  const normalized = apiRelativePath.startsWith("/") ? apiRelativePath : `/${apiRelativePath}`;
  const match = normalized.match(/^\/images\/(.+)$/);
  if (match) {
    return `/proxy-assessment-static/images/${match[1]}`;
  }
  return normalized;
}

/** Tashqi havola (masalan, yangi oynada ochish) */
export function assessmentFileAbsoluteUrl(apiRelativePath: string, baseUrl?: string): string {
  const base = (baseUrl || process.env.NEXT_PUBLIC_IMAGES_URL || "").replace(/\/$/, "");
  if (!base) return apiRelativePath;
  const path = apiRelativePath.startsWith("/") ? apiRelativePath : `/${apiRelativePath}`;
  return `${base}${path}`;
}
