import {
  MenuFoldOutlined,
  MenuUnfoldOutlined,
  UserOutlined,
  FileDoneOutlined,
  PlusSquareOutlined,
  RetweetOutlined,
  BookOutlined,
  AuditOutlined,
  PaperClipOutlined,
  CreditCardOutlined,
  SnippetsOutlined,
  SettingOutlined,
} from "@ant-design/icons";
import { Button, Flex, Image, Layout, Menu, theme } from "antd";
import { ReactNode, useEffect, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/router";
import LanguageSelect from "@/components/widgets/LanguageSelect";
import UserInfo from "@/components/widgets/UserInfo";
import { useAppDispatch, useAppSelector } from "@/hooks/hooks";
import { changeMenukey } from "@/reducers/counter";

const { Header, Sider, Content } = Layout;
interface Props {
  readonly children: ReactNode;
}
function MainLayout({ children }: Props) {
  const [collapsed, setCollapsed] = useState(false);
  const router = useRouter();
  const { locale } = router;
  const dispatch = useAppDispatch();
  const currentPath = router?.pathname || "";
  const menuKey = useAppSelector((state) => state?.counter?.menuKey);
  const userInfo = useAppSelector((state) => state.user);

  // console.log(32432432, menuKey);
  const menuItems = [
    {
      key: "/personal",
      icon: <UserOutlined />,
      label: (
        <Link href="/personal" locale={locale}>
          Shaxsiy ma'lumotlar
        </Link>
      ),
    },

    {
      key: "/deskbook",
      icon: <PlusSquareOutlined />,
      label: "Ro'yxatdan o'tish",
      children: [
        {
          key: "/deskbook/session-types",
          icon: <FileDoneOutlined />,
          label: (
            <Link href="/deskbook/session-types" locale={locale}>
              Testga ro'yxatdan o'tish
            </Link>
          ),
        },
        {
          key: "/deskbook/resubmission",
          icon: <FileDoneOutlined />,
          label: (
            <Link href="/deskbook/resubmission" locale={locale}>
              Testni qayta topshiring
            </Link>
          ),
        },
      ],
    },
    {
      key: "/certificate",
      icon: <RetweetOutlined />,
      label: "Qayta chiqarish",
      children: [
        {
          key: "/certificate/reissues",
          icon: <BookOutlined />,
          label: (
            <Link href="/certificate/reissues" locale={locale}>
              Sertifikatni qayta chiqarish
            </Link>
          ),
        },
      ],
    },
    {
      key: "/my-tests",
      icon: <AuditOutlined />,
      label: (
        <Link href="/my-tests" locale={locale}>
          Mening testlarim
        </Link>
      ),
    },
    {
      key: "/appeals",
      icon: <PaperClipOutlined />,
      label: (
        <Link href="/appeals" locale={locale}>
          Apellyatsiya
        </Link>
      ),
    },
    {
      key: "/payments",
      icon: <CreditCardOutlined />,
      label: (
        <Link href="/payments" locale={locale}>
          To'lovlar
        </Link>
      ),
    },
    {
      key: "/offert",
      icon: <SnippetsOutlined />,
      label: (
        <Link href="/offert" locale={locale}>
          Oferta
        </Link>
      ),
    },
    {
      key: "/settings",
      icon: <SettingOutlined />,
      label: (
        <Link href="/settings" locale={locale}>
          Sozlamalar
        </Link>
      ),
    },
  ];
  const {
    token: { colorBgContainer, borderRadiusLG },
  } = theme.useToken();
  // const openMenyu = () => {
  //   const pathSegments = currentPath.split("/").filter(Boolean);
  //   console.log("PPPPPP", pathSegments);
  //   if (pathSegments.length >= 1) {
  //     setOpenKeys([`/${pathSegments[0]}`]);
  //   } else {
  //     // setOpenKeys([]);
  //   }
  // };
  useEffect(() => {
    // const pathSegments = currentPath.split("/").filter(Boolean);/
    const pathSegments = currentPath
      .split("/")
      .filter(Boolean)
      .map((segment) => `/${segment}`);
    // console.log("Efecct", pathSegments);
    dispatch(changeMenukey(pathSegments));
    // if (pathSegments.length === 1) {
    //   dispatch(changeMenukey([`/${pathSegments[0]}`]));
    // } else if (pathSegments.length === 2) {
    //   dispatch(changeMenukey([`/${pathSegments[0]}`, `/${pathSegments[1]}`]));
    // } else if (pathSegments.length === 3) {
    //   dispatch(
    //     changeMenukey([`/${pathSegments[0]}`, `/${pathSegments[1]}`, `/${pathSegments[2]}`]),
    //   );
    // }
  }, []);
  const handleOpenChange = (keys: string[]) => {
    // console.log("keys", keys);
    dispatch(changeMenukey(keys));
    // if (keys.length === 1) {
    //   dispatch(changeMenukey([keys[0]]));
    // } else if (keys.length === 2) {
    //   dispatch(changeMenukey([keys[0], keys[1]]));
    // } else if (keys.length === 3) {
    //   dispatch(changeMenukey([keys[0], keys[1], keys[2]]));
    // }

    // setOpenKeys(keys);
  };

  useEffect(() => {
    if (!userInfo?.token) {
      router.push("/login"); // Agar token yo'q bo'lsa, foydalanuvchini login sahifasiga yo'naltirish
    }
  }, [router]);
  const onBreakpoint = (broken: boolean) => {
    setCollapsed(broken);
  };
  return (
    <Layout className="main-layout">
      <Sider
        trigger={null}
        className={!collapsed ? "big-layout-slider" : ""}
        collapsible
        collapsed={collapsed}
        onBreakpoint={onBreakpoint} // onBreakpoint yordamida collapsed boshqarish
        breakpoint="md"
      >
        <div className="demo-logo-vertical" />
        <div className="main-logo-box">
          <Image
            src="/images/Logo.svg"
            height={64}
            width="100%"
            alt="empty"
            className="main-logo"
            preview={false}
          />
        </div>
        <Menu
          className="menu-box"
          items={menuItems}
          theme="dark"
          mode="inline"
          defaultSelectedKeys={["1"]}
          selectedKeys={[currentPath]} // selectedKeys xususiyati
          openKeys={menuKey} // openKeys xususiyati
          onOpenChange={handleOpenChange}
        />
      </Sider>
      <Layout className="base-content-box">
        <Header style={{ padding: 0, background: colorBgContainer }}>
          <Flex justify={"space-between"} align={"center"}>
            <Button
              type="text"
              icon={collapsed ? <MenuUnfoldOutlined /> : <MenuFoldOutlined />}
              onClick={() => setCollapsed(!collapsed)}
              style={{
                fontSize: "16px",
                width: 68,
                height: 64,
              }}
            />
            <Flex align="center" className="user-dropdown-box">
              <LanguageSelect />
              <Flex className="user-dropdown" align="center">
                <UserInfo />
              </Flex>
            </Flex>
          </Flex>
        </Header>
        <Content>
          <div
            className="main-content-box"
            style={{
              margin: "24px 16px",
              padding: 24,
              background: colorBgContainer,
              borderRadius: borderRadiusLG,
            }}
          >
            {children}
          </div>
        </Content>
      </Layout>
    </Layout>
  );
}
export default MainLayout;
