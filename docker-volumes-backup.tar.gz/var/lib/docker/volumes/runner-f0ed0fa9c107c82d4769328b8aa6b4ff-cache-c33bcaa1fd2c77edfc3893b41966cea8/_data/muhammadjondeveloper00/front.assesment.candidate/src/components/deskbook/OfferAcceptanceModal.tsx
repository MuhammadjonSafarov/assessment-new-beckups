import { Modal, Checkbox, Button, Flex, Spin, Typography } from "antd";
import { Document, Page, pdfjs } from "react-pdf";
import "react-pdf/dist/Page/AnnotationLayer.css";
import "react-pdf/dist/Page/TextLayer.css";
import React, { useCallback, useEffect, useLayoutEffect, useRef, useState } from "react";

if (typeof window !== "undefined") {
  pdfjs.GlobalWorkerOptions.workerSrc = `https://unpkg.com/pdfjs-dist@${pdfjs.version}/build/pdf.worker.min.mjs`;
}

type OfferAcceptanceModalProps = {
  open: boolean;
  pdfUrl: string;
  onClose: () => void;
  onConfirm: () => void;
};

const SCROLL_END_THRESHOLD = 48;

export default function OfferAcceptanceModal({
  open,
  pdfUrl,
  onClose,
  onConfirm,
}: OfferAcceptanceModalProps) {
  const scrollRef = useRef<HTMLDivElement>(null);
  const [numPages, setNumPages] = useState<number | null>(null);
  const [scrolledToEnd, setScrolledToEnd] = useState(false);
  const [agreed, setAgreed] = useState(false);
  const [loadError, setLoadError] = useState(false);
  const [pageWidth, setPageWidth] = useState(640);
  const [modalWidth, setModalWidth] = useState(900);

  const checkScrollEnd = useCallback(() => {
    const el = scrollRef.current;
    if (!el) return;
    const { scrollTop, scrollHeight, clientHeight } = el;
    if (scrollHeight <= clientHeight + SCROLL_END_THRESHOLD) {
      setScrolledToEnd(true);
      return;
    }
    setScrolledToEnd(scrollTop + clientHeight >= scrollHeight - SCROLL_END_THRESHOLD);
  }, []);

  useEffect(() => {
    const measure = () => {
      if (typeof window === "undefined") return;
      setPageWidth(Math.min(720, Math.max(280, window.innerWidth - 80)));
      setModalWidth(Math.min(900, window.innerWidth - 32));
    };
    measure();
    window.addEventListener("resize", measure);
    return () => window.removeEventListener("resize", measure);
  }, []);

  useEffect(() => {
    if (open) {
      setScrolledToEnd(false);
      setAgreed(false);
      setNumPages(null);
      setLoadError(false);
    }
  }, [open, pdfUrl]);

  useEffect(() => {
    if (loadError) setScrolledToEnd(true);
  }, [loadError]);

  useLayoutEffect(() => {
    if (!open || !numPages) return;
    const id = requestAnimationFrame(() => {
      requestAnimationFrame(() => checkScrollEnd());
    });
    return () => cancelAnimationFrame(id);
  }, [open, numPages, checkScrollEnd]);

  const handleConfirm = () => {
    if (!agreed) return;
    onConfirm();
    onClose();
  };

  return (
    <Modal
      title="Oferta"
      open={open}
      onCancel={onClose}
      width={modalWidth}
      footer={null}
      destroyOnClose
      centered
    >
      {loadError ? (
        <Typography.Paragraph>
          PDF yuklanmadi.{" "}
          <Typography.Link href={pdfUrl} target="_blank" rel="noopener noreferrer">
            Yangi oynada ochish
          </Typography.Link>
        </Typography.Paragraph>
      ) : (
        <>
          <div
            ref={scrollRef}
            onScroll={checkScrollEnd}
            style={{
              maxHeight: "min(60vh, 520px)",
              overflowY: "auto",
              border: "1px solid #f0f0f0",
              borderRadius: 8,
              marginBottom: 16,
            }}
          >
            <Document
              file={pdfUrl}
              loading={
                <Flex justify="center" align="center" style={{ minHeight: 200 }}>
                  <Spin size="large" />
                </Flex>
              }
              onLoadSuccess={({ numPages: n }) => setNumPages(n)}
              onLoadError={() => {
                setLoadError(true);
                setNumPages(null);
              }}
            >
              {numPages
                ? Array.from({ length: numPages }, (_, i) => (
                    <Page
                      key={i + 1}
                      pageNumber={i + 1}
                      width={pageWidth}
                      onRenderSuccess={() => {
                        if (i + 1 === numPages) {
                          requestAnimationFrame(() => checkScrollEnd());
                        }
                      }}
                    />
                  ))
                : null}
            </Document>
          </div>
          <Flex vertical gap={12}>
            <Checkbox
              disabled={!scrolledToEnd}
              checked={agreed}
              onChange={(e) => setAgreed(e.target.checked)}
            >
              Shartlarga roziman
            </Checkbox>
            <Flex gap={8} justify="flex-end">
              <Button onClick={onClose}>Bekor qilish</Button>
              <Button type="primary" disabled={!agreed} onClick={handleConfirm}>
                Tasdiqlash
              </Button>
            </Flex>
          </Flex>
        </>
      )}
    </Modal>
  );
}
