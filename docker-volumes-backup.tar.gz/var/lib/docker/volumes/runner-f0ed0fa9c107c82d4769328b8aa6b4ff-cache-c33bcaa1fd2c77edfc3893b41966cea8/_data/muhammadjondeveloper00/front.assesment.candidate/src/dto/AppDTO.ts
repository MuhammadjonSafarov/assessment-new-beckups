export interface UniversalDTO {
  id: number;
  titleUz: string;
  titleRu: string;
  titleEn: string;
}

export interface PavilionDataType {
  id: number;
  nameUz: string;
  nameRu: string;
  addressUz: string;
  addressRu: string;
  isRent: boolean;
  status: string;
}
export interface SessionDataType {
  id: number;
  titleUz: string;
  titleRu: string;
  titleEn: string;
  partnerUz: string;
  partnerRu: string;
  partnerEn: string;
  isInOurPlatform: boolean;
  defaultPaymentAmount: number | null;
  isThereAnyOtherPavilion: boolean;
  otherPavilionPaymentAmount: number | null;
  examRunType: string;
  status: string;
  retakeAmount: number | null;
  isRetakeAvailable: boolean;
  reissueAmount: number | null;
  phone: string;
  telegram: string;
  maxCandidates: number | null;
  resultOptions: [];
  testType?: UniversalDTO;
}
export interface PermissionType {
  id: number;
  name: string;
  type: string;
}
export interface RoleType {
  id: number;
  name: string;
  description: string;
  isGetAllPermissions: boolean;
  roleType: string;
  permissionIds: [];
}
export interface OperatorType {
  id: number;
  username: string;
  status: string;
  firstName: string;
  lastName: string;
  middleName: string;
  phone: string;
  roles: [];
  pavilions: [];
  testTypes: [];
  lastActiveDate: string;
  createdDate: string;
}

export interface PaymentType {
  id: number;
  createdDate: string;
  paymentStatus: string;
  paymentTermDate: string;
  session: PaymentSessionType;
  tempSessionId: number;
}
export interface PaymentType {
  id: number;
  createdDate: string;
  paymentStatus: string;
  paymentTermDate: string;
  session: PaymentSessionType;
  tempSessionId: number;
}

export interface PaymentSessionType {
  id: number;
  cost: number;
  examType: string;
  startDate: string;
  pavilion: PavilionDataType;
  testType: SessionDataType;
}
export interface fileDto {
  id: number;
  name?: string;
  size?: number;
  url: string;
}
