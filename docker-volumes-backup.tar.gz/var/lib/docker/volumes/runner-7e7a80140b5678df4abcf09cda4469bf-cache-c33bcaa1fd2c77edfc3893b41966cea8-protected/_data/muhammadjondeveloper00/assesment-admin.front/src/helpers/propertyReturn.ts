export const propertyReturn = (locale: string, propert: string) => {
  switch (propert) {
    case "name":
      return locale === "uz" ? "nameUz" : locale === "ru" ? "nameRu" : "nameEn";
    case "address":
      return locale === "uz" ? "addressUz" : locale === "ru" ? "addressRu" : "addressEn";
    case "title":
      return locale === "uz" ? "titleUz" : locale === "ru" ? "titleRu" : "titleEn";
    case "partner":
      return locale === "uz" ? "partnerUz" : locale === "ru" ? "partnerRu" : "partnerEn";
  }
};
