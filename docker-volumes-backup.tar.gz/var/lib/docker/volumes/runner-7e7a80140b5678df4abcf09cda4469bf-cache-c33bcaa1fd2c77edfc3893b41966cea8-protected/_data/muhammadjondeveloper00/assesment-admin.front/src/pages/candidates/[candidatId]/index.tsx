import { Col, Row, Breadcrumb, Flex, Typography, Tabs, Card, Dropdown, Space, Image } from "antd";
import MainLayout from "@/components/layout/MainLayout";
import React, { useCallback, useEffect, useState } from "react";
import { useRouter } from "next/router";
import { axiosServer } from "@/plugins/axiosServer";
import { useAppSelector } from "@/hooks/hooks";
import type { TabsProps } from "antd";
import {
  ArrowLeftOutlined,
  UserOutlined,
  HomeOutlined,
  // SafetyCertificateOutlined,
  // HistoryOutlined,
  // WalletOutlined,
  // InboxOutlined,
  DownOutlined,
} from "@ant-design/icons";
// import useTranslation from "next-translate/useTranslation";
import type { MenuProps } from "antd";
import FileUpload from "@/components/widgets/FileUpload";
import { dateFormatLong, formatPhoneNumber } from "@/helpers/typeChange";
import useTranslation from "next-translate/useTranslation";
export default function CandidatesPage() {
  const { Title } = Typography;
  const router = useRouter();
  const { locale } = router;
  const { t } = useTranslation("lang");
  // const { t } = useTranslation("lang");
  const [dataItem, setDataItem] = useState<any>();
  // console.log(666666, filter.current);
  const { Paragraph } = Typography;
  const pasportChange = (act: any) => {
    if (act.status) {
      loadData();
    }
  };
  const userInfo = useAppSelector((state) => state.user); // hooks/hooks.ts qo'shilgandan keyin shundoq ishlatsa buladi
  const breadcrumbItem = [
    {
      href: `/${locale}`,
      title: <HomeOutlined />,
    },
    {
      href: "",
      title: `${t("candidates.list")}`,
    },
    {
      title: `${t("table.body.info")}`,
    },
  ];
  const itemsFirst: MenuProps["items"] = [
    {
      key: "1",
      label: (
        <div>
          <FileUpload type="pasport" handlechange={pasportChange} />
        </div>
      ),
    },
  ];
  const itemsSecond: MenuProps["items"] = [
    {
      key: "1",
      label: (
        <div>
          <FileUpload type="selfi" handlechange={pasportChange} />
        </div>
      ),
    },
  ];
  const itemsThree: MenuProps["items"] = [
    // {
    //   key: "1",
    //   label: <div className="bold-red">Bloklash</div>,
    // },
    // {
    //   key: "2",
    //   label: <div className="bold-red">Telefon raqamini o'zgartirish</div>,
    // },
  ];
  const loadData = useCallback(async () => {
    // console.log(88888, filter?.current);
    // const lastUrl = filter?.current || "ALL";
    const userId = router?.query?.candidatId || null;
    if (!userId) return;
    await axiosServer(router.locale, true, userInfo?.token)
      .get(`/api/v1/user/${userId}`)
      .then((res: any) => {
        setDataItem(res?.data || {}); // Update the state with the fetched data
      })
      .catch(() => {
        // console.log("error")
      });
  }, [router.locale]);
  useEffect(() => {
    loadData();
  }, [router.locale]);

  // Handle pagination changes

  const onChange = (key: string) => {
    // console.log(`Selected Tab: ${key}`);
    return key;
  };
  const items: TabsProps["items"] = [
    {
      key: "1",
      label: (
        <span>
          <UserOutlined className="mr-3" />
          {t("personalInfo")}
        </span>
      ),
      children: (
        <Row>
          <Col span={14}>
            <Row>
              <Col span={12}>
                <Card
                  title={`${t("operators.pasport")}`}
                  extra={
                    <Dropdown menu={{ items: itemsFirst }}>
                      <a onClick={(e) => e.preventDefault()}>
                        <Space>
                          {t("table.header.actions")}
                          <DownOutlined />
                        </Space>
                      </a>
                    </Dropdown>
                  }
                  style={{ width: 300 }}
                  cover={
                    dataItem?.passportFile?.url ? (
                      <Image
                        style={{ padding: "8px" }}
                        src={`${process.env.NEXT_PUBLIC_IMAGES_URL}/${dataItem?.passportFile?.url}`}
                        alt="empty"
                        preview
                      />
                    ) : (
                      <Image
                        style={{ padding: "8px" }}
                        src="/images/no-image.jpg"
                        alt="empty"
                        preview
                      />
                    )
                  }
                ></Card>
              </Col>
              <Col span={12}>
                <Card
                  title={`${t("selfi")}`}
                  extra={
                    <Dropdown menu={{ items: itemsSecond }}>
                      <a onClick={(e) => e.preventDefault()}>
                        <Space>
                          {t("table.header.actions")}
                          <DownOutlined />
                        </Space>
                      </a>
                    </Dropdown>
                  }
                  style={{ width: 300 }}
                  cover={
                    dataItem?.file?.url ? (
                      <Image
                        style={{ padding: "8px" }}
                        src={`${process.env.NEXT_PUBLIC_IMAGES_URL}/${dataItem?.file?.url}`}
                        alt="empty"
                        preview
                      />
                    ) : (
                      <Image
                        style={{ padding: "8px" }}
                        src="/images/no-image.jpg"
                        alt="empty"
                        preview
                      />
                    )
                  }
                ></Card>
              </Col>
            </Row>
          </Col>
          <Col span={10}>
            <Card
              title={`${t("personalInfo")}`}
              extra={
                <Dropdown menu={{ items: itemsThree }}>
                  <a onClick={(e) => e.preventDefault()}>
                    <Space>
                      {t("table.header.actions")}
                      <DownOutlined />
                    </Space>
                  </a>
                </Dropdown>
              }
              style={{ minWidth: 300 }}
            >
              <div>
                <span style={{ color: "gray" }}> {t("operators.name")}</span>
                <h3>{dataItem?.firstName}</h3>
              </div>
              <div>
                <span style={{ color: "gray" }}>{t("operators.surname")}</span>
                <h3>{dataItem?.lastName}</h3>
              </div>
              {dataItem?.middleName && (
                <div>
                  <span style={{ color: "gray" }}>{t("operators.middleName")}</span>
                  <h3>{dataItem?.middleName}</h3>
                </div>
              )}
              {dataItem?.userMyIdData?.profile?.common_data?.pinfl && (
                <div>
                  <span style={{ color: "gray" }}>{t("pnfl")}</span>
                  <h3>
                    <Paragraph copyable>
                      {dataItem?.userMyIdData?.profile?.common_data?.pinfl}
                    </Paragraph>
                  </h3>
                </div>
              )}

              <div>
                <span style={{ color: "gray" }}>{t("operators.phone")}</span>
                <h3>
                  <Paragraph copyable>{formatPhoneNumber(dataItem?.phone)}</Paragraph>
                </h3>
              </div>
              {dataItem?.userMyIdData?.profile?.doc_data?.pass_data && (
                <div>
                  <span style={{ color: "gray" }}>{t("operators.pasport")}</span>
                  <h3>
                    <Paragraph copyable>
                      {dataItem?.userMyIdData?.profile?.doc_data?.pass_data}
                    </Paragraph>
                  </h3>
                </div>
              )}
              {dataItem?.userMyIdData?.profile?.common_data?.birth_date && (
                <div>
                  <span style={{ color: "gray" }}>{t("birthDay")}</span>
                  <h3>{dataItem?.userMyIdData?.profile?.common_data?.birth_date}</h3>
                </div>
              )}
              {dataItem?.userMyIdData?.profile?.address?.permanent_registration?.region && (
                <div>
                  <span style={{ color: "gray" }}>{t("address")}</span>
                  <h3>
                    {dataItem?.userMyIdData?.profile?.address?.permanent_registration?.region}{" "}
                    {", "}
                    {dataItem?.userMyIdData?.profile?.address?.permanent_registration?.district}
                  </h3>
                </div>
              )}

              <div>
                <span style={{ color: "gray" }}>{t("registrationDate")}</span>
                <h3>{dateFormatLong(dataItem?.createdDate)}</h3>
              </div>
            </Card>
          </Col>
        </Row>
      ),
    },
    // {
    //   key: "2",
    //   label: (
    //     <span>
    //       <SafetyCertificateOutlined className="mr-3" /> {t("sertificates")}
    //     </span>
    //   ),
    //   children: "Content of Tab Pane 2",
    // },
    // {
    //   key: "3",
    //   label: (
    //     <span>
    //       <HistoryOutlined className="mr-3" />
    //       {t("session")}
    //     </span>
    //   ),
    //   children: "Content of Tab Pane 3",
    // },
    // {
    //   key: "4",
    //   label: (
    //     <span>
    //       <WalletOutlined className="mr-3" />
    //       To'lovlari
    //     </span>
    //   ),
    //   children: "Content of Tab Pane 4",
    // },
    // {
    //   key: "5",
    //   label: (
    //     <span>
    //       <InboxOutlined className="mr-3" />
    //       Apellyatsiyalar
    //     </span>
    //   ),
    //   children: "Content of Tab Pane 5",
    // },
    // {
    //   key: "6",
    //   label: (
    //     <span>
    //       <HistoryOutlined className="mr-3" />
    //       Bloklash tarixi
    //     </span>
    //   ),
    //   children: "Content of Tab Pane 6",
    // },
  ];
  const redirectPage = () => {
    router.push(`/candidates`);
  };
  return (
    <MainLayout>
      <Row className="pavilion-box ass-style">
        <Col span={24}>
          <div>
            <Breadcrumb items={breadcrumbItem} />
          </div>
        </Col>
        <Col span={24} className="add-pavilion-box">
          <Flex justify={"space-between"}>
            <div>
              <Flex align={"center"}>
                <ArrowLeftOutlined
                  onClick={redirectPage}
                  style={{ marginRight: "16px", fontSize: "16px", cursor: "pointer" }}
                />
                <Title level={4} className="m-0">
                  {t("fullInfo")}
                </Title>
              </Flex>
            </div>
          </Flex>
        </Col>
      </Row>
      <Row>
        <Col span={24}>
          <Tabs type="card" items={items} onChange={onChange} />
        </Col>
      </Row>
    </MainLayout>
  );
}
