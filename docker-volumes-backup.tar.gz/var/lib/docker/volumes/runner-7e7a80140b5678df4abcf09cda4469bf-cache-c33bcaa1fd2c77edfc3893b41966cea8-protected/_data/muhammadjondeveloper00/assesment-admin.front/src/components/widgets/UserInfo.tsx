import { useRouter } from "next/router";
import { Image, Dropdown, Button, Flex, Typography, Row, Col, Modal } from "antd";
import { LoginOutlined, QuestionCircleOutlined, SettingOutlined } from "@ant-design/icons";
import { useAppDispatch, useAppSelector } from "@/hooks/hooks";
import { clearUserInfo } from "@/reducers/user";
import { persistor } from "@/store/store";
import useTranslation from "next-translate/useTranslation";
export default function LanguageSelect() {
  const userInfo = useAppSelector((state) => state.user);
  const router = useRouter();
  const { t } = useTranslation("lang");
  const [modal, contextHolder] = Modal.useModal();
  const dispatch = useAppDispatch();
  const { Text } = Typography;

  const redirectUserPage = () => {
    router
      .push(`/personal`)
      .then(() => "")
      .catch(() => "");
  };
  const confirmModal = () => {
    modal.confirm({
      title: "",
      icon: <QuestionCircleOutlined style={{ marginTop: "10px" }} />,
      content: <h3>{t("logout")}</h3>,
      okText: t("form.yes"),
      cancelText: t("form.no"),
      onOk() {
        userLogout();
      },
      onCancel() {
        // console.log("Cancel");
      },
      okButtonProps: {
        style: {
          backgroundColor: "#ff4d4f",
          color: "white",
          border: "none",
        },
      },
    });
  };
  const userLogout = () => {
    dispatch(clearUserInfo());
    persistor.purge();
    router.push("/login");
  };
  const items = [
    {
      key: "userInfo",
      label: (
        <Flex
          onClick={redirectUserPage}
          justify={"space-between"}
          className="language-logo"
          align={"center"}
        >
          <SettingOutlined style={{ color: "#5893DB" }} />
          <Text style={{ color: "#5893DB" }} className="ml-2">
            Shaxsiy ma'lumotlar
          </Text>
        </Flex>
      ),
    },
    {
      key: "userLogout",
      label: (
        <Flex
          onClick={confirmModal}
          justify={"space-between"}
          className="language-logo user-logout"
          align={"center"}
        >
          <LoginOutlined style={{ color: "red" }} />
          <Text style={{ color: "red" }} className="ml-2">
            Chiqish
          </Text>
        </Flex>
      ),
    },
  ];

  return (
    <>
      {/*trigger={["click"]} -> Visible when clicked */}
      <Dropdown menu={{ items }} className="language-log-box">
        <Button className="language-logo">
          <Image
            width={24}
            height={24}
            src="/images/avatar-default.png"
            alt="empty"
            preview={false}
          />
          {userInfo?.username}
        </Button>
      </Dropdown>
      <Row>
        <Col span={24}>{contextHolder}</Col>
      </Row>
    </>
  );
}
