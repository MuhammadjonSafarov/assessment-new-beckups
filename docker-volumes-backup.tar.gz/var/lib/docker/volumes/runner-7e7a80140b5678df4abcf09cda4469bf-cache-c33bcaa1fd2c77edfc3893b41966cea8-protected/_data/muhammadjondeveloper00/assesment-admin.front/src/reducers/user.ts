import { createSlice, PayloadAction } from "@reduxjs/toolkit";

interface UserData {
  id: number | null;
  token: string;
  username: string;
  role: (string | null)[];
  permissions: string[];
}
const initialState: UserData = {
  id: null,
  token: "",
  username: "",
  role: [],
  permissions: [],
};

const userSlice = createSlice({
  name: "user",
  initialState,
  reducers: {
    setUserInfo: (state, action: PayloadAction<UserData>) => {
      state.id = action?.payload?.id || null;
      state.token = action?.payload?.token || "";
      state.username = action?.payload?.username || "";
      state.role = action?.payload?.role || [];
      state.permissions = action?.payload?.permissions || [];
    },
    clearUserInfo: () => {
      return initialState;
    },
  },
});
export const { setUserInfo, clearUserInfo } = userSlice.actions;
export default userSlice.reducer;
