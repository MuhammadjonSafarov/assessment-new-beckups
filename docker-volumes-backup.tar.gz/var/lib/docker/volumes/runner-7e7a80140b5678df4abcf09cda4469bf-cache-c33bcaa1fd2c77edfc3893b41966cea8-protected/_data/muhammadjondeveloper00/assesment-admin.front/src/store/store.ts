import { configureStore } from "@reduxjs/toolkit";
import counterSlice from "../reducers/counter";
import userSlice from "../reducers/user";
import { persistStore, persistReducer } from "redux-persist";
import storage from "redux-persist/lib/storage";
import createNoopStorage from "@/utils/ReduxPersistUtil";
const storageType = typeof window !== "undefined" ? storage : createNoopStorage();

const persistConfig = {
  key: "root",
  storage: storageType,
};
// const persistedReducer = persistReducer(persistConfig, counterSlice);
const persistedReducerUser = persistReducer(persistConfig, userSlice);
export const store = configureStore({
  reducer: {
    counter: counterSlice,
    user: persistedReducerUser,
  },
  middleware: (getDefaultMiddleware) =>
    getDefaultMiddleware({
      serializableCheck: {
        ignoredActions: ["persist/PERSIST", "persist/REHYDRATE"],
      },
    }),
});

// Infer the `RootState` and `AppDispatch` types from the store itself
export type RootState = ReturnType<typeof store.getState>;
// Inferred type: {posts: PostsState, comments: CommentsState, users: UsersState}
export type AppDispatch = typeof store.dispatch;
export const persistor = persistStore(store);
