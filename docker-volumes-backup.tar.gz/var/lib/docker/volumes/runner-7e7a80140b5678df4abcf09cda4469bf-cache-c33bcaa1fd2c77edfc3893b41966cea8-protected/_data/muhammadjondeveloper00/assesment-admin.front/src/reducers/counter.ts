import { createSlice, PayloadAction } from "@reduxjs/toolkit";

interface counterState {
  menuKey: string[];
}
const initialState: counterState = {
  menuKey: [],
};
const counterSlice = createSlice({
  name: "counter",
  initialState,
  reducers: {
    changeMenukey: (state, action: PayloadAction<string[]>) => {
      state.menuKey = action.payload;
    },
  },
});
export const { changeMenukey } = counterSlice.actions;
export default counterSlice.reducer;
