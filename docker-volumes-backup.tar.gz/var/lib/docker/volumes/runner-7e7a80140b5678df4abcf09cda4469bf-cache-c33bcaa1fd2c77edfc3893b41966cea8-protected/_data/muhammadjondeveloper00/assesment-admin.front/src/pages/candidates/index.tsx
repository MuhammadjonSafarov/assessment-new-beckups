import {
  Col,
  Row,
  Breadcrumb,
  Flex,
  Typography,
  Button,
  Select,
  Table,
  ConfigProvider,
  Skeleton,
  Tag,
} from "antd";
import MainLayout from "@/components/layout/MainLayout";
import React, { useCallback, useEffect, useRef, useState } from "react";
import { useRouter } from "next/router";
import { axiosServer } from "@/plugins/axiosServer";
import { useAppSelector } from "@/hooks/hooks";

const { Column } = Table;
import {
  ArrowLeftOutlined,
  UserOutlined,
  HomeOutlined,
  UserSwitchOutlined,
  UserDeleteOutlined,
  TeamOutlined,
  CheckOutlined,
  CloseOutlined,
} from "@ant-design/icons";
import useTranslation from "next-translate/useTranslation";
import { UserDataType } from "@/dto/AppDTO";
import { dateFormat, formatPhoneNumber } from "@/helpers/typeChange";

export default function CandidatesPage() {
  const { Title } = Typography;
  const { Option } = Select;
  const router = useRouter();
  const { locale } = router;
  const { t } = useTranslation("lang");
  const [dataItem, setDataItem] = useState<UserDataType[]>([]);
  const [loading, setLoading] = useState(false);
  const [totalItem, setTotalItem] = useState(1);
  const filter = useRef<string | null>("ALL");

  // console.log(666666, filter.current);
  const [query, setquery] = useState({
    page: 0,
    limit: 10,
    search: {},
  });

  const userInfo = useAppSelector((state) => state.user); // hooks/hooks.ts qo'shilgandan keyin shundoq ishlatsa buladi
  const breadcrumbItem = [
    {
      href: `/${locale}`,
      title: <HomeOutlined />,
    },
    {
      href: "",
      title: `${t("candidates.list")}`,
    },
  ];

  // Define the function to load pavilion data
  const loadData = useCallback(async () => {
    setLoading(true);
    // console.log(88888, filter?.current);
    // const lastUrl = filter?.current || "ALL";
    await axiosServer(router.locale, false, userInfo?.token)
      .post(`/api/v1/user/list-search?isListNomzod=true`, query)
      .then((res: any) => {
        setLoading(false);
        setTotalItem(res?.data?.total || 1);
        setDataItem(res?.data?.list || []); // Update the state with the fetched data
      })
      .catch(() => {
        setDataItem([]);
        setLoading(false);
      });
  }, [router.locale, query]);
  useEffect(() => {
    loadData();
  }, [router.locale, query]);

  // Handle pagination changes
  const handlePaginationChange = (page: number, pageSize: number) => {
    const limintChange = page - 1 === query.page;
    setquery((prevQuery) => ({
      ...prevQuery,
      page: limintChange ? 0 : page - 1, // Update page to 5
      limit: pageSize, // Update limit to 3
    }));
  };

  // useCallback(async () => {}, [router.locale, filter]);
  const handleChange = (value: string) => {
    // console.log(44444444, value);
    filter.current = value;
    loadData();
  };
  const userDetail = async (id: number) => {
    if (!id) return;
    router.push(`/candidates/${id}`).catch(() => "");
  };
  return (
    <MainLayout>
      <Row className="pavilion-box ass-style">
        <Col span={24}>
          <div>
            <Breadcrumb items={breadcrumbItem} />
          </div>
        </Col>
        <Col span={24} className="add-pavilion-box">
          <Flex justify={"space-between"}>
            <div>
              <Flex align={"center"}>
                <ArrowLeftOutlined
                  style={{ marginRight: "16px", fontSize: "16px", cursor: "pointer" }}
                />
                <Title level={4} className="m-0">
                  {t("candidates.list")}
                </Title>
              </Flex>
              <div>
                <Select
                  value={filter?.current}
                  onChange={handleChange}
                  style={{ width: "276px", height: "40px", marginTop: "16px" }}
                  placeholder="Ruxsat turini tanlang"
                  suffixIcon={<UserSwitchOutlined />}
                  allowClear
                >
                  <Option value="ALL">
                    <TeamOutlined className="select-item-icon mr-1" /> {t("candidates.all")}
                  </Option>
                  <Option className="select-item-icon" value="BLOCK">
                    <UserDeleteOutlined className="select-item-icon mr-1" /> {t("candidates.block")}
                  </Option>
                </Select>
              </div>
            </div>
          </Flex>
        </Col>
      </Row>
      <Row>
        <Col span={24}>
          <ConfigProvider
            //@ts-ignore
            locale={{
              Pagination: {
                items_per_page: "/" + t("table.page"), // Sahifa hajmi matnini o'zgartirish
              },
            }}
          >
            <Table<UserDataType>
              className="ass-table"
              dataSource={loading ? [] : dataItem}
              rowKey={(record): React.Key => record.id}
              pagination={{
                current: query.page + 1,
                pageSize: query.limit,
                total: totalItem,
                onChange: handlePaginationChange,
                showSizeChanger: true,
                pageSizeOptions: ["10", "20", "50"], // Customize the available page sizes
              }}
              loading={loading}
              locale={{
                emptyText: loading ? <Skeleton active paragraph={{ rows: 5 }} /> : t("empty"),
              }}
            >
              <Column
                title={`${t("operators.fish")}`}
                key="fish"
                render={(item: UserDataType) => (
                  <span>
                    {item?.lastName || ""} {item?.firstName || ""} {item?.middleName || ""}
                  </span>
                )}
              />
              <Column
                title={`${t("operators.pasport")}`}
                key="pasport"
                render={(item: UserDataType) => (
                  <Tag style={{ fontSize: "14px", padding: "5px 10px" }} color="#0F8FB0">
                    {item?.passportSerial || ""}
                    {item?.passportNumber || ""}
                  </Tag>
                )}
              />
              <Column
                title={`${t("operators.phone")}`}
                dataIndex="phone"
                key="phone"
                render={(phone: string) => phone && formatPhoneNumber(phone)}
              />
              <Column
                title={`${t("table.header.createdDate")}`}
                dataIndex="createdDate"
                key="createdDate"
                render={(date: string) => (date?.length ? dateFormat(date) : "")}
              />
              <Column
                title={`${t("table.body.active")}`}
                dataIndex="status"
                key="status"
                render={(status: string) =>
                  status === "ACTIVE" ? (
                    <CheckOutlined style={{ fontSize: "22px", color: "green" }} />
                  ) : (
                    <CloseOutlined style={{ fontSize: "22px", color: "red" }} />
                  )
                }
              />
              <Column
                title={`${t("table.body.info")}`}
                dataIndex="id"
                key="id"
                render={(id: number) => (
                  <div>
                    <Button variant="outlined" onClick={() => userDetail(id)} shape="round">
                      <UserOutlined />
                    </Button>
                  </div>
                )}
              />
            </Table>
          </ConfigProvider>
        </Col>
      </Row>
    </MainLayout>
  );
}
