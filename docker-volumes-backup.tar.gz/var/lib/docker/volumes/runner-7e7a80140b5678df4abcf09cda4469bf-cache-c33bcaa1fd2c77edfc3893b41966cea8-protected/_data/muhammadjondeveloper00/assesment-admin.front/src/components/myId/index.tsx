import { Alert, Button, Card, Col, DatePicker, Form, Input, Row } from "antd";
import React, { useEffect, useRef, useState } from "react";
import { cannotEmptyRules } from "@/helpers/validationRules";
import { axiosServer } from "@/plugins/axiosServer";
import dayjs from "dayjs";

export default function MyId() {
  const iframeRef = useRef(null);
  const [form] = Form.useForm();
  const values: any = Form.useWatch([], form);
  const [isButtonDisabled, setIsButtonDisabled] = useState(false);
  const [tabs, setTabs] = useState(1);
  const timeoutIdRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  const userInfo = useRef({
    grant_type: "password",
    username: "bkbminplace",
    password: "M5bvB8hEh|vAqnvS",
    client_id: "bkbm_in-place-6vkCtMG6pRwoX9joFPwBSj4i1IM4AA8iwct8lkVK",
  });
  const myIdToken = useRef({
    access_token: "",
  });
  const authenticationData = useRef({
    pass_data: "",
    birth_date: "",
    photo_from_camera: {
      front: "",
    },
    agreed_on_terms: true,
    client_id: userInfo?.current?.client_id,
    threshold: 0.5,
    is_resident: false,
  });
  const cannotEmpty = cannotEmptyRules();
  // const [initialValuesItem, setIsInitialValues] = useState<any>({ isRent: false });
  const layout = {
    // labelCol: { span: 8 },
    // wrapperCol: { span: 16 },
  };

  const loadMyIdToken = async () => {
    axiosServer("", true, "")
      .post(`https://devmyid.uz/api/v1/oauth2/access-token`, userInfo.current, {
        headers: {
          "Content-type": "application/x-www-form-urlencoded",
        },
      })
      .then((res) => {
        myIdToken.current.access_token = res?.data?.access_token || "";
      })
      .catch(() => "");
  };

  const clearForm = () => {
    form.setFieldsValue({ pass_data: "", birth_date: "" });

    authenticationData.current = {
      pass_data: "",
      birth_date: "",
      photo_from_camera: {
        front: "",
      },
      agreed_on_terms: true,
      client_id: userInfo?.current?.client_id,
      threshold: 0.5,
      is_resident: false,
    };
  };
  const restartProcess = () => {
    clearForm();
    setTabs(1);
  };
  const getUserInfo = async (jobId: string) => {
    axiosServer("", true, myIdToken?.current?.access_token)
      .post(
        `https://devmyid.uz/api/v1/authentication/simple-inplace-authentication-request-status?job_id=${jobId}`,
      )
      .then((res) => {
        if (res) {
          setTabs(3);
        }
      })
      .catch(() => {
        clearForm();
        setTabs(1);
      });
  };
  const getJobId = async () => {
    axiosServer("", true, myIdToken?.current?.access_token)
      .post(
        `https://devmyid.uz/api/v1/authentication/simple-inplace-authentication-request-task`,
        authenticationData.current,
      )
      .then((res) => {
        if (res?.data?.job_id) {
          closeCame();
          getUserInfo(res?.data?.job_id);
        }
      })
      .catch(() => {
        closeCame();
        clearForm();
        setTabs(1);
      });
  };

  useEffect(() => {
    loadMyIdToken();
    window.addEventListener("message", handleMessage);
    return () => {
      window.removeEventListener("message", handleMessage);
    };
  }, []);
  const openCame = () => {
    if (timeoutIdRef.current !== null) {
      clearTimeout(timeoutIdRef.current);
    }
    timeoutIdRef.current = setTimeout(() => {
      // @ts-ignore
      iframeRef?.current?.contentWindow.postMessage({ cmd: "open", config: { locale: "uz" } }, "*");
    }, 500);
  };
  const closeCame = () => {
    // @ts-ignore
    iframeRef?.current?.contentWindow.postMessage({ cmd: "close", config: { locale: "uz" } }, "*");
  };
  const handleMessage = (event: any) => {
    // Validate the origin to ensure security
    if (event?.data?.photo_from_camera?.length) {
      authenticationData.current.photo_from_camera.front = event?.data?.photo_from_camera || "";
      // console.log("Closeeee");
      // @ts-ignore
      getJobId();
      closeCame();
      // return;
    }

    // Your logic here...
  };
  const onFinish = (values: any) => {
    authenticationData.current.pass_data = values?.pass_data || "";
    authenticationData.current.birth_date = values.birth_date
      ? dayjs(values.birth_date).format("DD-MM-YYYY")
      : "";
    setTabs(2);
    openCame();
  };
  useEffect(() => {
    form
      .validateFields({ validateOnly: true })
      .then(() => setIsButtonDisabled(true))
      .catch(() => setIsButtonDisabled(false));
  }, [form, values]);
  return (
    <Row className="my-id-box" style={{ height: "calc(100vh - 130px)" }}>
      {tabs === 1 ? (
        <Col>
          <Card style={{ width: 500 }}>
            <Form
              {...layout}
              layout="vertical"
              form={form}
              name="control-hooks"
              autoComplete="off"
              onFinish={onFinish}
            >
              <Form.Item name="pass_data" label="Pasport seriyasi" rules={cannotEmpty}>
                <Input placeholder="AA1234567" />
              </Form.Item>
              <Form.Item name="birth_date" label="Tug'ilgan kun" rules={cannotEmpty}>
                {/*<Input placeholder="yyyy-oo-kk" />*/}
                <DatePicker
                  placeholder="DD-MM-YYYY"
                  format={{
                    format: "DD-MM-YYYY",
                    type: "mask",
                  }}
                />
              </Form.Item>
              <Form.Item>
                <Button
                  block
                  htmlType="submit"
                  key="create"
                  className={!isButtonDisabled ? "" : "base-bg color-white"}
                  disabled={!isButtonDisabled}
                >
                  Keyingi
                </Button>
              </Form.Item>
            </Form>
          </Card>
        </Col>
      ) : tabs === 2 ? (
        <Col>
          <Card style={{ width: 500 }}>
            <iframe
              ref={iframeRef}
              style={{ width: "100%", height: "500px" }}
              id="myid_iframe"
              src="https://docs.myid.uz/iframe"
              allow="camera;fullscreen"
              allowFullScreen
            />
          </Card>
        </Col>
      ) : tabs === 3 ? (
        <Col>
          <Alert
            style={{ width: "300px", height: "80px" }}
            message="Success"
            type="success"
            showIcon
            onClose={restartProcess}
            closable
          />
        </Col>
      ) : (
        ""
      )}
    </Row>
  );
}
