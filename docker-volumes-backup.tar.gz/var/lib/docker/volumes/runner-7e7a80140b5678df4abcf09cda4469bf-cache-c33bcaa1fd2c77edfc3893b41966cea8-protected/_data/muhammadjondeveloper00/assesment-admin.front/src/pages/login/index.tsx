import { Col, Flex, Row, Button, Checkbox, Form, Input } from "antd";
import { Image, Typography } from "antd";
import { LockOutlined, UserOutlined } from "@ant-design/icons";
import { useRouter } from "next/router";
import LanguageSelect from "@/components/widgets/LanguageSelect";
import { useCallback } from "react";
import { axiosServer } from "@/plugins/axiosServer";
import useTranslation from "next-translate/useTranslation";
import { useUserNameRules } from "@/helpers/validationRules";
import { useAppDispatch } from "@/hooks/hooks";
import { setUserInfo } from "@/reducers/user";

export default function Login() {
  const { Title } = Typography;
  const router = useRouter();
  const { locale } = router;
  const { t } = useTranslation("lang");
  const dispatch = useAppDispatch();
  const userNameRules = useUserNameRules();
  // const usePasswordRules = useUserPasswordRules();
  const onFinish = (values: any) => {
    if (values?.username && values?.password) {
      loginAction(values?.username, values?.password)
        .then(async (res: any) => {
          if (res && res.data?.data) {
            dispatch(setUserInfo(res.data.data));
            router
              .push(`/deskbook/pavilions`)
              .then(() => "")
              .catch(() => "");
          }
        })
        .catch(() => "");
    }
  };

  const loginAction = useCallback(async (username: string, password: string) => {
    return await axiosServer(router.locale, true).post("/api/v1/auth-payload", {
      username,
      password,
    });
  }, []);
  return (
    <>
      <Row className="login-form vertical-center ">
        <Col span={24}>
          <Row>
            <Col span={24}>
              <Flex justify={"center"} className="login-form-logo-box">
                <Image
                  className="logo"
                  src={
                    locale === "uz"
                      ? "/images/logo-admin-uz.svg"
                      : locale === "ru"
                      ? "/images/logo-admin-ru.svg"
                      : "/images/logo-admin-en.svg"
                  }
                  alt="empty"
                  preview={false}
                />
              </Flex>
            </Col>
          </Row>
          <Row>
            <Col xs={20} md={15} lg={10} xl={7} xxl={5} style={{ margin: "0 auto" }}>
              <Flex className="login-text-box" justify={"space-between"} align={"center"}>
                <Title className="login-title" level={2} style={{ margin: "0" }}>
                  {t("auth.title")}
                </Title>
                <LanguageSelect />
              </Flex>
              <Form
                name="login"
                initialValues={{ remember: true }}
                style={{ width: "100%", marginTop: "20px" }}
                onFinish={onFinish}
              >
                <Form.Item name="username" rules={userNameRules}>
                  <Input prefix={<UserOutlined />} placeholder={t("auth.login")} />
                </Form.Item>
                {/*<Form.Item name="password" rules={usePasswordRules}>*/}
                <Form.Item name="password">
                  <Input
                    prefix={<LockOutlined />}
                    type="password"
                    placeholder={t("auth.password")}
                  />
                </Form.Item>
                <Form.Item>
                  <Button block className="base-bg color-white" htmlType="submit">
                    {t("auth.submit")}
                  </Button>
                </Form.Item>
                <Form.Item>
                  <Flex justify="space-between" align="center">
                    <Form.Item name="remember" valuePropName="checked" noStyle>
                      <Checkbox className="login-checkbox base-color">
                        {t("auth.remember")}
                      </Checkbox>
                    </Form.Item>
                    <span className="base-color">{t("auth.forgotPassword")}</span>
                  </Flex>
                </Form.Item>
              </Form>
            </Col>
          </Row>
        </Col>
      </Row>
    </>
  );
}
