import {
  Col,
  Row,
  Breadcrumb,
  Flex,
  Typography,
  Button,
  Modal,
  Form,
  Input,
  Select,
  Table,
  ConfigProvider,
  Skeleton,
  Divider,
  Tooltip,
  Upload,
  Image,
  UploadProps,
  type UploadFile,
  type GetProp,
} from "antd";

import MainLayout from "@/components/layout/MainLayout";
import React, { useCallback, useEffect, useRef, useState } from "react";
import { useRouter } from "next/router";
import { axiosServer } from "@/plugins/axiosServer";
import { useAppSelector } from "@/hooks/hooks";
import type { InputRef } from "antd";
type FileType = Parameters<GetProp<UploadProps, "beforeUpload">>[0];

const getBase64 = (file: FileType): Promise<string> =>
  new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = () => resolve(reader.result as string);
    reader.onerror = (error) => reject(error);
  });
const { Column } = Table;
import {
  ArrowLeftOutlined,
  CheckCircleOutlined,
  CloseCircleOutlined,
  DeleteOutlined,
  EditOutlined,
  FileAddOutlined,
  HomeOutlined,
  PlusOutlined,
  QuestionCircleOutlined,
  WalletOutlined,
} from "@ant-design/icons";
import useTranslation from "next-translate/useTranslation";
import { cannotEmptyRules } from "@/helpers/validationRules";
import { toast } from "react-toastify";
import { SessionDataType } from "@/dto/AppDTO";
import { propertyReturn } from "@/helpers/propertyReturn";
// import FileUpload from "@/components/widgets/FileUpload";

export default function SessionTypes() {
  const { Title } = Typography;
  const { Option } = Select;
  const router = useRouter();
  const { locale } = router;
  const { t } = useTranslation("lang");
  const [form] = Form.useForm();
  const values: any = Form.useWatch([], form);
  const [dataItem, setDataItem] = useState<SessionDataType[]>([]);
  const [openModal, setOpenModal] = useState(false);
  const [loading, setLoading] = useState(false);
  const [formBtnLoading, setFormBtnLoading] = useState(false);
  const [editLineId, setEditLineId] = useState(0);
  const [totalItem, setTotalItem] = useState(1);
  const [name, setName] = useState("");
  const inputRef = useRef<InputRef>(null);
  const [items, setItems] = useState<string[]>([]);
  const [fileList, setFileList] = useState<UploadFile[]>([]);
  const [offerFileList, setOfferFileList] = useState<UploadFile[]>([]);
  const [previewImage, setPreviewImage] = useState("");
  const [previewOpen, setPreviewOpen] = useState(false);

  // const [listeningList, setListeningList] = useState<any[]>([]);
  const [query, setquery] = useState({
    page: 0,
    limit: 10,
    search: {},
  });
  const formTemplate = {
    titleUz: "",
    titleRu: "",
    titleEn: "",
    partnerUz: "",
    partnerRu: "",
    partnerEn: "",
    isInOurPlatform: true,
    defaultPaymentAmount: null,
    isThereAnyOtherPavilion: false,
    otherPavilionPaymentAmount: null,
    examRunType: "OUR",
    status: "ACTIVE",
    retakeAmount: null,
    isRetakeAvailable: false,
    reissueAmount: null,
    phone: "",
    telegram: "",
    maxCandidates: null,
    resultOptions: [],
    testType: "Test",
    fileId: null,
    offerFileId: null,
  };
  const [isButtonDisabled, setIsButtonDisabled] = useState(false);
  const [initialValuesItem, setIsInitialValues] = useState<any>({ isRent: false });
  const [modal, contextHolder] = Modal.useModal();
  const confirmModal = (id: number) => {
    modal.confirm({
      title: "",
      icon: <QuestionCircleOutlined style={{ marginTop: "10px" }} />,
      content: <h3>{t("deleteConfirmation")}</h3>,
      okText: t("form.yes"),
      cancelText: t("form.no"),
      onOk() {
        deleteLine(id);
      },
      onCancel() {
        // console.log("Cancel");
      },
      okButtonProps: {
        style: {
          backgroundColor: "#ff4d4f",
          color: "white",
          border: "none",
        },
      },
    });
  };
  const cannotEmpty = cannotEmptyRules();
  const userInfo = useAppSelector((state) => state.user); // hooks/hooks.ts qo'shilgandan keyin shundoq ishlatsa buladi
  const breadcrumbItem = [
    {
      href: `/${locale}`,
      title: <HomeOutlined />,
    },
    {
      href: "",
      title: `${t("menu.reference")}`,
    },
    {
      title: `${t("sessionTypes.testType")}`,
    },
  ];
  const onNameChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    setName(event.target.value);
  };

  const addItem = (e: React.MouseEvent<HTMLButtonElement | HTMLAnchorElement>) => {
    e.preventDefault();
    if (name) {
      setItems([...items, name]);
      setName("");
      setTimeout(() => {
        inputRef.current?.focus();
      }, 0);
    }
  };
  // Define the function to load pavilion data
  const loadTestTypeLists = useCallback(async () => {
    setLoading(true);
    await axiosServer(router.locale, false, userInfo?.token)
      .post("/api/v1/test-type/list-search", query)
      .then((res: any) => {
        setLoading(false);
        setTotalItem(res?.data?.total || 1);
        setDataItem(res?.data?.list || []); // Update the state with the fetched data
      })
      .catch(() => {
        setDataItem([]);
        setLoading(false);
      });
  }, [router.locale, query]);

  useEffect(() => {
    loadTestTypeLists();
  }, [router.locale, query]);

  /** Upload + Form.Item Ant Design maydonni { file, fileList } bilan to‘ldirishi mumkin; API faqat id raqamini kutadi */
  const toFileId = (v: unknown): number | undefined => {
    if (v == null || v === "") return undefined;
    if (typeof v === "number" && !Number.isNaN(v)) return v;
    if (typeof v === "string" && v.trim() !== "" && !Number.isNaN(Number(v))) {
      return Number(v);
    }
    if (typeof v === "object" && v !== null) {
      const o = v as {
        response?: { id?: number | string };
        file?: { response?: { id?: number | string } };
        fileList?: Array<{ response?: { id?: number | string } }>;
      };
      const raw = o.response?.id ?? o.file?.response?.id ?? o.fileList?.[0]?.response?.id;
      if (raw != null && raw !== "") {
        const n = typeof raw === "number" ? raw : Number(raw);
        if (!Number.isNaN(n)) return n;
      }
    }
    return undefined;
  };

  const buildTestTypePayload = () => {
    const values = form.getFieldsValue();
    return {
      ...values,
      fileId: toFileId(values.fileId),
      offerFileId: toFileId(values.offerFileId),
    };
  };

  const handleOk = async () => {
    const values = buildTestTypePayload();
    if (editLineId) {
      setFormBtnLoading(true);
      await axiosServer(router.locale, false, userInfo?.token)
        .put(`/api/v1/test-type/${editLineId}`, values)
        .then(() => {
          setEditLineId(0);
          toast.success(`${t("toast.successfully")}`);
          form.setFieldsValue(formTemplate);
          setFormBtnLoading(false);
          setOpenModal(false);
          closeModal();
          loadTestTypeLists();
        })
        .catch(() => {
          setFormBtnLoading(false);
        });
    } else {
      await axiosServer(router.locale, false, userInfo?.token)
        .post("/api/v1/test-type", values)
        .then(() => {
          toast.success(`${t("toast.successfully")}`);
          form.setFieldsValue(formTemplate);
          setOpenModal(false);
          loadTestTypeLists();
        })
        .catch(() => "");
    }
  };
  const editItemModal = async (id: number) => {
    form.setFieldsValue(formTemplate);
    // console.log("eeeeee", values);
    if (id) {
      setEditLineId(id);
      setOpenModal(true);
      setFormBtnLoading(true);
      setOfferFileList([]);
      await axiosServer(router.locale, false, userInfo?.token)
        .get(`/api/v1/test-type/${id}`)
        .then((res: any) => {
          setFormBtnLoading(false);
          if (res) {
            const data = { ...res };
            if (data?.fileDto) {
              delete data?.fileDto;
            }
            if (data?.offerFileDto) {
              delete data?.offerFileDto;
            }
            // data.listeningId = res?.listeningDTO?.id || undefined;
            // setListeningList([res?.listeningDTO]);
            setIsInitialValues(data);
            form.setFieldsValue({
              ...data,
              offerFileId: res.offerFileId ?? res.offerFileDto?.id ?? null,
            });
            if (res?.fileDto) {
              const fileDtosImages = [
                {
                  ...res?.fileDto,
                  url: `${process.env.IMAGES_URL}${res?.fileDto.url}`,
                },
              ];
              // console.log(122222, fileDtosImages);
              setFileList(fileDtosImages);
            }
            if (res?.offerFileDto) {
              const offerName =
                res.offerFileDto.url?.split("/").pop() || res.offerFileDto.name || "offer.pdf";
              setOfferFileList([
                {
                  uid: "-offer",
                  name: offerName,
                  status: "done",
                  url: res.offerFileDto.url
                    ? `${process.env.IMAGES_URL}${res.offerFileDto.url}`
                    : undefined,
                },
              ]);
            } else if (res?.offerFileId) {
              setOfferFileList([{ uid: "-offer", name: "offer.pdf", status: "done" }]);
            } else {
              setOfferFileList([]);
            }
          }
        })
        .catch(() => {
          setFormBtnLoading(false);
        });
    }
  };

  const deleteItemModal = (id: number) => {
    if (!id) return;
    confirmModal(id);

    // console.log("Delete Itemmm", id);
  };
  const deleteLine = async (id: number) => {
    if (!id) return;
    await axiosServer(router.locale, false, userInfo?.token)
      .delete(`/api/v1/test-type/${id}`)
      .then(() => {
        toast.success(`${t("toast.successfully")}`);
        loadTestTypeLists();
      })
      .catch(() => "");
  };

  const closeModal = () => {
    setEditLineId(0);
    setItems([]);
    form.setFieldsValue(formTemplate);
    setOpenModal(false);
    setFileList([]);
    setOfferFileList([]);
  };
  // Handle pagination changes
  const handlePaginationChange = (page: number, pageSize: number) => {
    const limintChange = page - 1 === query.page;
    setquery((prevQuery) => ({
      ...prevQuery,
      page: limintChange ? 0 : page - 1, // Update page to 5
      limit: pageSize, // Update limit to 3
    }));
  };

  const openCreateModal = () => {
    setOpenModal(true);
    setOfferFileList([]);
    // Explicitly set initial values for a new pavilion if required
    form.setFieldsValue(formTemplate);
  };
  const formatCurrency = (value: number) => {
    return value ? value.toLocaleString() : "";
  };
  // const photoChange = (act: any) => {
  //   if (act.status) {
  //     // console.log(422311, act);
  //     form.setFieldsValue({
  //       fileId: act?.info?.id,
  //     });
  //   } else {
  //     form.setFieldsValue({
  //       fileId: undefined,
  //     });
  //   }
  // };
  useEffect(() => {
    form
      .validateFields({ validateOnly: true })
      .then(() => {
        setIsButtonDisabled(true);
      })
      .catch(() => setIsButtonDisabled(false));
    // console.log(555, form.getFieldsValue());
  }, [form, values]);

  const handleChange: UploadProps["onChange"] = ({ fileList: newFileList }) => {
    setFileList(newFileList);
  };

  const handlePreview = async (file: UploadFile) => {
    if (!file.url && !file.preview) {
      file.preview = await getBase64(file.originFileObj as FileType);
    }

    setPreviewImage(file.url || (file.preview as string));
    setPreviewOpen(true);
  };

  const handleOfferPreview = async (file: UploadFile) => {
    if (file.url) {
      window.open(file.url, "_blank", "noopener,noreferrer");
      return;
    }
    if (file.preview) {
      window.open(String(file.preview), "_blank", "noopener,noreferrer");
      return;
    }
    if (file.originFileObj) {
      const blobUrl = URL.createObjectURL(file.originFileObj as Blob);
      window.open(blobUrl, "_blank", "noopener,noreferrer");
      setTimeout(() => URL.revokeObjectURL(blobUrl), 60_000);
    }
  };
  const handleRemove = () => {
    // const fileId: number = file?.response?.id;
    // if (fileId) {
    form.setFieldsValue({ fileId: undefined });
    // }
  };

  const handleOfferRemove = () => {
    form.setFieldsValue({ offerFileId: undefined });
  };

  const handleOfferChange: UploadProps["onChange"] = ({ fileList: newFileList }) => {
    setOfferFileList(newFileList);
  };

  const props2: UploadProps = {
    action: `${process.env.PUBLIC_API_SERVER_URL}/api/v1/file`,
    customRequest: async ({ file, onSuccess, onError }) => {
      const formData = new FormData();
      formData.append("file", file);

      try {
        await axiosServer(router.locale, false, userInfo?.token)
          .post(`/api/v1/file`, formData)
          .then((res: any) => {
            if (res?.id) {
              form.setFieldsValue({ fileId: res?.id || undefined });
              // @ts-ignore
              onSuccess(res);
            } else {
              // @ts-ignore
              onError(new Error("Upload failed"));
            }
          });
      } catch (error) {
        // @ts-ignore
        onError(error);
      }
    },
    fileList: fileList, // Pass fileList here
    onRemove: handleRemove, // Handle file removal
  };

  const offerUploadProps: UploadProps = {
    accept: ".pdf,application/pdf",
    beforeUpload: (file) => {
      const isPdf =
        file.type === "application/pdf" ||
        file.type === "application/x-pdf" ||
        /\.pdf$/i.test(file.name);
      if (!isPdf) {
        toast.warn(`${t("sessionTypes.pdfOnly")}`);
        return Upload.LIST_IGNORE;
      }
      return true;
    },
    customRequest: async ({ file, onSuccess, onError }) => {
      const formData = new FormData();
      formData.append("file", file);

      try {
        await axiosServer(router.locale, false, userInfo?.token)
          .post(`/api/v1/file`, formData)
          .then((res: any) => {
            if (res?.id) {
              form.setFieldsValue({ offerFileId: res?.id || undefined });
              // @ts-ignore
              onSuccess(res);
            } else {
              // @ts-ignore
              onError(new Error("Upload failed"));
            }
          });
      } catch (error) {
        // @ts-ignore
        onError(error);
      }
    },
    fileList: offerFileList,
    onRemove: handleOfferRemove,
  };

  const uploadButton = (
    <button style={{ border: 0, background: "none" }} type="button">
      <PlusOutlined />
      <div style={{ marginTop: 8 }}>{t("sessionTypes.upload")}</div>
    </button>
  );
  // const loadToeflData = useCallback(async (value = "") => {
  //   const listeningQuery = {
  //     page: 0,
  //     limit: 100,
  //     search: {
  //       name: value || undefined,
  //     },
  //   };
  //   await axiosServer(router.locale, false, userInfo?.token)
  //     .post(`/api/v1/listening/list-search`, listeningQuery)
  //     .then((res: any) => {
  //       setListeningList(res?.data?.list || []); // Update the state with the fetched data
  //     })
  //     .catch(() => {
  //       setListeningList([]);
  //     });
  // }, []);

  // const testTypeChange = (value: string) => {
  //   if (value === "TOEFL") {
  //     loadToeflData();
  //   }
  // };

  // const listeningSearch = (value: string) => {
  //   if (value && value.length > 1) {
  //     loadToeflData(value);
  //   }
  // };
  return (
    <MainLayout>
      <Row className="pavilion-box">
        <Col span={24}>
          <div>
            <Breadcrumb items={breadcrumbItem} />
          </div>
        </Col>
        <Col span={24} className="add-pavilion-box">
          <Flex justify={"space-between"}>
            <Flex align={"center"}>
              <ArrowLeftOutlined style={{ marginRight: "16px", fontSize: "16px" }} />
              <Title level={4} className="m-0">
                {t("test.list")}
              </Title>
            </Flex>
            <Button
              onClick={openCreateModal}
              style={{ marginRight: "20px" }}
              className="add-pavilion"
              type="primary"
              shape="round"
              icon={<FileAddOutlined />}
              size="large"
            >
              {t("test.add")}
            </Button>
          </Flex>
        </Col>
      </Row>
      <Row>
        <Col span={24}>
          <ConfigProvider
            //@ts-ignore
            locale={{
              Pagination: {
                items_per_page: "/" + t("table.page"), // Sahifa hajmi matnini o'zgartirish
              },
            }}
          >
            <Table<SessionDataType>
              className="ass-table"
              dataSource={loading ? [] : dataItem}
              rowKey={(record): React.Key => record.id}
              pagination={{
                current: query.page + 1,
                pageSize: query.limit,
                total: totalItem,
                onChange: handlePaginationChange,
                showSizeChanger: true,
                pageSizeOptions: ["10", "20", "50"], // Customize the available page sizes
              }}
              loading={loading}
              locale={{
                emptyText: loading ? <Skeleton active paragraph={{ rows: 5 }} /> : t("empty"),
              }}
            >
              <Column
                title={`${t("table.header.topic")}`}
                dataIndex={propertyReturn(`${locale}`, "title")}
                key={propertyReturn(`${locale}`, "title")}
              />
              <Column
                title={`${t("table.header.paymentAmount")}`}
                dataIndex="defaultPaymentAmount"
                key="defaultPaymentAmount"
                render={(text) => `${formatCurrency(text)} UZS`}
              />
              <Column
                title={`${t("table.header.status")}`}
                dataIndex="status"
                key="status"
                render={(status: string) =>
                  status === "ACTIVE" ? (
                    <Button className="bg-success color-white cursor-auto">
                      <CheckCircleOutlined />
                      {t("table.body.active")}
                    </Button>
                  ) : (
                    <Button className="bg-danger color-white cursor-auto">
                      <CloseCircleOutlined /> {t("table.body.inActive")}
                    </Button>
                  )
                }
              />
              <Column
                title={`${t("table.header.partner")}`}
                dataIndex={propertyReturn(`${locale}`, "partner")}
                key={propertyReturn(`${locale}`, "partner")}
              />
              <Column
                title={`${t("table.header.ourPlatform")}`}
                dataIndex="isInOurPlatform"
                key="isInOurPlatform"
                render={(isInOurPlatform: boolean) => (isInOurPlatform ? "Ha" : "Yo'q")}
              />

              <Column
                title={`${t("table.header.actions")}`}
                dataIndex="id"
                key="id"
                render={(id: number) => (
                  <div>
                    <Button
                      onClick={() => editItemModal(id)}
                      className="bg-primary color-white"
                      shape="round"
                    >
                      <EditOutlined />
                    </Button>
                    <Button
                      danger
                      onClick={() => deleteItemModal(id)}
                      className="ml-2"
                      shape="round"
                    >
                      <DeleteOutlined />
                    </Button>
                  </div>
                )}
              />
            </Table>
          </ConfigProvider>
        </Col>
      </Row>
      <Row className="ass-style">
        <Modal
          className="ass-style ass-modal"
          centered
          open={openModal}
          title={t("test.add")}
          onOk={handleOk}
          onCancel={closeModal}
          footer={[
            <Button key="close" onClick={closeModal}>
              {t("form.close")}
            </Button>,
            <Button
              key="create"
              className={!isButtonDisabled ? "" : "base-bg color-white"}
              disabled={!isButtonDisabled}
              onClick={handleOk}
              loading={formBtnLoading}
            >
              {t("form.create")}
            </Button>,
          ]}
        >
          <div className="ass-modal-body">
            <Skeleton loading={formBtnLoading} active paragraph={{ rows: 5 }}>
              <Form
                initialValues={initialValuesItem}
                form={form}
                layout="vertical"
                name="pavilion"
                style={{ width: "100%", marginTop: "20px" }}
                autoComplete="off"
              >
                <Row>
                  <Col span={10} className="pavilion-input">
                    <Form.Item name="titleUz" label={t("form.label.titleUz")} rules={cannotEmpty}>
                      <Input placeholder={t("form.enterTitle")} />
                    </Form.Item>
                  </Col>
                  <Col span={14} className="pavilion-input">
                    <Form.Item name="partnerUz" label={t("form.label.partner")} rules={cannotEmpty}>
                      <Input placeholder={t("form.enterTitle")} />
                    </Form.Item>
                  </Col>
                  <Col span={10} className="pavilion-input">
                    <Form.Item name="titleRu" label={t("form.label.titleRu")} rules={cannotEmpty}>
                      <Input placeholder={t("form.enterTitle")} />
                    </Form.Item>
                  </Col>
                  <Col span={14} className="pavilion-input">
                    <Form.Item name="partnerRu" label={t("form.label.partner")} rules={cannotEmpty}>
                      <Input placeholder={t("form.enterTitle")} />
                    </Form.Item>
                  </Col>
                  <Col span={10} className="pavilion-input">
                    <Form.Item name="titleEn" label={t("form.label.titleEn")} rules={cannotEmpty}>
                      <Input placeholder={t("form.enterTitle")} />
                    </Form.Item>
                  </Col>
                  <Col span={14} className="pavilion-input">
                    <Form.Item name="partnerEn" label={t("form.label.partner")} rules={cannotEmpty}>
                      <Input placeholder={t("form.enterTitle")} />
                    </Form.Item>
                  </Col>
                  <Col span={10} className="pavilion-input">
                    <Form.Item
                      name="isInOurPlatform"
                      label={t("form.label.ourPlatform")}
                      rules={cannotEmpty}
                    >
                      <Select allowClear>
                        <Option value={false}>{t("form.no")}</Option>
                        <Option value={true}>{t("form.yes")}</Option>
                      </Select>
                    </Form.Item>
                  </Col>
                  <Col span={14} className="pavilion-input">
                    <Form.Item
                      name="defaultPaymentAmount"
                      label={t("form.label.defaultPaymentAmount")}
                      rules={cannotEmpty}
                    >
                      <Input
                        prefix={<WalletOutlined />}
                        type="number"
                        min={0}
                        placeholder={t("form.enterPaymentAmount")}
                        onChange={(e) =>
                          form.setFieldsValue({
                            defaultPaymentAmount: e?.target?.value ? Number(e?.target?.value) : 0,
                          })
                        }
                      />
                    </Form.Item>
                  </Col>
                  <Col span={10} className="pavilion-input">
                    <Form.Item
                      name="isThereAnyOtherPavilion"
                      label={t("form.label.availableNonOurPavilions")}
                      rules={cannotEmpty}
                    >
                      <Select placeholder="isThereAnyOtherPavilion" allowClear>
                        <Option value={false}>{t("form.no")}</Option>
                        <Option value={true}>{t("form.yes")}</Option>
                      </Select>
                    </Form.Item>
                  </Col>
                  <Col span={14} className="pavilion-input">
                    {values?.isThereAnyOtherPavilion && (
                      <Form.Item
                        name="otherPavilionPaymentAmount"
                        label={t("form.label.priceNonOurPavilions")}
                        rules={cannotEmpty}
                      >
                        <Input
                          prefix={<WalletOutlined />}
                          type="number"
                          min={0}
                          placeholder={t("form.enterPriceNonOurPavilions")}
                          onChange={(e) =>
                            form.setFieldsValue({
                              otherPavilionPaymentAmount: e?.target?.value
                                ? Number(e?.target?.value)
                                : 0,
                            })
                          }
                        />
                      </Form.Item>
                    )}
                  </Col>
                  <Col span={10} className="pavilion-input">
                    <Form.Item
                      name="examRunType"
                      label={t("form.label.examRunType")}
                      rules={cannotEmpty}
                    >
                      <Select placeholder="isThereAnyOtherPavilion" allowClear>
                        <Option value="OUR">{t("form.ourExam")}</Option>
                        <Option value="APPLICATION">{t("form.appPath")}</Option>
                        <Option value="WEB">{t("form.pageUrl")}</Option>
                      </Select>
                    </Form.Item>
                  </Col>
                  <Col span={14} className="pavilion-input">
                    {values?.examRunType === "APPLICATION" && (
                      <Form.Item
                        name="application"
                        label={t("form.label.enterAppPath")}
                        rules={cannotEmpty}
                      >
                        <Input placeholder={t("form.appPath")} />
                      </Form.Item>
                    )}
                    {values?.examRunType === "WEB" && (
                      <Form.Item
                        name="externalUrl"
                        label={t("form.label.enterPageUrl")}
                        rules={cannotEmpty}
                      >
                        <Input placeholder={t("form.pageUrl")} />
                      </Form.Item>
                    )}
                  </Col>

                  <Col span={10} className="pavilion-input">
                    <Form.Item
                      name="isRetakeAvailable"
                      label={t("form.label.retakeAvailable")}
                      rules={cannotEmpty}
                    >
                      <Select placeholder="isRetakeAvailable" allowClear>
                        <Option value={false}>{t("form.no")}</Option>
                        <Option value={true}>{t("form.yes")}</Option>
                      </Select>
                    </Form.Item>
                  </Col>
                  <Col span={14} className="pavilion-input">
                    {values?.isRetakeAvailable && (
                      <Form.Item
                        name="retakeAmount"
                        label={t("form.label.retakePrice")}
                        rules={cannotEmpty}
                      >
                        <Input
                          prefix={<WalletOutlined />}
                          type="number"
                          min={0}
                          placeholder={t("form.enterPaymentAmount")}
                          onChange={(e) =>
                            form.setFieldsValue({
                              retakeAmount: e?.target?.value ? Number(e?.target?.value) : 0,
                            })
                          }
                        />
                      </Form.Item>
                    )}
                  </Col>
                  <Row style={{ width: "100%" }}>
                    <Col span={10} className="pavilion-input">
                      <Form.Item
                        name="reissueAmount"
                        label={t("form.label.reissuePrice")}
                        rules={cannotEmpty}
                      >
                        <Input
                          prefix={<WalletOutlined />}
                          type="number"
                          min={0}
                          placeholder={t("form.enterPaymentAmount")}
                          onChange={(e) =>
                            form.setFieldsValue({
                              reissueAmount: e?.target?.value ? Number(e?.target?.value) : 0,
                            })
                          }
                        />
                      </Form.Item>
                    </Col>
                  </Row>
                  <Col span={24} className="pavilion-input ass-style">
                    <Form.Item
                      name="resultOptions"
                      label={t("form.label.resultOptions")}
                      rules={cannotEmpty}
                    >
                      <Select
                        mode="multiple"
                        placeholder={t("form.enterResult")}
                        dropdownRender={(menu) => (
                          <>
                            {menu}
                            <Divider style={{ margin: "8px 0" }} />
                            <div
                              style={{
                                padding: "0 8px 4px",
                                flexDirection: "column",
                                width: "100%",
                              }}
                            >
                              <Input
                                style={{
                                  display: "block !important",
                                  width: "100% !important",
                                }}
                                placeholder=""
                                ref={inputRef}
                                value={name}
                                onChange={onNameChange}
                                onKeyDown={(e) => e.stopPropagation()}
                              />
                              <Button
                                type="text"
                                icon={<PlusOutlined />}
                                style={{ color: "#2DA5CC" }}
                                onClick={addItem}
                              >
                                {t("form.enterAddResult")}
                              </Button>
                            </div>
                          </>
                        )}
                        options={items.map((item) => ({ label: item, value: item }))}
                      />
                    </Form.Item>
                  </Col>
                  <Col span={10} className="pavilion-input">
                    <Form.Item name="phone" label={t("form.label.phone")} rules={cannotEmpty}>
                      <Input placeholder={t("form.enterPhone")} />
                    </Form.Item>
                  </Col>
                  <Col span={14} className="pavilion-input">
                    <Form.Item name="telegram" label={t("form.label.telegram")} rules={cannotEmpty}>
                      <Input placeholder={t("form.enterTelegram")} />
                    </Form.Item>
                  </Col>
                  <Col span={10} className="pavilion-input">
                    <Form.Item
                      name="maxCandidates"
                      label={
                        <>
                          {t("form.label.maxCandidates")}
                          <Tooltip title={t("form.label.maxCandidatesQuestion")}>
                            <QuestionCircleOutlined style={{ marginLeft: 8 }} />
                          </Tooltip>
                        </>
                      }
                      rules={cannotEmpty}
                    >
                      <Input
                        prefix="#"
                        type="number"
                        min={0}
                        placeholder={t("form.enterMaxCandidates")}
                        onChange={(e) =>
                          form.setFieldsValue({
                            maxCandidates: e?.target?.value ? Number(e?.target?.value) : 0,
                          })
                        }
                      />
                    </Form.Item>
                  </Col>
                  <Col span={14} className="pavilion-input">
                    <Form.Item name="status" label={t("form.label.status")} rules={cannotEmpty}>
                      <Select placeholder={t("form.status")} allowClear>
                        <Option value="ACTIVE">
                          <CheckCircleOutlined
                            className="select-item-icon"
                            style={{ marginRight: "8px" }}
                          />
                          {t("form.active")}
                        </Option>
                        <Option value="INACTIVE">
                          <CloseCircleOutlined
                            className="select-item-icon"
                            style={{ marginRight: "8px" }}
                          />
                          {t("form.inActive")}
                        </Option>
                      </Select>
                    </Form.Item>
                  </Col>
                  <Col span={10} className="pavilion-input">
                    <Form.Item
                      name="testType"
                      label={`${t("sessionTypes.testType")}`}
                      rules={cannotEmpty}
                    >
                      <Select placeholder={t("form.status")} allowClear>
                        <Select.Option value="TEST">Test</Select.Option>
                        <Select.Option value="TOEFL">Toefl</Select.Option>
                      </Select>
                    </Form.Item>
                  </Col>
                  <Col span={24} className="pavilion-input">
                    <Row gutter={16} style={{ width: "100%" }}>
                      <Col xs={24} md={12}>
                        <Form.Item name="fileId" label={`${t("sessionTypes.selectPhoto")}`}>
                          <Upload
                            {...props2}
                            listType="picture-card"
                            fileList={fileList}
                            onPreview={handlePreview}
                            onChange={handleChange}
                          >
                            {fileList?.length >= 1 ? null : uploadButton}
                          </Upload>
                          {previewImage && (
                            <Image
                              wrapperStyle={{ display: "none" }}
                              preview={{
                                visible: previewOpen,
                                onVisibleChange: (visible) => setPreviewOpen(visible),
                                afterOpenChange: (visible) => !visible && setPreviewImage(""),
                              }}
                              src={previewImage}
                            />
                          )}
                        </Form.Item>
                      </Col>
                      <Col xs={24} md={12}>
                        {/* Upload Form.Item ichida name bo‘lmasin — aks holda {file,fileList} yoziladi. Id faqat shu yashirin maydonda. */}
                        <Form.Item name="offerFileId" noStyle hidden>
                          <Input type="hidden" />
                        </Form.Item>
                        <Form.Item label={`${t("sessionTypes.uploadOfferPdf")}`}>
                          <Upload
                            {...offerUploadProps}
                            listType="picture-card"
                            fileList={offerFileList}
                            onPreview={handleOfferPreview}
                            onChange={handleOfferChange}
                          >
                            {offerFileList?.length >= 1 ? null : uploadButton}
                          </Upload>
                        </Form.Item>
                      </Col>
                    </Row>
                    {/*<Form.Item name="fileId" label="Test rasmi">*/}
                    {/*  <FileUpload*/}
                    {/*    image={initialValuesItem.fileDto?.url || ""}*/}
                    {/*    shape="rectangle"*/}
                    {/*    handlechange={photoChange}*/}
                    {/*  />*/}
                    {/*</Form.Item>*/}
                  </Col>
                  {/*<Col span={14} className="pavilion-input">*/}
                  {/*  {values?.testType === "TOEFL" && (*/}
                  {/*    <Form.Item name="listeningId" label="Listening ro'yhati" rules={cannotEmpty}>*/}
                  {/*      <Select*/}
                  {/*        placeholder="Listeningni tanlang"*/}
                  {/*        allowClear*/}
                  {/*        onSearch={($event) => {*/}
                  {/*          listeningSearch($event);*/}
                  {/*        }}*/}
                  {/*        filterOption={false}*/}
                  {/*        showSearch*/}
                  {/*      >*/}
                  {/*        /!* Optionsni map qilish *!/*/}
                  {/*        {listeningList?.map((option: any) => (*/}
                  {/*          <Select.Option key={option?.id} value={option?.id}>*/}
                  {/*            {option?.name}*/}
                  {/*          </Select.Option>*/}
                  {/*        ))}*/}
                  {/*      </Select>*/}
                  {/*    </Form.Item>*/}
                  {/*  )}*/}
                  {/*</Col>*/}
                </Row>
              </Form>
            </Skeleton>
          </div>
        </Modal>
      </Row>
      <Row>
        <Col span={24}>{contextHolder}</Col>
      </Row>
    </MainLayout>
  );
}
