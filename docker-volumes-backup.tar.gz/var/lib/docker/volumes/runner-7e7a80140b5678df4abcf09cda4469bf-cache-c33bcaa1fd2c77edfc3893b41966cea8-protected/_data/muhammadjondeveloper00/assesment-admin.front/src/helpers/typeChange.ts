import { useRouter } from "next/router";

const weekdaysUz: string[] = [
  "Yakshanba",
  "Dushanba",
  "Seshanba",
  "Chorshanba",
  "Payshanba",
  "Juma",
  "Shanba",
];
const weekdaysRu: string[] = [
  "Воскресенье",
  "Понедельник",
  "Вторник",
  "Среда",
  "Четверг",
  "Пятница",
  "Суббота",
];
const weekdaysEn: string[] = [
  "Sunday",
  "Monday",
  "Tuesday",
  "Wednesday",
  "Thursday",
  "Friday",
  "Saturday",
];
const monthsUz = [
  "Yanvar",
  "Fevral",
  "Mart",
  "Aprel",
  "May",
  "Iyun",
  "Iyul",
  "Avgust",
  "Sentabr",
  "Oktyabr",
  "Noyabr",
  "Dekabr",
];
const monthsRu = [
  "Январь",
  "Февраль",
  "Маршировать",
  "Апрель",
  "Может",
  "Июнь",
  "Июль",
  "Август",
  "Сентябрь",
  "Октябрь",
  "Ноябрь",
  "Декабрь",
];
const monthsEn = [
  "January",
  "February",
  "March",
  "April",
  "May",
  "June",
  "July",
  "August",
  "September",
  "October",
  "November",
  "December",
];

export const dateFormat = (dateStr: string) => {
  const router = useRouter();
  const { locale } = router;
  if (!dateStr) return "";
  const dateParts = dateStr.split(" ");
  const date = dateParts[0].split("-");
  const time = dateParts[1];

  // Sana va vaqtni to'g'ri formatda yaratish
  const formattedDate =
    dateStr?.length === 16
      ? new Date(`${date[2]}-${date[1]}-${date[0]}T${time}:00`)
      : new Date(`${date[2]}-${date[1]}-${date[0]}T${time}`);

  // Hafta kunini olish
  const weekdays = locale === "uz" ? weekdaysUz : locale === "ru" ? weekdaysRu : weekdaysEn;
  const weekDayName = weekdays[formattedDate.getDay()];

  // Sanani va vaqtni formatlash
  const months = locale === "uz" ? monthsUz : locale === "ru" ? monthsRu : monthsEn;
  const monthName = months[formattedDate.getMonth()];
  const day = formattedDate.getDate();
  const year = formattedDate.getFullYear();
  const hours = formattedDate.getHours().toString().padStart(2, "0");
  const minutes = formattedDate.getMinutes().toString().padStart(2, "0");
  const seconds = formattedDate.getSeconds().toString().padStart(2, "0");
  const result =
    dateStr?.length === 16
      ? `${day} ${monthName} ${year}, ${weekDayName} ${hours}:${minutes}`
      : `${day} ${monthName} ${year}, ${weekDayName} ${hours}:${minutes}:${seconds}`;
  return result;
};
export const dateFormatLong = (dateStr: string) => {
  if (!dateStr) return "";
  // Date obyektini yaratish
  // const date = new Date(dateStr);
  // console.log(8888,dateStr, "66666", date, "777", date.toLocaleTimeString());
  //// new logic
  // const day = String(date.getDate()).padStart(2, "0"); // Kunni 2 raqamli qilib formatlash
  // const month = String(date.getMonth() + 1).padStart(2, "0"); // Oyni 2 raqamli qilish (oy 0 dan boshlanadi)
  // const year = date.getFullYear();

  // // Vaqt elementlarini ajratib olish
  // const hours = String(date.getHours()).padStart(2, "0");
  // const minutes = String(date.getMinutes()).padStart(2, "0");
  // const seconds = String(date.getSeconds()).padStart(2, "0");

  // Formatga moslashtirish
  // const formattedDate = `${day}-${month}-${year} ${hours}:${minutes}:${seconds}`;
  // console.log(99999, formattedDate);
  // if (formattedDate) {
  return dateFormat(dateStr);
  // }
};
export const formatPhoneNumber = (phone: string) => {
  if (!phone?.length) return "";
  if (phone?.length !== 12) return phone;
  return phone.replace(/(\d{3})(\d{2})(\d{3})(\d{2})(\d{2})/, "+$1 ($2) $3-$4-$5");
};
