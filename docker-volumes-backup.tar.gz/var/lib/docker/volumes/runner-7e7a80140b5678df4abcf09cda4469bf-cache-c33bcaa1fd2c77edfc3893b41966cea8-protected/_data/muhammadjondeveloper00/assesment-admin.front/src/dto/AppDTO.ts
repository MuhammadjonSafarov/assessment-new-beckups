export interface PavilionDataType {
  id: number;
  nameUz: string;
  nameRu: string;
  addressUz: string;
  addressRu: string;
  isRent: boolean;
  status: string;
}
export interface SessionDataType {
  id: number;
  titleUz: string;
  titleRu: string;
  titleEn: string;
  partnerUz: string;
  partnerRu: string;
  partnerEn: string;
  isInOurPlatform: boolean;
  defaultPaymentAmount: number | null;
  isThereAnyOtherPavilion: boolean;
  otherPavilionPaymentAmount: number | null;
  examRunType: string;
  status: string;
  retakeAmount: number | null;
  isRetakeAvailable: boolean;
  reissueAmount: number | null;
  phone: string;
  telegram: string;
  maxCandidates: number | null;
  resultOptions: [];
  testType?: string | undefined;
}
export interface PermissionType {
  id: number;
  name: string;
  type: string;
}
export interface RoleType {
  id: number;
  name: string;
  description: string;
  isGetAllPermissions: boolean;
  roleType: string;
  permissionIds: [];
}
export interface OperatorType {
  id: number;
  username: string;
  status: string;
  firstName: string;
  lastName: string;
  middleName: string;
  phone: string;
  roles: [];
  pavilions: [];
  testTypes: [];
  lastActiveDate: string;
  createdDate: string;
}
export interface UserDataType {
  id: number;
  username: string;
  status: string;
  firstName: string;
  lastName: string;
  middleName: string;
  email: string;
  phone: string;
  roles: [];
  lastActiveDate: string;
  createdDate: string;
  passportSerial: string;
  passportNumber: string;
  birthDate: string;
  tmpCode: string;
}
export interface writingAnswersType {
  id: number;
  body: string;
}
export interface speakingAnswersType {
  id: number;
  speakingAnswerFile: {
    id: number;
    url: string;
  };
}
