import {
  Col,
  Row,
  Breadcrumb,
  Flex,
  Typography,
  Button,
  Modal,
  Form,
  Input,
  Select,
  Table,
  ConfigProvider,
  Skeleton,
  Tag,
  Image,
  Card,
} from "antd";
import MainLayout from "@/components/layout/MainLayout";
import React, { useCallback, useEffect, useState } from "react";
import { useRouter } from "next/router";
import { axiosServer } from "@/plugins/axiosServer";
import { useAppSelector } from "@/hooks/hooks";

const { Column } = Table;
import {
  ArrowLeftOutlined,
  DeleteFilled,
  EditOutlined,
  EyeOutlined,
  HomeOutlined,
  UnlockOutlined,
  UserAddOutlined,
} from "@ant-design/icons";
import useTranslation from "next-translate/useTranslation";
import { cannotEmptyRules, phoneLengthRules } from "@/helpers/validationRules";
import { toast } from "react-toastify";
import { OperatorType, PermissionType, RoleType, SessionDataType } from "@/dto/AppDTO";
import { dateFormat } from "@/helpers/typeChange";

export default function Operators() {
  const { Title } = Typography;
  const router = useRouter();
  const { locale } = router;
  const { t } = useTranslation("lang");
  const [form] = Form.useForm();
  const values: any = Form.useWatch([], form);
  const [dataItem, setDataItem] = useState<OperatorType[]>([]);
  const [openModal, setOpenModal] = useState(false);
  const [detailModal, setdDetailModal] = useState(false);
  const [operatorDetail, setOperatorDetail] = useState<OperatorType>();
  const [loading, setLoading] = useState(false);
  const [formBtnLoading, setFormBtnLoading] = useState(false);
  const [editLineId, setEditLineId] = useState(0);
  const [totalItem, setTotalItem] = useState(1);
  const [permissionList, setPermissionList] = useState<PermissionType[]>([]);
  const [roleList, setRoleList] = useState<RoleType[]>([]);
  const [testTypeList, setTestTypeList] = useState<SessionDataType[]>([]);
  const { Meta } = Card;
  const layout = {
    labelCol: { span: 8 },
    wrapperCol: { span: 16 },
  };
  // console.log(666666, filter.current);
  const [query, setquery] = useState({
    page: 0,
    limit: 10,
    search: {},
  });
  const formTemplate = {
    firstName: "",
    lastName: "",
    middleName: "",
    username: "",
    password: "",
    roleIds: [],
    permissionIds: [],
    testTypeIds: [],
  };
  const [isButtonDisabled, setIsButtonDisabled] = useState(false);
  const [initialValuesItem, setIsInitialValues] = useState<any>({ isRent: false });
  const cannotEmpty = cannotEmptyRules();
  const phoneLength = phoneLengthRules();
  const userInfo = useAppSelector((state) => state.user); // hooks/hooks.ts qo'shilgandan keyin shundoq ishlatsa buladi
  const breadcrumbItem = [
    {
      href: `/${locale}`,
      title: <HomeOutlined />,
    },
    {
      href: "",
      title: `${t("menu.reference")}`,
    },
    {
      title: `${t("menu.operators")}`,
    },
  ];

  // Define the function to load pavilion data
  const loadData = useCallback(async () => {
    setLoading(true);
    // console.log(88888, filter?.current);
    await axiosServer(router.locale, false, userInfo?.token)
      // .post(`/api/v1/user/list-search?isListOperators=true`, query)
      .post(`/api/v1/user/list-search?isListOperators=true`, query)
      .then((res: any) => {
        setLoading(false);
        setTotalItem(res?.data?.total || 1);
        setDataItem(res?.data?.list || []); // Update the state with the fetched data
      })
      .catch(() => {
        setDataItem([]);
        setLoading(false);
      });
  }, [router.locale, query]);

  const loadPermissionList = () => {
    const permissionQuery = {
      page: 0,
      limit: 5000,
      search: {},
    };
    axiosServer(router.locale, false, userInfo?.token)
      .post(`/api/v1/permission/list-search/ALL`, permissionQuery)
      .then((res: any) => {
        // setTotalItem(res?.data?.total || 1);
        setPermissionList(res?.data?.list || []);
      })
      .catch(() => "");
  };
  const loadRoleList = () => {
    const permissionQuery = {
      page: 0,
      limit: 5000,
      search: {},
    };
    axiosServer(router.locale, false, userInfo?.token)
      .post(`/api/v1/role/list-search`, permissionQuery)
      .then((res: any) => {
        // setTotalItem(res?.data?.total || 1);
        setRoleList(res?.data?.list || []);
      })
      .catch(() => "");
  };
  const loadTestTypeList = () => {
    const permissionQuery = {
      page: 0,
      limit: 5000,
      search: {},
    };
    axiosServer(router.locale, false, userInfo?.token)
      .post(`/api/v1/test-type/list-search`, permissionQuery)
      .then((res: any) => {
        // setTotalItem(res?.data?.total || 1);
        setTestTypeList(res?.data?.list || []);
      })
      .catch(() => "");
  };

  useEffect(() => {
    loadData();
    loadRoleList();
    loadPermissionList();
    loadTestTypeList();
  }, [router.locale, query]);

  useEffect(() => {
    form
      .validateFields({ validateOnly: true })
      .then(() => setIsButtonDisabled(true))
      .catch(() => setIsButtonDisabled(false));
    // console.log(555, formTemplate.getFieldsValue());
  }, [form, values]);
  const handleOk = async () => {
    const values = form.getFieldsValue();
    if (editLineId) {
      setFormBtnLoading(true);
      await axiosServer(router.locale, false, userInfo?.token)
        .put(`/api/v1/user/${editLineId}`, values)
        .then(() => {
          setEditLineId(0);
          toast.success(`${t("toast.successfully")}`);
          form.setFieldsValue(formTemplate);
          setFormBtnLoading(false);
          setOpenModal(false);
          loadData();
        })
        .catch(() => {
          setFormBtnLoading(false);
        });
    } else {
      await axiosServer(router.locale, false, userInfo?.token)
        .post("/api/v1/user", values)
        .then(() => {
          toast.success(`${t("toast.successfully")}`);
          form.setFieldsValue(formTemplate);
          setOpenModal(false);
          loadData();
        })
        .catch(() => "");
    }
  };
  const editItemModal = async (id: number) => {
    form.setFieldsValue(formTemplate);
    // console.log("eeeeee", values);
    if (id) {
      setEditLineId(id);
      setOpenModal(true);
      setFormBtnLoading(true);
      await axiosServer(router.locale, false, userInfo?.token)
        .get(`/api/v1/user/${id}`)
        .then((res: any) => {
          setFormBtnLoading(false);
          if (res) {
            setIsInitialValues(res);
            form.setFieldsValue(res);
            if (res?.roles?.length) {
              const roleIds = res?.roles.map((item: any) => item.id);
              setIsInitialValues({ roleIds });
              form.setFieldsValue({ roleIds });
            }
          }
        })
        .catch(() => {
          setFormBtnLoading(false);
        });
    }
  };
  const itemDetailModal = async (id: number) => {
    form.setFieldsValue(formTemplate);
    // console.log("eeeeee", values);
    if (id) {
      setdDetailModal(true);
      setFormBtnLoading(true);
      await axiosServer(router.locale, false, userInfo?.token)
        .get(`/api/v1/user/${id}`)
        .then((res: any) => {
          setFormBtnLoading(false);
          if (res) {
            setOperatorDetail(res);
          }
        })
        .catch(() => {
          setFormBtnLoading(false);
        });
    }
  };

  const deleteItemModal = () => {
    // console.log("Delete Itemmm", id);
  };

  const closeModal = () => {
    setEditLineId(0);
    form.setFieldsValue(formTemplate);
    setOpenModal(false);
  };
  const closeDetailModal = () => {
    setdDetailModal(false);
  };
  // Handle pagination changes
  const handlePaginationChange = (page: number, pageSize: number) => {
    const limintChange = page - 1 === query.page;
    setquery((prevQuery) => ({
      ...prevQuery,
      page: limintChange ? 0 : page - 1, // Update page to 5
      limit: pageSize, // Update limit to 3
    }));
  };

  const openCreateModal = () => {
    setOpenModal(true);
    // Explicitly set initial values for a new pavilion if required
    form.setFieldsValue(formTemplate);
  };

  const formatPhoneNumber = (phoneNumber: string) => {
    // Remove any non-numeric characters
    const cleanNumber = phoneNumber?.replace(/\D/g, "");

    // Check if the number has the expected length (13 digits for a number starting with 998)
    if (cleanNumber?.length === 12) {
      // Format the number as "+998 (99) 905-88-80"
      return `+${cleanNumber.slice(0, 3)} (${cleanNumber.slice(3, 5)}) ${cleanNumber.slice(
        5,
        8,
      )}-${cleanNumber.slice(8, 10)}-${cleanNumber.slice(10, 12)}`;
    } else {
      return "";
    }
  };

  return (
    <MainLayout>
      <Row className="pavilion-box ass-style">
        <Col span={24}>
          <div>
            <Breadcrumb items={breadcrumbItem} />
          </div>
        </Col>
        <Col span={24} className="add-pavilion-box">
          <Flex justify={"space-between"}>
            <Flex align={"center"}>
              <ArrowLeftOutlined style={{ marginRight: "16px", fontSize: "16px" }} />
              <Title level={4} className="m-0">
                {t("operators.list")}
              </Title>
            </Flex>

            <Flex align={"end"}>
              <Button
                onClick={openCreateModal}
                style={{ marginRight: "20px" }}
                className="add-pavilion"
                type="primary"
                shape="round"
                icon={<UserAddOutlined />}
                size="large"
              >
                {t("operators.add")}
              </Button>
            </Flex>
          </Flex>
        </Col>
      </Row>
      <Row>
        <Col span={24}>
          <ConfigProvider
            //@ts-ignore
            locale={{
              Pagination: {
                items_per_page: "/" + t("table.page"), // Sahifa hajmi matnini o'zgartirish
              },
            }}
          >
            <Table<OperatorType>
              className="ass-table"
              dataSource={loading ? [] : dataItem}
              rowKey={(record): React.Key => record.id}
              pagination={{
                current: query.page + 1,
                pageSize: query.limit,
                total: totalItem,
                onChange: handlePaginationChange,
                showSizeChanger: true,
                pageSizeOptions: ["10", "20", "50"], // Customize the available page sizes
              }}
              loading={loading}
              locale={{
                emptyText: loading ? <Skeleton active paragraph={{ rows: 5 }} /> : t("empty"),
              }}
            >
              <Column
                title={`${t("operators.avatar")}`}
                dataIndex="id"
                key="id"
                render={() => (
                  <Image
                    width={40}
                    height={40}
                    src="/images/avatar-default.png"
                    alt="empty"
                    preview={false}
                  />
                )}
              />
              <Column
                title={`${t("operators.fish")}`}
                dataIndex="id"
                key="id"
                render={(text, record) => (
                  <div>
                    <span>{record?.firstName}</span>
                    <span className="ml-2">{record?.lastName}</span>
                  </div>
                )}
              />
              <Column
                title={`${t("operators.rol")}`}
                dataIndex="roles"
                key="roles"
                render={(roles) =>
                  roles.length ? (
                    <Tag style={{ fontSize: "14px", padding: "5px 10px" }} color="#0F8FB0">
                      {roles[0]?.name}
                    </Tag>
                  ) : (
                    ""
                  )
                }
              />
              <Column
                title={`${t("operators.phone")}`}
                dataIndex="phone"
                key="phone"
                render={(phone) => formatPhoneNumber(phone)}
              />

              <Column
                title={`${t("operators.recentActivity")}`}
                dataIndex="lastActiveDate"
                key="lastActiveDate"
                render={(date: string) => (date?.length ? dateFormat(date) : "")}
              />
              <Column
                title={`${t("table.header.actions")}`}
                dataIndex="id"
                key="id"
                render={(id: number) => (
                  <div>
                    <Button onClick={() => itemDetailModal(id)} className="" shape="round">
                      <EyeOutlined />
                    </Button>
                    <Button
                      onClick={() => editItemModal(id)}
                      className="bg-primary color-white ml-2"
                      shape="round"
                    >
                      <EditOutlined />
                    </Button>
                    <Button danger className="ml-2" shape="round">
                      <UnlockOutlined />
                    </Button>
                    <Button
                      danger
                      disabled
                      onClick={() => deleteItemModal()}
                      className="ml-2"
                      shape="round"
                    >
                      <DeleteFilled />
                    </Button>
                  </div>
                )}
              />
            </Table>
          </ConfigProvider>
        </Col>
      </Row>
      <Row className="ass-style">
        <Modal
          className="ass-style ass-modal"
          centered
          open={openModal}
          title="Operatorni yaratish"
          onOk={handleOk}
          onCancel={closeModal}
          footer={[
            <Button key="close" onClick={closeModal}>
              {t("form.close")}
            </Button>,
            <Button
              key="create"
              className={!isButtonDisabled ? "" : "base-bg color-white"}
              disabled={!isButtonDisabled}
              onClick={handleOk}
              loading={formBtnLoading}
            >
              {t("form.create")}
            </Button>,
          ]}
        >
          <div className="ass-modal-body">
            <Skeleton loading={formBtnLoading} active paragraph={{ rows: 5 }}>
              <Form
                {...layout}
                initialValues={initialValuesItem}
                form={form}
                name="control-hooks"
                style={{ width: "650px", marginTop: "20px" }}
                autoComplete="off"
              >
                <Row>
                  <Col span={24} className="pavilion-input">
                    <Form.Item
                      name="firstName"
                      className="user-form-input"
                      label={`${t("operators.name")}`}
                      rules={cannotEmpty}
                    >
                      <Input placeholder={t("form.enterTitle")} />
                    </Form.Item>
                  </Col>
                  <Col span={24} className="pavilion-input">
                    <Form.Item
                      name="lastName"
                      label={`${t("operators.surname")}`}
                      className="user-form-input"
                      rules={cannotEmpty}
                    >
                      <Input placeholder={t("form.enterTitle")} />
                    </Form.Item>
                  </Col>
                  <Col span={24} className="pavilion-input">
                    <Form.Item
                      name="middleName"
                      className="user-form-input"
                      label={`${t("operators.middleName")}`}
                    >
                      <Input placeholder={t("form.enterTitle")} />
                    </Form.Item>
                  </Col>
                  <Col span={24} className="pavilion-input">
                    <Form.Item
                      name="username"
                      label={`${t("operators.login")}`}
                      className="user-form-input"
                      rules={cannotEmpty}
                    >
                      <Input placeholder={t("form.enterTitle")} />
                    </Form.Item>
                  </Col>
                  <Col span={24} className="pavilion-input">
                    <Form.Item
                      name="password"
                      className="user-form-input"
                      label={`${t("operators.password")}`}
                      rules={cannotEmpty}
                    >
                      <Input.Password placeholder={t("form.enterTitle")} />
                    </Form.Item>
                  </Col>
                  <Col span={24} className="pavilion-input">
                    <Form.Item
                      name="phone"
                      className="user-form-input"
                      label={`${t("operators.phone")}`}
                      rules={phoneLength}
                    >
                      <Input placeholder={t("form.enterTitle")} />
                    </Form.Item>
                  </Col>
                  <Col span={24} className="pavilion-input">
                    <Form.Item
                      className="user-form-input"
                      name="roleIds"
                      label={`${t("operators.rol")}`}
                      rules={cannotEmpty}
                    >
                      <Select
                        placeholder={`${t("table.header.select")}`}
                        onChange={(value) => {
                          if (!Array.isArray(value)) {
                            value = [value];
                          }
                          // Set form field with the array (to ensure it is always an array)
                          form.setFieldsValue({ roleIds: value });
                        }}
                      >
                        {/* Optionsni map qilish */}
                        {roleList.map((option) => (
                          <Select.Option key={option?.id} value={option?.id}>
                            {option?.name}
                          </Select.Option>
                        ))}
                      </Select>
                    </Form.Item>
                  </Col>
                  <Col span={24} className="pavilion-input">
                    <Form.Item
                      className="user-form-input"
                      name="permissionIds"
                      label={`${t("form.label.permissionsList")}`}
                      rules={cannotEmpty}
                    >
                      <Select mode="multiple" placeholder={`${t("table.header.select")}`}>
                        {/* Optionsni map qilish */}
                        {permissionList.map((option) => (
                          <Select.Option key={option?.id} value={option?.id}>
                            {option?.name}
                          </Select.Option>
                        ))}
                      </Select>
                    </Form.Item>
                  </Col>
                  <Col span={24} className="pavilion-input">
                    <Form.Item
                      className="user-form-input"
                      name="testTypeIds"
                      label={`${t("operators.session")}`}
                      rules={cannotEmpty}
                    >
                      <Select mode="multiple" placeholder={`${t("table.header.select")}`}>
                        {/* Optionsni map qilish */}
                        {testTypeList.map((option) => (
                          <Select.Option key={option?.id} value={option?.id}>
                            {option?.titleRu}
                          </Select.Option>
                        ))}
                      </Select>
                    </Form.Item>
                  </Col>
                </Row>
              </Form>
            </Skeleton>
          </div>
        </Modal>
      </Row>
      <Row className="ass-style">
        <Modal
          className="ass-style ass-modal"
          centered
          open={detailModal}
          title="Operatorni yaratish"
          onCancel={closeDetailModal}
          footer={[
            <Button key="close" onClick={closeDetailModal}>
              {t("form.close")}
            </Button>,
          ]}
        >
          <div className="ass-modal-body">
            <Skeleton loading={formBtnLoading} active paragraph={{ rows: 5 }}>
              <Row>
                <Col span={10} offset={2}>
                  <Card
                    cover={
                      <Image
                        style={{ width: "90%", display: "block", margin: "auto" }}
                        src="/images/avatar-default.png"
                        alt="empty"
                        preview={false}
                      />
                    }
                  >
                    <Meta
                      title={`${operatorDetail?.firstName} ${operatorDetail?.lastName}`}
                      description=""
                    />
                  </Card>
                </Col>
                <Col span={10} offset={1}>
                  <Card>
                    <div className="preaotor-detail mb-2">
                      <div className="detail-key">Login</div>
                      <div className="detail-item">{operatorDetail?.username}</div>
                    </div>
                    <div className="preaotor-detail mb-2">
                      <div className="detail-key">Ism</div>
                      <div className="detail-item">{operatorDetail?.firstName}</div>
                    </div>
                    <div className="preaotor-detail mb-2">
                      <div className="detail-key">Familiya</div>
                      <div className="detail-item">{operatorDetail?.lastName}</div>
                    </div>
                    <div className="preaotor-detail mb-2">
                      <div className="detail-key">Otasini ismi</div>
                      <div className="detail-item">{operatorDetail?.middleName}</div>
                    </div>
                    <div className="preaotor-detail mb-2">
                      <div className="detail-key">Rol</div>
                      <div className="detail-item">
                        {
                          // @ts-ignore
                          operatorDetail?.roles[0]?.name
                        }
                      </div>
                    </div>
                    <div className="preaotor-detail mb-2">
                      <div className="detail-key">Telefon raqami</div>
                      <div className="detail-item">
                        {operatorDetail?.phone ? formatPhoneNumber(operatorDetail?.phone) : ""}
                      </div>
                    </div>
                    <div className="preaotor-detail mb-2">
                      <div className="detail-key">Oxirgi faoliyat</div>
                      <div className="detail-item">
                        {operatorDetail?.lastActiveDate
                          ? dateFormat(operatorDetail?.lastActiveDate)
                          : ""}
                      </div>
                    </div>
                    <div className="preaotor-detail mb-2">
                      <div className="detail-key">Ro'yxatga otilgan sana</div>
                      <div className="detail-item">
                        {operatorDetail?.createdDate ? dateFormat(operatorDetail?.createdDate) : ""}
                      </div>
                    </div>
                  </Card>
                </Col>
              </Row>
            </Skeleton>
          </div>
        </Modal>
      </Row>
    </MainLayout>
  );
}
