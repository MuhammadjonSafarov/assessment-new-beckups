import {
  Col,
  Row,
  Breadcrumb,
  Flex,
  Typography,
  Button,
  Form,
  Input,
  Skeleton,
  Select,
  Upload,
  Image,
  UploadProps,
} from "antd";
import MainLayout from "@/components/layout/MainLayout";
import React, { useCallback, useEffect, useRef, useState } from "react";
import { useRouter } from "next/router";
import { axiosServer } from "@/plugins/axiosServer";
import { useAppSelector } from "@/hooks/hooks";
import type { GetProp, UploadFile } from "antd";
type FileType = Parameters<GetProp<UploadProps, "beforeUpload">>[0];
import QuestionCreate, { QuestionRef } from "@/components/toefl/QuestionCreate";

const getBase64 = (file: FileType): Promise<string> =>
  new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = () => resolve(reader.result as string);
    reader.onerror = (error) => reject(error);
  });

import { ArrowLeftOutlined, EditOutlined, HomeOutlined, PlusOutlined } from "@ant-design/icons";
import useTranslation from "next-translate/useTranslation";
import { cannotEmptyRules } from "@/helpers/validationRules";
import { toast } from "react-toastify";
import TinyMCEEditor from "@/components/TinyMCEEditor";
import { Option } from "rc-select";

export default function PassageCreate() {
  const { Title } = Typography;
  const body = useRef("");
  const [contentStatus, setContentStatus] = useState(false);
  const questionRef = useRef<QuestionRef>(null);

  const router = useRouter();
  const { locale } = router;
  const { t } = useTranslation("lang");
  const [form] = Form.useForm();
  const values: any = Form.useWatch([], form);
  const [formBtnLoading, setFormBtnLoading] = useState(false);
  const [fileList, setFileList] = useState<UploadFile[]>([]);

  const formTemplate = {
    name: "",
    body: "",
    fileId: undefined,
    orderNumber: undefined,
    questionIds: [],
  };
  const [isButtonDisabled, setIsButtonDisabled] = useState(false);
  const [previewImage, setPreviewImage] = useState("");
  const [previewOpen, setPreviewOpen] = useState(false);
  const [questionList, setQuestionList] = useState<any[]>([]);

  const cannotEmpty = cannotEmptyRules();
  const userInfo = useAppSelector((state) => state.user); // hooks/hooks.ts qo'shilgandan keyin shundoq ishlatsa buladi
  const breadcrumbItem = [
    {
      href: `/${locale}`,
      title: <HomeOutlined />,
    },
    {
      href: "",
      title: "TOEFL",
    },
    {
      title: `${t("menu.reading")}`,
    },
    {
      title: `${t("subPassage")}`,
    },
  ];

  useEffect(() => {
    form
      .validateFields({ validateOnly: true })
      .then(() => setIsButtonDisabled(true))
      .catch(() => setIsButtonDisabled(false));
    // console.log(555, form.getFieldsValue());
  }, [form, values]);
  const handleOk = async () => {
    const values = form.getFieldsValue();
    setFormBtnLoading(true);
    values.body = body?.current || "";
    values.isParent = false;
    await axiosServer(router.locale, false, userInfo?.token)
      .post("/api/v1/passsage", values)
      .then(() => {
        setFormBtnLoading(false);
        toast.success(`${t("toast.successfully")}`);
        form.setFieldsValue(formTemplate);
        redirectPassage();
      })
      .catch(() => {
        setFormBtnLoading(false);
      });
  };

  const redirectPassage = () => {
    router.push("/toefl/reading/sub-passage").catch(() => {
      // console.log(err)
    });
  };
  const handlePreview = async (file: UploadFile) => {
    if (!file.url && !file.preview) {
      file.preview = await getBase64(file.originFileObj as FileType);
    }

    setPreviewImage(file.url || (file.preview as string));
    setPreviewOpen(true);
  };
  const handleRemove = () => {
    // const fileId: number = file?.response?.id;
    // if (fileId) {
    form.setFieldsValue({ fileId: undefined });
    // }
  };
  const setContent = (value: string) => {
    body.current = value;
    setContentStatus(value ? true : false);
    // form.setFieldsValue({ body: value || "" });
  };
  const props2: UploadProps = {
    action: `${process.env.PUBLIC_API_SERVER_URL}/api/v1/file`,
    customRequest: async ({ file, onSuccess, onError }) => {
      const formData = new FormData();
      formData.append("file", file);

      try {
        await axiosServer(router.locale, false, userInfo?.token)
          .post(`/api/v1/file`, formData)
          .then((res: any) => {
            if (res?.id) {
              form.setFieldsValue({ fileId: res?.id || undefined });
              // @ts-ignore
              onSuccess(res);
            } else {
              // @ts-ignore
              onError(new Error("Upload failed"));
            }
          });
      } catch (error) {
        // @ts-ignore
        onError(error);
      }
    },
    fileList: fileList, // Pass fileList here
    onRemove: handleRemove, // Handle file removal
  };
  const handleChange: UploadProps["onChange"] = ({ fileList: newFileList }) => {
    setFileList(newFileList);
  };
  const uploadButton = (
    <button style={{ border: 0, background: "none" }} type="button">
      <PlusOutlined />
      <div style={{ marginTop: 8 }}>{t("sessionTypes.upload")}</div>
    </button>
  );
  const loadQuestionList = useCallback(async (value = "") => {
    const answerQuery = {
      page: 0,
      limit: 20,
      search: {
        value: value || undefined,
      },
    };
    await axiosServer(router.locale, false, userInfo?.token)
      .post(`/api/v1/question/list-search/READING`, answerQuery)
      .then((res: any) => {
        setQuestionList(res?.data?.list || []); // Update the state with the fetched data
      })
      .catch(() => {
        setQuestionList([]);
      });
  }, []);

  const selectItemSearch = (value: string) => {
    if (value && value.length > 1) {
      loadQuestionList(value);
    } else if (value === "") {
      loadQuestionList(value);
    }
  };
  const handleCreatedQuestion = (dataItem: any) => {
    // Masalan: toast ko‘rsatish, state yangilash, forma tozalash, h.k.
    if (dataItem.id) {
      const questionListItem = questionList.filter((item: any) => item.id !== dataItem.id);

      setQuestionList([...questionListItem, dataItem]);

      const prevQuestionIds = form.getFieldValue("questionIds")?.length
        ? form.getFieldValue("questionIds").filter((item: any) => item !== dataItem.id)
        : [];
      form.setFieldsValue({
        questionIds: [...prevQuestionIds, dataItem.id],
      });
    }
  };
  const editChildQuestion = (dataItem: any) => {
    questionRef?.current?.editItemModal(dataItem.id);
  };
  const addChildQuestion = () => {
    questionRef?.current?.openCreateModal();
  };
  useEffect(() => {
    (async () => {
      await loadQuestionList();
    })();
  }, [router.locale]);
  return (
    <MainLayout>
      <Row className="pavilion-box ass-style">
        <Col span={24}>
          <div>
            <Breadcrumb items={breadcrumbItem} />
          </div>
        </Col>

        <Col span={24} className="add-pavilion-box">
          <Flex justify={"space-between"}>
            <div>
              <Flex align={"center"}>
                <ArrowLeftOutlined
                  onClick={redirectPassage}
                  style={{ marginRight: "16px", fontSize: "16px" }}
                />
                <Title level={4} className="m-0">
                  {t("subPassageCreate")}
                </Title>
              </Flex>
            </div>
          </Flex>
        </Col>
      </Row>
      <Row className="pavilion-box ass-style">
        <Skeleton loading={formBtnLoading} active paragraph={{ rows: 5 }}>
          <Form
            form={form}
            layout="vertical"
            name="pavilion"
            style={{ width: "100%", marginTop: "20px" }}
            autoComplete="off"
          >
            <Row>
              <Col span={24} className="pavilion-input">
                <Form.Item name="name" label={`${t("table.header.title")}`} rules={cannotEmpty}>
                  <Input prefix={<EditOutlined />} placeholder={t("form.enterTitle")} />
                </Form.Item>
              </Col>

              <Col span={24} className="pavilion-input">
                <Form.Item name="orderNumber" label={`${t("index")}`} rules={cannotEmpty}>
                  <Input
                    type="number"
                    min={0}
                    placeholder={`${t("index")}`}
                    onChange={(e) =>
                      form.setFieldsValue({
                        orderNumber: e?.target?.value ? Number(e?.target?.value) : 0,
                      })
                    }
                  />
                </Form.Item>
              </Col>
              <Col span={24} className="pavilion-input">
                {/*<Form.Item name="body" label="Kontentni kiritin" rules={cannotEmpty}>*/}
                <div>
                  <label
                    className="red-star-before"
                    style={{ marginBottom: "8px", display: "block" }}
                  >
                    {t("content")}
                  </label>
                  <div></div>
                  <TinyMCEEditor onChange={(content: string) => setContent(content)} height={350} />
                </div>
                {/*</Form.Item>*/}
              </Col>
              <Col span={24} className="pavilion-input mt-3">
                <Form.Item name="fileId" label={`${t("picture")}`}>
                  <Upload
                    {...props2}
                    listType="picture-card"
                    fileList={fileList}
                    onPreview={handlePreview}
                    onChange={handleChange}
                  >
                    {fileList.length >= 1 ? null : uploadButton}
                  </Upload>
                  {previewImage && (
                    <Image
                      wrapperStyle={{ display: "none" }}
                      preview={{
                        visible: previewOpen,
                        onVisibleChange: (visible) => setPreviewOpen(visible),
                        afterOpenChange: (visible) => !visible && setPreviewImage(""),
                      }}
                      src={previewImage}
                    />
                  )}
                </Form.Item>
              </Col>
              <Col span={24} className="pavilion-input">
                <Form.Item name="innerTextType" label={`${t("table.header.type")}`}>
                  <Select
                    // onChange={() => form.setFieldsValue(templateChange)}
                    placeholder={t("table.header.type")}
                    allowClear
                  >
                    <Option value="FROM_TO">FROM TO</Option>
                    <Option value="SQUARE">SQUARE</Option>
                  </Select>
                </Form.Item>
              </Col>
              {/*<Col span={24} className="pavilion-input">*/}
              {/*  {values?.innerTextType === "SQUARE" && (*/}
              {/*    <Row>*/}
              {/*      <Col span={12} className="pavilion-input">*/}
              {/*        <Form.Item name="startIndex1" label="Index raqami 1" rules={cannotEmpty}>*/}
              {/*          <Input*/}
              {/*            type="number"*/}
              {/*            min={0}*/}
              {/*            placeholder="Index raqami 1"*/}
              {/*            onChange={(e) =>*/}
              {/*              form.setFieldsValue({*/}
              {/*                startIndex1: e?.target?.value ? Number(e?.target?.value) : 0,*/}
              {/*              })*/}
              {/*            }*/}
              {/*          />*/}
              {/*        </Form.Item>*/}
              {/*      </Col>*/}
              {/*      <Col span={12} className="pavilion-input">*/}
              {/*        <Form.Item name="startIndex2" label="Index raqami 2" rules={cannotEmpty}>*/}
              {/*          <Input*/}
              {/*            type="number"*/}
              {/*            min={0}*/}
              {/*            placeholder="Index raqami 2"*/}
              {/*            onChange={(e) =>*/}
              {/*              form.setFieldsValue({*/}
              {/*                startIndex2: e?.target?.value ? Number(e?.target?.value) : 0,*/}
              {/*              })*/}
              {/*            }*/}
              {/*          />*/}
              {/*        </Form.Item>*/}
              {/*      </Col>*/}
              {/*      <Col span={12} className="pavilion-input">*/}
              {/*        <Form.Item name="startIndex3" label="Index raqami 3" rules={cannotEmpty}>*/}
              {/*          <Input*/}
              {/*            type="number"*/}
              {/*            min={0}*/}
              {/*            placeholder="Index raqami 3"*/}
              {/*            onChange={(e) =>*/}
              {/*              form.setFieldsValue({*/}
              {/*                startIndex3: e?.target?.value ? Number(e?.target?.value) : 0,*/}
              {/*              })*/}
              {/*            }*/}
              {/*          />*/}
              {/*        </Form.Item>*/}
              {/*      </Col>*/}
              {/*      <Col span={12} className="pavilion-input">*/}
              {/*        <Form.Item name="startIndex4" label="Index raqami 4" rules={cannotEmpty}>*/}
              {/*          <Input*/}
              {/*            type="number"*/}
              {/*            min={0}*/}
              {/*            placeholder="Index raqami 4"*/}
              {/*            onChange={(e) =>*/}
              {/*              form.setFieldsValue({*/}
              {/*                startIndex4: e?.target?.value ? Number(e?.target?.value) : 0,*/}
              {/*              })*/}
              {/*            }*/}
              {/*          />*/}
              {/*        </Form.Item>*/}
              {/*      </Col>*/}
              {/*    </Row>*/}
              {/*  )}*/}
              {/*  {values?.innerTextType === "FROM_TO" && (*/}
              {/*    <Row>*/}
              {/*      <Col span={12} className="pavilion-input">*/}
              {/*        <Form.Item*/}
              {/*          name="beginIndex"*/}
              {/*          label="Boshlang'ich index raqami"*/}
              {/*          rules={cannotEmpty}*/}
              {/*        >*/}
              {/*          <Input*/}
              {/*            type="number"*/}
              {/*            min={0}*/}
              {/*            placeholder="Boshlang'ich index raqami"*/}
              {/*            onChange={(e) =>*/}
              {/*              form.setFieldsValue({*/}
              {/*                beginIndex: e?.target?.value ? Number(e?.target?.value) : 0,*/}
              {/*              })*/}
              {/*            }*/}
              {/*          />*/}
              {/*        </Form.Item>*/}
              {/*      </Col>*/}
              {/*      <Col span={12} className="pavilion-input">*/}
              {/*        <Form.Item name="endIndex" label="Tugash index raqami" rules={cannotEmpty}>*/}
              {/*          <Input*/}
              {/*            type="number"*/}
              {/*            min={0}*/}
              {/*            placeholder="Tugash index raqami"*/}
              {/*            onChange={(e) =>*/}
              {/*              form.setFieldsValue({*/}
              {/*                endIndex: e?.target?.value ? Number(e?.target?.value) : 0,*/}
              {/*              })*/}
              {/*            }*/}
              {/*          />*/}
              {/*        </Form.Item>*/}
              {/*      </Col>*/}
              {/*    </Row>*/}
              {/*  )}*/}
              {/*</Col>*/}
              <Col span={24} className="pavilion-input">
                <Form.Item name="questionIds" label={`${t("menu.questions")}`}>
                  <Select
                    mode="multiple"
                    placeholder={`${t("table.header.select")}`}
                    onSearch={($event) => {
                      selectItemSearch($event);
                    }}
                    showSearch
                    filterOption={false}
                  >
                    {/* Optionsni map qilish */}
                    {questionList?.map((option: any) => (
                      <Select.Option key={option?.id} value={option?.id}>
                        {option?.name}
                        <EditOutlined
                          onMouseDown={(e) => {
                            e.preventDefault(); // input focus tushmasligi uchun
                            e.stopPropagation(); // boshqa eventlar to‘xtaydi
                          }}
                          unselectable="on"
                          style={{ userSelect: "none" }}
                          onClick={(e) => {
                            e.stopPropagation();
                            e.preventDefault();
                            editChildQuestion(option);
                          }}
                        />
                      </Select.Option>
                    ))}
                  </Select>
                </Form.Item>
                <Button className="mb-3" onClick={addChildQuestion}>
                  + {t("addQuestions")}
                </Button>
              </Col>
              {/*<Col span={24} className="pavilion-input">*/}
              {/*  <Form.Item name="time" label="Vaqtni kiriting (min)">*/}
              {/*    <Input*/}
              {/*      type="number"*/}
              {/*      min={0}*/}
              {/*      placeholder="Vaqtni kiriting (min)"*/}
              {/*      onChange={(e) =>*/}
              {/*        form.setFieldsValue({*/}
              {/*          time: e?.target?.value ? Number(e?.target?.value) : 0,*/}
              {/*        })*/}
              {/*      }*/}
              {/*    />*/}
              {/*  </Form.Item>*/}
              {/*</Col>*/}

              <Col span={24} className="pavilion-input">
                <Button
                  key="create"
                  className={!isButtonDisabled || !contentStatus ? "" : "base-bg color-white"}
                  disabled={!isButtonDisabled || !contentStatus}
                  onClick={handleOk}
                  loading={formBtnLoading}
                >
                  {t("form.create")}
                </Button>
              </Col>
            </Row>
          </Form>
        </Skeleton>
      </Row>
      <Row gutter={24}>
        <QuestionCreate
          ref={questionRef}
          questionType="READING"
          onCreated={handleCreatedQuestion}
        />
      </Row>
    </MainLayout>
  );
}
