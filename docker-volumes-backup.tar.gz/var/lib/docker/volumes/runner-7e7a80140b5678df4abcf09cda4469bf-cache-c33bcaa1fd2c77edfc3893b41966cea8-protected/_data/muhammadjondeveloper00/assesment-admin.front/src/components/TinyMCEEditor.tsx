"use client";

import React, { useEffect, useRef, useState } from "react";

declare global {
  interface Window {
    tinymce?: any;
  }
}

const tinymceCDN = "https://cdn.jsdelivr.net/npm/tinymce-all-in-one@4.9.3/tinymce.min.js";

interface TinyMCEEditorProps {
  id?: string;
  value?: string;
  onChange?: (content: string) => void;
  height?: number;
  width?: string;
}

const TinyMCEEditor = React.memo(
  ({ id, value = "", onChange, height = 360, width = "auto" }: TinyMCEEditorProps) => {
    const editorRef = useRef<any>(null);
    const [editorId] = useState(id || `tinymce-editor-${Date.now()}`);

    useEffect(() => {
      const loadScript = (src: string, callback: () => void) => {
        if (document.getElementById(src)) {
          return callback();
        }
        const script = document.createElement("script");
        script.src = src;
        script.id = src;
        script.onload = callback;
        script.onerror = () => console.error("Failed to load TinyMCE script");
        document.body.appendChild(script);
      };

      loadScript(tinymceCDN, () => {
        if (window.tinymce) {
          window.tinymce.init({
            selector: `#${editorId}`,
            height,
            width,
            menubar: false,
            plugins: "link image code",
            toolbar:
              "undo redo | formatselect | bold italic | alignleft aligncenter alignright | code",
            setup: (editor: any) => {
              editorRef.current = editor;
              editor.on("init", () => {
                editor.setContent(value || "");
              });
              editor.on("input change keyup", () => {
                onChange && onChange(editor.getContent());
              });
            },
          });
        }
      });

      return () => {
        if (window.tinymce) {
          window.tinymce.remove(`#${editorId}`);
        }
      };
    }, [editorId, height, width]); // `value` va `onChange` ni dependency sifatida qo‘shmadik

    useEffect(() => {
      if (editorRef.current && window.tinymce) {
        const editor = editorRef.current;
        if (editor.getContent() !== value) {
          editor.setContent(value || "");
        }
      }
    }, [value]);

    return (
      <div style={{ width }}>
        <textarea id={editorId} style={{ visibility: "hidden" }} />
      </div>
    );
  },
);

// Display name qo'shish (React DevTools uchun)
TinyMCEEditor.displayName = "TinyMCEEditor";

export default TinyMCEEditor;
