import MainLayout from "@/components/layout/MainLayout";
import MyId from "@/components/myId";

export default function Candidates() {
  return <MainLayout> {<MyId />}</MainLayout>;
}
