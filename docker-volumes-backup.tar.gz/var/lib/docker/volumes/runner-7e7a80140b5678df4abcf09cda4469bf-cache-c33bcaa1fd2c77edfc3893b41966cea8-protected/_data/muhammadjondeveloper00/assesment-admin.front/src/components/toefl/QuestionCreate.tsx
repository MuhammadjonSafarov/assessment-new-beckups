import {
  Col,
  Row,
  Flex,
  Button,
  Modal,
  Form,
  Input,
  Skeleton,
  Select,
  Collapse,
  Switch,
} from "antd";
import React, { useEffect, useState, forwardRef, useImperativeHandle } from "react";
import { useRouter } from "next/router";
import { axiosServer } from "@/plugins/axiosServer";
import { useAppSelector } from "@/hooks/hooks";
import type { CollapseProps } from "antd";
import { EditOutlined } from "@ant-design/icons";
import useTranslation from "next-translate/useTranslation";
import { cannotEmptyRules } from "@/helpers/validationRules";
import { toast } from "react-toastify";
export type QuestionRef = {
  openCreateModal: () => void;
  editItemModal: (id: number) => void;
};
type QuestionCreateProps = {
  onCreated?: (data: any) => void; // Parentga signal
  questionType?: string;
};
const QuestionCreate = forwardRef<QuestionRef, QuestionCreateProps>(
  ({ onCreated, questionType }, ref) => {
    const router = useRouter();
    const { t } = useTranslation("lang");
    const [form] = Form.useForm();
    const values: any = Form.useWatch([], form);
    const [openModal, setOpenModal] = useState(false);
    const [formBtnLoading, setFormBtnLoading] = useState(false);
    const [editLineId, setEditLineId] = useState(0);
    const [answerList, setAnswerList] = useState([]);

    // console.log(666666, filter.current);
    const formTemplate = {
      name: "",
      correctAnswersCount: undefined,
      coefficient: undefined,
      answerIds: [],
    };
    const [isButtonDisabled, setIsButtonDisabled] = useState(false);
    const [answerItem, setAnswerItem] = useState({
      answer: "",
      isCorrect: false,
    });
    const [activeKey, setActiveKey] = useState<string | string[]>(""); // Default to open the first item

    const [initialValuesItem, setIsInitialValues] = useState<any>({ isRent: false });
    const cannotEmpty = cannotEmptyRules();
    const userInfo = useAppSelector((state) => state.user); // hooks/hooks.ts qo'shilgandan keyin shundoq ishlatsa buladi
    const isGetAllPermissionsChange = (e: any) => {
      // form.setFieldsValue({ permissionIds: undefined });
      setAnswerItem((prev) => ({
        ...prev, // Spread previous state
        isCorrect: e || false, // Update the answer property
      }));
    };
    const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
      setAnswerItem((prev) => ({
        ...prev, // Spread previous state
        answer: e.target.value, // Update the answer property
      }));
    };
    const questionCreate = async () => {
      await axiosServer(router.locale, true, userInfo?.token)
        .post("/api/v1/answer", answerItem)
        .then((res) => {
          setAnswerItem({ answer: "", isCorrect: false });
          toast.success(`${t("toast.successfully")}`);
          setAnswerList((prevList): any => [...prevList, res.data]); // Create a new array with the new answer added
        })
        .catch(() => "");
    };
    const itemsCollapse: CollapseProps["items"] = [
      {
        key: "1",
        label: <h3 className="m-0">{t("answer.add")}</h3>,
        children: (
          <div>
            <Row>
              <Col span={24} className="pavilion-input">
                <Form.Item label={`${t("table.header.title")}`} rules={cannotEmpty}>
                  <Input
                    value={answerItem.answer}
                    prefix={<EditOutlined />}
                    placeholder={t("form.enterTitle")}
                    onChange={(e) => handleChange(e)}
                  />
                </Form.Item>
              </Col>

              <Col span={24} className="pavilion-input" style={{ textAlign: "left" }}>
                <Form.Item label={`${t("answer.correct")}`}>
                  <Switch
                    value={answerItem.isCorrect}
                    onChange={isGetAllPermissionsChange}
                    checkedChildren={t("form.yes")}
                    unCheckedChildren={t("form.no")}
                  />
                </Form.Item>
              </Col>
              <Flex justify={"end"} style={{ width: "100%" }}>
                <Button onClick={() => setActiveKey("")}>{t("form.close")}</Button>{" "}
                <Button
                  className={!answerItem?.answer ? "ml-1" : "base-bg color-white ml-1"}
                  disabled={!answerItem?.answer}
                  onClick={questionCreate}
                >
                  {t("form.create")}
                </Button>
              </Flex>
            </Row>
          </div>
        ),
      },
    ];

    useEffect(() => {
      form
        .validateFields({ validateOnly: true })
        .then(() => setIsButtonDisabled(true))
        .catch(() => setIsButtonDisabled(false));
      // console.log(555, form.getFieldsValue());
    }, [form, values]);
    const handleOk = async () => {
      const values = form.getFieldsValue();
      if (editLineId) {
        setFormBtnLoading(true);
        await axiosServer(router.locale, false, userInfo?.token)
          .put(`/api/v1/question/${editLineId}`, {
            ...values,
            questionType: questionType ? questionType : "",
          })
          .then((res: any) => {
            onCreated?.(res);
            setAnswerList([]);
            setEditLineId(0);
            toast.success(`${t("toast.successfully")}`);
            form.setFieldsValue(formTemplate);
            setFormBtnLoading(false);
            setOpenModal(false);
          })
          .catch(() => {
            setFormBtnLoading(false);
          });
      } else {
        await axiosServer(router.locale, false, userInfo?.token)
          .post("/api/v1/question", {
            ...values,
            questionType: questionType ? questionType : "",
          })
          .then((res: any) => {
            setAnswerList([]);
            toast.success(`${t("toast.successfully")}`);
            form.setFieldsValue(formTemplate);
            setOpenModal(false);
            onCreated?.(res);
          })
          .catch(() => "");
      }
    };
    const editItemModal = async (id: number) => {
      form.setFieldsValue(formTemplate);
      // console.log("eeeeee", values);
      if (id) {
        setEditLineId(id);
        setOpenModal(true);
        setFormBtnLoading(true);
        await axiosServer(router.locale, false, userInfo?.token)
          .get(`/api/v1/question/${id}`)
          .then((res: any) => {
            setFormBtnLoading(false);

            if (res) {
              const data = res;
              if (res?.answers?.length) {
                setAnswerList(res.answers);
                const answerIds = res.answers.map((item: any) => item.id);
                data.answerIds = answerIds || [];
              }
              setIsInitialValues(data);
              form.setFieldsValue(data);
            }
          })
          .catch(() => {
            setFormBtnLoading(false);
          });
      }
    };

    const closeModal = () => {
      setAnswerList([]);
      setEditLineId(0);
      form.setFieldsValue(formTemplate);
      setIsInitialValues(formTemplate);
      setOpenModal(false);
    };
    // Handle pagination changes

    const openCreateModal = () => {
      setOpenModal(true);
      // Explicitly set initial values for a new pavilion if required
      form.setFieldsValue(formTemplate);
    };
    useImperativeHandle(ref, () => ({
      openCreateModal,
      editItemModal,
    }));

    return (
      <>
        <Row className="ass-style">
          <Modal
            className="ass-style ass-modal ass-modal-small"
            centered
            open={openModal}
            title={`${t("createQuestions")}`}
            onOk={handleOk}
            onCancel={closeModal}
            footer={[
              <Button key="close" onClick={closeModal}>
                {t("form.close")}
              </Button>,
              <Button
                key="create"
                className={!isButtonDisabled ? "" : "base-bg color-white"}
                disabled={!isButtonDisabled}
                onClick={handleOk}
                loading={formBtnLoading}
              >
                {t("form.create")}
              </Button>,
            ]}
          >
            <div className="ass-modal-body">
              <Skeleton loading={formBtnLoading} active paragraph={{ rows: 5 }}>
                <Form
                  initialValues={initialValuesItem}
                  form={form}
                  layout="vertical"
                  name="pavilion"
                  style={{ width: "100%", marginTop: "20px" }}
                  autoComplete="off"
                >
                  <Row>
                    <Col span={24} className="pavilion-input">
                      <Form.Item
                        name="name"
                        label={`${t("table.header.title")}`}
                        rules={cannotEmpty}
                      >
                        <Input prefix={<EditOutlined />} placeholder={t("form.enterTitle")} />
                      </Form.Item>
                    </Col>

                    <Col span={24} className="pavilion-input">
                      <Form.Item name="correctAnswersCount" label={`${t("enterCorrectNumber")}`}>
                        <Input
                          type="number"
                          min={0}
                          placeholder={`${t("correctNumber")}`}
                          onChange={(e) =>
                            form.setFieldsValue({
                              correctAnswersCount: e?.target?.value ? Number(e?.target?.value) : 0,
                            })
                          }
                        />
                      </Form.Item>
                    </Col>
                    <Col span={24} className="pavilion-input">
                      <Form.Item
                        name="coefficient"
                        label={`${t("coefficient")}`}
                        rules={cannotEmpty}
                      >
                        <Input
                          type="number"
                          min={0}
                          placeholder={`${t("enterCoefficient")}`}
                          onChange={(e) =>
                            form.setFieldsValue({
                              coefficient: e?.target?.value ? Number(e?.target?.value) : 0,
                            })
                          }
                        />
                      </Form.Item>
                    </Col>
                    <Col span={24} className="pavilion-input">
                      {/*<div style={{ textAlign: "center" }}>Savol yaratish</div>*/}
                      <div className="mt-1" style={{ textAlign: "center" }}>
                        <Collapse
                          activeKey={activeKey}
                          items={itemsCollapse}
                          onChange={(key) => setActiveKey(key)}
                        />
                      </div>
                    </Col>
                    <Col span={24} className="pavilion-input mt-3">
                      <Form.Item name="answerIds" label={`${t("attachmentAnswers")}`}>
                        <Select
                          mode="multiple"
                          placeholder={`${t("attachmentAnswers")}`}
                          // onSearch={($event) => {
                          //   answerSearch($event);
                          // }}
                          showSearch
                          filterOption={false}
                        >
                          {/* Optionsni map qilish */}
                          {answerList?.map((option: any) => (
                            <Select.Option key={option?.id} value={option?.id}>
                              {option?.answer}
                            </Select.Option>
                          ))}
                        </Select>
                      </Form.Item>
                    </Col>
                  </Row>
                </Form>
              </Skeleton>
            </div>
          </Modal>
        </Row>
      </>
    );
  },
);
export default QuestionCreate;
