import {
  Col,
  Row,
  Breadcrumb,
  Flex,
  Typography,
  Button,
  Modal,
  Form,
  Input,
  Table,
  ConfigProvider,
  Skeleton,
  Select,
  Collapse,
  Switch,
} from "antd";
import MainLayout from "@/components/layout/MainLayout";
import React, { useCallback, useEffect, useState } from "react";
import { useRouter } from "next/router";
import { axiosServer } from "@/plugins/axiosServer";
import { useAppSelector } from "@/hooks/hooks";
import type { CollapseProps } from "antd";
const { Column } = Table;
import {
  ArrowLeftOutlined,
  DeleteOutlined,
  EditOutlined,
  HomeOutlined,
  QuestionCircleOutlined,
} from "@ant-design/icons";
import useTranslation from "next-translate/useTranslation";
import { cannotEmptyRules } from "@/helpers/validationRules";
import { toast } from "react-toastify";
import { PermissionType } from "@/dto/AppDTO";

export default function Questions() {
  const { Title } = Typography;
  const router = useRouter();
  const { locale } = router;
  const { t } = useTranslation("lang");
  const [form] = Form.useForm();
  const values: any = Form.useWatch([], form);
  const [dataItem, setDataItem] = useState<PermissionType[]>([]);
  const [openModal, setOpenModal] = useState(false);
  const [loading, setLoading] = useState(false);
  const [formBtnLoading, setFormBtnLoading] = useState(false);
  const [editLineId, setEditLineId] = useState(0);
  const [totalItem, setTotalItem] = useState(1);
  const [answerList, setAnswerList] = useState([]);

  // console.log(666666, filter.current);
  const [query, setquery] = useState({
    page: 0,
    limit: 10,
    search: {},
  });
  const formTemplate = {
    name: "",
    correctAnswersCount: undefined,
    coefficient: undefined,
    answerIds: [],
  };
  const [modal, contextHolder] = Modal.useModal();
  const [isButtonDisabled, setIsButtonDisabled] = useState(false);
  const [answerItem, setAnswerItem] = useState({
    answer: "",
    isCorrect: false,
  });
  const [activeKey, setActiveKey] = useState<string | string[]>(""); // Default to open the first item

  const [initialValuesItem, setIsInitialValues] = useState<any>({ isRent: false });
  const cannotEmpty = cannotEmptyRules();
  const userInfo = useAppSelector((state) => state.user); // hooks/hooks.ts qo'shilgandan keyin shundoq ishlatsa buladi
  const breadcrumbItem = [
    {
      href: `/${locale}`,
      title: <HomeOutlined />,
    },
    {
      href: "",
      title: "TOEFL",
    },
    {
      title: `${t("menu.questions")}`,
    },
  ];
  const isGetAllPermissionsChange = (e: any) => {
    // form.setFieldsValue({ permissionIds: undefined });
    setAnswerItem((prev) => ({
      ...prev, // Spread previous state
      isCorrect: e || false, // Update the answer property
    }));
  };
  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setAnswerItem((prev) => ({
      ...prev, // Spread previous state
      answer: e.target.value, // Update the answer property
    }));
  };
  const questionCreate = async () => {
    await axiosServer(router.locale, true, userInfo?.token)
      .post("/api/v1/answer", answerItem)
      .then((res) => {
        setAnswerItem({ answer: "", isCorrect: false });
        toast.success(`${t("toast.successfully")}`);
        setAnswerList((prevList): any => [...prevList, res.data]); // Create a new array with the new answer added
      })
      .catch(() => "");
  };
  const itemsCollapse: CollapseProps["items"] = [
    {
      key: "1",
      label: <h3 className="m-0">{t("answer.add")}</h3>,
      children: (
        <div>
          <Row>
            <Col span={24} className="pavilion-input">
              <Form.Item label={`${t("table.header.title")}`} rules={cannotEmpty}>
                <Input
                  value={answerItem.answer}
                  prefix={<EditOutlined />}
                  placeholder={t("form.enterTitle")}
                  onChange={(e) => handleChange(e)}
                />
              </Form.Item>
            </Col>

            <Col span={24} className="pavilion-input" style={{ textAlign: "left" }}>
              <Form.Item label={`${t("answer.correct")}`}>
                <Switch
                  value={answerItem.isCorrect}
                  onChange={isGetAllPermissionsChange}
                  checkedChildren={t("form.yes")}
                  unCheckedChildren={t("form.no")}
                />
              </Form.Item>
            </Col>
            <Flex justify={"end"} style={{ width: "100%" }}>
              <Button onClick={() => setActiveKey("")}>{t("form.close")}</Button>{" "}
              <Button
                className={!answerItem?.answer ? "ml-1" : "base-bg color-white ml-1"}
                disabled={!answerItem?.answer}
                onClick={questionCreate}
              >
                {t("form.create")}
              </Button>
            </Flex>
          </Row>
        </div>
      ),
    },
  ];
  const confirmModal = (id: number) => {
    modal.confirm({
      title: "",
      icon: <QuestionCircleOutlined style={{ marginTop: "10px" }} />,
      content: <h3>{t("deleteConfirmation")}</h3>,
      okText: t("form.yes"),
      cancelText: t("form.no"),
      onOk() {
        deleteLine(id);
      },
      onCancel() {
        // console.log("Cancel");
      },
      okButtonProps: {
        style: {
          backgroundColor: "#ff4d4f",
          color: "white",
          border: "none",
        },
      },
    });
  };

  // Define the function to load pavilion data
  const loadData = useCallback(async () => {
    setLoading(true);
    // console.log(88888, filter?.current);
    await axiosServer(router.locale, false, userInfo?.token)
      .post(`/api/v1/question/list-search/READING`, query)
      .then((res: any) => {
        setLoading(false);
        setTotalItem(res?.data?.total || 1);
        setDataItem(res?.data?.list || []); // Update the state with the fetched data
      })
      .catch(() => {
        setDataItem([]);
        setLoading(false);
      });
  }, [router.locale, query]);
  // const loadAnswerList = useCallback(async (value = "") => {
  //   const answerQuery = {
  //     page: 0,
  //     limit: 100,
  //     search: {
  //       answer: value || undefined,
  //     },
  //   };
  //   await axiosServer(router.locale, false, userInfo?.token)
  //     .post(`/api/v1/answer/list-search`, answerQuery)
  //     .then((res: any) => {
  //       setAnswerList(res?.data?.list || []); // Update the state with the fetched data
  //     })
  //     .catch(() => {
  //       setAnswerList([]);
  //     });
  // }, []);

  useEffect(() => {
    (async () => {
      await loadData();
      // await loadAnswerList();
    })();
  }, [router.locale, query]);

  useEffect(() => {
    form
      .validateFields({ validateOnly: true })
      .then(() => setIsButtonDisabled(true))
      .catch(() => setIsButtonDisabled(false));
    // console.log(555, form.getFieldsValue());
  }, [form, values]);
  const handleOk = async () => {
    const values = form.getFieldsValue();
    if (editLineId) {
      setFormBtnLoading(true);
      await axiosServer(router.locale, false, userInfo?.token)
        .put(`/api/v1/question/${editLineId}`, { ...values, questionType: "READING" })
        .then(() => {
          setEditLineId(0);
          toast.success(`${t("toast.successfully")}`);
          form.setFieldsValue(formTemplate);
          setFormBtnLoading(false);
          setOpenModal(false);
          loadData();
        })
        .catch(() => {
          setFormBtnLoading(false);
        });
    } else {
      await axiosServer(router.locale, false, userInfo?.token)
        .post("/api/v1/question", { ...values, questionType: "READING" })
        .then(() => {
          toast.success(`${t("toast.successfully")}`);
          form.setFieldsValue(formTemplate);
          setOpenModal(false);
          loadData();
        })
        .catch(() => "");
    }
  };
  const editItemModal = async (id: number) => {
    form.setFieldsValue(formTemplate);
    // console.log("eeeeee", values);
    if (id) {
      setEditLineId(id);
      setOpenModal(true);
      setFormBtnLoading(true);
      await axiosServer(router.locale, false, userInfo?.token)
        .get(`/api/v1/question/${id}`)
        .then((res: any) => {
          setFormBtnLoading(false);

          if (res) {
            const data = res;
            if (res?.answers?.length) {
              setAnswerList(res.answers);
              const answerIds = res.answers.map((item: any) => item.id);
              data.answerIds = answerIds || [];
            }
            setIsInitialValues(data);
            form.setFieldsValue(data);
          }
        })
        .catch(() => {
          setFormBtnLoading(false);
        });
    }
  };

  const deleteItemModal = (id: number) => {
    // console.log("Delete Itemmm", id);
    if (!id) return;
    confirmModal(id);
  };

  const closeModal = () => {
    setEditLineId(0);
    form.setFieldsValue(formTemplate);
    setIsInitialValues(formTemplate);
    setOpenModal(false);
    setAnswerList([]);
  };
  // Handle pagination changes
  const handlePaginationChange = (page: number, pageSize: number) => {
    const limintChange = page - 1 === query.page;
    setquery((prevQuery) => ({
      ...prevQuery,
      page: limintChange ? 0 : page - 1, // Update page to 5
      limit: pageSize, // Update limit to 3
    }));
  };

  const openCreateModal = () => {
    setOpenModal(true);
    // Explicitly set initial values for a new pavilion if required
    form.setFieldsValue(formTemplate);
  };

  // useCallback(async () => {}, [router.locale, filter]);
  const deleteLine = async (id: number) => {
    if (!id) return;
    await axiosServer(router.locale, false, userInfo?.token)
      .delete(`/api/v1/question/${id}`)
      .then(() => {
        toast.success(`${t("toast.successfully")}`);
        loadData();
      })
      .catch(() => "");
  };
  // const answerSearch = (value: string) => {
  //   if (value && value.length > 1) {
  //     loadAnswerList(value);
  //   }
  // };
  return (
    <MainLayout>
      <Row className="pavilion-box ass-style">
        <Col span={24}>
          <div>
            <Breadcrumb items={breadcrumbItem} />
          </div>
        </Col>
        <Col span={24} className="add-pavilion-box">
          <Flex justify={"space-between"}>
            <div>
              <Flex align={"center"}>
                <ArrowLeftOutlined style={{ marginRight: "16px", fontSize: "16px" }} />
                <Title level={4} className="m-0">
                  {t("menu.list")}
                </Title>
              </Flex>
            </div>
            <Flex align={"end"}>
              <Button
                onClick={openCreateModal}
                style={{ marginRight: "20px" }}
                className="add-pavilion"
                type="primary"
                shape="round"
                size="large"
              >
                {t("createQuestions")}
              </Button>
            </Flex>
          </Flex>
        </Col>
      </Row>
      <Row>
        <Col span={24}>
          <ConfigProvider
            //@ts-ignore
            locale={{
              Pagination: {
                items_per_page: "/" + t("table.page"), // Sahifa hajmi matnini o'zgartirish
              },
            }}
          >
            <Table<PermissionType>
              className="ass-table"
              dataSource={loading ? [] : dataItem}
              rowKey={(record): React.Key => record.id}
              pagination={{
                current: query.page + 1,
                pageSize: query.limit,
                total: totalItem,
                onChange: handlePaginationChange,
                showSizeChanger: true,
                pageSizeOptions: ["10", "20", "50"], // Customize the available page sizes
              }}
              loading={loading}
              locale={{
                emptyText: loading ? <Skeleton active paragraph={{ rows: 5 }} /> : t("empty"),
              }}
            >
              <Column title="#" dataIndex="id" key="id" />
              <Column
                title={`${t("table.header.title")}`}
                dataIndex="name"
                key="name"
                render={(name: string) => <div style={{ maxWidth: "250px" }}>{name}</div>}
              />
              <Column
                title={`${t("enterCorrectNumber")}`}
                dataIndex="correctAnswersCount"
                key="correctAnswersCount"
              />

              <Column
                title={`${t("table.header.actions")}`}
                dataIndex="id"
                key="id"
                render={(id: number) => (
                  <div>
                    <Button
                      onClick={() => editItemModal(id)}
                      className="bg-primary color-white"
                      shape="round"
                    >
                      <EditOutlined />
                    </Button>
                    <Button
                      danger
                      onClick={() => deleteItemModal(id)}
                      className="ml-2"
                      shape="round"
                    >
                      <DeleteOutlined />
                    </Button>
                  </div>
                )}
              />
            </Table>
          </ConfigProvider>
        </Col>
      </Row>
      <Row className="ass-style">
        <Modal
          className="ass-style ass-modal ass-modal-small"
          centered
          open={openModal}
          title={`${t("createQuestions")}`}
          onOk={handleOk}
          onCancel={closeModal}
          footer={[
            <Button key="close" onClick={closeModal}>
              {t("form.close")}
            </Button>,
            <Button
              key="create"
              className={!isButtonDisabled ? "" : "base-bg color-white"}
              disabled={!isButtonDisabled}
              onClick={handleOk}
              loading={formBtnLoading}
            >
              {t("form.create")}
            </Button>,
          ]}
        >
          <div className="ass-modal-body">
            <Skeleton loading={formBtnLoading} active paragraph={{ rows: 5 }}>
              <Form
                initialValues={initialValuesItem}
                form={form}
                layout="vertical"
                name="pavilion"
                style={{ width: "100%", marginTop: "20px" }}
                autoComplete="off"
              >
                <Row>
                  <Col span={24} className="pavilion-input">
                    <Form.Item name="name" label={`${t("table.header.title")}`} rules={cannotEmpty}>
                      <Input prefix={<EditOutlined />} placeholder={t("form.enterTitle")} />
                    </Form.Item>
                  </Col>

                  <Col span={24} className="pavilion-input">
                    <Form.Item name="correctAnswersCount" label={`${t("enterCorrectNumber")}`}>
                      <Input
                        type="number"
                        min={0}
                        placeholder="To'g'ri javoblar sonini kiriting"
                        onChange={(e) =>
                          form.setFieldsValue({
                            correctAnswersCount: e?.target?.value ? Number(e?.target?.value) : 0,
                          })
                        }
                      />
                    </Form.Item>
                  </Col>
                  <Col span={24} className="pavilion-input">
                    <Form.Item name="coefficient" label={`${t("coefficient")}`} rules={cannotEmpty}>
                      <Input
                        type="number"
                        min={0}
                        placeholder={`${t("enterCoefficient")}`}
                        onChange={(e) =>
                          form.setFieldsValue({
                            coefficient: e?.target?.value ? Number(e?.target?.value) : 0,
                          })
                        }
                      />
                    </Form.Item>
                  </Col>
                  <Col span={24} className="pavilion-input">
                    {/*<div style={{ textAlign: "center" }}>Savol yaratish</div>*/}
                    <div className="mt-1" style={{ textAlign: "center" }}>
                      <Collapse
                        activeKey={activeKey}
                        items={itemsCollapse}
                        onChange={(key) => setActiveKey(key)}
                      />
                    </div>
                  </Col>
                  <Col span={24} className="pavilion-input mt-3">
                    <Form.Item name="answerIds" label={`${t("attachmentAnswers")}`}>
                      <Select
                        mode="multiple"
                        placeholder={`${t("attachmentAnswers")}`}
                        // onSearch={($event) => {
                        //   answerSearch($event);
                        // }}
                        showSearch
                        filterOption={false}
                      >
                        {/* Optionsni map qilish */}
                        {answerList?.map((option: any) => (
                          <Select.Option key={option?.id} value={option?.id}>
                            {option?.answer}
                          </Select.Option>
                        ))}
                      </Select>
                    </Form.Item>
                  </Col>
                </Row>
              </Form>
            </Skeleton>
          </div>
        </Modal>
      </Row>
      <Row>
        <Col span={24}>{contextHolder}</Col>
      </Row>
    </MainLayout>
  );
}
