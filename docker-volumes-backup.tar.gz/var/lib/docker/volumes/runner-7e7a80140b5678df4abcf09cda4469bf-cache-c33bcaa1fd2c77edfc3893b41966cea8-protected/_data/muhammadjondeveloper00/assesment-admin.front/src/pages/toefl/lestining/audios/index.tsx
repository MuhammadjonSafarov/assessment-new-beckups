import {
  Col,
  Row,
  Breadcrumb,
  Flex,
  Typography,
  Button,
  Modal,
  Form,
  Input,
  Table,
  ConfigProvider,
  Skeleton,
  Select,
  Upload,
  UploadProps,
  Image,
} from "antd";
import MainLayout from "@/components/layout/MainLayout";
import React, { useCallback, useEffect, useRef, useState } from "react";
import { useRouter } from "next/router";
import { axiosServer } from "@/plugins/axiosServer";
import { useAppSelector } from "@/hooks/hooks";
import type { GetProp, UploadFile } from "antd";
type FileType = Parameters<GetProp<UploadProps, "beforeUpload">>[0];

const getBase64 = (file: FileType): Promise<string> =>
  new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = () => resolve(reader.result as string);
    reader.onerror = (error) => reject(error);
  });
const { Column } = Table;
import {
  ArrowLeftOutlined,
  DeleteOutlined,
  EditOutlined,
  HomeOutlined,
  PlusOutlined,
  QuestionCircleOutlined,
  UploadOutlined,
} from "@ant-design/icons";
import useTranslation from "next-translate/useTranslation";
import { cannotEmptyRules } from "@/helpers/validationRules";
import { toast } from "react-toastify";
import { PermissionType } from "@/dto/AppDTO";
import QuestionCreate, { QuestionRef } from "@/components/toefl/QuestionCreate";

export default function Audios() {
  const questionRef = useRef<QuestionRef>(null);
  const { Title } = Typography;
  const router = useRouter();
  const { locale } = router;
  const { t } = useTranslation("lang");
  const [form] = Form.useForm();
  const values: any = Form.useWatch([], form);
  const [dataItem, setDataItem] = useState<PermissionType[]>([]);
  const [openModal, setOpenModal] = useState(false);
  const [loading, setLoading] = useState(false);
  const [formBtnLoading, setFormBtnLoading] = useState(false);
  const [editLineId, setEditLineId] = useState(0);
  const [totalItem, setTotalItem] = useState(1);
  const [questionList, setQuestionList] = useState<any[]>([]);
  const [fileListMp3, setFileListMp3] = useState<any[]>([]); // to manage the file list locally

  // console.log(666666, filter.current);
  const [query, setquery] = useState({
    page: 0,
    limit: 10,
    search: {},
  });
  const formTemplate = {
    name: "",
    audioFileId: undefined,
    fileIds: [],
    orderNumber: undefined,
    questionIds: [],
  };
  const [modal, contextHolder] = Modal.useModal();
  const [isButtonDisabled, setIsButtonDisabled] = useState(false);
  const [initialValuesItem, setIsInitialValues] = useState<any>({ isRent: false });
  const cannotEmpty = cannotEmptyRules();
  const userInfo = useAppSelector((state) => state.user); // hooks/hooks.ts qo'shilgandan keyin shundoq ishlatsa buladi
  const breadcrumbItem = [
    {
      href: `/${locale}`,
      title: <HomeOutlined />,
    },
    {
      href: "",
      title: "TOEFL",
    },
    {
      title: `${t("audios")}`,
    },
  ];
  const [previewOpen, setPreviewOpen] = useState(false);
  const [previewImage, setPreviewImage] = useState("");
  const [fileList, setFileList] = useState<UploadFile[]>([]);
  const props: UploadProps = {
    action: `${process.env.PUBLIC_API_SERVER_URL}/api/v1/file`,
    fileList: fileListMp3,
    customRequest: async ({ file, onSuccess, onError }) => {
      const formData = new FormData();
      formData.append("file", file);

      try {
        await axiosServer(router.locale, false, userInfo?.token)
          .post(`/api/v1/file`, formData)
          .then((res: any) => {
            if (res?.id) {
              // @ts-ignore
              onSuccess(res);
              form.setFieldsValue({ audioFileId: res.id });
            } else {
              // @ts-ignore
              onError(new Error("Upload failed"));
            }
          });
      } catch (error) {
        // @ts-ignore
        onError(error);
      }
    },
    accept: ".mp3",
    onChange({ file, fileList }) {
      if (!file) return;
      setFileListMp3(fileList);
      if (!fileList.length) {
        form.setFieldsValue({ audioFileId: undefined });
      }

      // }
    },
  };
  const handleRemove = (file: any) => {
    const fileId: number = file?.response?.id;
    if (fileId && values?.fileIds?.length) {
      const ids = values?.fileIds.filter((item: number) => item !== fileId);
      form.setFieldsValue({ fileIds: ids || [] });
    }
  };
  const props2: UploadProps = {
    action: `${process.env.PUBLIC_API_SERVER_URL}/api/v1/file`,
    customRequest: async ({ file, onSuccess, onError }) => {
      const formData = new FormData();
      formData.append("file", file);

      try {
        await axiosServer(router.locale, false, userInfo?.token)
          .post(`/api/v1/file`, formData)
          .then((res: any) => {
            if (res?.id) {
              // @ts-ignore
              onSuccess(res);
            } else {
              // @ts-ignore
              onError(new Error("Upload failed"));
            }
          });
      } catch (error) {
        // @ts-ignore
        onError(error);
      }
    },
    fileList: fileList, // Pass fileList here
    onRemove: handleRemove, // Handle file removal
  };
  const confirmModal = (id: number) => {
    modal.confirm({
      title: "",
      icon: <QuestionCircleOutlined style={{ marginTop: "10px" }} />,
      content: <h3>{t("deleteConfirmation")}</h3>,
      okText: t("form.yes"),
      cancelText: t("form.no"),
      onOk() {
        deleteLine(id);
      },
      onCancel() {
        // console.log("Cancel");
      },
      okButtonProps: {
        style: {
          backgroundColor: "#ff4d4f",
          color: "white",
          border: "none",
        },
      },
    });
  };

  // Define the function to load pavilion data
  const loadData = useCallback(async () => {
    setLoading(true);
    // console.log(88888, filter?.current);
    await axiosServer(router.locale, false, userInfo?.token)
      .post(`/api/v1/audio/list-search`, query)
      .then((res: any) => {
        setLoading(false);
        setTotalItem(res?.data?.total || 1);
        setDataItem(res?.data?.list || []); // Update the state with the fetched data
      })
      .catch(() => {
        setDataItem([]);
        setLoading(false);
      });
  }, [router.locale, query]);
  const loadQuestionList = useCallback(async (value = "") => {
    const answerQuery = {
      page: 0,
      limit: 100,
      search: {
        value: value || undefined,
      },
    };
    await axiosServer(router.locale, false, userInfo?.token)
      .post(`/api/v1/question/list-search/LISTENING`, answerQuery)
      .then((res: any) => {
        setQuestionList(res?.data?.list || []); // Update the state with the fetched data
      })
      .catch(() => {
        setQuestionList([]);
      });
  }, []);

  useEffect(() => {
    (async () => {
      await loadData();
      await loadQuestionList();
    })();
  }, [router.locale, query]);

  useEffect(() => {
    form
      .validateFields({ validateOnly: true })
      .then(() => setIsButtonDisabled(true))
      .catch(() => setIsButtonDisabled(false));
    // console.log(555, form.getFieldsValue());
  }, [form, values]);
  const handleOk = async () => {
    const values = form.getFieldsValue();
    if (editLineId) {
      setFormBtnLoading(true);
      await axiosServer(router.locale, false, userInfo?.token)
        .put(`/api/v1/audio/${editLineId}`, values)
        .then(() => {
          setEditLineId(0);
          toast.success(`${t("toast.successfully")}`);
          form.setFieldsValue(formTemplate);
          setFormBtnLoading(false);
          setOpenModal(false);
          loadData();
        })
        .catch(() => {
          setFormBtnLoading(false);
        });
    } else {
      await axiosServer(router.locale, false, userInfo?.token)
        .post("/api/v1/audio", values)
        .then(() => {
          toast.success(`${t("toast.successfully")}`);
          form.setFieldsValue(formTemplate);
          setOpenModal(false);
          loadData();
        })
        .catch(() => "");
    }
  };
  const editItemModal = async (id: number) => {
    form.setFieldsValue(formTemplate);
    // console.log("eeeeee", values);
    if (id) {
      setEditLineId(id);
      setOpenModal(true);
      setFormBtnLoading(true);
      await axiosServer(router.locale, false, userInfo?.token)
        .get(`/api/v1/audio/${id}`)
        .then((res: any) => {
          setFormBtnLoading(false);
          if (res) {
            const data = res;
            data.audioFileId = res?.audiFileDto?.id;
            if (res?.fileDtos?.length) {
              data.fileIds = res?.fileDtos.map((item: any) => {
                return item.id;
              });
            }
            if (res?.fileDtos?.length) {
              data.questionIds = res?.questions.map((item: any) => {
                return item.id;
              });
            }

            setFileListMp3([res.audiFileDto]);

            setFileList(res.fileDtos);
            setIsInitialValues(data);
            form.setFieldsValue(data);
            setQuestionList(res?.questions || questionList);
            if (res?.fileDtos?.length) {
              const fileDtosImages = res.fileDtos.map((item: any) => {
                return { ...item, url: `${process.env.IMAGES_URL}${item.url}` };
              });
              setFileList(fileDtosImages);
            }
          }
        })
        .catch(() => {
          setFormBtnLoading(false);
        });
    }
  };

  const deleteItemModal = (id: number) => {
    // console.log("Delete Itemmm", id);
    if (!id) return;
    confirmModal(id);
  };

  const closeModal = () => {
    setEditLineId(0);
    form.setFieldsValue(formTemplate);
    setIsInitialValues(formTemplate);
    setOpenModal(false);
    setFileList([]);
    setFileListMp3([]);
  };
  // Handle pagination changes
  const handlePaginationChange = (page: number, pageSize: number) => {
    const limintChange = page - 1 === query.page;
    setquery((prevQuery) => ({
      ...prevQuery,
      page: limintChange ? 0 : page - 1, // Update page to 5
      limit: pageSize, // Update limit to 3
    }));
  };

  const openCreateModal = () => {
    setOpenModal(true);
    // Explicitly set initial values for a new pavilion if required
    form.setFieldsValue(formTemplate);
  };

  // useCallback(async () => {}, [router.locale, filter]);
  const deleteLine = async (id: number) => {
    if (!id) return;
    await axiosServer(router.locale, false, userInfo?.token)
      .delete(`/api/v1/audio/${id}`)
      .then(() => {
        toast.success(`${t("toast.successfully")}`);
        loadData();
      })
      .catch(() => "");
  };
  const selectItemSearch = (value: string) => {
    if (value && value.length > 1) {
      loadQuestionList(value);
    } else if (value === "") {
      loadQuestionList(value);
    }
  };
  const handlePreview = async (file: UploadFile) => {
    if (!file.url && !file.preview) {
      file.preview = await getBase64(file.originFileObj as FileType);
    }

    setPreviewImage(file.url || (file.preview as string));
    setPreviewOpen(true);
  };

  const handleChange: UploadProps["onChange"] = ({ fileList: newFileList }) => {
    setFileList(newFileList);
  };

  const uploadButton = (
    <button style={{ border: 0, background: "none" }} type="button">
      <PlusOutlined />
      <div style={{ marginTop: 8 }}>{t("sessionTypes.upload")}</div>
    </button>
  );
  const addChildQuestion = () => {
    questionRef?.current?.openCreateModal();
  };
  const handleCreatedQuestion = (dataItem: any) => {
    // Masalan: toast ko‘rsatish, state yangilash, forma tozalash, h.k.
    if (dataItem.id) {
      const questionListItem = questionList.filter((item: any) => item.id !== dataItem.id);

      setQuestionList([...questionListItem, dataItem]);

      const prevQuestionIds = form.getFieldValue("questionIds").length
        ? form.getFieldValue("questionIds").filter((item: any) => item !== dataItem.id)
        : [];
      form.setFieldsValue({
        questionIds: [...prevQuestionIds, dataItem.id],
      });
    }
  };
  const editChildQuestion = (dataItem: any) => {
    questionRef?.current?.editItemModal(dataItem.id);
  };
  useEffect(() => {
    if (fileList?.length) {
      const ids = fileList.map((item: any) => {
        if (item?.response?.id) {
          return item.response.id;
        } else if (item?.id) {
          return item.id;
        }
      });
      form.setFieldsValue({ fileIds: ids || [] });
    }
  }, [fileList]); //
  return (
    <MainLayout>
      <Row className="pavilion-box ass-style">
        <Col span={24}>
          <div>
            <Breadcrumb items={breadcrumbItem} />
          </div>
        </Col>
        <Col span={24} className="add-pavilion-box">
          <Flex justify={"space-between"}>
            <div>
              <Flex align={"center"}>
                <ArrowLeftOutlined style={{ marginRight: "16px", fontSize: "16px" }} />
                <Title level={4} className="m-0">
                  {t("questionsList")}
                </Title>
              </Flex>
            </div>
            <Flex align={"end"}>
              <Button
                onClick={openCreateModal}
                style={{ marginRight: "20px" }}
                className="add-pavilion"
                type="primary"
                shape="round"
                size="large"
              >
                {t("addAudio")}
              </Button>
            </Flex>
          </Flex>
        </Col>
      </Row>
      <Row>
        <Col span={24}>
          <ConfigProvider
            //@ts-ignore
            locale={{
              Pagination: {
                items_per_page: "/" + t("table.page"), // Sahifa hajmi matnini o'zgartirish
              },
            }}
          >
            <Table<PermissionType>
              className="ass-table"
              dataSource={loading ? [] : dataItem}
              rowKey={(record): React.Key => record.id}
              pagination={{
                current: query.page + 1,
                pageSize: query.limit,
                total: totalItem,
                onChange: handlePaginationChange,
                showSizeChanger: true,
                pageSizeOptions: ["10", "20", "50"], // Customize the available page sizes
              }}
              loading={loading}
              locale={{
                emptyText: loading ? <Skeleton active paragraph={{ rows: 5 }} /> : t("empty"),
              }}
            >
              <Column title="#" dataIndex="id" key="id" />
              <Column title={`${t("table.header.title")}`} dataIndex="name" key="name" />
              <Column title={`${t("audioIndex")}`} dataIndex="orderNumber" key="orderNumber" />

              <Column
                title={`${t("table.header.actions")}`}
                dataIndex="id"
                key="id"
                render={(id: number) => (
                  <div>
                    <Button
                      onClick={() => editItemModal(id)}
                      className="bg-primary color-white"
                      shape="round"
                    >
                      <EditOutlined />
                    </Button>
                    <Button
                      danger
                      onClick={() => deleteItemModal(id)}
                      className="ml-2"
                      shape="round"
                    >
                      <DeleteOutlined />
                    </Button>
                  </div>
                )}
              />
            </Table>
          </ConfigProvider>
        </Col>
      </Row>
      <Row className="ass-style">
        <Modal
          className="ass-style ass-modal ass-modal-small"
          centered
          open={openModal}
          title={`${t("addAudio")}`}
          onOk={handleOk}
          onCancel={closeModal}
          footer={[
            <Button key="close" onClick={closeModal}>
              {t("form.close")}
            </Button>,
            <Button
              key="create"
              className={!isButtonDisabled ? "" : "base-bg color-white"}
              disabled={!isButtonDisabled}
              onClick={handleOk}
              loading={formBtnLoading}
            >
              {t("form.create")}
            </Button>,
          ]}
        >
          <div className="ass-modal-body">
            <Skeleton loading={formBtnLoading} active paragraph={{ rows: 5 }}>
              <Form
                initialValues={initialValuesItem}
                form={form}
                layout="vertical"
                name="pavilion"
                style={{ width: "100%", marginTop: "20px" }}
                autoComplete="off"
              >
                <Row>
                  <Col span={24} className="pavilion-input">
                    <Form.Item name="name" label={`${t("table.header.title")}`} rules={cannotEmpty}>
                      <Input prefix={<EditOutlined />} placeholder={t("form.enterTitle")} />
                    </Form.Item>
                  </Col>

                  <Col span={24} className="pavilion-input">
                    <Form.Item
                      name="audioFileId"
                      label={`${t("uploadAudioFile")}`}
                      rules={cannotEmpty}
                    >
                      <Upload {...props}>
                        <Button disabled={values?.audioFileId} icon={<UploadOutlined />}>
                          {t("sessionTypes.upload")}
                        </Button>
                      </Upload>
                    </Form.Item>
                  </Col>
                  <Col span={24} className="pavilion-input">
                    <Form.Item name="orderNumber" label={`${t("audioIndex")}`} rules={cannotEmpty}>
                      <Input
                        type="number"
                        min={0}
                        placeholder={`${t("enterAudioIndex")}`}
                        onChange={(e) =>
                          form.setFieldsValue({
                            orderNumber: e?.target?.value ? Number(e?.target?.value) : 0,
                          })
                        }
                      />
                    </Form.Item>
                  </Col>
                  <Col span={24} className="pavilion-input">
                    <Form.Item name="fileIds" label={`${t("picture")}`} rules={cannotEmpty}>
                      <Upload
                        {...props2}
                        listType="picture-card"
                        fileList={fileList}
                        onPreview={handlePreview}
                        onChange={handleChange}
                      >
                        {fileList.length >= 8 ? null : uploadButton}
                      </Upload>
                      {previewImage && (
                        <Image
                          wrapperStyle={{ display: "none" }}
                          preview={{
                            visible: previewOpen,
                            onVisibleChange: (visible) => setPreviewOpen(visible),
                            afterOpenChange: (visible) => !visible && setPreviewImage(""),
                          }}
                          src={previewImage}
                        />
                      )}
                    </Form.Item>
                  </Col>

                  <Col span={24} className="pavilion-input">
                    <Form.Item name="questionIds" label={`${t("question")}`} rules={cannotEmpty}>
                      <Select
                        className="custom-select-edit"
                        mode="multiple"
                        placeholder={`${t("table.header.select")}`}
                        onSearch={($event) => {
                          selectItemSearch($event);
                        }}
                        showSearch
                        filterOption={false}
                      >
                        {/* Optionsni map qilish */}
                        {questionList?.map((option: any) => (
                          <Select.Option
                            key={option?.id}
                            value={option?.id}
                            style={{ marginRight: "16px" }}
                          >
                            {option?.name}{" "}
                            <EditOutlined
                              onMouseDown={(e) => {
                                e.preventDefault(); // input focus tushmasligi uchun
                                e.stopPropagation(); // boshqa eventlar to‘xtaydi
                              }}
                              unselectable="on"
                              style={{ userSelect: "none" }}
                              onClick={(e) => {
                                e.stopPropagation();
                                e.preventDefault();
                                editChildQuestion(option);
                              }}
                            />
                          </Select.Option>
                        ))}
                      </Select>
                    </Form.Item>
                    <Button onClick={addChildQuestion}>+ {t("addQuestions")}</Button>
                  </Col>
                </Row>
              </Form>
            </Skeleton>
          </div>
        </Modal>
      </Row>
      <Row>
        <Col span={24}>{contextHolder}</Col>
      </Row>
      <Row gutter={24}>
        <QuestionCreate
          ref={questionRef}
          questionType="LISTENING"
          onCreated={handleCreatedQuestion}
        />
      </Row>
    </MainLayout>
  );
}
