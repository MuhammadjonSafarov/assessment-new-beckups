import { PlusOutlined, UploadOutlined } from "@ant-design/icons";
import { Button, Image, Upload } from "antd";
import { axiosServer } from "@/plugins/axiosServer";
import { useRouter } from "next/router";
import { useAppSelector } from "@/hooks/hooks";
import { toast } from "react-toastify";
import useTranslation from "next-translate/useTranslation";
import React, { useEffect, useState } from "react";
import type { GetProp, UploadProps, UploadFile } from "antd";
interface FileUploadProps {
  type?: string;
  handlechange: (act: any) => void;
  shape?: string;
  image?: string;
}
const FileUpload: React.FC<FileUploadProps> = ({ type, handlechange, shape, image }) => {
  const router = useRouter();
  const userInfo = useAppSelector((state) => state.user); // hooks/hooks.ts qo'shilgandan keyin shundoq ishlatsa buladi
  const { t } = useTranslation("lang");
  const [fileList, setFileList] = useState<UploadFile[]>([]);
  const [previewImage, setPreviewImage] = useState("");
  const [previewOpen, setPreviewOpen] = useState(false);

  type FileType = Parameters<GetProp<UploadProps, "beforeUpload">>[0];
  const handleRemove = () => {
    // const fileId: number = file?.response?.id;
    // if (fileId) {
    handlechange({ status: false, info: {} });
    // }
  };
  const props: UploadProps = {
    customRequest: async ({ file, onSuccess, onError }) => {
      const formData = new FormData();
      formData.append("file", file);
      const userId = router?.query?.candidatId || null;

      const fileUrl =
        type === "pasport"
          ? `/api/v1/user/attach-passport-file?id=${userId}`
          : type === "selfi"
          ? `/api/v1/user/attach-file?id=${userId}`
          : "/api/v1/file";
      try {
        await axiosServer(router.locale, false, userInfo?.token)
          .post(`${fileUrl}`, formData)
          .then((res: any) => {
            if (res?.id) {
              // @ts-ignore
              onSuccess(res);
              toast.success(`${t("toast.successfully")}`);
              handlechange({ status: true, info: res });
            } else {
              // @ts-ignore
              onError(new Error("Upload failed"));
              handlechange({ status: false, info: {} });
            }
          });
      } catch (error) {
        // @ts-ignore
        onError(error);
      }
    },
  };
  const props2: UploadProps = {
    action: `${process.env.PUBLIC_API_SERVER_URL}/api/v1/file`,
    customRequest: async ({ file, onSuccess, onError }) => {
      const formData = new FormData();
      formData.append("file", file);

      try {
        await axiosServer(router.locale, false, userInfo?.token)
          .post(`/api/v1/file`, formData)
          .then((res: any) => {
            if (res?.id) {
              // @ts-ignore
              onSuccess(res);
              toast.success(`${t("toast.successfully")}`);
              handlechange({ status: true, info: res });
            } else {
              // @ts-ignore
              onError(new Error("Upload failed"));
            }
          });
      } catch (error) {
        // @ts-ignore
        onError(error);
      }
    },
    fileList: fileList, // Pass fileList here
    onRemove: handleRemove, // Handle file removal
  };
  const getBase64 = (file: FileType): Promise<string> =>
    new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = () => resolve(reader.result as string);
      reader.onerror = (error) => reject(error);
    });
  const handlePreview = async (file: UploadFile) => {
    if (!file.url && !file.preview) {
      file.preview = await getBase64(file.originFileObj as FileType);
    }

    setPreviewImage(file.url || (file.preview as string));
    setPreviewOpen(true);
  };
  const uploadButton = (
    <button style={{ border: 0, background: "none" }} type="button">
      <PlusOutlined />
      <div style={{ marginTop: 8 }}>{t("sessionTypes.upload")}</div>
    </button>
  );
  const handleChange: UploadProps["onChange"] = ({ fileList: newFileList }) => {
    setFileList(newFileList);
  };
  // const beforeUpload = (file: FileType) => {
  //   const isJpgOrPng = file.type === "image/jpeg" || file.type === "image/png";
  //   if (!isJpgOrPng) {
  //     toast.warning("Iltimos JPG yokiy PNG formatdagi fayl tanlang!");
  //     // message.error("You can only upload JPG/PNG file!");
  //   }
  //   // const isLt2M = file.size / 1024 / 1024 < 2;
  //   // if (!isLt2M) {
  //   // message.error("Image must smaller than 2MB!");
  //   // }
  //   // return isJpgOrPng && isLt2M;
  //   return isJpgOrPng;
  // };
  useEffect(() => {
    if (image) {
      setFileList([
        {
          uid: "1",
          name: "image.jpg",
          url: `${process.env.NEXT_PUBLIC_IMAGES_URL}${image}`,
          status: "done",
        },
      ]);
    }
  }, [image]);
  return (
    <>
      {shape && shape === "rectangle" ? (
        <div>
          <Upload
            {...props2}
            listType="picture-card"
            fileList={fileList}
            onPreview={handlePreview}
            onChange={handleChange}
            // beforeUpload={beforeUpload}
          >
            {fileList.length >= 1 ? null : uploadButton}
          </Upload>
          {previewImage && (
            <Image
              wrapperStyle={{ display: "none" }}
              preview={{
                visible: previewOpen,
                onVisibleChange: (visible) => setPreviewOpen(visible),
                afterOpenChange: (visible) => !visible && setPreviewImage(""),
              }}
              src={previewImage}
            />
          )}
        </div>
      ) : (
        <Upload {...props}>
          <Button icon={<UploadOutlined />}>{t("sessionTypes.upload")}</Button>
        </Upload>
      )}
    </>
  );
};

export default FileUpload;
