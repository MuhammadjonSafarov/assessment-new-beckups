import {
  Col,
  Row,
  Breadcrumb,
  Flex,
  Typography,
  Button,
  Modal,
  Form,
  Input,
  Select,
  Table,
  ConfigProvider,
  Skeleton,
} from "antd";
import MainLayout from "@/components/layout/MainLayout";
import React, { useCallback, useEffect, useState } from "react";
import { useRouter } from "next/router";
import { axiosServer } from "@/plugins/axiosServer";
import { useAppSelector } from "@/hooks/hooks";

const { Column } = Table;
import {
  ArrowLeftOutlined,
  CheckCircleOutlined,
  CloseCircleOutlined,
  EditOutlined,
  FileAddOutlined,
  HomeOutlined,
} from "@ant-design/icons";
import useTranslation from "next-translate/useTranslation";
import { cannotEmptyRules } from "@/helpers/validationRules";
import { toast } from "react-toastify";
import { PavilionDataType } from "@/dto/AppDTO";
import { propertyReturn } from "@/helpers/propertyReturn";

export default function Pavilions() {
  const { Title } = Typography;
  const { Option } = Select;
  const router = useRouter();
  const { locale } = router;
  const { t } = useTranslation("lang");
  const [form] = Form.useForm();
  const values: any = Form.useWatch([], form);
  const [pavilions, setPavilions] = useState<PavilionDataType[]>([]);
  const [openModal, setOpenModal] = useState(false);
  const [loading, setLoading] = useState(false);
  const [formBtnLoading, setFormBtnLoading] = useState(false);
  const [pavilionId, setpavilionId] = useState(0);
  const [totalItem, setTotalItem] = useState(1);
  const [query, setquery] = useState({
    page: 0,
    limit: 10,
    search: {},
  });
  const formTemplate = {
    nameUz: "",
    nameRu: "",
    addressUz: "",
    addressRu: "",
    isRent: false,
    status: "",
  };
  const [isButtonDisabled, setIsButtonDisabled] = useState(false);
  const [initialValuesItem, setIsInitialValues] = useState<any>({ isRent: false });
  const cannotEmpty = cannotEmptyRules();
  const userInfo = useAppSelector((state) => state.user); // hooks/hooks.ts qo'shilgandan keyin shundoq ishlatsa buladi
  const breadcrumbItem = [
    {
      href: `/${locale}`,
      title: <HomeOutlined />,
    },
    {
      href: "",
      title: `${t("menu.reference")}`,
    },
    {
      title: `${t("menu.pavilions")}`,
    },
  ];
  // Define the function to load pavilion data
  const loadPavilionLists = useCallback(async () => {
    setLoading(true);
    await axiosServer(router.locale, false, userInfo?.token)
      .post("/api/v1/pavilion/list-search", query)
      .then((res: any) => {
        setLoading(false);
        setTotalItem(res?.data?.total || 1);
        setPavilions(res?.data?.list || []); // Update the state with the fetched data
      })
      .catch(() => {
        setPavilions([]);
        setLoading(false);
      });
  }, [router.locale, query, userInfo?.token]);
  useEffect(() => {
    loadPavilionLists();
  }, [loadPavilionLists]);
  useEffect(() => {
    form
      .validateFields({ validateOnly: true })
      .then(() => setIsButtonDisabled(true))
      .catch(() => setIsButtonDisabled(false));
  }, [form, values]);
  const handleOk = async () => {
    const values = form.getFieldsValue();
    if (pavilionId) {
      setFormBtnLoading(true);
      await axiosServer(router.locale, false, userInfo?.token)
        .put(`/api/v1/pavilion/${pavilionId}`, values)
        .then(() => {
          setpavilionId(0);
          toast.success(`${t("toast.successfully")}`);
          form.setFieldsValue(formTemplate);
          setFormBtnLoading(false);
          setOpenModal(false);
          loadPavilionLists();
        })
        .catch(() => {
          setFormBtnLoading(false);
        });
    } else {
      await axiosServer(router.locale, false, userInfo?.token)
        .post("/api/v1/pavilion", values)
        .then(() => {
          toast.success(`${t("toast.successfully")}`);
          form.setFieldsValue(formTemplate);
          setOpenModal(false);
          loadPavilionLists();
        })
        .catch(() => "");
    }
  };
  const editPavilionModal = async (id: number) => {
    form.setFieldsValue(formTemplate);
    if (id) {
      setpavilionId(id);
      setOpenModal(true);
      setFormBtnLoading(true);
      await axiosServer(router.locale, false, userInfo?.token)
        .get(`/api/v1/pavilion/${id}`)
        .then((res: any) => {
          setFormBtnLoading(false);
          if (res) {
            setIsInitialValues(res);
            form.setFieldsValue(res);
          }
        })
        .catch(() => {
          setFormBtnLoading(false);
        });
    }
  };

  const closeModal = () => {
    setpavilionId(0);
    form.setFieldsValue(formTemplate);
    setOpenModal(false);
  };
  // Handle pagination changes
  const handlePaginationChange = (page: number, pageSize: number) => {
    const limintChange = page - 1 === query.page;
    setquery((prevQuery) => ({
      ...prevQuery,
      page: limintChange ? 0 : page - 1, // Update page to 5
      limit: pageSize, // Update limit to 3
    }));
  };

  const openCreateModal = () => {
    setOpenModal(true);
    // Explicitly set initial values for a new pavilion if required
    form.setFieldsValue(formTemplate);
  };
  return (
    <MainLayout>
      <Row className="pavilion-box">
        <Col span={24}>
          <div>
            <Breadcrumb items={breadcrumbItem} />
          </div>
        </Col>
        <Col span={24} className="add-pavilion-box">
          <Flex justify={"space-between"}>
            <Flex align={"center"}>
              <ArrowLeftOutlined style={{ marginRight: "16px", fontSize: "16px" }} />
              <Title level={4} className="m-0">
                {t("pavilion.list")}
              </Title>
            </Flex>
            <Button
              onClick={openCreateModal}
              style={{ marginRight: "20px" }}
              className="add-pavilion"
              type="primary"
              shape="round"
              icon={<FileAddOutlined />}
              size="large"
            >
              {t("pavilion.add")}
            </Button>
          </Flex>
        </Col>
      </Row>
      <Row>
        <Col span={24}>
          <ConfigProvider
            //@ts-ignore
            locale={{
              Pagination: {
                items_per_page: "/" + t("table.page"), // Sahifa hajmi matnini o'zgartirish
              },
            }}
          >
            <Table<PavilionDataType>
              className="ass-table"
              dataSource={loading ? [] : pavilions}
              rowKey={(record): React.Key => record.id}
              pagination={{
                current: query.page + 1,
                pageSize: query.limit,
                total: totalItem,
                onChange: handlePaginationChange,
                showSizeChanger: true,
                pageSizeOptions: ["10", "20", "50"], // Customize the available page sizes
              }}
              loading={loading}
              locale={{
                emptyText: loading ? <Skeleton active paragraph={{ rows: 5 }} /> : t("empty"),
              }}
            >
              <Column title="#" dataIndex="id" key="id" />
              <Column
                title={`${t("table.header.shortAddress")}`}
                dataIndex={propertyReturn(`${locale}`, "name")}
                key={propertyReturn(`${locale}`, "name")}
              />
              <Column
                title={`${t("table.header.status")}`}
                dataIndex="status"
                key="status"
                render={(status: string) =>
                  status === "ACTIVE" ? (
                    <Button className="bg-success color-white cursor-auto">
                      <CheckCircleOutlined />
                      {t("table.body.active")}
                    </Button>
                  ) : (
                    <Button className="bg-danger color-white cursor-auto">
                      <CloseCircleOutlined /> {t("table.body.inActive")}
                    </Button>
                  )
                }
              />
              <Column
                title={`${t("table.header.fullAddress")}`}
                dataIndex={propertyReturn(`${locale}`, "address")}
                key={propertyReturn(`${locale}`, "address")}
              />
              <Column
                title={`${t("table.header.numberOfSeats")}`}
                dataIndex="numberOfSeats"
                key="numberOfSeats"
              />
              <Column
                title={`${t("table.header.rented")}`}
                dataIndex="isRent"
                key="isRent"
                render={(isRent: boolean) => (
                  <Button
                    size="middle"
                    className={
                      isRent
                        ? "bg-success color-white cursor-auto"
                        : "bg-danger color-white cursor-auto"
                    }
                  >
                    {isRent ? <CheckCircleOutlined /> : <CloseCircleOutlined />}
                    {isRent ? t("table.body.yes") : t("table.body.no")}
                  </Button>
                )}
              />
              <Column
                title={`${t("table.header.actions")}`}
                dataIndex="id"
                key="id"
                render={(id: number) => (
                  <Button
                    onClick={() => editPavilionModal(id)}
                    className="bg-primary color-white"
                    shape="round"
                  >
                    <EditOutlined />
                  </Button>
                )}
              />
            </Table>
          </ConfigProvider>
        </Col>
      </Row>
      <Row className="ass-style">
        <Modal
          className="ass-style ass-modal"
          centered
          open={openModal}
          title={pavilionId ? t("pavilion.edit") : t("pavilion.add")}
          onOk={handleOk}
          onCancel={closeModal}
          footer={[
            <Button key="close" onClick={closeModal}>
              {t("form.close")}
            </Button>,
            <Button
              key="create"
              className={!isButtonDisabled ? "" : "base-bg color-white"}
              disabled={!isButtonDisabled}
              onClick={handleOk}
              loading={formBtnLoading}
            >
              {pavilionId ? t("form.update") : t("form.create")}
            </Button>,
          ]}
        >
          <div className="ass-modal-body">
            <Skeleton loading={formBtnLoading} active paragraph={{ rows: 5 }}>
              <Form
                initialValues={initialValuesItem}
                form={form}
                layout="vertical"
                name="pavilion"
                style={{ width: "100%", marginTop: "20px" }}
                autoComplete="off"
              >
                <Row>
                  <Col span={10} className="pavilion-input">
                    <Form.Item
                      name="nameUz"
                      label={t("form.label.shortAddressUz")}
                      rules={cannotEmpty}
                    >
                      <Input placeholder={t("form.enterTitle")} />
                    </Form.Item>
                  </Col>
                  <Col span={14} className="pavilion-input">
                    <Form.Item
                      name="addressUz"
                      label={t("form.label.fullAddressUz")}
                      rules={cannotEmpty}
                    >
                      <Input placeholder={t("form.enterTitle")} />
                    </Form.Item>
                  </Col>
                  <Col span={10} className="pavilion-input">
                    <Form.Item
                      name="nameRu"
                      label={t("form.label.shortAddressRu")}
                      rules={cannotEmpty}
                    >
                      <Input placeholder={t("form.enterTitle")} />
                    </Form.Item>
                  </Col>
                  <Col span={14} className="pavilion-input">
                    <Form.Item
                      name="addressRu"
                      label={t("form.label.fullAddressRu")}
                      rules={cannotEmpty}
                    >
                      <Input placeholder={t("form.enterTitle")} />
                    </Form.Item>
                  </Col>
                  <Col span={10} className="pavilion-input">
                    <Form.Item name="isRent" label={t("form.label.rented")} rules={cannotEmpty}>
                      <Select placeholder="isRent" allowClear>
                        <Option value={false}>{t("form.no")}</Option>
                        <Option value={true}>{t("form.yes")}</Option>
                      </Select>
                    </Form.Item>
                  </Col>
                  <Col span={14} className="pavilion-input">
                    <Form.Item name="status" label={t("form.label.status")} rules={cannotEmpty}>
                      <Select placeholder={t("form.status")} allowClear>
                        <Option value="ACTIVE">
                          <CheckCircleOutlined
                            className="select-item-icon"
                            style={{ marginRight: "8px" }}
                          />
                          {t("form.active")}
                        </Option>
                        <Option value="INACTIVE">
                          <CloseCircleOutlined
                            className="select-item-icon"
                            style={{ marginRight: "8px" }}
                          />
                          {t("form.inActive")}
                        </Option>
                      </Select>
                    </Form.Item>
                  </Col>
                </Row>
              </Form>
            </Skeleton>
          </div>
        </Modal>
      </Row>
    </MainLayout>
  );
}
