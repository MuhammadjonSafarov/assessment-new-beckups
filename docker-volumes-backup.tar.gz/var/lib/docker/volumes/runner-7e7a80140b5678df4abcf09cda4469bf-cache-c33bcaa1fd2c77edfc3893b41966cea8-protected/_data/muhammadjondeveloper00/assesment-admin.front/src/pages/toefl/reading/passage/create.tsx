import {
  Col,
  Row,
  Breadcrumb,
  Flex,
  Typography,
  Button,
  Form,
  Input,
  Skeleton,
  Select,
  Upload,
  Image,
  UploadProps,
} from "antd";
import MainLayout from "@/components/layout/MainLayout";
import React, { useCallback, useEffect, useRef, useState } from "react";
import { useRouter } from "next/router";
import { axiosServer } from "@/plugins/axiosServer";
import { useAppSelector } from "@/hooks/hooks";
import type { GetProp, UploadFile } from "antd";
type FileType = Parameters<GetProp<UploadProps, "beforeUpload">>[0];

const getBase64 = (file: FileType): Promise<string> =>
  new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = () => resolve(reader.result as string);
    reader.onerror = (error) => reject(error);
  });

import { ArrowLeftOutlined, EditOutlined, HomeOutlined, PlusOutlined } from "@ant-design/icons";
import useTranslation from "next-translate/useTranslation";
import { cannotEmptyRules } from "@/helpers/validationRules";
import { toast } from "react-toastify";
import TinyMCEEditor from "@/components/TinyMCEEditor";

export default function PassageCreate() {
  const { Title } = Typography;
  const body = useRef("");

  const router = useRouter();
  const { locale } = router;
  const { t } = useTranslation("lang");
  const [form] = Form.useForm();
  const values: any = Form.useWatch([], form);
  const [formBtnLoading, setFormBtnLoading] = useState(false);
  const [fileList, setFileList] = useState<UploadFile[]>([]);

  const formTemplate = {
    name: "",
    fileId: undefined,
    childrenIds: [],
  };
  const [isButtonDisabled, setIsButtonDisabled] = useState(false);
  const [previewImage, setPreviewImage] = useState("");
  const [previewOpen, setPreviewOpen] = useState(false);
  const [subPassageList, setSubPassageList] = useState([]);

  const cannotEmpty = cannotEmptyRules();
  const userInfo = useAppSelector((state) => state.user); // hooks/hooks.ts qo'shilgandan keyin shundoq ishlatsa buladi
  const breadcrumbItem = [
    {
      href: `/${locale}`,
      title: <HomeOutlined />,
    },
    {
      href: "",
      title: "TOEFL",
    },
    {
      title: `${t("menu.reading")}`,
    },
    {
      title: `${t("passage")}`,
    },
  ];

  useEffect(() => {
    form
      .validateFields({ validateOnly: true })
      .then(() => setIsButtonDisabled(true))
      .catch(() => setIsButtonDisabled(false));
    // console.log(555, form.getFieldsValue());
  }, [form, values]);
  const handleOk = async () => {
    const values = form.getFieldsValue();
    setFormBtnLoading(true);
    values.body = body?.current || "";
    values.isParent = true;
    await axiosServer(router.locale, false, userInfo?.token)
      .post("/api/v1/passsage", values)
      .then(() => {
        setFormBtnLoading(false);
        toast.success(`${t("toast.successfully")}`);
        form.setFieldsValue(formTemplate);
        redirectPassage();
      })
      .catch(() => {
        setFormBtnLoading(false);
      });
  };

  const redirectPassage = () => {
    router.push("/toefl/reading/passage").catch(() => {
      // console.log(err)
    });
  };
  const handlePreview = async (file: UploadFile) => {
    if (!file.url && !file.preview) {
      file.preview = await getBase64(file.originFileObj as FileType);
    }

    setPreviewImage(file.url || (file.preview as string));
    setPreviewOpen(true);
  };
  const handleRemove = () => {
    // const fileId: number = file?.response?.id;
    // if (fileId) {
    form.setFieldsValue({ fileId: undefined });
    // }
  };
  const props2: UploadProps = {
    action: `${process.env.PUBLIC_API_SERVER_URL}/api/v1/file`,
    customRequest: async ({ file, onSuccess, onError }) => {
      const formData = new FormData();
      formData.append("file", file);

      try {
        await axiosServer(router.locale, false, userInfo?.token)
          .post(`/api/v1/file`, formData)
          .then((res: any) => {
            if (res?.id) {
              form.setFieldsValue({ fileId: res?.id || undefined });
              // @ts-ignore
              onSuccess(res);
            } else {
              // @ts-ignore
              onError(new Error("Upload failed"));
            }
          });
      } catch (error) {
        // @ts-ignore
        onError(error);
      }
    },
    fileList: fileList, // Pass fileList here
    onRemove: handleRemove, // Handle file removal
  };
  const handleChange: UploadProps["onChange"] = ({ fileList: newFileList }) => {
    setFileList(newFileList);
  };
  const uploadButton = (
    <button style={{ border: 0, background: "none" }} type="button">
      <PlusOutlined />
      <div style={{ marginTop: 8 }}>{t("sessionTypes.upload")}</div>
    </button>
  );
  const loadSubPassageList = useCallback(async (value = "") => {
    const answerQuery = {
      page: 0,
      limit: 100,
      search: {
        value: value || undefined,
      },
    };
    await axiosServer(router.locale, false, userInfo?.token)
      .post(`/api/v1/passsage/list-search/children`, answerQuery)
      .then((res: any) => {
        setSubPassageList(res?.data?.list || []); // Update the state with the fetched data
      })
      .catch(() => {
        setSubPassageList([]);
      });
  }, []);

  const selectItemSearch = (value: string) => {
    if (value && value.length > 1) {
      loadSubPassageList(value);
    } else if (!value.length) {
      loadSubPassageList("");
    }
  };
  useEffect(() => {
    (async () => {
      await loadSubPassageList();
    })();
  }, [router.locale]);
  const setContent = (value: string) => {
    body.current = value;
    // form.setFieldsValue({ body: value || "" });
  };
  return (
    <MainLayout>
      <Row className="pavilion-box ass-style">
        <Col span={24}>
          <div>
            <Breadcrumb items={breadcrumbItem} />
          </div>
        </Col>

        <Col span={24} className="add-pavilion-box">
          <Flex justify={"space-between"}>
            <div>
              <Flex align={"center"}>
                <ArrowLeftOutlined
                  onClick={redirectPassage}
                  style={{ marginRight: "16px", fontSize: "16px" }}
                />
                <Title level={4} className="m-0">
                  {t("createPassage")}
                </Title>
              </Flex>
            </div>
          </Flex>
        </Col>
      </Row>
      <Row className="pavilion-box ass-style">
        <Skeleton loading={formBtnLoading} active paragraph={{ rows: 5 }}>
          <Form
            form={form}
            layout="vertical"
            name="pavilion"
            style={{ width: "100%", marginTop: "20px" }}
            autoComplete="off"
          >
            <Row>
              <Col span={24} className="pavilion-input">
                <Form.Item name="name" label={`${t("table.header.title")}`} rules={cannotEmpty}>
                  <Input prefix={<EditOutlined />} placeholder={t("form.enterTitle")} />
                </Form.Item>
              </Col>
              <Col span={24} className="pavilion-input">
                {/*<Form.Item name="body" label="Kontentni kiritin" rules={cannotEmpty}>*/}
                <div>
                  <label style={{ marginBottom: "8px", display: "block" }}>{t("content")}</label>
                  <div></div>
                  <TinyMCEEditor onChange={(content: string) => setContent(content)} height={350} />
                </div>
                {/*</Form.Item>*/}
              </Col>
              <Col span={24} className="pavilion-input mt-3">
                <Form.Item name="fileId" label={`${t("picture")}`}>
                  <Upload
                    {...props2}
                    listType="picture-card"
                    fileList={fileList}
                    onPreview={handlePreview}
                    onChange={handleChange}
                  >
                    {fileList.length >= 1 ? null : uploadButton}
                  </Upload>
                  {previewImage && (
                    <Image
                      wrapperStyle={{ display: "none" }}
                      preview={{
                        visible: previewOpen,
                        onVisibleChange: (visible) => setPreviewOpen(visible),
                        afterOpenChange: (visible) => !visible && setPreviewImage(""),
                      }}
                      src={previewImage}
                    />
                  )}
                </Form.Item>
              </Col>
              <Col span={24} className="pavilion-input">
                <Form.Item name="childrenIds" label={`${t("subPassage")}`} rules={cannotEmpty}>
                  <Select
                    mode="multiple"
                    placeholder={`${t("table.header.select")}`}
                    onSearch={($event) => {
                      selectItemSearch($event);
                    }}
                    showSearch
                    filterOption={false}
                  >
                    {/* Optionsni map qilish */}
                    {subPassageList?.map((option: any) => (
                      <Select.Option key={option?.id} value={option?.id}>
                        {option?.name}
                      </Select.Option>
                    ))}
                  </Select>
                </Form.Item>
              </Col>
              {/*<Col span={24} className="pavilion-input">*/}
              {/*  <Form.Item name="time" label="Vaqtni kiriting (min)">*/}
              {/*    <Input*/}
              {/*      type="number"*/}
              {/*      min={0}*/}
              {/*      placeholder="Vaqtni kiriting (min)"*/}
              {/*      onChange={(e) =>*/}
              {/*        form.setFieldsValue({*/}
              {/*          time: e?.target?.value ? Number(e?.target?.value) : 0,*/}
              {/*        })*/}
              {/*      }*/}
              {/*    />*/}
              {/*  </Form.Item>*/}
              {/*</Col>*/}

              <Col span={24} className="pavilion-input">
                <Button
                  key="create"
                  className={!isButtonDisabled ? "" : "base-bg color-white"}
                  disabled={!isButtonDisabled}
                  onClick={handleOk}
                  loading={formBtnLoading}
                >
                  {t("form.create")}
                </Button>
              </Col>
            </Row>
          </Form>
        </Skeleton>
      </Row>
    </MainLayout>
  );
}
