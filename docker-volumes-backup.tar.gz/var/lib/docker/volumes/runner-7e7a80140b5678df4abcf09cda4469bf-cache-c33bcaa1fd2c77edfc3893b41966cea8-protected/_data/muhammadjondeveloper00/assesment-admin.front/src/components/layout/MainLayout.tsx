import {
  MenuFoldOutlined,
  MenuUnfoldOutlined,
  UserOutlined,
  ApartmentOutlined,
  FileDoneOutlined,
  UserSwitchOutlined,
  UsergroupAddOutlined,
  AudioOutlined,
  UnlockOutlined,
  TeamOutlined,
  CodeSandboxOutlined,
  ControlOutlined,
  AppstoreOutlined,
  QuestionCircleOutlined,
  CustomerServiceOutlined,
  CommentOutlined,
  ScheduleOutlined,
  ProfileOutlined,
  ContainerOutlined,
  EditOutlined,
} from "@ant-design/icons";
import { Button, Flex, Image, Layout, Menu, theme } from "antd";
import React, { ReactNode, useEffect, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/router";
import LanguageSelect from "@/components/widgets/LanguageSelect";
import UserInfo from "@/components/widgets/UserInfo";
import { useAppDispatch, useAppSelector } from "@/hooks/hooks";
import { changeMenukey } from "@/reducers/counter";
import useTranslation from "next-translate/useTranslation";

const { Header, Sider, Content } = Layout;
interface Props {
  readonly children: ReactNode;
}

function MainLayout({ children }: Props) {
  const [collapsed, setCollapsed] = useState(false);
  const router = useRouter();
  const { locale } = router;
  const dispatch = useAppDispatch();
  const currentPath = router?.pathname || "";
  const menuKey = useAppSelector((state) => state?.counter?.menuKey);
  const userInfo = useAppSelector((state) => state.user);
  const { t } = useTranslation("lang");
  // console.log(32432432, menuKey);
  const menuItems = [
    {
      key: "/statistika",
      icon: <UserOutlined />,
      label: (
        <Link href="/statistika" locale={locale}>
          {t("menu.statistics")}
        </Link>
      ),
    },
    {
      key: "/candidates",
      icon: <ScheduleOutlined />,
      label: (
        <Link href="/candidates" locale={locale}>
          {t("menu.candidates")}
        </Link>
      ),
    },
    {
      key: "/sessions",
      icon: <ControlOutlined />,
      label: (
        <Link href="/sessions" locale={locale}>
          {t("menu.sessionControl")}
        </Link>
      ),
    },
    {
      key: "/toefl",
      icon: <AppstoreOutlined />,
      label: `${t("menu.toefl")}`,
      children: [
        {
          key: "/lestining",
          icon: <CustomerServiceOutlined />,
          label: `${t("menu.listening")}`,
          children: [
            {
              key: "/toefl/lestining/audios",
              icon: <AudioOutlined />,
              label: (
                <Link href="/toefl/lestining/audios" locale={locale}>
                  {t("menu.audios")}
                </Link>
              ),
            },
            {
              key: "/toefl/lestining/list",
              icon: <CustomerServiceOutlined />,
              label: (
                <Link href="/toefl/lestining/list" locale={locale}>
                  {t("menu.list")}
                </Link>
              ),
            },
            {
              key: "/toefl/lestining/questions",
              icon: <QuestionCircleOutlined />,
              label: (
                <Link href="/toefl/lestining/questions" locale={locale}>
                  {t("menu.questions")}
                </Link>
              ),
            },
          ],
        },
        {
          key: "/reading",
          icon: <ProfileOutlined />,
          label: `${t("menu.reading")}`,
          children: [
            {
              key: "/toefl/reading/passage",
              icon: <ContainerOutlined />,
              label: (
                <Link href="/toefl/reading/passage" locale={locale}>
                  {t("menu.passage")}
                </Link>
              ),
            },
            {
              key: "/toefl/reading/sub-passage",
              icon: <ContainerOutlined />,
              label: (
                <Link href="/toefl/reading/sub-passage" locale={locale}>
                  {t("menu.subPassage")}
                </Link>
              ),
            },
            {
              key: "/toefl/reading/list",
              icon: <ProfileOutlined />,
              label: (
                <Link href="/toefl/reading/list" locale={locale}>
                  {t("menu.list")}
                </Link>
              ),
            },
            {
              key: "/toefl/reading/questions",
              icon: <QuestionCircleOutlined />,
              label: (
                <Link href="/toefl/reading/questions" locale={locale}>
                  {t("menu.questions")}
                </Link>
              ),
            },
          ],
        },
        {
          key: "/writing",
          icon: <EditOutlined />,
          label: `${t("menu.writing")}`,
          children: [
            {
              key: "/toefl/writing/writing-part",
              icon: <ContainerOutlined />,
              label: (
                <Link href="/toefl/writing/writing-part" locale={locale}>
                  {t("menu.writingPart")}
                </Link>
              ),
            },
            {
              key: "/toefl/writing/list",
              icon: <ProfileOutlined />,
              label: (
                <Link href="/toefl/writing/list" locale={locale}>
                  {t("menu.list")}
                </Link>
              ),
            },
            {
              key: "/toefl/writing/questions",
              icon: <QuestionCircleOutlined />,
              label: (
                <Link href="/toefl/writing/questions" locale={locale}>
                  {t("menu.questions")}
                </Link>
              ),
            },
          ],
        },
        {
          key: "/speaking",
          icon: <AudioOutlined />,
          label: `${t("menu.speaking")}`,
          children: [
            {
              key: "/toefl/speaking/speaking-part",
              icon: <ContainerOutlined />,
              label: (
                <Link href="/toefl/speaking/speaking-part" locale={locale}>
                  {t("menu.speakingPart")}
                </Link>
              ),
            },
            {
              key: "/toefl/speaking/list",
              icon: <ProfileOutlined />,
              label: (
                <Link href="/toefl/speaking/list" locale={locale}>
                  {t("menu.list")}
                </Link>
              ),
            },
          ],
        },
        {
          key: "/toefl/answers",
          icon: <CommentOutlined />,
          label: (
            <Link href="/toefl/answers" locale={locale}>
              {t("menu.answers")}
            </Link>
          ),
        },
        // {
        //   key: "/toefl/questions",
        //   icon: <QuestionCircleOutlined />,
        //   label: (
        //     <Link href="/toefl/questions" locale={locale}>
        //       {t("menu.questions")}
        //     </Link>
        //   ),
        // },
      ],
    },
    {
      key: "/deskbook",
      icon: <CodeSandboxOutlined />,
      label: `${t("menu.reference")}`,
      children: [
        {
          key: "/deskbook/pavilions",
          icon: <ApartmentOutlined />,
          label: (
            <Link href="/deskbook/pavilions" locale={locale}>
              {t("menu.pavilions")}
            </Link>
          ),
        },
        {
          key: "/deskbook/session-types",
          icon: <FileDoneOutlined />,
          label: (
            <Link href="/deskbook/session-types" locale={locale}>
              {t("menu.testType")}
            </Link>
          ),
        },
        // {
        //   key: "/expr1",
        //   icon: <FileDoneOutlined />,
        //   label: "MyId",
        //   children: [
        //     {
        //       key: "/deskbook/expr1/expr2",
        //       icon: <FileDoneOutlined />,
        //       label: (
        //         <Link href="/deskbook/expr1/expr2" locale={locale}>
        //           MyId
        //         </Link>
        //       ),
        //     },
        //   ],
        // },
      ],
    },
    {
      key: "/accounts",
      icon: <UserSwitchOutlined />,
      label: `${t("menu.profiles")}`,
      children: [
        {
          key: "/accounts/users",
          icon: <UsergroupAddOutlined />,
          label: (
            <Link href="/accounts/users" locale={locale}>
              {t("menu.users")}
            </Link>
          ),
        },
        {
          key: "/accounts/operators",
          icon: <AudioOutlined />,
          label: (
            <Link href="/accounts/operators" locale={locale}>
              {t("menu.operators")}
            </Link>
          ),
        },
        {
          key: "/accounts/permissions",
          icon: <UnlockOutlined />,
          label: (
            <Link href="/accounts/permissions" locale={locale}>
              {t("menu.permissions")}
            </Link>
          ),
        },
        {
          key: "/accounts/roles",
          icon: <TeamOutlined />,
          label: (
            <Link href="/accounts/roles" locale={locale}>
              {t("menu.roles")}
            </Link>
          ),
        },
      ],
    },
  ];
  const {
    token: { colorBgContainer, borderRadiusLG },
  } = theme.useToken();

  useEffect(() => {
    const pathSegments = currentPath
      .split("/")
      .filter(Boolean)
      .map((segment) => `/${segment}`);
    dispatch(changeMenukey(pathSegments));
  }, []);
  const handleOpenChange = (keys: string[]) => {
    dispatch(changeMenukey(keys));
  };

  useEffect(() => {
    if (!userInfo?.token) {
      router.push("/login"); // Agar token yo'q bo'lsa, foydalanuvchini login sahifasiga yo'naltirish
    }
  }, [router]);
  const onBreakpoint = (broken: boolean) => {
    setCollapsed(broken);
  };
  const getActiveMenuKeys = (path: string) => {
    const segments = path.split("/").filter(Boolean);
    return segments.map((_, index) => `/${segments.slice(0, index + 1).join("/")}`);
  };
  return (
    <Layout className="main-layout">
      <Sider
        trigger={null}
        className={!collapsed ? "big-layout-slider" : ""}
        collapsible
        collapsed={collapsed}
        onBreakpoint={onBreakpoint} // onBreakpoint yordamida collapsed boshqarish
        breakpoint="md"
      >
        <div className="demo-logo-vertical" />
        <div className="main-logo-box">
          <Image
            src="/images/Logo.svg"
            height={64}
            width="100%"
            alt="empty"
            className="main-logo"
            preview={false}
          />
        </div>
        <Menu
          className="menu-box"
          items={menuItems}
          theme="dark"
          mode="inline"
          defaultSelectedKeys={["1"]}
          // selectedKeys={[currentPath]} // selectedKeys xususiyati
          selectedKeys={getActiveMenuKeys(currentPath)}
          openKeys={menuKey} // openKeys xususiyati
          onOpenChange={handleOpenChange}
        />
      </Sider>
      <Layout className="base-content-box">
        <Header style={{ padding: 0, background: colorBgContainer }}>
          <Flex justify={"space-between"} align={"center"}>
            <Button
              type="text"
              icon={collapsed ? <MenuUnfoldOutlined /> : <MenuFoldOutlined />}
              onClick={() => setCollapsed(!collapsed)}
              style={{
                fontSize: "16px",
                width: 68,
                height: 64,
              }}
            />
            <Flex align="center" className="user-dropdown-box">
              <LanguageSelect />
              <Flex className="user-dropdown" align="center">
                <UserInfo />
              </Flex>
            </Flex>
          </Flex>
        </Header>
        <Content>
          <div
            className="main-content-box"
            style={{
              margin: "24px 16px",
              padding: 24,
              background: colorBgContainer,
              borderRadius: borderRadiusLG,
            }}
          >
            {children}
          </div>
        </Content>
      </Layout>
    </Layout>
  );
}
export default MainLayout;
