export default function Custom500() {
  return (
    <div>
      <div>
        <h1>500 | 😢</h1>
        <div className="">Технические неполадки</div>
      </div>
    </div>
  );
}
