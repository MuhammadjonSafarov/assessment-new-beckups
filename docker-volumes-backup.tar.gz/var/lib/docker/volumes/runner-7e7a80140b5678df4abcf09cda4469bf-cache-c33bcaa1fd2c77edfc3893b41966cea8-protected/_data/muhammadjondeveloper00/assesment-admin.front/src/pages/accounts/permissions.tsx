import {
  Col,
  Row,
  Breadcrumb,
  Flex,
  Typography,
  Button,
  Modal,
  Form,
  Input,
  Select,
  Table,
  ConfigProvider,
  Skeleton,
  Tag,
} from "antd";
import MainLayout from "@/components/layout/MainLayout";
import React, { useCallback, useEffect, useRef, useState } from "react";
import { useRouter } from "next/router";
import { axiosServer } from "@/plugins/axiosServer";
import { useAppSelector } from "@/hooks/hooks";

const { Column } = Table;
import {
  ArrowLeftOutlined,
  CrownOutlined,
  DeleteOutlined,
  DesktopOutlined,
  EditOutlined,
  HomeOutlined,
  KeyOutlined,
  UnlockOutlined,
} from "@ant-design/icons";
import useTranslation from "next-translate/useTranslation";
import { cannotEmptyRules } from "@/helpers/validationRules";
import { toast } from "react-toastify";
import { PermissionType } from "@/dto/AppDTO";
import { dateFormat } from "@/helpers/typeChange";

export default function Permissions() {
  const { Title } = Typography;
  const { Option } = Select;
  const router = useRouter();
  const { locale } = router;
  const { t } = useTranslation("lang");
  const [form] = Form.useForm();
  const values: any = Form.useWatch([], form);
  const [dataItem, setDataItem] = useState<PermissionType[]>([]);
  const [openModal, setOpenModal] = useState(false);
  const [loading, setLoading] = useState(false);
  const [formBtnLoading, setFormBtnLoading] = useState(false);
  const [editLineId, setEditLineId] = useState(0);
  const [totalItem, setTotalItem] = useState(1);
  const filter = useRef<string | null>(null);

  // console.log(666666, filter.current);
  const [query, setquery] = useState({
    page: 0,
    limit: 10,
    search: {},
  });
  const formTemplate = {
    name: "",
    type: "ADMINISTRATOR",
  };
  const [isButtonDisabled, setIsButtonDisabled] = useState(false);
  const [initialValuesItem, setIsInitialValues] = useState<any>({ isRent: false });
  const cannotEmpty = cannotEmptyRules();
  const userInfo = useAppSelector((state) => state.user); // hooks/hooks.ts qo'shilgandan keyin shundoq ishlatsa buladi
  const breadcrumbItem = [
    {
      href: `/${locale}`,
      title: <HomeOutlined />,
    },
    {
      href: "",
      title: `${t("menu.reference")}`,
    },
    {
      title: `${t("menu.permissions")}`,
    },
  ];

  // Define the function to load pavilion data
  const loadData = useCallback(async () => {
    setLoading(true);
    // console.log(88888, filter?.current);
    const lastUrl = filter?.current || "ALL";
    await axiosServer(router.locale, false, userInfo?.token)
      .post(`/api/v1/permission/list-search/${lastUrl}`, query)
      .then((res: any) => {
        setLoading(false);
        setTotalItem(res?.data?.total || 1);
        setDataItem(res?.data?.list || []); // Update the state with the fetched data
      })
      .catch(() => {
        setDataItem([]);
        setLoading(false);
      });
  }, [router.locale, query]);
  useEffect(() => {
    loadData();
  }, [router.locale, query]);

  useEffect(() => {
    form
      .validateFields({ validateOnly: true })
      .then(() => setIsButtonDisabled(true))
      .catch(() => setIsButtonDisabled(false));
    // console.log(555, form.getFieldsValue());
  }, [form, values]);
  const handleOk = async () => {
    const values = form.getFieldsValue();
    if (editLineId) {
      setFormBtnLoading(true);
      await axiosServer(router.locale, false, userInfo?.token)
        .put(`/api/v1/permission/${editLineId}`, values)
        .then(() => {
          setEditLineId(0);
          toast.success(`${t("toast.successfully")}`);
          form.setFieldsValue(formTemplate);
          setFormBtnLoading(false);
          setOpenModal(false);
          loadData();
        })
        .catch(() => {
          setFormBtnLoading(false);
        });
    } else {
      await axiosServer(router.locale, false, userInfo?.token)
        .post("/api/v1/permission", values)
        .then(() => {
          toast.success(`${t("toast.successfully")}`);
          form.setFieldsValue(formTemplate);
          setOpenModal(false);
          loadData();
        })
        .catch(() => "");
    }
  };
  const editItemModal = async (id: number) => {
    form.setFieldsValue(formTemplate);
    // console.log("eeeeee", values);
    if (id) {
      setEditLineId(id);
      setOpenModal(true);
      setFormBtnLoading(true);
      await axiosServer(router.locale, false, userInfo?.token)
        .get(`/api/v1/permission/${id}`)
        .then((res: any) => {
          setFormBtnLoading(false);
          if (res) {
            setIsInitialValues(res);
            form.setFieldsValue(res);
          }
        })
        .catch(() => {
          setFormBtnLoading(false);
        });
    }
  };

  const deleteItemModal = () => {
    // console.log("Delete Itemmm", id);
  };

  const closeModal = () => {
    setEditLineId(0);
    form.setFieldsValue(formTemplate);
    setOpenModal(false);
  };
  // Handle pagination changes
  const handlePaginationChange = (page: number, pageSize: number) => {
    const limintChange = page - 1 === query.page;
    setquery((prevQuery) => ({
      ...prevQuery,
      page: limintChange ? 0 : page - 1, // Update page to 5
      limit: pageSize, // Update limit to 3
    }));
  };

  const openCreateModal = () => {
    setOpenModal(true);
    // Explicitly set initial values for a new pavilion if required
    form.setFieldsValue(formTemplate);
  };

  // useCallback(async () => {}, [router.locale, filter]);
  const handleChange = (value: string) => {
    // console.log(44444444, value);
    filter.current = value;
    loadData();
  };

  return (
    <MainLayout>
      <Row className="pavilion-box ass-style">
        <Col span={24}>
          <div>
            <Breadcrumb items={breadcrumbItem} />
          </div>
        </Col>
        <Col span={24} className="add-pavilion-box">
          <Flex justify={"space-between"}>
            <div>
              <Flex align={"center"}>
                <ArrowLeftOutlined style={{ marginRight: "16px", fontSize: "16px" }} />
                <Title level={4} className="m-0">
                  {t("permissions.list")}
                </Title>
              </Flex>
              <div>
                <Select
                  value={filter?.current}
                  onChange={handleChange}
                  style={{ width: "276px", height: "40px", marginTop: "16px" }}
                  placeholder={t("permissions.select")}
                  suffixIcon={<UnlockOutlined />}
                  allowClear
                >
                  <Option value="ADMINISTRATOR">
                    <CrownOutlined className="select-item-icon mr-1" />
                    {t("permissions.adminPanel")}
                  </Option>
                  <Option className="select-item-icon" value="MONITORING">
                    <UnlockOutlined className="select-item-icon mr-1" />{" "}
                    {t("permissions.monitoring")}
                  </Option>
                </Select>
              </div>
            </div>
            <Flex align={"end"}>
              <Button
                onClick={openCreateModal}
                style={{ marginRight: "20px" }}
                className="add-pavilion"
                type="primary"
                shape="round"
                icon={<KeyOutlined />}
                size="large"
              >
                {t("permissions.add")}
              </Button>
            </Flex>
          </Flex>
        </Col>
      </Row>
      <Row>
        <Col span={24}>
          <ConfigProvider
            //@ts-ignore
            locale={{
              Pagination: {
                items_per_page: "/" + t("table.page"), // Sahifa hajmi matnini o'zgartirish
              },
            }}
          >
            <Table<PermissionType>
              className="ass-table"
              dataSource={loading ? [] : dataItem}
              rowKey={(record): React.Key => record.id}
              pagination={{
                current: query.page + 1,
                pageSize: query.limit,
                total: totalItem,
                onChange: handlePaginationChange,
                showSizeChanger: true,
                pageSizeOptions: ["10", "20", "50"], // Customize the available page sizes
              }}
              loading={loading}
              locale={{
                emptyText: loading ? <Skeleton active paragraph={{ rows: 5 }} /> : t("empty"),
              }}
            >
              <Column title={`${t("table.header.title")}`} dataIndex="name" key="name" />
              <Column
                title={`${t("table.header.type")}`}
                dataIndex="type"
                key="type"
                render={(text) =>
                  text === "ADMINISTRATOR" ? (
                    <Tag
                      icon={<CrownOutlined />}
                      style={{ fontSize: "14px", padding: "5px 10px" }}
                      color="#3BB371"
                    >
                      Admin-panel ruxsatlari
                    </Tag>
                  ) : (
                    <Tag
                      icon={<DesktopOutlined />}
                      style={{ fontSize: "14px", padding: "5px 10px" }}
                      color="#0F8FB0"
                    >
                      Monitoring ruxsatlari
                    </Tag>
                  )
                }
              />
              <Column
                title={`${t("table.header.createdDate")}`}
                dataIndex="createdDate"
                key="createdDate"
                render={(date: string) => (date?.length ? dateFormat(date) : "")}
              />

              <Column
                title={`${t("table.header.actions")}`}
                dataIndex="id"
                key="id"
                render={(id: number) => (
                  <div>
                    <Button
                      onClick={() => editItemModal(id)}
                      className="bg-primary color-white"
                      shape="round"
                    >
                      <EditOutlined />
                    </Button>
                    <Button
                      danger
                      disabled
                      onClick={() => deleteItemModal()}
                      className="ml-2"
                      shape="round"
                    >
                      <DeleteOutlined />
                    </Button>
                  </div>
                )}
              />
            </Table>
          </ConfigProvider>
        </Col>
      </Row>
      <Row className="ass-style">
        <Modal
          className="ass-style ass-modal ass-modal-small"
          centered
          open={openModal}
          title={`${t("permissions.add")}`}
          onOk={handleOk}
          onCancel={closeModal}
          footer={[
            <Button key="close" onClick={closeModal}>
              {t("form.close")}
            </Button>,
            <Button
              key="create"
              className={!isButtonDisabled ? "" : "base-bg color-white"}
              disabled={!isButtonDisabled}
              onClick={handleOk}
              loading={formBtnLoading}
            >
              {t("form.create")}
            </Button>,
          ]}
        >
          <div className="ass-modal-body">
            <Skeleton loading={formBtnLoading} active paragraph={{ rows: 5 }}>
              <Form
                initialValues={initialValuesItem}
                form={form}
                layout="vertical"
                name="pavilion"
                style={{ width: "100%", marginTop: "20px" }}
                autoComplete="off"
              >
                <Row>
                  <Col span={24} className="pavilion-input">
                    <Form.Item name="name" label={`${t("table.header.title")}`} rules={cannotEmpty}>
                      <Input prefix={<EditOutlined />} placeholder={t("form.enterTitle")} />
                    </Form.Item>
                  </Col>

                  <Col span={24} className="pavilion-input">
                    <Form.Item name="type" label={`${t("table.header.type")}`} rules={cannotEmpty}>
                      <Select placeholder={t("form.status")} allowClear>
                        <Option value="ADMINISTRATOR"> {t("permissions.adminPanel")}</Option>
                        <Option value="MONITORING"> {t("permissions.monitoring")}</Option>
                      </Select>
                    </Form.Item>
                  </Col>
                </Row>
              </Form>
            </Skeleton>
          </div>
        </Modal>
      </Row>
    </MainLayout>
  );
}
