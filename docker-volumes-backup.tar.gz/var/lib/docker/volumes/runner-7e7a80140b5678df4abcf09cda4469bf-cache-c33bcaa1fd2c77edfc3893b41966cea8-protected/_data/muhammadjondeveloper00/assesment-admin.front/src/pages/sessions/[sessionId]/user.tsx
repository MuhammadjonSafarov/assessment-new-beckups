import {
  Col,
  Row,
  Flex,
  Typography,
  Tabs,
  Table,
  Skeleton,
  Button,
  Modal,
  Form,
  Select,
  Tag,
  Card,
  Dropdown,
  Space,
  Image,
  type MenuProps,
} from "antd";
import MainLayout from "@/components/layout/MainLayout";
import React, { useCallback, useEffect, useState } from "react";
import { useRouter } from "next/router";
import { axiosServer } from "@/plugins/axiosServer";
import { useAppSelector } from "@/hooks/hooks";
import type { TabsProps } from "antd";
import {
  ArrowLeftOutlined,
  CustomerServiceOutlined,
  EditOutlined,
  DashboardOutlined,
  AudioOutlined,
  ScheduleOutlined,
  DownOutlined,
} from "@ant-design/icons";
// import useTranslation from "next-translate/useTranslation";
import { OperatorType, speakingAnswersType, writingAnswersType } from "@/dto/AppDTO";
import useTranslation from "next-translate/useTranslation";
import { toast } from "react-toastify";
import { cannotEmptyRules } from "@/helpers/validationRules";
import FileUpload from "@/components/widgets/FileUpload";
import { Input } from "antd";
export default function CandidatesPage() {
  const { Title } = Typography;
  const { TextArea } = Input;
  const router = useRouter();
  // const { t } = useTranslation("lang");
  const [dataItem, setDataItem] = useState<any>();
  const [loading, setLoading] = useState(false);
  const [keyItem, setKeyItem] = useState<string>("1");
  const { t } = useTranslation("lang");
  const { Column } = Table;
  // console.log(666666, filter.current);
  const userInfo = useAppSelector((state) => state.user); // hooks/hooks.ts qo'shilgandan keyin shundoq ishlatsa buladi
  const [openModal, setOpenModal] = useState(false);
  const [initialValuesItem, setIsInitialValues] = useState<any>({ isRent: false });
  const formTemplate = {
    id: null,
    degree: null,
  };
  const [isButtonDisabled, setIsButtonDisabled] = useState(false);
  const [formBtnLoading, setFormBtnLoading] = useState(false);
  const [resultOptions, setResultOptions] = useState<string[]>([]);
  const cannotEmpty = cannotEmptyRules();

  const [form] = Form.useForm();
  const values: any = Form.useWatch([], form);
  const loadData = useCallback(async () => {
    // console.log(88888, filter?.current);
    // const lastUrl = filter?.current || "ALL";
    const userId = router?.query?.userId || null;
    if (!userId) return;
    const query = {
      page: 0,
      limit: 0,
      search: {
        value: "",
      },
    };
    setLoading(true);
    await axiosServer(router.locale, true, userInfo?.token)
      .post(`/api/v1/user-application/list-search/${userId}`, query)
      .then((res: any) => {
        setLoading(false);
        // console.log(9999, res?.data?.list[0].session.testType.resultOptions);
        const sessionIdItem: number | undefined = router?.query?.sessionId
          ? Number(router?.query?.sessionId)
          : undefined;

        if (res?.data?.data.list?.length && sessionIdItem) {
          const listItem: any = res?.data?.data?.list.find(
            (item: any) => item && item.tempSessionId === sessionIdItem,
          );
          setDataItem(listItem); // Update the state with the fetched data
          setResultOptions(
            listItem?.session?.testType?.resultOptions?.length
              ? listItem?.session?.testType?.resultOptions
              : [],
          );
          // setResultOptions(
          //     res?.data?.data.list?.length &&
          //     res?.data?.data?.list[0] &&
          //     res?.data?.data?.list[0]?.session?.testType?.resultOptions?.length
          //         ? res?.data?.data?.list[0].session.testType.resultOptions
          //         : [],
          // );
        } else {
          setDataItem([]);
          setResultOptions([]);
        }
      })
      .catch(() => {
        setLoading(false);

        // console.log("error")
      });
  }, [router.locale]);
  useEffect(() => {
    loadData();
  }, [router.locale]);

  const addDegree = () => {
    setOpenModal(true);
  };
  const closeModal = () => {
    setIsInitialValues(formTemplate);
    form.setFieldsValue(formTemplate);
    setOpenModal(false);
  };
  useEffect(() => {
    form
      .validateFields({ validateOnly: true })
      .then(() => setIsButtonDisabled(true))
      .catch(() => setIsButtonDisabled(false));
    // console.log(555, form.getFieldsValue());
  }, [form, values]);
  // Handle pagination changes
  const onChange = (key: string) => {
    setKeyItem(key);
    return key;
  };
  const answerCorrectList = (answer: any) => {
    const list: any[] = [];
    if (answer.answers.length) {
      answer.answers.forEach((item: any) => {
        const question = answer?.question?.answers?.find(
          (itm: any) => itm?.id === item && itm?.isCorrect,
        );
        if (question) {
          list.push(question);
        }
      });
    }

    return list;
  };
  const addCertificate = async (fileId: number) => {
    const userAplicationId = dataItem.id || null;
    if (fileId && userAplicationId) {
      await axiosServer(router.locale, true, userInfo?.token)
        .post(`/api/v1/user-application/attach-certificate-file/${userAplicationId}/${fileId}`)
        .then(() => {
          loadData();
          toast.success(`${t("toast.successfully")}`);
        })
        .catch(() => {
          // console.log("error")
        });
    }
  };
  const certificateChange = (act: any) => {
    if (act.status) {
      addCertificate(act?.info?.id);
    }
  };
  const answerProsent = (item: any) => {
    return parseFloat(
      ((answerCorrectList(item).length * 100) / item?.question?.correctAnswersCount).toFixed(1),
    );
  };
  const answerProsentCount = (item: any, type: string) => {
    if (
      type === "listening" &&
      dataItem?.session?.listeningScore &&
      item?.question?.coefficient &&
      dataItem?.listeningAnswers?.length
    ) {
      return parseFloat(
        (
          (answerCorrectList(item).length *
            dataItem?.session?.listeningScore *
            item?.question?.coefficient) /
          (item?.question?.correctAnswersCount * dataItem?.listeningAnswers?.length)
        ).toFixed(2),
      );
    } else if (
      type === "reading" &&
      dataItem?.session?.readingScore &&
      dataItem?.readingAnswers?.length &&
      item?.question?.coefficient
    ) {
      return parseFloat(
        (
          (answerCorrectList(item).length *
            dataItem?.session?.readingScore *
            item?.question?.coefficient) /
          (item?.question?.correctAnswersCount * dataItem?.readingAnswers?.length)
        ).toFixed(2),
      );
    } else {
      return 0;
    }
  };
  const itemsFirst: MenuProps["items"] = [
    {
      key: "1",
      label: (
        <div>
          <FileUpload handlechange={certificateChange} />
        </div>
      ),
    },
  ];
  const items: TabsProps["items"] = [
    {
      key: "1",
      label: (
        <span>
          <CustomerServiceOutlined className="mr-3" />
          {t("form.label.listening")}
        </span>
      ),
      children: (
        <Row>
          <Col span={24} className="mt-3 mb-2">
            <Flex justify={"end"}>
              <div>
                {dataItem?.listeningDegree && (
                  <Tag style={{ fontSize: "14px", padding: "5px 10px" }} color="cyan">
                    {dataItem?.listeningDegree}
                  </Tag>
                )}
                <Button className="mb-3" type="primary" onClick={addDegree} shape="round">
                  {t("addDegree")}
                </Button>
              </div>
            </Flex>
          </Col>
          {dataItem?.listeningAnswers?.length ? (
            <Col span={24}>
              <Table<OperatorType>
                className="ass-table"
                dataSource={loading ? [] : dataItem.listeningAnswers}
                rowKey={(record): React.Key => record.id}
                loading={loading}
                locale={{
                  emptyText: loading ? <Skeleton active paragraph={{ rows: 5 }} /> : t("empty"),
                }}
              >
                <Column title="#" dataIndex="id" key="id" />
                <Column
                  title={`${t("question")}`}
                  key="question"
                  render={(item: any) => (
                    <div>
                      <div className="ml-2" style={{ maxWidth: "250px", whiteSpace: "wrap" }}>
                        {item?.question?.name}
                      </div>
                    </div>
                  )}
                />

                <Column
                  title={`${t("answers")}`}
                  key="answers"
                  render={(item: any) => (
                    <div>
                      <div className="ml-2" style={{ maxWidth: "250px", whiteSpace: "wrap" }}>
                        {item?.question?.answers?.length &&
                          item?.question.answers.map((val: any) => (
                            <div>
                              {(val?.isCorrect &&
                                item?.answers?.length &&
                                item?.answers.includes(val.id)) ||
                              val?.isCorrect ? (
                                <Tag
                                  style={{ marginTop: "10px", whiteSpace: "wrap" }}
                                  color="green"
                                >
                                  {val?.answer}
                                </Tag>
                              ) : !val?.isCorrect &&
                                item?.answers?.length &&
                                item?.answers.includes(val.id) ? (
                                <Tag style={{ marginTop: "10px", whiteSpace: "wrap" }} color="red">
                                  {val?.answer}
                                </Tag>
                              ) : (
                                <Tag
                                  style={{ marginTop: "10px", whiteSpace: "wrap" }}
                                  color="default"
                                >
                                  {val?.answer}
                                </Tag>
                              )}
                            </div>
                          ))}
                      </div>
                    </div>
                  )}
                />

                <Column
                  title={`${t("percentage")}`}
                  render={(item: any) => (
                    <div>
                      <div className="ml-2" style={{ maxWidth: "250px", whiteSpace: "wrap" }}>
                        {item?.question?.correctAnswersCount && answerCorrectList(item)?.length
                          ? answerProsent(item)
                          : 0}
                        %
                      </div>
                    </div>
                  )}
                />
                <Column
                  title={`${t("ball")}`}
                  render={(item: any) => (
                    <div>
                      {/*<div className="ml-2" style={{ maxWidth: "250px", whiteSpace: "wrap" }}>*/}
                      {/*  {item?.question?.correctAnswersCount && answerCorrectList(item)?.length*/}
                      {/*    ? answerProsent(item)*/}
                      {/*    : 0}*/}
                      {/*  %*/}
                      {/*</div>*/}
                      <div className="ml-2" style={{ maxWidth: "250px", whiteSpace: "wrap" }}>
                        {item?.question?.correctAnswersCount && answerCorrectList(item)?.length
                          ? answerProsentCount(item, "listening")
                          : 0}
                      </div>
                    </div>
                  )}
                />
              </Table>
            </Col>
          ) : (
            ""
          )}
        </Row>
      ),
    },
    {
      key: "2",
      label: (
        <span>
          <DashboardOutlined className="mr-3" />
          {t("form.label.reading")}
        </span>
      ),
      children: (
        <Row>
          <Col span={24} className="mt-3 mb-2">
            <Flex justify={"end"}>
              <div>
                {dataItem?.readingDegree && (
                  <Tag style={{ fontSize: "14px", padding: "5px 10px" }} color="cyan">
                    {dataItem?.readingDegree}
                  </Tag>
                )}

                <Button className="mb-3" type="primary" onClick={addDegree} shape="round">
                  {t("addDegree")}
                </Button>
              </div>
            </Flex>
          </Col>
          {dataItem?.readingAnswers?.length ? (
            <Col span={24}>
              <Table<OperatorType>
                className="ass-table"
                dataSource={loading ? [] : dataItem.readingAnswers}
                rowKey={(record): React.Key => record.id}
                loading={loading}
                locale={{
                  emptyText: loading ? <Skeleton active paragraph={{ rows: 5 }} /> : t("empty"),
                }}
              >
                <Column title="#" dataIndex="id" key="id" />
                <Column
                  title={`${t("question")}`}
                  key="question"
                  render={(item: any) => (
                    <div>
                      <div className="ml-2" style={{ maxWidth: "250px", whiteSpace: "wrap" }}>
                        {item?.question?.name}
                      </div>
                    </div>
                  )}
                />

                <Column
                  title={`${t("answers")}`}
                  key="answers"
                  render={(item: any) => (
                    <div>
                      <div className="ml-2" style={{ maxWidth: "250px", whiteSpace: "wrap" }}>
                        {item?.question?.answers?.length &&
                          item?.question.answers.map((val: any) => (
                            <div>
                              {(val?.isCorrect &&
                                item?.answers?.length &&
                                item?.answers.includes(val.id)) ||
                              val?.isCorrect ? (
                                <Tag
                                  style={{ marginTop: "10px", whiteSpace: "wrap" }}
                                  color="green"
                                >
                                  {val?.answer}
                                </Tag>
                              ) : !val?.isCorrect &&
                                item?.answers?.length &&
                                item?.answers.includes(val.id) ? (
                                <Tag style={{ marginTop: "10px", whiteSpace: "wrap" }} color="red">
                                  {val?.answer}
                                </Tag>
                              ) : (
                                <Tag
                                  style={{ marginTop: "10px", whiteSpace: "wrap" }}
                                  color="default"
                                >
                                  {val?.answer}
                                </Tag>
                              )}
                            </div>
                          ))}
                      </div>
                    </div>
                  )}
                />

                <Column
                  title={`${t("percentage")}`}
                  render={(item: any) => (
                    <div>
                      <div className="ml-2" style={{ maxWidth: "250px", whiteSpace: "wrap" }}>
                        {item?.question?.correctAnswersCount && answerCorrectList(item)?.length
                          ? answerProsent(item)
                          : 0}
                        %
                      </div>
                    </div>
                  )}
                />
                <Column
                  title={`${t("ball")}`}
                  render={(item: any) => (
                    <div>
                      {/*<div className="ml-2" style={{ maxWidth: "250px", whiteSpace: "wrap" }}>*/}
                      {/*  {item?.question?.correctAnswersCount && answerCorrectList(item)?.length*/}
                      {/*    ? answerProsent(item)*/}
                      {/*    : 0}*/}
                      {/*  %*/}
                      {/*</div>*/}
                      <div className="ml-2" style={{ maxWidth: "250px", whiteSpace: "wrap" }}>
                        {item?.question?.correctAnswersCount && answerCorrectList(item)?.length
                          ? answerProsentCount(item, "reading")
                          : 0}
                      </div>
                    </div>
                  )}
                />
              </Table>
            </Col>
          ) : (
            ""
          )}
        </Row>
      ),
    },
    {
      key: "3",
      label: (
        <span>
          <EditOutlined className="mr-3" />
          {t("form.label.writing")}
        </span>
      ),
      children: (
        <Row>
          <Col span={24} className="mt-3 mb-2">
            <Flex justify={"end"}>
              <div>
                {dataItem?.writingDegree && (
                  <Tag style={{ fontSize: "14px", padding: "5px 10px" }} color="cyan">
                    {dataItem?.writingDegree}
                  </Tag>
                )}

                <Button className="mb-3" type="primary" onClick={addDegree} shape="round">
                  {t("addDegree")}
                </Button>
              </div>
            </Flex>
          </Col>
          {dataItem?.writingAnswers?.length ? (
            <Col span={24}>
              <Table<writingAnswersType>
                className="ass-table"
                dataSource={loading ? [] : dataItem.writingAnswers}
                rowKey={(record): React.Key => record.id}
                loading={loading}
                locale={{
                  emptyText: loading ? <Skeleton active paragraph={{ rows: 5 }} /> : t("empty"),
                }}
              >
                <Column title="#" dataIndex="id" key="id" />

                <Column
                  title={`${t("answers")}`}
                  key="body"
                  render={(item: any) => (
                    <div>
                      <div className="ml-2">
                        <TextArea
                          autoSize={{ minRows: 3, maxRows: 1000 }}
                          placeholder={`${t("noInfo")}`}
                          value={item?.body}
                        />
                      </div>
                    </div>
                  )}
                />
              </Table>
            </Col>
          ) : (
            ""
          )}
        </Row>
      ),
    },
    {
      key: "4",
      label: (
        <span>
          <AudioOutlined className="mr-3" />
          {t("form.label.speaking")}
        </span>
      ),
      children: (
        <Row>
          <Col span={24} className="mt-3 mb-2">
            <Flex justify={"end"}>
              <div>
                {dataItem?.speakingDegree && (
                  <Tag style={{ fontSize: "14px", padding: "5px 10px" }} color="cyan">
                    {dataItem?.speakingDegree}
                  </Tag>
                )}

                <Button className="mb-3" type="primary" onClick={addDegree} shape="round">
                  {t("addDegree")}
                </Button>
              </div>
            </Flex>
          </Col>
          {dataItem?.speakingAnswers?.length ? (
            <Col span={24}>
              <Table<speakingAnswersType>
                className="ass-table"
                dataSource={loading ? [] : dataItem.speakingAnswers}
                rowKey={(record): React.Key => record.id}
                loading={loading}
                locale={{
                  emptyText: loading ? <Skeleton active paragraph={{ rows: 5 }} /> : t("empty"),
                }}
              >
                <Column title="#" dataIndex="id" key="id" />

                <Column
                  title={`${t("answersAudio")}`}
                  key="speakingAnswerFile"
                  render={(item: any) => (
                    <div>
                      <div className="ml-2">
                        {item?.speakingAnswerFile?.url ? (
                          <audio controls>
                            <source
                              src={`${process.env.NEXT_PUBLIC_IMAGES_URL}/${item.speakingAnswerFile.url}`}
                              type="audio/mp3"
                            />
                            <source
                              src={`${process.env.NEXT_PUBLIC_IMAGES_URL}/${item.url}`}
                              type="audio/wav"
                            />
                          </audio>
                        ) : (
                          <div>{t("noInfo")}</div>
                        )}
                      </div>
                    </div>
                  )}
                />
              </Table>
            </Col>
          ) : (
            ""
          )}
        </Row>
      ),
    },
    {
      key: "5",
      label: (
        <span>
          <ScheduleOutlined className="mr-3" />
          {t("form.label.speaking")}
        </span>
      ),
      children: (
        <div>
          <Col span={12}>
            <Card
              title={`${t("sertificate")}`}
              extra={
                <Dropdown menu={{ items: itemsFirst }}>
                  <a onClick={(e) => e.preventDefault()}>
                    <Space>
                      {t("table.header.actions")}
                      <DownOutlined />
                    </Space>
                  </a>
                </Dropdown>
              }
              style={{ width: 300 }}
              cover={
                dataItem?.certificateFileDto?.url ? (
                  <Image
                    style={{ padding: "8px" }}
                    src={`${process.env.NEXT_PUBLIC_IMAGES_URL}/${dataItem?.certificateFileDto?.url}`}
                    alt="empty"
                    preview
                  />
                ) : (
                  <Image
                    style={{ padding: "8px" }}
                    src="/images/no-image.jpg"
                    alt="empty"
                    preview
                  />
                )
              }
            ></Card>
          </Col>
        </div>
      ),
    },
  ];
  const backLink = () => {
    const sessionId = router?.query?.sessionId || null;
    if (!sessionId) return;
    router.push(`/sessions/${sessionId}`).catch(() => {
      //
    });
  };
  const handleOk = async () => {
    const values = form.getFieldsValue();

    if (dataItem?.id && values?.degree && keyItem === "1") {
      setFormBtnLoading(true);
      await axiosServer(router.locale, false, userInfo?.token)
        .post(`/api/v1/user-application/attach-listening-degree/${dataItem?.id}/${values.degree}`)
        .then(() => {
          setFormBtnLoading(false);
          toast.success(`${t("toast.successfully")}`);
          form.setFieldsValue(formTemplate);
          setOpenModal(false);
          loadData();
        })
        .catch(() => {
          setFormBtnLoading(false);
        });
    } else if (dataItem?.id && values?.degree && keyItem === "2") {
      setFormBtnLoading(true);
      await axiosServer(router.locale, false, userInfo?.token)
        .post(`/api/v1/user-application/attach-reading-degree/${dataItem?.id}/${values.degree}`)
        .then(() => {
          setFormBtnLoading(false);
          toast.success(`${t("toast.successfully")}`);
          form.setFieldsValue(formTemplate);
          setOpenModal(false);
          loadData();
        })
        .catch(() => {
          setFormBtnLoading(false);
        });
    } else if (dataItem?.id && values?.degree && keyItem === "3") {
      setFormBtnLoading(true);
      await axiosServer(router.locale, false, userInfo?.token)
        .post(`/api/v1/user-application/attach-writing-degree/${dataItem?.id}/${values.degree}`)
        .then(() => {
          setFormBtnLoading(false);
          toast.success(`${t("toast.successfully")}`);
          form.setFieldsValue(formTemplate);
          setOpenModal(false);
          loadData();
        })
        .catch(() => {
          setFormBtnLoading(false);
        });
    } else if (dataItem?.id && values?.degree && keyItem === "4") {
      setFormBtnLoading(true);
      await axiosServer(router.locale, false, userInfo?.token)
        .post(`/api/v1/user-application/attach-speaking-degree/${dataItem?.id}/${values.degree}`)
        .then(() => {
          setFormBtnLoading(false);
          toast.success(`${t("toast.successfully")}`);
          form.setFieldsValue(formTemplate);
          setOpenModal(false);
          loadData();
        })
        .catch(() => {
          setFormBtnLoading(false);
        });
    }
  };
  return (
    <MainLayout>
      <Row className="pavilion-box ass-style">
        <Col span={24} className="add-pavilion-box">
          <Flex justify={"space-between"}>
            <div>
              <Flex align={"center"}>
                <ArrowLeftOutlined
                  onClick={backLink}
                  style={{ marginRight: "16px", fontSize: "16px" }}
                />
                <Title level={4} className="m-0">
                  {t("result")}
                </Title>
              </Flex>
            </div>
          </Flex>
        </Col>
      </Row>
      <Row>
        <Col span={24}>
          <Tabs type="card" items={items} onChange={onChange} />
        </Col>
      </Row>
      <Row className="ass-style">
        <Modal
          className="ass-style ass-modal ass-modal-small"
          centered
          open={openModal}
          title={`${t("addDegree")}`}
          onOk={handleOk}
          onCancel={closeModal}
          footer={[
            <Button key="close" onClick={closeModal}>
              {t("form.close")}
            </Button>,
            <Button
              key="create"
              className={!isButtonDisabled ? "" : "base-bg color-white"}
              disabled={!isButtonDisabled}
              onClick={handleOk}
              loading={formBtnLoading}
            >
              {t("form.create")}
            </Button>,
          ]}
        >
          <div className="ass-modal-body">
            {/*<Skeleton loading={formBtnLoading} active paragraph={{ rows: 5 }}>*/}
            <Form
              initialValues={initialValuesItem}
              form={form}
              layout="vertical"
              name="pavilion"
              style={{ width: "100%", marginTop: "20px" }}
              autoComplete="off"
            >
              <Row>
                <Col span={24} className="pavilion-input">
                  {resultOptions?.length ? (
                    <Form.Item name="degree" label={`${t("variantName")}`} rules={cannotEmpty}>
                      <Select placeholder={`${t("table.header.select")}`}>
                        {/* Optionsni map qilish */}
                        {resultOptions.map((item: string) => (
                          <Select.Option key={item} value={item}>
                            {item}
                          </Select.Option>
                        ))}
                      </Select>
                    </Form.Item>
                  ) : (
                    <h2 className="text-center"> {t("noInfo")}</h2>
                  )}
                </Col>
              </Row>
            </Form>
            {/*</Skeleton>*/}
          </div>
        </Modal>
      </Row>
    </MainLayout>
  );
}
