import { Button, Result } from "antd";
import { useRouter } from "next/router";
export default function Custom404() {
  const router = useRouter();
  const redirectBack = () => {
    router.back(); // Oldingi sahifaga qaytadi
  };
  return (
    <Result
      status="404"
      title="404"
      subTitle="Kechirasiz, siz tashrif buyurgan sahifa mavjud emas.."
      extra={
        <Button onClick={redirectBack} type="primary">
          Bosh sahifaga o'tish
        </Button>
      }
    />
  );
}
