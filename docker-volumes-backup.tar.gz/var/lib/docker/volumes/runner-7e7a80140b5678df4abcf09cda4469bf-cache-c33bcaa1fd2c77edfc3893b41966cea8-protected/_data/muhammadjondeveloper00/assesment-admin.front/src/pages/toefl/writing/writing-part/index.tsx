import {
  Col,
  Row,
  Breadcrumb,
  Flex,
  Typography,
  Button,
  Modal,
  Table,
  ConfigProvider,
  Skeleton,
} from "antd";
import MainLayout from "@/components/layout/MainLayout";
import React, { useCallback, useEffect, useState } from "react";
import { useRouter } from "next/router";
import { axiosServer } from "@/plugins/axiosServer";
import { useAppSelector } from "@/hooks/hooks";

const { Column } = Table;
import {
  ArrowLeftOutlined,
  DeleteOutlined,
  EditOutlined,
  HomeOutlined,
  QuestionCircleOutlined,
} from "@ant-design/icons";
import useTranslation from "next-translate/useTranslation";
import { toast } from "react-toastify";
import { PermissionType } from "@/dto/AppDTO";

export default function Passage() {
  const { Title } = Typography;
  const router = useRouter();
  const { locale } = router;
  const { t } = useTranslation("lang");
  const [dataItem, setDataItem] = useState<PermissionType[]>([]);
  const [loading, setLoading] = useState(false);
  const [totalItem, setTotalItem] = useState(1);

  // console.log(666666, filter.current);
  const [query, setquery] = useState({
    page: 0,
    limit: 10,
    search: {},
  });
  const [modal, contextHolder] = Modal.useModal();
  const userInfo = useAppSelector((state) => state.user); // hooks/hooks.ts qo'shilgandan keyin shundoq ishlatsa buladi
  const breadcrumbItem = [
    {
      href: `/${locale}`,
      title: <HomeOutlined />,
    },
    {
      href: "",
      title: "TOEFL",
    },
    {
      title: `${t("menu.writing")}`,
    },
  ];
  const confirmModal = (id: number) => {
    modal.confirm({
      title: "",
      icon: <QuestionCircleOutlined style={{ marginTop: "10px" }} />,
      content: <h3>{t("deleteConfirmation")}</h3>,
      okText: t("form.yes"),
      cancelText: t("form.no"),
      onOk() {
        deleteLine(id);
      },
      onCancel() {
        // console.log("Cancel");
      },
      okButtonProps: {
        style: {
          backgroundColor: "#ff4d4f",
          color: "white",
          border: "none",
        },
      },
    });
  };

  // Define the function to load pavilion data
  const loadData = useCallback(async () => {
    setLoading(true);
    // console.log(88888, filter?.current);
    await axiosServer(router.locale, false, userInfo?.token)
      .post(`/api/v1/writingPart/list-search`, query)
      .then((res: any) => {
        setLoading(false);
        setTotalItem(res?.data?.total || 1);
        setDataItem(res?.data?.list || []); // Update the state with the fetched data
      })
      .catch(() => {
        setDataItem([]);
        setLoading(false);
      });
  }, [router.locale, query]);

  useEffect(() => {
    (async () => {
      await loadData();
    })();
  }, [router.locale, query]);

  const deleteItemModal = (id: number) => {
    // console.log("Delete Itemmm", id);
    if (!id) return;
    confirmModal(id);
  };
  const editItemModal = (id: number) => {
    // console.log("Delete Itemmm", id);
    if (!id) return;
    router.push(`/toefl/writing/writing-part/${id}/edit`).catch(() => {
      //
    });
  };
  // Handle pagination changes
  const handlePaginationChange = (page: number, pageSize: number) => {
    const limintChange = page - 1 === query.page;
    setquery((prevQuery) => ({
      ...prevQuery,
      page: limintChange ? 0 : page - 1, // Update page to 5
      limit: pageSize, // Update limit to 3
    }));
  };

  const redirectCreatePage = () => {
    router.push("/toefl/writing/writing-part/create").catch(() => {
      //
    });
  };

  // useCallback(async () => {}, [router.locale, filter]);
  const deleteLine = async (id: number) => {
    if (!id) return;
    await axiosServer(router.locale, false, userInfo?.token)
      .delete(`/api/v1/writingPart/${id}`)
      .then(() => {
        toast.success(`${t("toast.successfully")}`);
        loadData();
      })
      .catch(() => "");
  };

  return (
    <MainLayout>
      <Row className="pavilion-box ass-style">
        <Col span={24}>
          <div>
            <Breadcrumb items={breadcrumbItem} />
          </div>
        </Col>
        <Col span={24} className="add-pavilion-box">
          <Flex justify={"space-between"}>
            <div>
              <Flex align={"center"}>
                <ArrowLeftOutlined style={{ marginRight: "16px", fontSize: "16px" }} />
                <Title level={4} className="m-0">
                  {t("menu.list")}
                </Title>
              </Flex>
            </div>
            <Flex align={"end"}>
              <Button
                onClick={redirectCreatePage}
                style={{ marginRight: "20px" }}
                className="add-pavilion"
                type="primary"
                shape="round"
                size="large"
              >
                {t("createWritingPart")}
              </Button>
            </Flex>
          </Flex>
        </Col>
      </Row>
      <Row>
        <Col span={24}>
          <ConfigProvider
            //@ts-ignore
            locale={{
              Pagination: {
                items_per_page: "/" + t("table.page"), // Sahifa hajmi matnini o'zgartirish
              },
            }}
          >
            <Table<PermissionType>
              className="ass-table"
              dataSource={loading ? [] : dataItem}
              rowKey={(record): React.Key => record.id}
              pagination={{
                current: query.page + 1,
                pageSize: query.limit,
                total: totalItem,
                onChange: handlePaginationChange,
                showSizeChanger: true,
                pageSizeOptions: ["10", "20", "50"], // Customize the available page sizes
              }}
              loading={loading}
              locale={{
                emptyText: loading ? <Skeleton active paragraph={{ rows: 5 }} /> : t("empty"),
              }}
            >
              <Column title="#" dataIndex="id" key="id" />
              <Column
                title={`${t("table.header.title")}`}
                dataIndex="name"
                key="name"
                render={(name: string) => <div style={{ maxWidth: "250px" }}>{name}</div>}
              />
              <Column title={`${t("index")}`} dataIndex="orderNumber" key="orderNumber" />

              <Column
                title={`${t("table.header.actions")}`}
                dataIndex="id"
                key="id"
                render={(id: number) => (
                  <div>
                    <Button
                      className="bg-primary color-white"
                      shape="round"
                      onClick={() => editItemModal(id)}
                    >
                      <EditOutlined />
                    </Button>
                    <Button
                      danger
                      onClick={() => deleteItemModal(id)}
                      className="ml-2"
                      shape="round"
                    >
                      <DeleteOutlined />
                    </Button>
                  </div>
                )}
              />
            </Table>
          </ConfigProvider>
        </Col>
      </Row>

      <Row>
        <Col span={24}>{contextHolder}</Col>
      </Row>
    </MainLayout>
  );
}
