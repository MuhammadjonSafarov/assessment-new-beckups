import {
  Col,
  Row,
  Breadcrumb,
  Flex,
  Typography,
  Button,
  Table,
  ConfigProvider,
  Skeleton,
  Tag,
  Modal,
  Form,
  Select,
} from "antd";
import MainLayout from "@/components/layout/MainLayout";
import React, { useCallback, useEffect, useState } from "react";
import { useRouter } from "next/router";
import { axiosServer } from "@/plugins/axiosServer";
import { useAppSelector } from "@/hooks/hooks";

const { Column } = Table;
import {
  ApiOutlined,
  ArrowLeftOutlined,
  AuditOutlined,
  CheckOutlined,
  CloseOutlined,
  HomeOutlined,
} from "@ant-design/icons";
import useTranslation from "next-translate/useTranslation";
import { PermissionType } from "@/dto/AppDTO";
import { formatPhoneNumber } from "@/helpers/typeChange";
import { cannotEmptyRules } from "@/helpers/validationRules";
import { toast } from "react-toastify";

export default function SessionUsers() {
  const { Title } = Typography;

  const router = useRouter();
  const { locale } = router;
  const { t } = useTranslation("lang");
  const [dataItem, setDataItem] = useState<PermissionType[]>([]);
  const [loading, setLoading] = useState(false);
  const [totalItem, setTotalItem] = useState(1);
  const [openModal, setOpenModal] = useState(false);
  const formTemplate = {
    id: null,
    degree: null,
  };
  const [isButtonDisabled, setIsButtonDisabled] = useState(false);
  const [formBtnLoading, setFormBtnLoading] = useState(false);
  const [initialValuesItem, setIsInitialValues] = useState<any>({ isRent: false });
  const cannotEmpty = cannotEmptyRules();

  const [oneUserData, setUserData] = useState<any>();
  // console.log(666666, filter.current);
  const [query, setquery] = useState({
    page: 0,
    limit: 10,
    search: {},
  });
  const [form] = Form.useForm();
  const values: any = Form.useWatch([], form);

  const userInfo = useAppSelector((state) => state.user); // hooks/hooks.ts qo'shilgandan keyin shundoq ishlatsa buladi
  const breadcrumbItem = [
    {
      href: `/${locale}`,
      title: <HomeOutlined />,
    },
    {
      href: "/sessions  ",
      title: `${t("sessions.list")}`,
    },
    {
      title: `${t("menu.users")}`,
    },
  ];

  // Define the function to load pavilion data
  const loadData = useCallback(async () => {
    const sessionId = router?.query?.sessionId;
    if (!sessionId) return;
    setLoading(true);
    // console.log(88888, filter?.current);
    await axiosServer(router.locale, false, userInfo?.token)
      .post(`/api/v1/session/users/${sessionId}`, query)
      .then((res: any) => {
        setLoading(false);
        setTotalItem(res?.data?.total || 1);
        setDataItem(res?.data?.list || []); // Update the state with the fetched data
      })
      .catch(() => {
        setDataItem([]);
        setLoading(false);
      });
  }, [router.locale, query]);
  useEffect(() => {
    loadData();
  }, [router.locale, query]);

  // Handle pagination changes
  const handlePaginationChange = (page: number, pageSize: number) => {
    const limintChange = page - 1 === query.page;
    setquery((prevQuery) => ({
      ...prevQuery,
      page: limintChange ? 0 : page - 1, // Update page to 5
      limit: pageSize, // Update limit to 3
    }));
  };
  const addDegree = (item: any) => {
    setOpenModal(true);
    setUserData(item);
  };
  const handleOk = async () => {
    const values = form.getFieldsValue();
    if (oneUserData?.userApplication?.id && values?.degree) {
      setFormBtnLoading(true);
      await axiosServer(router.locale, false, userInfo?.token)
        .post(
          `/api/v1/user-application/attach-degree/${oneUserData?.userApplication?.id}/${values.degree}`,
        )
        .then(() => {
          setFormBtnLoading(false);
          toast.success(`${t("toast.successfully")}`);
          form.setFieldsValue(formTemplate);
          setOpenModal(false);
          setUserData({});
          loadData();
        })
        .catch(() => {
          setFormBtnLoading(false);
        });
    }
  };
  const closeModal = () => {
    setIsInitialValues(formTemplate);
    form.setFieldsValue(formTemplate);
    setOpenModal(false);
  };
  useEffect(() => {
    form
      .validateFields({ validateOnly: true })
      .then(() => setIsButtonDisabled(true))
      .catch(() => setIsButtonDisabled(false));
    // console.log(555, form.getFieldsValue());
  }, [form, values]);
  const backLink = () => {
    router.push("/sessions").catch(() => {
      //
    });
  };
  const redirectSessionUsersPage = (item: any) => {
    if (!item?.userApplication?.tempSessionId || !item?.userApplication?.user?.id) return;
    router.push(
      `/sessions/${item.userApplication.tempSessionId}/user?userId=${item.userApplication.user.id}`,
    );
  };
  return (
    <MainLayout>
      <Row className="pavilion-box ass-style">
        <Col span={24}>
          <div>
            <Breadcrumb items={breadcrumbItem} />
          </div>
        </Col>
        <Col span={24} className="add-pavilion-box">
          <Flex justify={"space-between"}>
            <div>
              <Flex align={"center"}>
                <ArrowLeftOutlined
                  onClick={backLink}
                  style={{ marginRight: "16px", fontSize: "16px" }}
                />
                <Title level={4} className="m-0">
                  {t("menu.users")}
                </Title>
              </Flex>
            </div>
          </Flex>
        </Col>
      </Row>
      <Row>
        <Col span={24}>
          <ConfigProvider
            //@ts-ignore
            locale={{
              Pagination: {
                items_per_page: "/" + t("table.page"), // Sahifa hajmi matnini o'zgartirish
              },
            }}
          >
            <Table<any>
              className="ass-table"
              dataSource={loading ? [] : dataItem}
              rowKey={(record): React.Key => record.id}
              pagination={{
                current: query.page + 1,
                pageSize: query.limit,
                total: totalItem,
                onChange: handlePaginationChange,
                showSizeChanger: true,
                pageSizeOptions: ["10", "20", "50"], // Customize the available page sizes
              }}
              loading={loading}
              locale={{
                emptyText: loading ? <Skeleton active paragraph={{ rows: 5 }} /> : t("empty"),
              }}
            >
              <Column
                title={`${t("operators.fish")}`}
                key="fish"
                render={(item: any) => (
                  <span>
                    {item?.userApplication?.user?.lastName || ""}{" "}
                    {item?.userApplication?.user?.firstName || ""}{" "}
                    {item?.userApplication?.user?.middleName || ""}
                  </span>
                )}
              />
              <Column
                title={`${t("operators.pasport")}`}
                key="pasport"
                render={(item: any) => (
                  <Tag style={{ fontSize: "14px", padding: "5px 10px" }} color="#0F8FB0">
                    {item?.userApplication?.user?.passportSerial || ""}
                    {item?.userApplication?.user?.passportNumber || ""}
                  </Tag>
                )}
              />
              <Column
                title={`${t("operators.allDegree")}`}
                key="degree"
                render={(item: any) =>
                  item?.userApplication?.degree ? (
                    <Flex justify="center">
                      <Tag style={{ fontSize: "14px", padding: "5px 10px" }} color="cyan">
                        {item?.userApplication?.degree || ""}
                      </Tag>
                    </Flex>
                  ) : (
                    ""
                  )
                }
              />
              <Column
                title={`${t("form.label.listening")}`}
                key="degree"
                render={(item: any) =>
                  item?.userApplication?.listeningDegree ? (
                    <Flex justify="center">
                      <Tag style={{ fontSize: "14px", padding: "5px 10px" }} color="cyan">
                        {item?.userApplication?.listeningDegree || ""}
                      </Tag>
                    </Flex>
                  ) : (
                    ""
                  )
                }
              />
              <Column
                title={`${t("form.label.reading")}`}
                key="degree"
                render={(item: any) =>
                  item?.userApplication?.readingDegree ? (
                    <Flex justify="center">
                      <Tag style={{ fontSize: "14px", padding: "5px 10px" }} color="cyan">
                        {item?.userApplication?.readingDegree || ""}
                      </Tag>
                    </Flex>
                  ) : (
                    ""
                  )
                }
              />
              <Column
                title={`${t("form.label.writing")}`}
                key="degree"
                render={(item: any) =>
                  item?.userApplication?.writingDegree ? (
                    <Flex justify="center">
                      <Tag style={{ fontSize: "14px", padding: "5px 10px" }} color="cyan">
                        {item?.userApplication?.writingDegree || ""}
                      </Tag>
                    </Flex>
                  ) : (
                    ""
                  )
                }
              />
              <Column
                title={`${t("form.label.speaking")}`}
                key="degree"
                render={(item: any) =>
                  item?.userApplication?.speakingDegree ? (
                    <Flex justify="center">
                      <Tag style={{ fontSize: "14px", padding: "5px 10px" }} color="cyan">
                        {item?.userApplication?.speakingDegree || ""}
                      </Tag>
                    </Flex>
                  ) : (
                    ""
                  )
                }
              />
              <Column
                title={`${t("form.label.phone")}`}
                key="phone"
                render={(item: any) =>
                  item?.userApplication?.user?.phone &&
                  formatPhoneNumber(item?.userApplication?.user?.phone)
                }
              />
              {/*<Column*/}
              {/*  title="Ro'yxatga otilgan sana"*/}
              {/*  key="createdDate"*/}
              {/*  render={(item: any) =>*/}
              {/*    item?.userApplication?.user?.createdDate*/}
              {/*      ? dateFormat(item?.userApplication?.user?.createdDate)*/}
              {/*      : ""*/}
              {/*  }*/}
              {/*/>*/}
              <Column
                title={`${t("form.active")}`}
                key="status"
                render={(item: any) =>
                  item?.userApplication?.user?.status === "ACTIVE" ? (
                    <CheckOutlined style={{ fontSize: "22px", color: "green" }} />
                  ) : (
                    <CloseOutlined style={{ fontSize: "22px", color: "red" }} />
                  )
                }
              />
              <Column
                title={`${t("table.header.actions")}`}
                render={(item: any) => (
                  <div>
                    <Button variant="outlined" onClick={() => addDegree(item)} shape="round">
                      <ApiOutlined />
                    </Button>
                    <Button
                      className="ml-1"
                      variant="outlined"
                      onClick={() => redirectSessionUsersPage(item)}
                      shape="round"
                    >
                      <AuditOutlined />
                    </Button>
                  </div>
                )}
              />
            </Table>
          </ConfigProvider>
        </Col>
      </Row>
      <Row className="ass-style">
        <Modal
          className="ass-style ass-modal ass-modal-small"
          centered
          open={openModal}
          title={`${t("addDegree")}`}
          onOk={handleOk}
          onCancel={closeModal}
          footer={[
            <Button key="close" onClick={closeModal}>
              {t("form.close")}
            </Button>,
            <Button
              key="create"
              className={!isButtonDisabled ? "" : "base-bg color-white"}
              disabled={!isButtonDisabled}
              onClick={handleOk}
              loading={formBtnLoading}
            >
              {t("form.create")}
            </Button>,
          ]}
        >
          <div className="ass-modal-body">
            {/*<Skeleton loading={formBtnLoading} active paragraph={{ rows: 5 }}>*/}
            <Form
              initialValues={initialValuesItem}
              form={form}
              layout="vertical"
              name="pavilion"
              style={{ width: "100%", marginTop: "20px" }}
              autoComplete="off"
            >
              <Row>
                <Col span={24} className="pavilion-input">
                  {oneUserData?.userApplication?.session?.testType?.resultOptions?.length ? (
                    <Form.Item name="degree" label={`${t("variantName")}`} rules={cannotEmpty}>
                      <Select placeholder={`${t("table.header.select")}`}>
                        {/* Optionsni map qilish */}
                        {oneUserData?.userApplication?.session?.testType?.resultOptions.map(
                          (item: string) => (
                            <Select.Option key={item} value={item}>
                              {item}
                            </Select.Option>
                          ),
                        )}
                      </Select>
                    </Form.Item>
                  ) : (
                    <h2 className="text-center"> {t("noInfo")}</h2>
                  )}
                </Col>
              </Row>
            </Form>
            {/*</Skeleton>*/}
          </div>
        </Modal>
      </Row>
    </MainLayout>
  );
}
