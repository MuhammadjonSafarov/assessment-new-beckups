import {
  Col,
  Row,
  Breadcrumb,
  Flex,
  Typography,
  Button,
  Form,
  Input,
  Skeleton,
  Upload,
  Image,
  UploadProps,
} from "antd";
import MainLayout from "@/components/layout/MainLayout";
import React, { useCallback, useEffect, useState } from "react";
import { useRouter } from "next/router";
import { axiosServer } from "@/plugins/axiosServer";
import { useAppSelector } from "@/hooks/hooks";
import type { GetProp, UploadFile } from "antd";
type FileType = Parameters<GetProp<UploadProps, "beforeUpload">>[0];

const getBase64 = (file: FileType): Promise<string> =>
  new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = () => resolve(reader.result as string);
    reader.onerror = (error) => reject(error);
  });

import { ArrowLeftOutlined, HomeOutlined, PlusOutlined } from "@ant-design/icons";
import useTranslation from "next-translate/useTranslation";
import { cannotEmptyRules } from "@/helpers/validationRules";
import { toast } from "react-toastify";
// import TinyMCEEditor from "@/components/TinyMCEEditor";
const { TextArea } = Input;
export default function PassageCreate() {
  const { Title } = Typography;
  const router = useRouter();
  const { locale } = router;
  const { t } = useTranslation("lang");
  const [form] = Form.useForm();
  const values: any = Form.useWatch([], form);
  const [formBtnLoading, setFormBtnLoading] = useState(false);
  const [fileList, setFileList] = useState<UploadFile[]>([]);
  const [fileListSecond, setFileListSecond] = useState<UploadFile[]>([]);
  const [fileListThree, setFileListThree] = useState<UploadFile[]>([]);
  const [fileListFour, setFileListFour] = useState<UploadFile[]>([]);

  const formTemplate = {
    text: "",
    textAudioFileId: undefined,
    orderNumber: undefined,
    textSuggestedReadingTime: undefined,

    photoFileFileId: undefined,
    photoAudioFileId: undefined,
    question: undefined,
    questionAudioFileId: undefined,
    preparationTime: undefined,
    responseTime: undefined,
    coefficient: undefined,
  };
  const [isButtonDisabled, setIsButtonDisabled] = useState(false);
  const [previewImage, setPreviewImage] = useState("");
  const [previewOpen, setPreviewOpen] = useState(false);

  const cannotEmpty = cannotEmptyRules();
  const userInfo = useAppSelector((state) => state.user); // hooks/hooks.ts qo'shilgandan keyin shundoq ishlatsa buladi
  const breadcrumbItem = [
    {
      href: `/${locale}`,
      title: <HomeOutlined />,
    },
    {
      href: "",
      title: "TOEFL",
    },
    {
      href: `/${router.locale}/toefl/speaking/speaking-part`,
      title: `${t("menu.speaking")}`,
    },
    {
      title: `${t("speakingPart")}`,
    },
  ];

  useEffect(() => {
    form
      .validateFields({ validateOnly: true })
      .then(() => setIsButtonDisabled(true))
      .catch(() => setIsButtonDisabled(false));
    // console.log(555, form.getFieldsValue());
  }, [form, values]);
  const handleOk = async () => {
    const values = form.getFieldsValue();
    setFormBtnLoading(true);
    const speakingPartId = router?.query?.speakingPartId;
    if (!speakingPartId) return;
    await axiosServer(router.locale, false, userInfo?.token)
      .put(`/api/v1/speaking-part/${speakingPartId}`, values)
      .then(() => {
        setFormBtnLoading(false);
        toast.success(`${t("toast.successfully")}`);
        form.setFieldsValue(formTemplate);
        redirectPassage();
      })
      .catch(() => {
        setFormBtnLoading(false);
      });
  };

  const redirectPassage = () => {
    router.push("/toefl/speaking/speaking-part").catch(() => {
      // console.log(err)
    });
  };
  const handlePreview = async (file: UploadFile) => {
    if (!file.url && !file.preview) {
      file.preview = await getBase64(file.originFileObj as FileType);
    }

    setPreviewImage(file.url || (file.preview as string));
    setPreviewOpen(true);
  };
  const handleRemove = (file: any) => {
    const fileId: number = file?.response?.id;
    if (fileId) {
      form.setFieldsValue({ textAudioFileId: undefined });
    }
  };
  const props2: UploadProps = {
    action: `${process.env.PUBLIC_API_SERVER_URL}/api/v1/file`,
    customRequest: async ({ file, onSuccess, onError }) => {
      const formData = new FormData();
      formData.append("file", file);

      try {
        await axiosServer(router.locale, false, userInfo?.token)
          .post(`/api/v1/file`, formData)
          .then((res: any) => {
            if (res?.id) {
              // @ts-ignore
              onSuccess(res);
            } else {
              // @ts-ignore
              onError(new Error("Upload failed"));
            }
          });
      } catch (error) {
        // @ts-ignore
        onError(error);
      }
    },
    accept: ".mp3",
    fileList: fileList, // Pass fileList here
    onRemove: handleRemove, // Handle file removal
  };
  const propsFoto: UploadProps = {
    fileList: fileListSecond, // Pass fileList here
    action: `${process.env.PUBLIC_API_SERVER_URL}/api/v1/file`,
    customRequest: async ({ file, onSuccess, onError }) => {
      const formData = new FormData();
      formData.append("file", file);

      try {
        await axiosServer(router.locale, false, userInfo?.token)
          .post(`/api/v1/file`, formData)
          .then((res: any) => {
            if (res?.id) {
              // @ts-ignore
              onSuccess(res);
              form.setFieldsValue({ photoFileFileId: res.id });
            } else {
              // @ts-ignore
              onError(new Error("Upload failed"));
            }
          });
      } catch (error) {
        // @ts-ignore
        onError(error);
      }
    },
    onChange({ file, fileList }) {
      if (!file) return;
      // setFileListMp3(fileList);
      if (!fileList.length) {
        form.setFieldsValue({ photoFileFileId: undefined });
      }

      // }
    },
  };
  const propsFotoAudio: UploadProps = {
    fileList: fileListThree, // Pass fileList here
    action: `${process.env.PUBLIC_API_SERVER_URL}/api/v1/file`,
    accept: ".mp3",
    customRequest: async ({ file, onSuccess, onError }) => {
      const formData = new FormData();
      formData.append("file", file);

      try {
        await axiosServer(router.locale, false, userInfo?.token)
          .post(`/api/v1/file`, formData)
          .then((res: any) => {
            if (res?.id) {
              // @ts-ignore
              onSuccess(res);
              form.setFieldsValue({ photoAudioFileId: res.id });
            } else {
              // @ts-ignore
              onError(new Error("Upload failed"));
            }
          });
      } catch (error) {
        // @ts-ignore
        onError(error);
      }
    },
    onChange({ file, fileList }) {
      if (!file) return;
      // setFileListMp3(fileList);
      if (!fileList.length) {
        form.setFieldsValue({ photoAudioFileId: undefined });
      }

      // }
    },
  };
  const questionAudio: UploadProps = {
    fileList: fileListFour,
    action: `${process.env.PUBLIC_API_SERVER_URL}/api/v1/file`,
    accept: ".mp3",
    customRequest: async ({ file, onSuccess, onError }) => {
      const formData = new FormData();
      formData.append("file", file);

      try {
        await axiosServer(router.locale, false, userInfo?.token)
          .post(`/api/v1/file`, formData)
          .then((res: any) => {
            if (res?.id) {
              // @ts-ignore
              onSuccess(res);
              form.setFieldsValue({ questionAudioFileId: res.id });
            } else {
              // @ts-ignore
              onError(new Error("Upload failed"));
            }
          });
      } catch (error) {
        // @ts-ignore
        onError(error);
      }
    },
    onChange({ file, fileList }) {
      if (!file) return;
      // setFileListMp3(fileList);
      if (!fileList.length) {
        form.setFieldsValue({ questionAudioFileId: undefined });
      }

      // }
    },
  };
  const handleChange: UploadProps["onChange"] = ({ fileList: newFileList }) => {
    setFileList(newFileList);
    if (!newFileList.length) {
      form.setFieldsValue({ textAudioFileId: undefined });
    }
  };
  const handleChangeSecond: UploadProps["onChange"] = ({ fileList: newFileList }) => {
    setFileListSecond(newFileList);
    if (!newFileList.length) {
      form.setFieldsValue({ photoFileFileId: undefined });
    }
  };
  const handleChangeThree: UploadProps["onChange"] = ({ fileList: newFileList }) => {
    setFileListThree(newFileList);
    if (!newFileList.length) {
      form.setFieldsValue({ photoAudioFileId: undefined });
    }
  };
  const handleChangeFour: UploadProps["onChange"] = ({ fileList: newFileList }) => {
    setFileListFour(newFileList);
    if (!newFileList.length) {
      form.setFieldsValue({ questionAudioFileId: undefined });
    }
  };
  const uploadButton = (
    <button style={{ border: 0, background: "none" }} type="button">
      <PlusOutlined />
      <div style={{ marginTop: 8 }}>{t("sessionTypes.upload")}</div>
    </button>
  );

  useEffect(() => {
    if (fileList?.length) {
      const ids = fileList.map((item: any) => {
        if (item?.response?.id) {
          return item.response.id;
        } else if (item?.id) {
          return item.id;
        }
      });
      form.setFieldsValue({ textAudioFileId: ids.length && ids[0] ? ids[0] : undefined });
    }
  }, [fileList]); //
  const loadOnePassageInfo = useCallback(async () => {
    const speakingPartId = router?.query?.speakingPartId;
    if (!speakingPartId) return;
    await axiosServer(router.locale, true, userInfo?.token)
      .get(`/api/v1/speaking-part/${speakingPartId}`)
      .then((res: any) => {
        const data = {
          text: res?.data?.text,
          orderNumber: res?.data?.orderNumber,
          textSuggestedReadingTime: res?.data?.textSuggestedReadingTime,
          question: res?.data?.question,
          preparationTime: res?.data?.preparationTime,
          responseTime: res?.data?.responseTime,
          textAudioFileId: res?.data?.textAudio?.id,
          photoFileFileId: res?.data?.photoFile?.id,
          photoAudioFileId: res?.data?.photoAudio?.id,
          questionAudioFileId: res?.data?.questionAudio?.id,
          coefficient: res?.data?.coefficient || undefined,
        };

        if (res?.data?.textAudio?.id) {
          setFileList([res?.data?.textAudio]);
        }
        if (res?.data?.photoAudio?.id) {
          setFileListThree([res?.data?.photoAudio]);
        }
        if (res?.data?.questionAudio?.id) {
          setFileListFour([res?.data?.questionAudio]);
        }
        if (res?.data?.photoFile?.id) {
          setFileListSecond([
            {
              ...res?.data?.photoFile,
              url: `${process.env.IMAGES_URL}${res?.data?.photoFile.url}`,
            },
          ]);
        }
        form.setFieldsValue(data);
        // setQuestionList(res?.data?.list || []); // Update the state with the fetched data
      })
      .catch(() => {
        //
      });
  }, []);
  useEffect(() => {
    (async () => {
      await loadOnePassageInfo();
    })();
  }, [router.locale]);
  return (
    <MainLayout>
      <Row className="pavilion-box ass-style">
        <Col span={24}>
          <div>
            <Breadcrumb items={breadcrumbItem} />
          </div>
        </Col>

        <Col span={24} className="add-pavilion-box">
          <Flex justify={"space-between"}>
            <div>
              <Flex align={"center"}>
                <ArrowLeftOutlined
                  onClick={redirectPassage}
                  style={{ marginRight: "16px", fontSize: "16px" }}
                />
                <Title level={4} className="m-0">
                  {t("edit")}
                </Title>
              </Flex>
            </div>
          </Flex>
        </Col>
      </Row>
      <Row className="pavilion-box ass-style">
        <Skeleton loading={formBtnLoading} active paragraph={{ rows: 5 }}>
          <Form
            form={form}
            layout="vertical"
            name="pavilion"
            style={{ width: "100%", marginTop: "20px" }}
            autoComplete="off"
          >
            <Row>
              <Col span={24} className="pavilion-input">
                <Form.Item name="orderNumber" label={`${t("index")}`} rules={cannotEmpty}>
                  <Input
                    type="number"
                    min={0}
                    placeholder={`${t("index")}`}
                    onChange={(e) =>
                      form.setFieldsValue({
                        orderNumber: e?.target?.value ? Number(e?.target?.value) : 0,
                      })
                    }
                  />
                </Form.Item>
              </Col>
              <Col span={24} className="pavilion-input">
                <Form.Item name="coefficient" label={`${t("coefficient")}`} rules={cannotEmpty}>
                  <Input
                    type="number"
                    min={0}
                    placeholder={`${t("enterCoefficient")}`}
                    onChange={(e) =>
                      form.setFieldsValue({
                        coefficient: e?.target?.value ? Number(e?.target?.value) : 0,
                      })
                    }
                  />
                </Form.Item>
              </Col>
              <Col span={24} className="pavilion-input mt-3">
                <Form.Item name="text" label={`${t("text")}`} rules={cannotEmpty}>
                  <TextArea rows={6} />
                </Form.Item>
              </Col>
              <Col span={24} className="pavilion-input mt-3">
                <Form.Item name="textAudioFileId" label={`${t("textAudio")}`} rules={cannotEmpty}>
                  <Upload
                    {...props2}
                    listType="picture-card"
                    fileList={fileList}
                    onPreview={handlePreview}
                    onChange={handleChange}
                  >
                    {fileList.length >= 1 ? null : uploadButton}
                  </Upload>
                  {previewImage && (
                    <Image
                      wrapperStyle={{ display: "none" }}
                      preview={{
                        visible: previewOpen,
                        onVisibleChange: (visible) => setPreviewOpen(visible),
                        afterOpenChange: (visible) => !visible && setPreviewImage(""),
                      }}
                      src={previewImage}
                    />
                  )}
                </Form.Item>
              </Col>
              <Col span={24} className="pavilion-input mt-3">
                <Flex>
                  <Form.Item name="photoFileFileId" label={`${t("picture")}`} rules={cannotEmpty}>
                    <Upload
                      {...propsFoto}
                      listType="picture-card"
                      onPreview={handlePreview}
                      onChange={handleChangeSecond}
                    >
                      {fileListSecond.length >= 1 ? null : uploadButton}
                    </Upload>
                    {previewImage && (
                      <Image
                        wrapperStyle={{ display: "none" }}
                        preview={{
                          visible: previewOpen,
                          onVisibleChange: (visible) => setPreviewOpen(visible),
                          afterOpenChange: (visible) => !visible && setPreviewImage(""),
                        }}
                        src={previewImage}
                      />
                    )}
                  </Form.Item>
                  <div className="ml-2"></div>
                  <Form.Item
                    name="photoAudioFileId"
                    label={`${t("photoAudio")}`}
                    rules={cannotEmpty}
                  >
                    <Upload
                      {...propsFotoAudio}
                      listType="picture-card"
                      onPreview={handlePreview}
                      onChange={handleChangeThree}
                    >
                      {fileListThree.length >= 1 ? null : uploadButton}
                    </Upload>
                    {previewImage && (
                      <Image
                        wrapperStyle={{ display: "none" }}
                        preview={{
                          visible: previewOpen,
                          onVisibleChange: (visible) => setPreviewOpen(visible),
                          afterOpenChange: (visible) => !visible && setPreviewImage(""),
                        }}
                        src={previewImage}
                      />
                    )}
                  </Form.Item>
                </Flex>
              </Col>
              <Col span={24} className="pavilion-input mt-3">
                <Form.Item name="question" label={`${t("question")}`} rules={cannotEmpty}>
                  <TextArea rows={6} />
                </Form.Item>
              </Col>
              <Col span={24} className="pavilion-input mt-3">
                <Flex>
                  <Form.Item
                    name="questionAudioFileId"
                    label={`${t("questionAudio")}`}
                    rules={cannotEmpty}
                  >
                    <Upload
                      {...questionAudio}
                      listType="picture-card"
                      onPreview={handlePreview}
                      onChange={handleChangeFour}
                    >
                      {fileListFour.length >= 1 ? null : uploadButton}
                    </Upload>
                    {previewImage && (
                      <Image
                        wrapperStyle={{ display: "none" }}
                        preview={{
                          visible: previewOpen,
                          onVisibleChange: (visible) => setPreviewOpen(visible),
                          afterOpenChange: (visible) => !visible && setPreviewImage(""),
                        }}
                        src={previewImage}
                      />
                    )}
                  </Form.Item>
                </Flex>
              </Col>
              <Col span={24} className="pavilion-input">
                <Form.Item
                  name="textSuggestedReadingTime"
                  label={`${t("readingTime")}`}
                  rules={cannotEmpty}
                >
                  <Input
                    type="number"
                    min={0}
                    placeholder="0"
                    onChange={(e) =>
                      form.setFieldsValue({
                        textSuggestedReadingTime: e?.target?.value ? Number(e?.target?.value) : 0,
                      })
                    }
                  />
                </Form.Item>
              </Col>
              <Col span={24} className="pavilion-input">
                <Form.Item
                  name="preparationTime"
                  label={`${t("preparationTime")}`}
                  rules={cannotEmpty}
                >
                  <Input
                    type="number"
                    min={0}
                    placeholder="0"
                    onChange={(e) =>
                      form.setFieldsValue({
                        preparationTime: e?.target?.value ? Number(e?.target?.value) : 0,
                      })
                    }
                  />
                </Form.Item>
              </Col>
              <Col span={24} className="pavilion-input">
                <Form.Item name="responseTime" label={`${t("responseTime")}`} rules={cannotEmpty}>
                  <Input
                    type="number"
                    min={0}
                    placeholder="0"
                    onChange={(e) =>
                      form.setFieldsValue({
                        responseTime: e?.target?.value ? Number(e?.target?.value) : 0,
                      })
                    }
                  />
                </Form.Item>
              </Col>
              <Col span={24} className="pavilion-input">
                <Button
                  key="create"
                  className={!isButtonDisabled ? "" : "base-bg color-white"}
                  disabled={!isButtonDisabled}
                  onClick={handleOk}
                  loading={formBtnLoading}
                >
                  {t("form.create")}
                </Button>
              </Col>
            </Row>
          </Form>
        </Skeleton>
      </Row>
    </MainLayout>
  );
}
