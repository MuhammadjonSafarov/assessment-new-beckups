import { useRouter } from "next/router";
import { Image, Dropdown, Button, Flex, Typography } from "antd";
import setLanguage from "next-translate/setLanguage";
import { useEffect, useState } from "react";
export default function LanguageSelect() {
  const [selectedLanguage, setSelectedLanguage] = useState("");
  const router = useRouter();
  const { locale } = router;
  const { Text } = Typography;
  useEffect(() => {
    // return () => {
    // console.log(55555, locale);
    setSelectedLanguage(locale === "uz" ? "O'zbekcha" : locale === "ru" ? "Русский" : "English");
    // };
  }, []); // Bu faqat bir marta amalga oshiriladi

  // const handleMenuClick = (e: { key: string }) => {
  //   setSelectedLanguage(e.key === "uz" ? "O'zbekcha" : e.key === "ru" ? "Русский" : "English");
  //   setLanguage(e.key); // change language
  // };
  const handleMenuClick = (key: string) => {
    const languageMap: { [key: string]: string } = {
      uz: "O'zbekcha",
      ru: "Русский",
      en: "English",
    };
    setSelectedLanguage(languageMap[key]);
    setLanguage(key);
  };
  const items = [
    {
      key: "uz",
      label: (
        <Flex
          onClick={() => handleMenuClick("uz")}
          justify={"space-between"}
          className="language-logo"
          align={"center"}
          style={{ display: locale === "uz" ? "none" : "flex" }}
        >
          <Image width={20} height={20} src="/images/uz.png" alt="empty" preview={false} />
          <Text className="ml-2">O'zbekcha</Text>
        </Flex>
      ),
    },
    {
      key: "ru",
      label: (
        <Flex
          onClick={() => handleMenuClick("ru")}
          justify={"space-between"}
          className="language-logo"
          align={"center"}
          style={{ display: locale === "ru" ? "none" : "flex" }}
        >
          <Image width={20} height={20} src="/images/ru.png" alt="empty" preview={false} />
          <Text className="ml-2">Русский</Text>
        </Flex>
      ),
    },
    {
      key: "en",
      label: (
        <Flex
          onClick={() => handleMenuClick("en")}
          justify={"space-between"}
          className="language-logo"
          align={"center"}
          style={{ display: locale === "en" ? "none" : "flex" }}
        >
          <Image width={20} height={20} src="/images/en.png" alt="empty" preview={false} />
          <Text className="ml-2">English</Text>
        </Flex>
      ),
    },
  ];
  return (
    <>
      {/*trigger={["click"]} -> Visible when clicked */}
      <Dropdown menu={{ items }} className="language-log-box">
        <Button className="language-logo">
          {locale === "uz" ? (
            <Image width={20} height={20} src="/images/uz.png" alt="empty" preview={false} />
          ) : locale === "ru" ? (
            <Image width={20} height={20} src="/images/ru.png" alt="empty" preview={false} />
          ) : (
            <Image width={20} height={20} src="/images/en.png" alt="empty" preview={false} />
          )}
          {selectedLanguage}
        </Button>
      </Dropdown>
    </>
  );
}
