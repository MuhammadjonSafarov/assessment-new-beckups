// validationRules.js
import useTranslation from "next-translate/useTranslation";

export const useUserNameRules = () => {
  const { t } = useTranslation();

  return [
    { required: true, message: t("validation:loginUserNameRequired") },
    { min: 4, message: t("validation:loginUserNameMinLength") },
  ];
};
export const useUserPasswordRules = () => {
  const { t } = useTranslation();

  return [
    { required: true, message: t("validation:loginPasswordRequired") },
    { min: 6, message: t("validation:loginPasswordMinLength") },
  ];
};

export const cannotEmptyRules = () => {
  const { t } = useTranslation();
  return [{ required: true, message: t("validation:notEmpty") }];
};
export const phoneLengthRules = () => {
  const { t } = useTranslation();
  return [
    { required: true, message: t("validation:number") },
    { min: 12, max: 12, message: t(`validation:phone`) },
  ];
};
