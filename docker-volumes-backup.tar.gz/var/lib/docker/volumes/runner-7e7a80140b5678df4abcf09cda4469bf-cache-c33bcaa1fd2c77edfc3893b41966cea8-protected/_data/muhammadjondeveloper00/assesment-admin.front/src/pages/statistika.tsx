import { Col, Row } from "antd";
import MainLayout from "@/components/layout/MainLayout";

export default function Statistika() {
  return (
    <MainLayout>
      <Row className="">
        <Col span={24}>Statistika</Col>
      </Row>
    </MainLayout>
  );
}
