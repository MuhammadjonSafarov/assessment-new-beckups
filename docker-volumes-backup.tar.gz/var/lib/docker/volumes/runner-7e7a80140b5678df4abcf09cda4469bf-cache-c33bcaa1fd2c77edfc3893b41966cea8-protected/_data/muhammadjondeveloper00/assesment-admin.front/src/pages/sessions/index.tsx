import {
  Col,
  Row,
  Breadcrumb,
  Flex,
  Typography,
  Button,
  Modal,
  Form,
  Input,
  Select,
  Table,
  ConfigProvider,
  Skeleton,
  Dropdown,
  MenuProps,
  DatePicker,
} from "antd";
import MainLayout from "@/components/layout/MainLayout";
import React, { useCallback, useEffect, useState } from "react";
import { useRouter } from "next/router";
import { axiosServer } from "@/plugins/axiosServer";
import { useAppSelector } from "@/hooks/hooks";

const { Column } = Table;
import {
  DeleteFilled,
  DownOutlined,
  EditOutlined,
  HomeOutlined,
  PlusOutlined,
  QuestionCircleOutlined,
  TeamOutlined,
} from "@ant-design/icons";
import useTranslation from "next-translate/useTranslation";
import { cannotEmptyRules } from "@/helpers/validationRules";
import { toast } from "react-toastify";
import { OperatorType, PavilionDataType, SessionDataType } from "@/dto/AppDTO";
import { dateFormatLong } from "@/helpers/typeChange";
import { Option } from "rc-select";
import dayjs from "dayjs";
export default function Sessions() {
  const { Title } = Typography;
  const router = useRouter();
  const { locale } = router;
  const { t } = useTranslation("lang");
  const [form] = Form.useForm();
  const values: any = Form.useWatch([], form);
  const [dataItem, setDataItem] = useState<OperatorType[]>([]);
  const [openModal, setOpenModal] = useState(false);

  const [loading, setLoading] = useState(false);
  const [formBtnLoading, setFormBtnLoading] = useState(false);
  const [editLineId, setEditLineId] = useState(0);
  const [totalItem, setTotalItem] = useState(1);
  const [testTypeList, setTestTypeList] = useState<SessionDataType[]>([]);
  const [selectOneTestType, setSelectOneTestType] = useState<string>("");
  const [pavilionList, setPavilionList] = useState<PavilionDataType[]>([]);
  const [listeningList, setListeningList] = useState<any[]>([]);
  const [readingList, setReadingList] = useState<any[]>([]);
  const [writingList, setWritingList] = useState<any[]>([]);
  const [speakingList, setSpeakingList] = useState<any[]>([]);

  const layout = {
    labelCol: { span: 8 },
    wrapperCol: { span: 16 },
  };
  // console.log(666666, filter.current);
  const [query, setquery] = useState({
    page: 0,
    limit: 10,
    search: {},
  });
  const formTemplate = {
    examType: "",
    testTypeId: undefined,
    examFormat: "",
    maxCountCandidate: undefined,
    pavilionId: undefined,
    startDate: "",
    cost: undefined,
    listeningId: undefined,
    listeningScore: undefined,
    readingScore: undefined,
    speakingScore: undefined,
    writingScore: undefined,
  };
  const templateChange = {
    testTypeId: undefined,
    examFormat: "",
    maxCountCandidate: undefined,
    pavilionId: undefined,
    cost: undefined,
    startDate: "",
  };
  const [isButtonDisabled, setIsButtonDisabled] = useState(false);
  const [initialValuesItem, setIsInitialValues] = useState<any>({ isRent: false });
  const cannotEmpty = cannotEmptyRules();
  const [modal, contextHolder] = Modal.useModal();
  const userInfo = useAppSelector((state) => state.user); // hooks/hooks.ts qo'shilgandan keyin shundoq ishlatsa buladi
  const breadcrumbItem = [
    {
      href: `/${locale}`,
      title: <HomeOutlined />,
    },
    {
      href: "",
      title: `${t("sessions.list")}`,
    },
  ];
  const confirmModal = (id: number) => {
    modal.confirm({
      title: "",
      icon: <QuestionCircleOutlined style={{ marginTop: "10px" }} />,
      content: <h3>{t("deleteConfirmation")}</h3>,
      okText: t("form.yes"),
      cancelText: t("form.no"),
      onOk() {
        deleteLine(id);
      },
      onCancel() {
        // console.log("Cancel");
      },
      okButtonProps: {
        style: {
          backgroundColor: "#ff4d4f",
          color: "white",
          border: "none",
        },
      },
    });
  };
  // Define the function to load pavilion data
  const loadData = useCallback(async () => {
    setLoading(true);
    // console.log(88888, filter?.current);
    await axiosServer(router.locale, false, userInfo?.token)
      // .post(`/api/v1/user/list-search?isListOperators=true`, query)
      .post(`/api/v1/session/list-search`, query)
      .then((res: any) => {
        setLoading(false);
        setTotalItem(res?.data?.total || 1);
        setDataItem(res?.data?.list || []); // Update the state with the fetched data
      })
      .catch(() => {
        setDataItem([]);
        setLoading(false);
      });
  }, [router.locale, query]);

  const loadTestTypeList = () => {
    const permissionQuery = {
      page: 0,
      limit: 5000,
      search: {},
    };
    axiosServer(router.locale, false, userInfo?.token)
      .post(`/api/v1/test-type/list-search`, permissionQuery)
      .then((res: any) => {
        // setTotalItem(res?.data?.total || 1);
        setTestTypeList(res?.data?.list || []);
      })
      .catch(() => "");
  };
  const loadPavilionList = () => {
    const permissionQuery = {
      page: 0,
      limit: 5000,
      search: {},
    };
    axiosServer(router.locale, false, userInfo?.token)
      .post(`/api/v1/pavilion/list-search`, permissionQuery)
      .then((res: any) => {
        // setTotalItem(res?.data?.total || 1);
        setPavilionList(res?.data?.list || []);
      })
      .catch(() => "");
  };
  useEffect(() => {
    loadData();

    loadTestTypeList();
    loadPavilionList();
  }, [router.locale, query]);

  useEffect(() => {
    const timeout = setTimeout(() => {
      form
        .validateFields({ validateOnly: true })
        .then(() => setIsButtonDisabled(true))
        .catch(() => setIsButtonDisabled(false));
    }, 300);

    // console.log(555);
    return () => clearTimeout(timeout);
  }, [form, values]);
  const handleOk = async () => {
    const values = form.getFieldsValue();
    values.startDate = dayjs(values.startDate).format("DD-MM-YYYY HH:mm:ss") || undefined;
    if (editLineId) {
      setFormBtnLoading(true);
      await axiosServer(router.locale, false, userInfo?.token)
        .put(`/api/v1/session/${editLineId}`, values)
        .then(() => {
          setSelectOneTestType("");
          setEditLineId(0);
          toast.success(`${t("toast.successfully")}`);
          form.setFieldsValue(formTemplate);
          setFormBtnLoading(false);
          setOpenModal(false);
          loadData();
        })
        .catch(() => {
          setFormBtnLoading(false);
        });
    } else {
      await axiosServer(router.locale, false, userInfo?.token)
        .post("/api/v1/session", values)
        .then(() => {
          setSelectOneTestType("");
          toast.success(`${t("toast.successfully")}`);
          form.setFieldsValue(formTemplate);
          setOpenModal(false);
          loadData();
        })
        .catch(() => "");
    }
  };
  const editItemModal = async (id: number) => {
    form.setFieldsValue(formTemplate);
    // console.log("eeeeee", values);
    if (id) {
      setEditLineId(id);
      setOpenModal(true);
      setFormBtnLoading(true);
      await axiosServer(router.locale, false, userInfo?.token)
        .get(`/api/v1/session/${id}`)
        .then((res: any) => {
          setFormBtnLoading(false);
          if (res) {
            const data = {
              examType: res?.examType,
              testTypeId: res?.testType?.id,
              examFormat: res?.examFormat,
              maxCountCandidate: res?.maxCountCandidate,
              pavilionId: res?.pavilion?.id,
              startDate: res.startDate ? dayjs(res.startDate, "DD-MM-YYYY HH:mm:ss") : undefined,
              cost: res?.cost,
              listeningId: res?.listeningDTO?.id || undefined,
              readingId: res?.readingDTO?.id || undefined,
              writingId: res?.writingDTO?.id || undefined,
              speakingId: res?.speakingDTO?.id || undefined,
              listeningScore: res?.listeningScore || undefined,
              readingScore: res?.readingScore || undefined,
              speakingScore: res?.speakingScore || undefined,
              writingScore: res?.writingScore || undefined,
            };
            setSelectOneTestType(res?.testType?.testType || "");
            setIsInitialValues(data);
            form.setFieldsValue(data);
            setListeningList([{ id: res?.listeningDTO?.id, name: res?.listeningDTO?.name }]);
            setReadingList([{ id: res?.readingDTO?.id, name: res?.readingDTO?.name }]);
            setWritingList([{ id: res?.writingDTO?.id, name: res?.writingDTO?.name }]);
            setSpeakingList([{ id: res?.speakingDTO?.id, name: res?.speakingDTO?.name }]);
            // setTimeout(() => {
            //   form.validateFields({ validateOnly: true })
            //     .then(() => setIsButtonDisabled(true))
            //     .catch(() => setIsButtonDisabled(false));
            // }, 500);
          }
        })
        .catch(() => {
          setFormBtnLoading(false);
        });
    }
  };

  const deleteItemModal = (id: number) => {
    if (!id) return;
    confirmModal(id);

    // console.log("Delete Itemmm", id);
  };
  const deleteLine = async (id: number) => {
    if (!id) return;
    await axiosServer(router.locale, false, userInfo?.token)
      .delete(`/api/v1/session/${id}`)
      .then(() => {
        toast.success(`${t("toast.successfully")}`);
        loadData();
      })
      .catch(() => "");
  };
  const closeModal = () => {
    setEditLineId(0);
    form.setFieldsValue(formTemplate);
    setOpenModal(false);
  };

  // Handle pagination changes
  const handlePaginationChange = (page: number, pageSize: number) => {
    const limintChange = page - 1 === query.page;
    setquery((prevQuery) => ({
      ...prevQuery,
      page: limintChange ? 0 : page - 1, // Update page to 5
      limit: pageSize, // Update limit to 3
    }));
  };

  const openCreateModal = () => {
    setOpenModal(true);
    // Explicitly set initial values for a new pavilion if required
    form.setFieldsValue(formTemplate);
  };

  const handleChange = (id: number) => {
    if (!id) return;
    const selectedOption: SessionDataType | undefined = testTypeList.find(
      (option: SessionDataType) => option.id === id,
    );
    form.setFieldsValue({
      maxCountCandidate: selectedOption?.maxCandidates,
      cost: selectedOption?.defaultPaymentAmount,
    });
    setSelectOneTestType(selectedOption?.testType || "");
    if (selectedOption?.testType === "TOEFL") {
      loadToeflData();
      loadToeflDataReading();
      loadToeflDataWriting();
      loadToeflDataSpeaking();
    }
  };
  const items: MenuProps["items"] = [
    {
      key: "1",
      label: (
        <div onClick={openCreateModal}>
          <PlusOutlined /> {t("sessions.add")}
        </div>
      ),
    },
  ];
  const loadToeflData = useCallback(async (value = "") => {
    const listeningQuery = {
      page: 0,
      limit: 100,
      search: {
        value: value || undefined,
      },
    };
    await axiosServer(router.locale, false, userInfo?.token)
      .post(`/api/v1/listening/list-search`, listeningQuery)
      .then((res: any) => {
        setListeningList(res?.data?.list || []); // Update the state with the fetched data
      })
      .catch(() => {
        setListeningList([]);
      });
  }, []);
  const loadToeflDataReading = useCallback(async (value = "") => {
    const listeningQuery = {
      page: 0,
      limit: 100,
      search: {
        value: value || undefined,
      },
    };
    await axiosServer(router.locale, false, userInfo?.token)
      .post(`/api/v1/reading/list-search`, listeningQuery)
      .then((res: any) => {
        setReadingList(res?.data?.list || []); // Update the state with the fetched data
      })
      .catch(() => {
        setReadingList([]);
      });
  }, []);
  const loadToeflDataWriting = useCallback(async (value = "") => {
    const listeningQuery = {
      page: 0,
      limit: 100,
      search: {
        value: value || undefined,
      },
    };
    await axiosServer(router.locale, false, userInfo?.token)
      .post(`/api/v1/writing/list-search`, listeningQuery)
      .then((res: any) => {
        setWritingList(res?.data?.list || []); // Update the state with the fetched data
      })
      .catch(() => {
        setWritingList([]);
      });
  }, []);
  const loadToeflDataSpeaking = useCallback(async (value = "") => {
    const listeningQuery = {
      page: 0,
      limit: 100,
      search: {
        value: value || undefined,
      },
    };
    await axiosServer(router.locale, false, userInfo?.token)
      .post(`/api/v1/speaking/list-search`, listeningQuery)
      .then((res: any) => {
        setSpeakingList(res?.data?.list || []); // Update the state with the fetched data
      })
      .catch(() => {
        setSpeakingList([]);
      });
  }, []);

  // const testTypeChange = (value: string) => {
  //   if (value === "TOEFL") {
  //     loadToeflData();
  //   }
  // };
  const listeningSearch = (value: string) => {
    if (value && value.length > 1) {
      loadToeflData(value);
    } else if (value === "") {
      loadToeflData(value);
    }
  };
  const readingSearch = (value: string) => {
    if (value && value.length > 1) {
      loadToeflDataReading(value);
    } else if (value === "") {
      loadToeflDataReading(value);
    }
  };
  const writingSearch = (value: string) => {
    if (value && value.length > 1) {
      loadToeflDataWriting(value);
    } else if (value === "") {
      loadToeflDataWriting(value);
    }
  };
  const SpeakingSearch = (value: string) => {
    if (value && value.length > 1) {
      loadToeflDataSpeaking(value);
    } else if (value === "") {
      loadToeflDataSpeaking(value);
    }
  };
  const redirectSessionUsersPage = (item: any) => {
    if (item?.testType?.testType === "TOEFL") {
      router.push(`/sessions/${item.id}`);
    } else if (item?.testType?.testType === "TEST" && item.id) {
      router.push(`/sessions/${item.id}/test-types-user`);
    }
  };
  return (
    <MainLayout>
      <Row className="pavilion-box ass-style">
        <Col span={24}>
          <div>
            <Breadcrumb items={breadcrumbItem} />
          </div>
        </Col>
        <Col span={24} className="add-pavilion-box">
          <Flex justify={"space-between"}>
            <Flex align={"center"}>
              {/*<ArrowLeftOutlined style={{ marginRight: "16px", fontSize: "16px" }} />*/}
              <Title level={4} className="m-0">
                {t("sessions.list")}
              </Title>
            </Flex>

            <Flex align={"end"}>
              <Dropdown menu={{ items }} placement="bottom">
                <Button type="primary" ghost>
                  {t("table.header.actions")} <DownOutlined />
                </Button>
              </Dropdown>
            </Flex>
          </Flex>
        </Col>
      </Row>
      <Row>
        <Col span={24}>
          <ConfigProvider
            //@ts-ignore
            locale={{
              Pagination: {
                items_per_page: "/" + t("table.page"), // Sahifa hajmi matnini o'zgartirish
              },
            }}
          >
            <Table<OperatorType>
              className="ass-table"
              dataSource={loading ? [] : dataItem}
              rowKey={(record): React.Key => record.id}
              pagination={{
                current: query.page + 1,
                pageSize: query.limit,
                total: totalItem,
                onChange: handlePaginationChange,
                showSizeChanger: true,
                pageSizeOptions: ["10", "20", "50"], // Customize the available page sizes
              }}
              loading={loading}
              locale={{
                emptyText: loading ? <Skeleton active paragraph={{ rows: 5 }} /> : t("empty"),
              }}
            >
              <Column title="#" dataIndex="id" key="id" />
              <Column
                title={`${t("table.header.type")}`}
                dataIndex="examType"
                key="examType"
                render={(examType: any) => (
                  <div>
                    <span className="ml-2">{examType}</span>
                  </div>
                )}
              />

              <Column
                title={`${t("table.header.maxCountCandidate")}`}
                dataIndex="maxCountCandidate"
                key="maxCountCandidate"
              />

              <Column
                title={`${t("table.header.startDate")}`}
                dataIndex="startDate"
                key="startDate"
                render={(date: string) => (date?.length ? dateFormatLong(date) : "")}
              />
              <Column title={`${t("table.header.cost")}`} dataIndex="cost" key="cost" />
              <Column
                title={`${t("table.header.actions")}`}
                key="id"
                render={(item: any) => (
                  <div>
                    <Button
                      onClick={() => redirectSessionUsersPage(item)}
                      className="bg-primary color-white ml-2"
                      shape="round"
                    >
                      <TeamOutlined />
                    </Button>

                    <Button
                      disabled={!item && item.id}
                      onClick={() => editItemModal(item.id)}
                      className="bg-primary color-white ml-2"
                      shape="round"
                    >
                      <EditOutlined />
                    </Button>
                    <Button
                      disabled={!item && item.id}
                      danger
                      onClick={() => deleteItemModal(item.id)}
                      className="ml-2"
                      shape="round"
                    >
                      <DeleteFilled />
                    </Button>
                  </div>
                )}
              />
            </Table>
          </ConfigProvider>
        </Col>
      </Row>
      <Row className="ass-style">
        <Modal
          className="ass-style ass-modal"
          centered
          open={openModal}
          title={`${t("sessions.add")}`}
          onOk={handleOk}
          onCancel={closeModal}
          footer={[
            <Button key="close" onClick={closeModal}>
              {t("form.close")}
            </Button>,
            <Button
              key="create"
              className={!isButtonDisabled ? "" : "base-bg color-white"}
              disabled={!isButtonDisabled}
              onClick={handleOk}
              loading={formBtnLoading}
            >
              {t("form.create")}
            </Button>,
          ]}
        >
          <div className="ass-modal-body">
            <Skeleton loading={formBtnLoading} active paragraph={{ rows: 5 }}>
              <Form
                {...layout}
                initialValues={initialValuesItem}
                form={form}
                name="control-hooks"
                style={{ width: "650px", marginTop: "20px" }}
                autoComplete="off"
              >
                <Row>
                  <Col span={24} className="pavilion-input">
                    <Form.Item
                      className="user-form-input"
                      name="examType"
                      label={`${t("table.header.type")}`}
                      rules={cannotEmpty}
                    >
                      <Select
                        onChange={() => form.setFieldsValue(templateChange)}
                        placeholder={t("form.status")}
                      >
                        <Option value="RETAKE">{t("form.label.retake")}</Option>
                        <Option value="EXAM">{t("form.label.exam")}</Option>
                      </Select>
                    </Form.Item>
                  </Col>
                  <Col span={24} className="pavilion-input">
                    {values?.examType && (
                      <Form.Item
                        className="user-form-input"
                        name="testTypeId"
                        label={`${t("form.label.sessionType")}`}
                        rules={cannotEmpty}
                      >
                        <Select placeholder={`${t("table.header.select")}`} onChange={handleChange}>
                          {/* Optionsni map qilish */}
                          {testTypeList.map((option) => (
                            <Select.Option key={option?.id} value={option?.id}>
                              {option?.titleRu}
                            </Select.Option>
                          ))}
                        </Select>
                      </Form.Item>
                    )}
                  </Col>
                  <Col span={24} className="pavilion-input">
                    {values?.testTypeId && values?.examType === "RETAKE" && (
                      <Form.Item
                        className="user-form-input"
                        name="examFormat"
                        label={`${t("form.label.examFormat")}`}
                        rules={cannotEmpty}
                      >
                        <Select placeholder={`${t("table.header.select")}`}>
                          <Option value="COMPUTER">{t("form.label.compyuter")}</Option>
                          <Option value="WRITE">{t("form.label.writing")}</Option>
                        </Select>
                      </Form.Item>
                    )}
                  </Col>
                  <Col span={24} className="pavilion-input">
                    {values?.testTypeId && (
                      <Form.Item
                        className="user-form-input"
                        name="maxCountCandidate"
                        label={`${t("table.header.maxCountCandidate")}`}
                        rules={cannotEmpty}
                      >
                        <Input
                          type="number"
                          min={0}
                          onChange={(e) =>
                            form.setFieldsValue({
                              reissueAmount: e?.target?.value ? Number(e?.target?.value) : 0,
                            })
                          }
                        />
                      </Form.Item>
                    )}
                  </Col>
                  <Col span={24} className="pavilion-input">
                    {values?.testTypeId && (
                      <Form.Item
                        className="user-form-input"
                        name="cost"
                        label={`${t("table.header.cost")}`}
                        rules={cannotEmpty}
                      >
                        <Input
                          type="number"
                          min={0}
                          placeholder={t("form.enterPaymentAmount")}
                          onChange={(e) =>
                            form.setFieldsValue({
                              reissueAmount: e?.target?.value ? Number(e?.target?.value) : 0,
                            })
                          }
                        />
                      </Form.Item>
                    )}
                  </Col>

                  <Col span={24} className="pavilion-input">
                    {values?.testTypeId && (
                      <Form.Item
                        className="user-form-input"
                        name="pavilionId"
                        label={`${t("form.label.pavilyon")}`}
                        rules={cannotEmpty}
                      >
                        <Select placeholder={`${t("table.header.select")}`}>
                          {/* Optionsni map qilish */}
                          {pavilionList.map((option) => (
                            <Select.Option key={option?.id} value={option?.id}>
                              {option?.nameRu}
                            </Select.Option>
                          ))}
                        </Select>
                      </Form.Item>
                    )}
                  </Col>
                  <Col span={24} className="pavilion-input">
                    {values?.testTypeId && values?.examType === "EXAM" && (
                      <Form.Item
                        className="user-form-input"
                        name="startDate"
                        label={`${t("form.label.date")}`}
                        rules={cannotEmpty}
                      >
                        <DatePicker
                          placeholder={`${t("table.header.select")}`}
                          format="DD-MM-YYYY HH:mm:ss"
                          showTime={{ defaultValue: dayjs("00:00:00", "HH:mm:ss") }}
                        />
                      </Form.Item>
                    )}
                  </Col>

                  <Col span={24} className="pavilion-input">
                    {selectOneTestType === "TOEFL" && (
                      <Form.Item
                        className="user-form-input"
                        name="listeningId"
                        label={`${t("form.label.listening")}`}
                        rules={cannotEmpty}
                      >
                        <Select
                          placeholder={`${t("table.header.select")}`}
                          allowClear
                          onSearch={($event) => {
                            listeningSearch($event);
                          }}
                          filterOption={false}
                          showSearch
                        >
                          {/* Optionsni map qilish */}
                          {listeningList?.map((option: any) => (
                            <Select.Option key={option?.id} value={option?.id}>
                              {option?.name}
                            </Select.Option>
                          ))}
                        </Select>
                      </Form.Item>
                    )}
                  </Col>
                  <Col span={24} className="pavilion-input">
                    {selectOneTestType === "TOEFL" && (
                      <Form.Item
                        className="user-form-input"
                        name="listeningScore"
                        label={`${t("form.label.listeningBall")}`}
                        rules={cannotEmpty}
                      >
                        <Input
                          type="number"
                          min={0}
                          onChange={(e) =>
                            form.setFieldsValue({
                              listeningScore: e?.target?.value ? Number(e?.target?.value) : 0,
                            })
                          }
                        />
                      </Form.Item>
                    )}
                  </Col>
                  <Col span={24} className="pavilion-input">
                    {selectOneTestType === "TOEFL" && (
                      <Form.Item
                        className="user-form-input"
                        name="readingId"
                        label={`${t("form.label.reading")}`}
                        rules={cannotEmpty}
                      >
                        <Select
                          allowClear
                          onSearch={($event) => {
                            readingSearch($event);
                          }}
                          filterOption={false}
                          showSearch
                        >
                          {/* Optionsni map qilish */}
                          {readingList?.map((option: any) => (
                            <Select.Option key={option?.id} value={option?.id}>
                              {option?.name}
                            </Select.Option>
                          ))}
                        </Select>
                      </Form.Item>
                    )}
                  </Col>
                  <Col span={24} className="pavilion-input">
                    {selectOneTestType === "TOEFL" && (
                      <Form.Item
                        className="user-form-input"
                        name="readingScore"
                        label={`${t("form.label.readinggBall")}`}
                        rules={cannotEmpty}
                      >
                        <Input
                          type="number"
                          min={0}
                          onChange={(e) =>
                            form.setFieldsValue({
                              readingScore: e?.target?.value ? Number(e?.target?.value) : 0,
                            })
                          }
                        />
                      </Form.Item>
                    )}
                  </Col>
                  <Col span={24} className="pavilion-input">
                    {selectOneTestType === "TOEFL" && (
                      <Form.Item
                        className="user-form-input"
                        name="writingId"
                        label={`${t("form.label.writings")}`}
                        rules={cannotEmpty}
                      >
                        <Select
                          allowClear
                          onSearch={($event) => {
                            writingSearch($event);
                          }}
                          filterOption={false}
                          showSearch
                        >
                          {/* Optionsni map qilish */}
                          {writingList?.map((option: any) => (
                            <Select.Option key={option?.id} value={option?.id}>
                              {option?.name}
                            </Select.Option>
                          ))}
                        </Select>
                      </Form.Item>
                    )}
                  </Col>
                  <Col span={24} className="pavilion-input">
                    {selectOneTestType === "TOEFL" && (
                      <Form.Item
                        className="user-form-input"
                        name="writingScore"
                        label={`${t("form.label.writingsBall")}`}
                        rules={cannotEmpty}
                      >
                        <Input
                          type="number"
                          min={0}
                          onChange={(e) =>
                            form.setFieldsValue({
                              writingScore: e?.target?.value ? Number(e?.target?.value) : 0,
                            })
                          }
                        />
                      </Form.Item>
                    )}
                  </Col>
                  <Col span={24} className="pavilion-input">
                    {selectOneTestType === "TOEFL" && (
                      <Form.Item
                        className="user-form-input"
                        name="speakingId"
                        label={`${t("form.label.speaking")}`}
                        rules={cannotEmpty}
                      >
                        <Select
                          allowClear
                          onSearch={($event) => {
                            SpeakingSearch($event);
                          }}
                          filterOption={false}
                          showSearch
                        >
                          {/* Optionsni map qilish */}
                          {speakingList?.map((option: any) => (
                            <Select.Option key={option?.id} value={option?.id}>
                              {option?.name}
                            </Select.Option>
                          ))}
                        </Select>
                      </Form.Item>
                    )}
                  </Col>
                  <Col span={24} className="pavilion-input">
                    {selectOneTestType === "TOEFL" && (
                      <Form.Item
                        className="user-form-input"
                        name="speakingScore"
                        label={`${t("form.label.speakingBall")}`}
                        rules={cannotEmpty}
                      >
                        <Input
                          type="number"
                          min={0}
                          onChange={(e) =>
                            form.setFieldsValue({
                              speakingScore: e?.target?.value ? Number(e?.target?.value) : 0,
                            })
                          }
                        />
                      </Form.Item>
                    )}
                  </Col>
                </Row>
              </Form>
            </Skeleton>
          </div>
        </Modal>
      </Row>

      <Row>
        <Col span={24}>{contextHolder}</Col>
      </Row>
    </MainLayout>
  );
}
