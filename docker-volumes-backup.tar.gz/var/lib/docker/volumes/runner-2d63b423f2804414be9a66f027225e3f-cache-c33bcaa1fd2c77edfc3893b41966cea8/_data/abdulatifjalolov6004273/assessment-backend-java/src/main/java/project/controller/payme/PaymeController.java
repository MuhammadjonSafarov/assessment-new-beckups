package project.controller.payme;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import net.minidev.json.JSONObject;
import org.springframework.web.bind.annotation.*;
import project.model.payme.json.PaycomRequestForm;
import project.service.payme.IPaycomService;

@Slf4j
@RequestMapping("/api/v1/paycom")
@RestController
@RequiredArgsConstructor
public class PaymeController {

    private final IPaycomService ipaycomService;

    @PostMapping
    public JSONObject post(
            @RequestBody PaycomRequestForm requestForm,
            @RequestHeader(value = "Authorization", required = false) String authorization
    ) {
        log.info("Authorization: {}", authorization);
        log.info("Request: {}", requestForm);
        return ipaycomService.payWithPaycom(requestForm, authorization);
    }
}
