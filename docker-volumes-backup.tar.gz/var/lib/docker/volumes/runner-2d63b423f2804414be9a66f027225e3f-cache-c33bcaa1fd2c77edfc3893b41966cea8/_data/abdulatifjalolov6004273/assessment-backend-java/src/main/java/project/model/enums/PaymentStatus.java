package project.model.enums;

public enum PaymentStatus {

    UNPAID, PAID, OUT_OF_TERM_DATE

}
