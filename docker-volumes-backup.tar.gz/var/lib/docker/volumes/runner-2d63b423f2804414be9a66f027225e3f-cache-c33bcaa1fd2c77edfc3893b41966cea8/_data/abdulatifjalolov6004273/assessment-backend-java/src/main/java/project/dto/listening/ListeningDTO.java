package project.dto.listening;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import project.model.entity.listening.Listening;
import project.repository.QuestionsRepository;

import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class ListeningDTO {

    private Long id;

    private String name;

    private Set<AudiosDTO> audios;

    private List<Long> audioIds;

    private String time;

    public ListeningDTO(Listening listening, QuestionsRepository questionsRepository) {
        setId(listening.getId());
        setTime(listening.getTime());
        setName(listening.getName());
        setAudios(listening.getAudios().stream().map((a) -> new AudiosDTO(a, questionsRepository)).collect(Collectors.toSet()));
    }
    public ListeningDTO(Listening listening) {
        setId(listening.getId());
        setTime(listening.getTime());
        setName(listening.getName());
    }

}
