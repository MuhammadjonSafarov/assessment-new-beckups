package project.controller;

import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import project.dto.PavilionDto;
import project.model.Pagination;
import project.service.PavilionService;
import project.utility.Search;

@RestController
@RequestMapping("/api/v1/pavilion")
@RequiredArgsConstructor
@SecurityRequirement(name = "Bearer Authentication")
public class PavilionController {

    private final PavilionService pavilionService;

    @PostMapping
    @ResponseStatus(HttpStatus.OK)
    public ResponseEntity<?> create(
            @RequestBody PavilionDto pavilionDto
    ) {
        return pavilionService.create(pavilionDto);
    }

    @PutMapping("/{id}")
    @ResponseStatus(HttpStatus.OK)
    public ResponseEntity<?> update(
            @RequestBody PavilionDto pavilionDto,
            @PathVariable Long id
    ) {
        return pavilionService.update(pavilionDto, id);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.OK)
    public ResponseEntity<?> delete(
            @PathVariable Long id
    ) {
        return pavilionService.delete(id);
    }

    @GetMapping("/{id}")
    @ResponseStatus(HttpStatus.OK)
    public ResponseEntity<?> get(
            @PathVariable Long id
    ) {
        return pavilionService.get(id);
    }


    @PostMapping("/list-search")
    @ResponseStatus(HttpStatus.OK)
    public ResponseEntity<?> listSearch(
            @RequestBody Pagination<Search> pagination
    ) {
        return pavilionService.search(pagination);
    }


    @GetMapping("/test-type/{testTypeId}/{examType}")
    @ResponseStatus(HttpStatus.OK)
    public ResponseEntity<?> getPavilionsByTestType(
            @PathVariable Long testTypeId,
            @PathVariable String examType
    ) {
        return pavilionService.getPavilionsByTestType(testTypeId, examType);
    }

}
