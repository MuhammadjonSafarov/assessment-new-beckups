package project.controller;

import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import project.dto.UserApplicationAnswerRequestDTO;
import project.dto.UserApplicationDTO;
import project.model.Pagination;
import project.service.UserApplicationService;
import project.utility.Search;

import java.util.List;

@RestController
@RequestMapping("/api/v1/user-application")
@RequiredArgsConstructor
@SecurityRequirement(name = "Bearer Authentication")
public class UserApplicationController {

    private final UserApplicationService userApplicationService;

    @PostMapping
    @ResponseStatus(HttpStatus.OK)
    public ResponseEntity<?> create(
            @RequestBody UserApplicationDTO userApplicationDTO
    ) {
        return userApplicationService.crete(userApplicationDTO);
    }

    @PutMapping("/{id}")
    @ResponseStatus(HttpStatus.OK)
    public ResponseEntity<?> payApplication(
            @PathVariable Long id
    ) {
        return userApplicationService.payApplication(id);
    }

    @PutMapping("/change-my-id-status/{id}")
    @ResponseStatus(HttpStatus.OK)
    public ResponseEntity<?> changeMyIdStatus(
            @PathVariable Long id
    ) {
        return userApplicationService.changeMyIdStatus(id);
    }

    @GetMapping("/{id}")
    @ResponseStatus(HttpStatus.OK)
    public ResponseEntity<?> get(
            @PathVariable Long id
    ) {
        return userApplicationService.get(id);
    }

    @PostMapping("/list-search/{userId}")
    @ResponseStatus(HttpStatus.OK)
    public ResponseEntity<?> listSearch(
            @RequestBody Pagination<Search> pagination,
            @PathVariable Long userId
    ) {
        return userApplicationService.search(userId, pagination);
    }

    @PostMapping("/attach-listening-answers/{id}")
    @ResponseStatus(HttpStatus.OK)
    public ResponseEntity<?> attachListeningAnswers(
            @PathVariable Long id,
            @RequestBody List<UserApplicationAnswerRequestDTO> answers
    ) {
        return userApplicationService.attachListeningAnswers(id, answers);
    }

    @PostMapping("/attach-speaking-answers/{id}")
    @ResponseStatus(HttpStatus.OK)
    public ResponseEntity<?> attachSpeakingAnswers(
            @PathVariable Long id,
            @RequestBody List<UserApplicationAnswerRequestDTO> answers
    ) {
        return userApplicationService.attachSpeakingAnswers(id, answers);
    }

    @PostMapping("/attach-reading-answers/{id}")
    @ResponseStatus(HttpStatus.OK)
    public ResponseEntity<?> attachReadingAnswers(
            @PathVariable Long id,
            @RequestBody List<UserApplicationAnswerRequestDTO> answers
    ) {
        return userApplicationService.attachReadingAnswers(id, answers);
    }

    @PostMapping("/attach-writing-answers/{id}")
    @ResponseStatus(HttpStatus.OK)
    public ResponseEntity<?> attachWritingAnswers(
            @PathVariable Long id,
            @RequestBody List<UserApplicationAnswerRequestDTO> answers
    ) {
        return userApplicationService.attachWritingAnswers(id, answers);
    }

    @PostMapping("/attach-listening-degree/{id}/{listeningDegree}")
    @ResponseStatus(HttpStatus.OK)
    public ResponseEntity<?> attachListeningDegree(
            @PathVariable Long id,
            @PathVariable String listeningDegree
    ) {
        return userApplicationService.attachListeningDegree(id, listeningDegree);
    }

    @PostMapping("/attach-reading-degree/{id}/{readingDegree}")
    @ResponseStatus(HttpStatus.OK)
    public ResponseEntity<?> attachReadingDegree(
            @PathVariable Long id,
            @PathVariable String readingDegree
    ) {
        return userApplicationService.attachReadingDegree(id, readingDegree);
    }

    @PostMapping("/attach-speaking-degree/{id}/{speakingDegree}")
    @ResponseStatus(HttpStatus.OK)
    public ResponseEntity<?> attachSpeakingDegree(
            @PathVariable Long id,
            @PathVariable String speakingDegree
    ) {
        return userApplicationService.attachSpeakingDegree(id, speakingDegree);
    }

    @PostMapping("/attach-writing-degree/{id}/{writingDegree}")
    @ResponseStatus(HttpStatus.OK)
    public ResponseEntity<?> attachWritingDegree(
            @PathVariable Long id,
            @PathVariable String writingDegree
    ) {
        return userApplicationService.attachWritingDegree(id, writingDegree);
    }

    @PostMapping("/attach-degree/{id}/{degree}")
    @ResponseStatus(HttpStatus.OK)
    public ResponseEntity<?> attachDegree(
            @PathVariable Long id,
            @PathVariable String degree
    ) {
        return userApplicationService.attachDegree(id, degree);
    }

    @PostMapping("/attach-certificate-file/{id}/{fileId}")
    @ResponseStatus(HttpStatus.OK)
    public ResponseEntity<?> attachCertificateFile(
            @PathVariable Long id,
            @PathVariable Long fileId
    ) {
        return userApplicationService.attachCertificateFile(id, fileId);
    }

    @PostMapping("/certificates/{userId}")
    @ResponseStatus(HttpStatus.OK)
    public ResponseEntity<?> listCertificates(
            @PathVariable Long userId,
            @RequestBody Pagination<Search> pagination
    ) {
        return userApplicationService.listCertificates(userId, pagination);
    }

}
