package project.service.writing;

import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import project.dto.ResponseDto;
import project.dto.writing.WritingPartsDTO;
import project.exception.RecordBadRequestException;
import project.exception.RecordNotFoundException;
import project.model.Pagination;
import project.model.entity.Questions;
import project.model.entity.writing.WritingParts;
import project.model.enums.Status;
import project.repository.FileRepository;
import project.repository.QuestionsRepository;
import project.repository.writing.WritingPartsRepository;
import project.utility.PageWrapper;
import project.utility.Search;
import project.utility.Utils;

import java.util.HashSet;
import java.util.List;

@Service
@RequiredArgsConstructor
public class WritingPartsService {

    private final WritingPartsRepository writingPartsRepository;
    private final QuestionsRepository questionsRepository;
    private final FileRepository fileRepository;

    public ResponseEntity<?> create(WritingPartsDTO writingPartsDTO) {
//        writingPartsRepository.findByName(writingPartsDTO.getName()).ifPresent((answer) -> {
//            throw new RecordBadRequestException("WritingParts already exists with " + writingPartsDTO.getName());
//        });
        WritingParts writingParts = writingPartsRepository.save(
                WritingParts.builder()
                        .status(Status.ACTIVE)
                        .name(writingPartsDTO.getName())
                        .body(writingPartsDTO.getBody())
                        .files((writingPartsDTO.getFileIds() != null && !writingPartsDTO.getFileIds().isEmpty()) ? new HashSet<>(fileRepository.findAllById(writingPartsDTO.getFileIds())) : new HashSet<>())
                        .orderNumber(writingPartsDTO.getOrderNumber())
                        .build());
        if (writingPartsDTO.getQuestionIds() != null && !writingPartsDTO.getQuestionIds().isEmpty()) {
            writingPartsDTO.getQuestionIds().forEach((questionId) -> questionsRepository.findById(questionId).ifPresent((questions) -> {
                questions.setWritingParts(writingParts);
                questionsRepository.save(questions);
            }));
        }
        return ResponseEntity.ok(new WritingPartsDTO(writingPartsRepository.save(writingParts), questionsRepository));
    }


    public ResponseEntity<?> update(Long id, WritingPartsDTO writingPartsDTO) {
        WritingParts writingParts = writingPartsRepository.findById(id).orElseThrow(() -> new RecordNotFoundException("WritingParts not found with id " + id));
//        if (!writingParts.getName().equals(writingPartsDTO.getName())) {
//            writingPartsRepository.findByName(writingPartsDTO.getName()).ifPresent((audio) -> {
//                throw new RecordBadRequestException("WritingParts already exists with " + writingPartsDTO.getName());
//            });
//        }
        writingParts.setName(writingPartsDTO.getName());
        writingParts.setBody(writingPartsDTO.getBody());
        writingParts.setOrderNumber(writingPartsDTO.getOrderNumber());
        writingParts.setFiles((writingPartsDTO.getFileIds() != null && !writingPartsDTO.getFileIds().isEmpty()) ? new HashSet<>(fileRepository.findAllById(writingPartsDTO.getFileIds())) : new HashSet<>());
        for (Questions questions : questionsRepository.finAllByWritingParts(writingParts.getId())) {
            questions.setWritingParts(null);
            questionsRepository.save(questions);
        }

        if (writingPartsDTO.getQuestionIds() != null && !writingPartsDTO.getQuestionIds().isEmpty()) {
            writingPartsDTO.getQuestionIds().forEach((questionId) -> questionsRepository.findById(questionId).ifPresent((questions) -> {
                questions.setWritingParts(writingParts);
                questionsRepository.save(questions);
            }));
        }
        return ResponseEntity.ok(new WritingPartsDTO(writingPartsRepository.save(writingParts), questionsRepository));

    }

    public ResponseEntity<?> get(Long id) {
        WritingParts questions = writingPartsRepository.findById(id).orElseThrow(() -> new RecordNotFoundException("WritingParts not found with id " + id));
        return ResponseEntity.ok((new WritingPartsDTO(writingPartsRepository.save(questions), questionsRepository)));
    }

    public ResponseEntity<ResponseDto<PageWrapper>> search(Pagination<Search> pagination) {
        Page<WritingParts> writingPartsPage;
        if (pagination.getSearch().getValue() != null && !pagination.getSearch().getValue().isEmpty()) {
            writingPartsPage = search(pagination.getSearch().getValue().toLowerCase(), pagination);
        } else {
            writingPartsPage = search("", pagination);
        }
        List<WritingPartsDTO> writingPartsDTOs = writingPartsPage.stream()
                .map(question -> new WritingPartsDTO(question, questionsRepository))
                .toList();
        return ResponseEntity.ok(new ResponseDto<>(ResponseDto.States.SUCCESS, HttpStatus.OK, 200, null, PageWrapper.builder().list(writingPartsDTOs).total(writingPartsPage.getTotalElements()).build()));
    }

    public Page<WritingParts> search(String value, Pagination<Search> pagination) {
        Pageable paging = Utils.getPageableFromPagination(pagination);
        Page<WritingParts> pagedResult;
        if (!value.isEmpty()) {
            pagedResult = writingPartsRepository.findAllBySearch(value, paging);
        } else {
            pagedResult = writingPartsRepository.findAllWritingParts(paging);
        }
        return pagedResult;
    }

    public ResponseEntity<?> delete(Long id) {
        WritingParts questions = writingPartsRepository.findById(id).orElseThrow(() -> new RecordNotFoundException("WritingParts not found with id " + id));
        questions.setStatus(Status.DELETED);
        writingPartsRepository.save(questions);
        return ResponseEntity.ok("SUCCESS");
    }

}
