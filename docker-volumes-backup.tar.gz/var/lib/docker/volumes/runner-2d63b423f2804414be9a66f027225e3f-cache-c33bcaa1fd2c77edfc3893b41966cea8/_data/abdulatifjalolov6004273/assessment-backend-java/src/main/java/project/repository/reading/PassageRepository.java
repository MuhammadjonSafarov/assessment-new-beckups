package project.repository.reading;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.data.repository.query.QueryByExampleExecutor;
import project.model.entity.File;
import project.model.entity.reading.Passage;

import java.util.List;
import java.util.Optional;

public interface PassageRepository extends JpaRepository<Passage, Long>, PagingAndSortingRepository<Passage, Long>, QueryByExampleExecutor<Passage> {

    @Query("select q from Passage q where q.status = 'ACTIVE' and q.name = ?1 ")
    Optional<Passage> findByName(String name);

    @Query("select p from Passage p where p.status = 'ACTIVE' and p.isParent = ?2 and lower(p.name) like %?1% order by p.id ")
    Page<Passage> findAllBySearch(String value, Boolean isParent, Pageable pageable);

    @Query("select p from Passage p where p.status = 'ACTIVE' and p.isParent = ?1 order by p.id ")
    Page<Passage> findAllPassage(Boolean isParent, Pageable pageable);

    @Query("SELECT a.file FROM Passage a WHERE a.file IS NOT NULL ")
    List<File> findAllLinkedPassageFiles();

    @Query("SELECT f FROM Passage a JOIN a.file f ")
    List<File> findAllLinkedFiles();

}
