package project.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import project.model.entity.Answers;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class AnswersDTO {

    private Long id;

    private String answer;

    private Boolean isCorrect;

    public AnswersDTO(Answers answer) {
        setId(answer.getId());
        setAnswer(answer.getAnswer());
        setIsCorrect(answer.getIsCorrect());
    }

}
