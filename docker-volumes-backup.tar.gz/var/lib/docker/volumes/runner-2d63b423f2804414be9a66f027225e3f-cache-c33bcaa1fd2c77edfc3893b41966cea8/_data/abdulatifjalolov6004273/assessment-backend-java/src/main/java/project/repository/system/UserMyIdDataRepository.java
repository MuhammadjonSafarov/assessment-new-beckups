package project.repository.system;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.data.repository.query.QueryByExampleExecutor;
import project.model.entity.system.UserMyIdData;

import java.util.Optional;

public interface UserMyIdDataRepository extends JpaRepository<UserMyIdData, Long>, PagingAndSortingRepository<UserMyIdData, Long>, QueryByExampleExecutor<UserMyIdData> {
    @Query("select umd from UserMyIdData umd where umd.user.id = ?1 ")
    Optional<UserMyIdData> findByUserId(Long id);
}
