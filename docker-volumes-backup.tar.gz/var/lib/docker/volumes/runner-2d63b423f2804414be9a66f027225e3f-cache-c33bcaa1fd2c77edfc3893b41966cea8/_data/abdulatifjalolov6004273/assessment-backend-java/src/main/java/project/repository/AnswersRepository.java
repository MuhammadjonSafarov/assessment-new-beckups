package project.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.data.repository.query.QueryByExampleExecutor;
import project.dto.AnswersDTO;
import project.model.entity.Answers;
import project.model.entity.Questions;

import java.util.List;
import java.util.Optional;

public interface AnswersRepository extends JpaRepository<Answers, Long>, PagingAndSortingRepository<Answers, Long>, QueryByExampleExecutor<Answers> {

    @Query("select a from Answers a where a.status = 'ACTIVE' and a.answer = ?1 ")
    Optional<Answers> findByAnswer(String answer);

    @Query("select p from Answers p where p.status = 'ACTIVE' and p.answer like %?1% order by p.id ")
    Page<Answers> findAllBySearch(String value, Pageable pageable);

    @Query("select p from Answers p where p.status = 'ACTIVE' order by p.id ")
    Page<Answers> findAllAnswers(Pageable pageable);

    @Query("select new project.dto.AnswersDTO(a) from Answers a where a.status = 'ACTIVE' and ?1 member of a.questions ")
    List<AnswersDTO> findAllByQuestionsId(Questions questions);

}
