package project.repository.listening;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.data.repository.query.QueryByExampleExecutor;
import project.model.entity.listening.Listening;

import java.util.Optional;

public interface ListeningRepository extends JpaRepository<Listening, Long>, PagingAndSortingRepository<Listening, Long>, QueryByExampleExecutor<Listening> {

    @Query("select q from Listening q where q.status = 'ACTIVE' and q.name = ?1 ")
    Optional<Listening> findByName(String name);

    @Query("select p from Listening p where p.status = 'ACTIVE' and p.name like %?1% order by p.id ")
    Page<Listening> findAllBySearch(String value, Pageable pageable);

    @Query("select p from Listening p where p.status = 'ACTIVE' order by p.id ")
    Page<Listening> findAllListening(Pageable pageable);

}
