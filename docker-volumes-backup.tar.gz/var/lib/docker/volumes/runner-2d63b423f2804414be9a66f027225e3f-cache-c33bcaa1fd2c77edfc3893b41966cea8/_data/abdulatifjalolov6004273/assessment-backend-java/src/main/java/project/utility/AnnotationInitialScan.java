package project.utility;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import project.repository.system.RoleRepository;
import project.repository.system.UserRepository;
import project.service.system.PermissionService;
import project.service.system.RoleService;
import project.service.system.UserService;

import javax.annotation.PostConstruct;

@Slf4j
@Configuration
public class AnnotationInitialScan {
    @Value("${initial.username}")
    String username;
    @Value("${initial.password}")
    String password;
    @Value("${initial.roleName}")
    String roleName;
    @Value("${initial.roleCode}")
    String roleCode;
    @Autowired
    private RoleService roleService;
    @Autowired
    private UserService userService;

    @Autowired
    private PermissionService permissionService;
    @Autowired
    private BCryptPasswordEncoder passwordEncoder;
    @Autowired
    private RoleRepository roleRepository;
    @Autowired
    private UserRepository userRepository;

    @PostConstruct
    public void postConstruct() {
//        this.startView();
//        this.startPerm();
//        this.startRole();
        this.startUser();
    }

    private void startUser() {
//        Role role = roleRepository.save(Role.builder()
//                .isGetAllPermissions(true)
//                .name(roleName)
//                .code(roleCode)
//                .description(roleName)
//                .type(Type.ADMINISTRATOR)
//                .build());
//
//        User user = User.builder()
//                .username(username)
//                .password(passwordEncoder.encode(password))
//                .roles(List.of(role))
//                .status(Status.ACTIVE)
//                .build();
//
//        userRepository.save(user);
    }

//    public void startView() {
//        log.info("---------------------------------------");
//        log.info("-------Scan for View annotations-------");
//        log.info("---------------------------------------");
//        Reflections reflections = new Reflections("project.controller", new MethodAnnotationsScanner());
//        Set<Method> methods = reflections.getMethodsAnnotatedWith(View.class);
//        methods.forEach(method -> {
//            View perm = method.getAnnotation(View.class);
//            for (String code : perm.value()) {
//                try {
//                    String methodType = method.getDeclaringClass().getSimpleName();
//                    String type = null;
//                    if (methodType.contains("Controller"))
//                        type = methodType.replace("Controller", "");
//                    if (type != null) {
//                        Permission permissionOpt = permissionService.getPermissionByName(code);
//                        if (permissionOpt == null) {
//                            Permission permission = new Permission();
//                            permission.setName(code);
//                            permission.setType(type);
//                            permissionService.savePermission(permission);
//                            log.info("Found a permission '" + code + "'");
//                        }
//                    }
//                } catch (Throwable e) {
//                    log.error(e.getMessage(), e);
//                }
//            }
//        });
//    }
//
//    public void startPerm() {
//        log.info("---------------------------------------");
//        log.info("----Scan for Permission annotations----");
//        log.info("---------------------------------------");
//        Reflections reflections = new Reflections(
//                "project.controller", new MethodAnnotationsScanner()
//        );
//        Set<Method> methods = reflections.getMethodsAnnotatedWith(PreAuthorize.class);
//        methods.forEach(method -> {
//            PreAuthorize perm = method.getAnnotation(PreAuthorize.class);
//            String name = perm.value();
//            if (name.contains("hasAuthority")) {
//                String codeAndName = name.replace("hasAuthority('", "").replace("')", "");
//                try {
//                    String methodType = method.getDeclaringClass().getSimpleName();
//                    String type = null;
//                    if (methodType.contains("Controller"))
//                        type = methodType.replace("Controller", "");
//                    if (type != null) {
//                        Permission hasPerm = permissionService.permissionByCode(codeAndName);
//                        if (hasPerm == null) {
//                            Permission permission = new Permission();
//                            permission.setName(codeAndName);
//                            permission.setCode(codeAndName);
//                            if (codeAndName.equals("View Reference")) {
//                                permission.setType("References");
//                            } else {
//                                permission.setType(type);
//                            }
//                            permissionService.savePermission(permission);
//                        }
//                    }
//                } catch (Throwable e) {
//                    log.error(e.getMessage(), e);
//                }
//            } else if (name.contains("hasAnyAuthority")) {
//                String codeAndName = name.replace("hasAnyAuthority('", "").replace("')", "");
//                String[] codeAndNames = codeAndName.split(",");
//                try {
//                    String methodType = method.getDeclaringClass().getSimpleName();
//                    String type = null;
//                    if (methodType.contains("Controller"))
//                        type = methodType.replace("Controller", "");
//                    if (type != null) {
//                        for (String andName : codeAndNames) {
//                            String permissionName = andName.replaceAll("'", "").trim();
//                            Permission hasPerm = permissionService.permissionByCode(permissionName);
//                            if (hasPerm == null) {
//                                Permission permission = new Permission();
//                                permission.setName(permissionName);
//                                permission.setCode(permissionName);
//                                if (permissionName.equals("View Reference")) {
//                                    permission.setType("References");
//                                } else {
//                                    permission.setType(type);
//                                }
//                                permissionService.savePermission(permission);
//                                log.info("Found a permission '" + permissionName + "'");
//                            }
//                        }
//                    }
//                } catch (Throwable e) {
//                    log.error(e.getMessage(), e);
//                }
//            }
//        });
//    }

//    public void startRole() {
//        List<String> roles = new ArrayList<>();
//        roles.add("admin");
//        roles.forEach(roleName -> {
//            Role role = roleService.findByCode(roleCode);
//            if (role == null) {
//                role = new Role();
//                role.setName(roleName);
//                role.setCode(roleCode);
//                role.setStatus(ACTIVE);
//                roleService.createRole(role);
//            }
//            if (roleName.equalsIgnoreCase("admin")) {
//                role.getPermissions().addAll(permissionService.findNotInRole(role.getId()));
//                roleService.updateRole(role);
//            }
//        });
//    }

//    public void startUser() {
//        User user = userService.findByUsername(username);
//        if (user == null) {
//            user = new User();
//            user.setUsername(username);
//            user.setStatus(ACTIVE);
//            user.setPassword(passwordEncoder.encode(password));
//            user.getRoles().add(roleService.findByCode(roleCode));
//            userService.saveUser(user);
//        }
//    }
}
