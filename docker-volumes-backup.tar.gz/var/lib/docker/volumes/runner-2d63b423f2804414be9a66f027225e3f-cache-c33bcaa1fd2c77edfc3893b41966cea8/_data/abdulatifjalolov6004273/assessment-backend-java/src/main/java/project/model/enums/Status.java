package project.model.enums;

/**
 * Enumeration that represents status of domain objects - ACTIVE, DELETED, etc.
 */

public enum Status {
    ACTIVE, INACTIVE, DELETED
}