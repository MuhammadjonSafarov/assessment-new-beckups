package project.controller;


import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import project.exception.RecordNotFoundException;
import project.model.entity.File;
import project.repository.FileRepository;
import project.service.FileService;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/v1/file")
@SecurityRequirement(name = "Bearer Authentication")
public class FileController {

    @Value("${file.path}")
    public String filePath;

    private final FileService fileService;
    private final FileRepository fileRepository;

    @PostMapping(consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    @ResponseStatus(HttpStatus.OK)
    public ResponseEntity<?> storeFile(
            @RequestParam MultipartFile file
    ) {
        return ResponseEntity.ok(fileService.storeFile(file));
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.OK)
    public ResponseEntity<?> deleteFile(
            @PathVariable Long id
    ) {
        return fileService.delete(id);
    }

    @GetMapping("/download/{fileId}")
    @ResponseStatus(HttpStatus.OK)
    public ResponseEntity<?> downloadFile(
            @PathVariable Long fileId
    ) {
        try {
            File file = fileRepository.findById(fileId).orElseThrow(() -> new RecordNotFoundException("File not found with id " + fileId));
            Path filePathA = Paths.get(filePath, file.getName());
            byte[] fileContent = Files.readAllBytes(filePathA);

            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_OCTET_STREAM);
            headers.setContentDisposition(ContentDisposition.inline().build());
            headers.setCacheControl("must-revalidate, post-check=0, pre-check=0");
            return ResponseEntity.ok()
                    .headers(headers)
                    .body(fileContent);
        } catch (IOException e) {
            return ResponseEntity.notFound().build();
        }
    }

}
