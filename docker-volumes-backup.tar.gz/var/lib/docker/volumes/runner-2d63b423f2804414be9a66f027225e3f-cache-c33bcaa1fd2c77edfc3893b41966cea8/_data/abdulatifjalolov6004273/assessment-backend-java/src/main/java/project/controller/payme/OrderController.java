package project.controller.payme;

import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import project.service.payme.OrderService;

@RestController
@RequestMapping("/api/v1/order-paycom")
@RequiredArgsConstructor
@SecurityRequirement(name = "Bearer Authentication")
public class OrderController {

    private final OrderService orderService;

    @PostMapping
    @ResponseStatus(HttpStatus.OK)
    public ResponseEntity<?> createOrder(
            @RequestParam Integer orderSum,
            @RequestParam Long userApplicationId
    ) {
        return orderService.createOrder(userApplicationId, orderSum);
    }

}
