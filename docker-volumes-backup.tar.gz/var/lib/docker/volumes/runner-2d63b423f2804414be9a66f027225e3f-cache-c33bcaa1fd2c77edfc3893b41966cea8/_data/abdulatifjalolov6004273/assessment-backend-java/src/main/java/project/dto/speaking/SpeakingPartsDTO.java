package project.dto.speaking;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import project.dto.FileDto;
import project.model.entity.speaking.SpeakingParts;
import project.model.enums.Status;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class SpeakingPartsDTO {

    private Long id;

    private FileDto textAudio;

    private Long textAudioFileId;

    private Long textSuggestedReadingTime;

    private String text;

    private FileDto photoAudio;

    private Long photoAudioFileId;

    private FileDto photoFile;

    private Long photoFileFileId;

    private String question;

    private FileDto questionAudio;

    private Long questionAudioFileId;

    private Long preparationTime;

    private Long responseTime;

    private Long orderNumber;

    private Status status;

    private Double coefficient;

    private Double score;

    public SpeakingPartsDTO(SpeakingParts speakingParts) {
        setId(speakingParts.getId());
        setCoefficient(speakingParts.getCoefficient());
        setScore(speakingParts.getScore());
        if (speakingParts.getTextAudio() != null)
            setTextAudio(new FileDto(speakingParts.getTextAudio()));
        setTextSuggestedReadingTime(speakingParts.getTextSuggestedReadingTime());
        setText(speakingParts.getText());
        if (speakingParts.getQuestionAudio() != null)
                    setQuestionAudio(new FileDto(speakingParts.getQuestionAudio()));

        if (speakingParts.getPhotoAudio() != null)
            setPhotoAudio(new FileDto(speakingParts.getPhotoAudio()));
        if (speakingParts.getPhotoFile() != null)
            setPhotoFile(new FileDto(speakingParts.getPhotoFile()));
        setQuestion(speakingParts.getQuestion());
        setPreparationTime(speakingParts.getPreparationTime());
        setResponseTime(speakingParts.getResponseTime());
        setOrderNumber(speakingParts.getOrderNumber());
        setStatus(speakingParts.getStatus());
    }

}
