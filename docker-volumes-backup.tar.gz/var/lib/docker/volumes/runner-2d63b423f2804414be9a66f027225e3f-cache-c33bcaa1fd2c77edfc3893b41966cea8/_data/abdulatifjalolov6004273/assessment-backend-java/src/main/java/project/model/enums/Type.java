package project.model.enums;

public enum Type {
    MONITORING, ADMINISTRATOR
}
