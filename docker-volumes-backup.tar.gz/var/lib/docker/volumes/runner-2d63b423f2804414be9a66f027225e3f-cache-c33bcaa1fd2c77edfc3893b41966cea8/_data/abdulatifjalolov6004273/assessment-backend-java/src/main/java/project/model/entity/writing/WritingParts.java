package project.model.entity.writing;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.*;
import project.model.entity.File;
import project.model.enums.Status;

import javax.persistence.*;
import java.util.HashSet;
import java.util.Set;

import static javax.persistence.FetchType.LAZY;
import static javax.persistence.GenerationType.SEQUENCE;

@AllArgsConstructor
@Getter
@Setter
@Entity
@NoArgsConstructor
@Builder
@Table(name = "writing_parts")
public class WritingParts {

    @Id
    @GeneratedValue(strategy = SEQUENCE, generator = "WRITING_PARTS_SEQUENCE")
    @SequenceGenerator(sequenceName = "WRITING_PARTS_SEQUENCE", allocationSize = 1, name = "WRITING_PARTS_SEQUENCE")
    @Column(name = "id", nullable = false, updatable = false)
    private Long id;

    private String name;

    @Column(columnDefinition = "TEXT")
    private String body;

    @ManyToMany(fetch = LAZY)
    @JoinTable(name = "writing_part_files")
    private Set<File> files = new HashSet<>();

    @Column(name = "order_number")
    private Long orderNumber;

    @ManyToMany(mappedBy = "writingParts")
    @JsonIgnore
    private Set<Writing> writings = new HashSet<>();

    @Enumerated(EnumType.STRING)
    private Status status;

}
