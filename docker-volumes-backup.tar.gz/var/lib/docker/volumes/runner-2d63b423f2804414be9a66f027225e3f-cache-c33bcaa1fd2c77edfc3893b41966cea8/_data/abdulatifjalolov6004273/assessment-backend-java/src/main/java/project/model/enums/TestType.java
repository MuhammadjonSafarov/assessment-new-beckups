package project.model.enums;

public enum TestType {
    TOEFL, TEST
}
