package project.model.enums;

public enum MyIdStatus {

    ACCEPTED, REJECTED

}
