package project.model.entity;


import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.*;
import project.model.Auditable;
import project.model.entity.listening.Audios;
import project.model.entity.reading.Passage;
import project.model.entity.writing.WritingParts;
import project.model.enums.InnerTextType;
import project.model.enums.QuestionType;
import project.model.enums.Status;

import javax.persistence.*;

import java.util.HashSet;
import java.util.Set;

import static javax.persistence.FetchType.LAZY;
import static javax.persistence.GenerationType.SEQUENCE;

@AllArgsConstructor
@Getter
@Setter
@Entity
@NoArgsConstructor
@Builder
@Table(name = "questions")
public class Questions extends Auditable<String> {

    @Id
    @GeneratedValue(strategy = SEQUENCE, generator = "QUESTIONS_SEQUENCE")
    @SequenceGenerator(sequenceName = "QUESTIONS_SEQUENCE", allocationSize = 1, name = "QUESTIONS_SEQUENCE")
    @Column(name = "id", nullable = false, updatable = false)
    private Long id;

    @Column(columnDefinition = "TEXT")
    private String name;

    @Column(name = "correct_ansers_count")
    private Long correctAnswersCount;

    @Enumerated(EnumType.STRING)
    private InnerTextType innerTextType;

    private Long startIndex;

    private Long endIndex;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "audio_id")
    @JsonIgnore
    private Audios audios;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "passage_id")
    @JsonIgnore
    private Passage passages;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "writing_parts_id")
    @JsonIgnore
    private WritingParts writingParts;

    @ManyToMany(fetch = LAZY)
    @JoinTable(name = "question_answers",
            joinColumns = {@JoinColumn(name = "question_id", referencedColumnName = "id")},
            inverseJoinColumns = {@JoinColumn(name = "answer_id", referencedColumnName = "id")})
    private Set<Answers> answers = new HashSet<>();

    @Enumerated(EnumType.STRING)
    private Status status;

    @Enumerated(EnumType.STRING)
    private QuestionType questionType;

    private Double coefficient;

    private Double score;

}
