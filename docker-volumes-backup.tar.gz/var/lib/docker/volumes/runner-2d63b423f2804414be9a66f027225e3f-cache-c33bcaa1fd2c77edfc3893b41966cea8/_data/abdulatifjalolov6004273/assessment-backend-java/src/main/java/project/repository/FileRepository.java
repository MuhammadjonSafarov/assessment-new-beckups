package project.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.data.repository.query.QueryByExampleExecutor;
import project.model.entity.File;

public interface FileRepository extends PagingAndSortingRepository<File, Long>, JpaRepository<File, Long>, QueryByExampleExecutor<File> {

}
