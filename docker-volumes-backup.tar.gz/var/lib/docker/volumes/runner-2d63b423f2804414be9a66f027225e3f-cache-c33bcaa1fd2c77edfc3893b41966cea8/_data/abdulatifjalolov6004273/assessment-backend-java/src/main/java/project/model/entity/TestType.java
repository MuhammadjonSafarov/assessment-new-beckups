package project.model.entity;


import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.*;
import project.dto.TestTypeDto;
import project.model.Auditable;
import project.model.enums.ExamRunType;
import project.model.enums.Status;

import javax.persistence.*;
import java.math.BigDecimal;
import java.util.List;

import static javax.persistence.EnumType.STRING;
import static javax.persistence.FetchType.LAZY;
import static javax.persistence.GenerationType.SEQUENCE;

@AllArgsConstructor
@Getter
@Setter
@Entity
@NoArgsConstructor
@Builder
@Table(name = "test_types")
public class TestType extends Auditable<String> {

    @Id
    @GeneratedValue(strategy = SEQUENCE, generator = "TEST_TYPE_SEQUENCE")
    @SequenceGenerator(sequenceName = "TEST_TYPE_SEQUENCE", allocationSize = 1, name = "TEST_TYPE_SEQUENCE")
    @Column(name = "id", nullable = false, updatable = false)
    private Long id;

    @Column(name = "title_uz")
    private String titleUz;

    @Column(name = "title_ru")
    private String titleRu;

    @Column(name = "title_en")
    private String titleEn;

    @Column(name = "partner_uz")
    private String partnerUz;

    @Column(name = "partner_ru")
    private String partnerRu;

    @Column(name = "partner_en")
    private String partnerEn;

    @Column(name = "is_in_our_platform")
    private Boolean isInOurPlatform = false;

    @Column(name = "default_payment_amount")
    private BigDecimal defaultPaymentAmount = BigDecimal.ZERO;

    @Column(name = "is_there_any_other_pavilion")
    private Boolean isThereAnyOtherPavilion = false;

    @Column(name = "other_pavilion_payment_amount")
    private BigDecimal otherPavilionPaymentAmount = BigDecimal.ZERO;

    @Enumerated(STRING)
    @Column(name = "exam_run_type")
    private ExamRunType examRunType;

    @Enumerated(STRING)
    @Column(name = "status")
    private Status status;

    @Column(name = "retake_amount")
    private BigDecimal retakeAmount = BigDecimal.ZERO;

    @Column(name = "is_retake_available")
    private Boolean isRetakeAvailable = false;

    @Column(name = "reissue_amount")
    private BigDecimal reissueAmount = BigDecimal.ZERO;

    private String phone;

    private String telegram;

    @Column(name = "max_candidates")
    private Long maxCandidates;

    @Column(name = "result_options")
    @ElementCollection(fetch = LAZY)
    private List<String> resultOptions;

    @Enumerated(STRING)
    private project.model.enums.TestType testType;

    @ManyToOne
    private File file;

  @ManyToOne
  private File offerFile;

    @JsonIgnore
    public static TestType of(TestType testType, TestTypeDto testTypeDto) {
        testType.setTitleUz(testTypeDto.getTitleUz());
        testType.setTitleRu(testTypeDto.getTitleRu());
        testType.setTitleEn(testTypeDto.getTitleEn());
        testType.setPartnerUz(testTypeDto.getPartnerUz());
        testType.setPartnerRu(testTypeDto.getPartnerRu());
        testType.setStatus(testTypeDto.getStatus());
        testType.setTestType(testTypeDto.getTestType());
        testType.setPartnerEn(testTypeDto.getPartnerEn());
        testType.setIsInOurPlatform(testTypeDto.getIsInOurPlatform());
        testType.setDefaultPaymentAmount(testTypeDto.getDefaultPaymentAmount());
        testType.setIsThereAnyOtherPavilion(testTypeDto.getIsThereAnyOtherPavilion());
        testType.setOtherPavilionPaymentAmount(testTypeDto.getOtherPavilionPaymentAmount());
        testType.setExamRunType(testTypeDto.getExamRunType());
        testType.setRetakeAmount(testTypeDto.getRetakeAmount());
        testType.setIsRetakeAvailable(testTypeDto.getIsRetakeAvailable());
        testType.setReissueAmount(testTypeDto.getReissueAmount());
        testType.setPhone(testTypeDto.getPhone());
        testType.setTelegram(testTypeDto.getTelegram());
        testType.setMaxCandidates(testTypeDto.getMaxCandidates());
        testType.setResultOptions(testTypeDto.getResultOptions());
        return testType;
    }
}
