package project.model.entity.reading;

import lombok.*;
import project.model.Auditable;
import project.model.enums.Status;

import javax.persistence.*;

import java.util.HashSet;
import java.util.Set;

import static javax.persistence.FetchType.LAZY;
import static javax.persistence.GenerationType.SEQUENCE;

@AllArgsConstructor
@Getter
@Setter
@Entity
@NoArgsConstructor
@Builder
@Table(name = "readings")
public class Reading extends Auditable<String> {

    @Id
    @GeneratedValue(strategy = SEQUENCE, generator = "READING_SEQUENCE")
    @SequenceGenerator(sequenceName = "READING_SEQUENCE", allocationSize = 1, name = "READING_SEQUENCE")
    @Column(name = "id", nullable = false, updatable = false)
    private Long id;

    private String name;

    private String time;

    @Enumerated(EnumType.STRING)
    private Status status;

    @ManyToMany(fetch = LAZY)
    @JoinTable(name = "reading_passages",
            joinColumns = {@JoinColumn(name = "reading_id", referencedColumnName = "id")},
            inverseJoinColumns = {@JoinColumn(name = "passage_id", referencedColumnName = "id")})
    private Set<Passage> passages = new HashSet<>();

}
