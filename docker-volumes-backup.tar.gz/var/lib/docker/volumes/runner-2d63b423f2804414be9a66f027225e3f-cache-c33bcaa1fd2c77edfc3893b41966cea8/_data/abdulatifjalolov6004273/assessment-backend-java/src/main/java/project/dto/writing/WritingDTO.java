package project.dto.writing;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import project.model.entity.writing.Writing;
import project.repository.QuestionsRepository;

import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class WritingDTO {

    private Long id;

    private String name;

    private Set<WritingPartsDTO> writingParts;

    private List<Long> writingPartIds;

    private String time;

    public WritingDTO(Writing writing, QuestionsRepository questionsRepository) {
        setId(writing.getId());
        setTime(writing.getTime());
        setName(writing.getName());
        setWritingParts(writing.getWritingParts().stream().map((a) -> new WritingPartsDTO(a, questionsRepository)).collect(Collectors.toSet()));
    }
    public WritingDTO(Writing writing) {
        setId(writing.getId());
        setTime(writing.getTime());
        setName(writing.getName());
    }

}
