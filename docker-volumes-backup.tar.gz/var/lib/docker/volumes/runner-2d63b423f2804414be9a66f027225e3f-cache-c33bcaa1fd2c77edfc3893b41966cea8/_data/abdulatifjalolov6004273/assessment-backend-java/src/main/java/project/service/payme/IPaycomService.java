package project.service.payme;

import net.minidev.json.JSONObject;
import project.model.payme.json.PaycomRequestForm;

public interface IPaycomService {

    JSONObject payWithPaycom(PaycomRequestForm requestForm, String auth);

}