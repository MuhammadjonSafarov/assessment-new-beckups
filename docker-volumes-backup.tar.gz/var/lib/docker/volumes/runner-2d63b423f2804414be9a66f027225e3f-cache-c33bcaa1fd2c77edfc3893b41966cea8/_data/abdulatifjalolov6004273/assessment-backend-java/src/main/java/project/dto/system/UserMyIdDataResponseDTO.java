package project.dto.system;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.*;
import project.dto.UserApplicationDTO;
import project.model.entity.UserApplication;
import project.model.entity.system.UserMyIdData;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class UserMyIdDataResponseDTO {

    private Long id;

    private JsonNode myIdData;

    private UserDTO userDto;

    private UserApplicationDTO userApplicationDTO;

    public UserMyIdDataResponseDTO(UserMyIdData userMyIdData, ObjectMapper objectMapper, UserApplication userApplication) throws JsonProcessingException {
        setId(userMyIdData.getId());
        setUserDto(new UserDTO(userMyIdData.getUser()));
        setMyIdData(objectMapper.readTree(userMyIdData.getMyIdData()));
        if (userApplication != null)
            setUserApplicationDTO(new UserApplicationDTO(userApplication));
    }
}
