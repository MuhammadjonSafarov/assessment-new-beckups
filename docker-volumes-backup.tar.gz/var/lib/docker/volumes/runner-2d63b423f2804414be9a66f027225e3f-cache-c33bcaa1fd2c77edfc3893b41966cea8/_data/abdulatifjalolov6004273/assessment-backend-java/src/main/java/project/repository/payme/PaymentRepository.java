package project.repository.payme;

import org.springframework.data.jpa.repository.JpaRepository;
import project.model.payme.Payment;

import java.util.Optional;

public interface PaymentRepository extends JpaRepository<Payment, Long> {

    Optional<Payment> findFirstByOrderTransactionIdOrderByPayDateDesc(Long orderTransactionId);


}
