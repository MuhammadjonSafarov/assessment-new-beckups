package project.service;

import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import project.dto.ResponseDto;
import project.dto.SessionDTO;
import project.exception.RecordNotFoundException;
import project.model.Pagination;
import project.model.entity.Questions;
import project.model.entity.Session;
import project.model.entity.listening.Audios;
import project.model.entity.reading.Passage;
import project.model.entity.speaking.SpeakingParts;
import project.model.entity.system.User;
import project.model.entity.writing.WritingParts;
import project.model.enums.ExamType;
import project.model.enums.Status;
import project.repository.PavilionRepository;
import project.repository.QuestionsRepository;
import project.repository.SessionRepository;
import project.repository.TestTypeRepository;
import project.repository.listening.ListeningRepository;
import project.repository.reading.ReadingRepository;
import project.repository.speaking.SpeakingPartsRepository;
import project.repository.speaking.SpeakingRepository;
import project.repository.system.UserRepository;
import project.repository.writing.WritingRepository;
import project.utility.PageWrapper;
import project.utility.Search;
import project.utility.SearchSession;
import project.utility.Utils;

import javax.transaction.Transactional;
import java.text.ParseException;
import java.util.List;

@Service
@RequiredArgsConstructor
public class SessionService {

    private final SessionRepository sessionRepository;
    private final PavilionRepository pavilionRepository;
    private final TestTypeRepository testTypeRepository;
    private final UserRepository userRepository;
    private final ListeningRepository listeningRepository;
    private final ReadingRepository readingRepository;
    private final WritingRepository writingRepository;
    private final SpeakingRepository speakingRepository;
    private final ComputerService computerService;
    private final QuestionsRepository questionsRepository;
    private final SpeakingPartsRepository speakingPartsRepository;

    @Transactional
    public ResponseEntity<?> create(SessionDTO sessionDto) throws ParseException {
        Session session = sessionRepository.save(
                Session.builder()
                        .pavilion(sessionDto.getPavilionId() != null ? pavilionRepository.findById(sessionDto.getPavilionId()).orElse(null) : null)
                        .testType(sessionDto.getTestTypeId() != null ? testTypeRepository.findById(sessionDto.getTestTypeId()).orElse(null) : null)
                        .examFormat(sessionDto.getExamFormat())
                        .cost(sessionDto.getCost())
                        .examType(sessionDto.getExamType())
                        .status(Status.ACTIVE)
                        .listeningScore(sessionDto.getListeningScore())
                        .speakingScore(sessionDto.getSpeakingScore())
                        .writingScore(sessionDto.getWritingScore())
                        .readingScore(sessionDto.getReadingScore())
                        .listening(sessionDto.getListeningId() != null ? listeningRepository.findById(sessionDto.getListeningId()).orElse(null) : null)
                        .reading(sessionDto.getReadingId() != null ? readingRepository.findById(sessionDto.getReadingId()).orElse(null) : null)
                        .writing(sessionDto.getWritingId() != null ? writingRepository.findById(sessionDto.getWritingId()).orElse(null) : null)
                        .speaking(sessionDto.getSpeakingId() != null ? speakingRepository.findById(sessionDto.getSpeakingId()).orElse(null) : null)
                        .maxCountCandidate(sessionDto.getMaxCountCandidate())
                        .startDate(sessionDto.getStartDate())
                        .build()
        );
        if (session.getListening() != null && session.getReading() != null && session.getWriting() != null && session.getSpeaking() != null)
            calculateQuestionScores(session);
        computerService.createPavilionDefaultComputers(session);
        return ResponseEntity.ok(new SessionDTO(session));
    }

    private void calculateQuestionScores(Session session) {
        for (Audios audio : session.getListening().getAudios()) {
            for (Questions question : questionsRepository.finAllByAudio(audio.getId())) {
                if (question.getCoefficient() != null && session.getListeningScore() != null) {
                    question.setScore(session.getListeningScore() * question.getCoefficient());
                    questionsRepository.save(question);
                }
            }
        }

        for (WritingParts writingPart : session.getWriting().getWritingParts()) {
            for (Questions questions : questionsRepository.finAllByWritingParts(writingPart.getId())) {
                if (questions.getCoefficient() != null && session.getWritingScore() != null) {
                    questions.setScore(session.getWritingScore() * questions.getCoefficient());
                    questionsRepository.save(questions);
                }
            }
        }

        for (Passage passage : session.getReading().getPassages()) {
            for (Questions questions : questionsRepository.finAllByPassage(passage.getId())) {
                if (questions.getCoefficient() != null && session.getReadingScore() != null) {
                    questions.setScore(session.getReadingScore() * questions.getCoefficient());
                    questionsRepository.save(questions);
                }
            }
        }

        for (SpeakingParts speakingPart : session.getSpeaking().getSpeakingParts()) {
            if (speakingPart.getCoefficient() != null && session.getSpeakingScore() != null) {
                speakingPart.setScore(session.getSpeakingScore() * speakingPart.getCoefficient());
                speakingPartsRepository.save(speakingPart);
            }
        }

    }

    public ResponseEntity<?> update(SessionDTO sessionDto, Long id) throws ParseException {
        Session session = sessionRepository.findById(id).orElseThrow(
                () -> new RecordNotFoundException("Not found")
        );
        session.setPavilion(sessionDto.getPavilionId() != null ? pavilionRepository.findById(sessionDto.getPavilionId()).orElse(null) : null);
        session.setTestType(sessionDto.getTestTypeId() != null ? testTypeRepository.findById(sessionDto.getTestTypeId()).orElse(null) : null);
        session.setExamFormat(sessionDto.getExamFormat());
        session.setExamType(sessionDto.getExamType());
        session.setListeningScore(sessionDto.getListeningScore());
        session.setSpeakingScore(sessionDto.getSpeakingScore());
        session.setWritingScore(sessionDto.getWritingScore());
        session.setReadingScore(sessionDto.getReadingScore());
        session.setListening(sessionDto.getListeningId() != null ? listeningRepository.findById(sessionDto.getListeningId()).orElse(null) : null);
        session.setSpeaking(sessionDto.getSpeakingId() != null ? speakingRepository.findById(sessionDto.getSpeakingId()).orElse(null) : null);
        session.setReading(sessionDto.getReadingId() != null ? readingRepository.findById(sessionDto.getReadingId()).orElse(null) : null);
        session.setWriting(sessionDto.getWritingId() != null ? writingRepository.findById(sessionDto.getWritingId()).orElse(null) : null);
        session.setMaxCountCandidate(sessionDto.getMaxCountCandidate());
        session.setStartDate(sessionDto.getStartDate());
        session.setCost(sessionDto.getCost());
        return ResponseEntity.ok(
                new SessionDTO(sessionRepository.save(session))
        );
    }

    public ResponseEntity<?> delete(Long id) {
        Session session = sessionRepository.findById(id).orElseThrow(
                () -> new RecordNotFoundException("Not found")
        );
        session.setStatus(Status.DELETED);
        sessionRepository.save(session);
        return ResponseEntity.ok("SUCCESS");
    }

    public ResponseEntity<?> get(Long id) throws ParseException {
        Session session = sessionRepository.findById(id).orElseThrow(
                () -> new RecordNotFoundException("Not found")
        );
        return ResponseEntity.ok(
                new SessionDTO(session)
        );
    }

    public ResponseEntity<ResponseDto<PageWrapper>> search(Pagination<SearchSession> pagination) throws ParseException {
        List<ExamType> examTypes = pagination.getSearch().getExamTypes();
        Page<Session> sessionPage;
        if (pagination.getSearch().getValue() != null && !pagination.getSearch().getValue().isEmpty()) {
            sessionPage = search(examTypes, pagination.getSearch().getValue().toLowerCase(), pagination);
        } else {
            sessionPage = search(examTypes, "", pagination);
        }
        List<SessionDTO> sessionDtos = sessionPage.stream().map(SessionDTO::new).toList();
        return ResponseEntity.ok(new ResponseDto<>(ResponseDto.States.SUCCESS, HttpStatus.OK, 200, null, PageWrapper.builder().list(sessionDtos).total(sessionPage.getTotalElements()).build()));
    }

    public Page<Session> search(List<ExamType> examTypes, String value, Pagination<SearchSession> pagination) {
        if (examTypes == null || examTypes.isEmpty())
            examTypes = List.of(ExamType.EXAM, ExamType.RETAKE);
        Pageable paging = Utils.getPageableFromPagination(pagination);
        Page<Session> pagedResult;
        if (!value.isEmpty()) {
            pagedResult = sessionRepository.findAllBySearch(value, examTypes, paging);
        } else {
            pagedResult = sessionRepository.findAllSessions(examTypes, paging);
        }
        return pagedResult;
    }

    public ResponseEntity<ResponseDto<PageWrapper>> search(Long userId, Pagination<Search> pagination) throws ParseException {
        Page<Session> sessionPage;
        if (pagination.getSearch().getValue() != null && !pagination.getSearch().getValue().isEmpty()) {
            sessionPage = search(userId, pagination.getSearch().getValue().toLowerCase(), pagination);
        } else {
            sessionPage = search(userId, "", pagination);
        }
        List<SessionDTO> sessionDtos = sessionPage.stream().map(SessionDTO::new).toList();
        return ResponseEntity.ok(new ResponseDto<>(ResponseDto.States.SUCCESS, HttpStatus.OK, 200, null, PageWrapper.builder().list(sessionDtos).total(sessionPage.getTotalElements()).build()));
    }

    public Page<Session> search(Long userId, String value, Pagination<Search> pagination) {
        Pageable paging = Utils.getPageableFromPagination(pagination);
        User user = userRepository.findByIdActive(userId);
        if (user == null)
            throw new RecordNotFoundException("User not found with id " + userId);
        Page<Session> pagedResult;
        if (!value.isEmpty()) {
            pagedResult = sessionRepository.findAllBySearch(user, value, paging);
        } else {
            pagedResult = sessionRepository.findAllSessions(user, paging);
        }
        return pagedResult;
    }

    public ResponseEntity<?> getByTestTypeAndPavilion(Long testTypeId, Long pavilionId, String examType) {
        List<SessionDTO> sessionDTOS = sessionRepository.findByTestTypeAndPavilion(testTypeId, pavilionId, ExamType.valueOf(examType))
                .stream().map(SessionDTO::new).toList();
        return ResponseEntity.ok(sessionDTOS);
    }
}
