package project.repository.writing;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.data.repository.query.QueryByExampleExecutor;
import project.model.entity.writing.Writing;

import java.util.Optional;

public interface WritingRepository extends JpaRepository<Writing, Long>, PagingAndSortingRepository<Writing, Long>, QueryByExampleExecutor<Writing> {

    @Query("select q from Writing q where q.status = 'ACTIVE' and q.name = ?1 ")
    Optional<Writing> findByName(String name);

    @Query("select p from Writing p where p.status = 'ACTIVE' and p.name like %?1% order by p.id ")
    Page<Writing> findAllBySearch(String value, Pageable pageable);

    @Query("select p from Writing p where p.status = 'ACTIVE' order by p.id ")
    Page<Writing> findAllWriting(Pageable pageable);

}
