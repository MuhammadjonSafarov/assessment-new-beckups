package project.repository.payme;

import org.springframework.data.jpa.repository.JpaRepository;
import project.model.payme.Order;

public interface OrderRepository extends JpaRepository<Order, Long> {

}