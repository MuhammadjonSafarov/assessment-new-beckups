package project.model.entity.system;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.*;
import project.dto.system.PermissionDto;
import project.model.Auditable;
import project.model.enums.Status;
import project.model.enums.Type;

import javax.persistence.*;
import java.util.HashSet;
import java.util.Set;

import static javax.persistence.EnumType.STRING;
import static javax.persistence.GenerationType.SEQUENCE;

@Entity
@Getter
@Setter
@NoArgsConstructor
@Builder
@AllArgsConstructor
@Table(name = "sys_permissions")
public class Permission extends Auditable<String> {

    @Id
    @GeneratedValue(strategy = SEQUENCE, generator = "PERMISSION_SEQUENCE")
    @SequenceGenerator(sequenceName = "PERMISSION_SEQUENCE", allocationSize = 1, name = "PERMISSION_SEQUENCE")
    @Column(name = "id", nullable = false, updatable = false)
    private Long id;

    @Column(name = "name")
    private String name;

    @Enumerated(STRING)
    @Column(name = "type")
    private Type type;

    @Enumerated(STRING)
    @Column(name = "status")
    private Status status;

    @ManyToMany(mappedBy = "permissions")
    @JsonIgnore
    private Set<Role> roles = new HashSet<>();

    @JsonIgnore
    public static Permission of(Permission permission, PermissionDto permissionDto) {
        permission.setName(permissionDto.getName());
        return permission;
    }
}
