package project.service.reading;

import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import project.dto.ResponseDto;
import project.dto.reading.PassageDTO;
import project.exception.RecordBadRequestException;
import project.exception.RecordNotFoundException;
import project.model.Pagination;
import project.model.entity.Questions;
import project.model.entity.reading.Passage;
import project.model.enums.Status;
import project.repository.FileRepository;
import project.repository.QuestionsRepository;
import project.repository.reading.PassageRepository;
import project.utility.PageWrapper;
import project.utility.Search;
import project.utility.Utils;

import java.util.HashSet;
import java.util.List;

@RequiredArgsConstructor
@Service
public class PassageService {

    private final PassageRepository passagesRepository;
    private final QuestionsRepository questionsRepository;
    private final FileRepository fileRepository;

    public ResponseEntity<?> create(PassageDTO passagesDTO) {
        passagesRepository.findByName(passagesDTO.getName()).ifPresent((answer) -> {
            throw new RecordBadRequestException("Passage already exists with " + passagesDTO.getName());
        });
        Passage passages = passagesRepository.save(
                Passage.builder()
                        .status(Status.ACTIVE)
                        .isParent(passagesDTO.getIsParent())
                        .name(passagesDTO.getName())
                        .body(passagesDTO.getBody())
                        .innerTextType(passagesDTO.getInnerTextType() != null ? passagesDTO.getInnerTextType() : null)
//                        .beginIndex(passagesDTO.getBeginIndex())
//                        .endIndex(passagesDTO.getEndIndex())
//                        .startIndex1(passagesDTO.getStartIndex1())
//                        .startIndex2(passagesDTO.getStartIndex2())
//                        .startIndex3(passagesDTO.getStartIndex3())
//                        .startIndex4(passagesDTO.getStartIndex4())
                        .file(passagesDTO.getFileId() != null ? fileRepository.findById(passagesDTO.getFileId()).orElse(null) : null)
                        .orderNumber(passagesDTO.getOrderNumber())
                        .children(passagesDTO.getChildrenIds() != null ? new HashSet<>(passagesRepository.findAllById(passagesDTO.getChildrenIds())) : new HashSet<>())
                        .build());
        if (passagesDTO.getQuestionIds() != null && !passagesDTO.getQuestionIds().isEmpty()) {
            passagesDTO.getQuestionIds().forEach((questionId) -> questionsRepository.findById(questionId).ifPresent((questions) -> {
                questions.setPassages(passages);
                questionsRepository.save(questions);
            }));
        }
        return ResponseEntity.ok(new PassageDTO(passagesRepository.save(passages), questionsRepository));
    }


    public ResponseEntity<?> update(Long id, PassageDTO passagesDTO) {
        Passage passages = passagesRepository.findById(id).orElseThrow(() -> new RecordNotFoundException("Passage not found with id " + id));
        if (!passages.getName().equals(passagesDTO.getName())) {
            passagesRepository.findByName(passagesDTO.getName()).ifPresent((audio) -> {
                throw new RecordBadRequestException("Passage already exists with " + passagesDTO.getName());
            });
        }
        passages.setName(passagesDTO.getName());
        passages.setBody(passagesDTO.getBody());
        passages.setInnerTextType(passagesDTO.getInnerTextType() != null ? passagesDTO.getInnerTextType() : null);
//        passages.setBeginIndex(passagesDTO.getBeginIndex());
//        passages.setEndIndex(passagesDTO.getEndIndex());
//        passages.setStartIndex1(passagesDTO.getStartIndex1());
//        passages.setStartIndex2(passagesDTO.getStartIndex2());
//        passages.setStartIndex3(passagesDTO.getStartIndex3());
//        passages.setStartIndex4(passagesDTO.getStartIndex4());
        passages.setChildren(passagesDTO.getChildrenIds() != null ? new HashSet<>(passagesRepository.findAllById(passagesDTO.getChildrenIds())) : new HashSet<>());
        passages.setOrderNumber(passagesDTO.getOrderNumber());
        passages.setFile(passagesDTO.getFileId() != null ? fileRepository.findById(passagesDTO.getFileId()).orElse(null) : null);
        for (Questions questions : questionsRepository.finAllByPassage(passages.getId())) {
            questions.setPassages(null);
            questionsRepository.save(questions);
        }

        if (passagesDTO.getQuestionIds() != null && !passagesDTO.getQuestionIds().isEmpty()) {
            passagesDTO.getQuestionIds().forEach((questionId) -> questionsRepository.findById(questionId).ifPresent((questions) -> {
                questions.setPassages(passages);
                questionsRepository.save(questions);
            }));
        }
        return ResponseEntity.ok(new PassageDTO(passagesRepository.save(passages), questionsRepository));

    }

    public ResponseEntity<?> get(Long id) {
        Passage questions = passagesRepository.findById(id).orElseThrow(() -> new RecordNotFoundException("Passage not found with id " + id));
        return ResponseEntity.ok((new PassageDTO(passagesRepository.save(questions), questionsRepository)));
    }

    public ResponseEntity<ResponseDto<PageWrapper>> search(Pagination<Search> pagination, Boolean isParent) {
        Page<Passage> passagesPage;
        if (pagination.getSearch().getValue() != null && !pagination.getSearch().getValue().isEmpty()) {
            passagesPage = search(isParent, pagination.getSearch().getValue().toLowerCase(), pagination);
        } else {
            passagesPage = search(isParent, "", pagination);
        }
        List<PassageDTO> passagesDTOs = passagesPage.stream()
                .map(question -> new PassageDTO(question, questionsRepository))
                .toList();
        return ResponseEntity.ok(new ResponseDto<>(ResponseDto.States.SUCCESS, HttpStatus.OK, 200, null, PageWrapper.builder().list(passagesDTOs).total(passagesPage.getTotalElements()).build()));
    }

    public Page<Passage> search(Boolean isParent, String value, Pagination<Search> pagination) {
        Pageable paging = Utils.getPageableFromPagination(pagination);
        Page<Passage> pagedResult;
        if (!value.isEmpty()) {
            pagedResult = passagesRepository.findAllBySearch(value, isParent, paging);
        } else {
            pagedResult = passagesRepository.findAllPassage(isParent, paging);
        }
        return pagedResult;
    }

    public ResponseEntity<?> delete(Long id) {
        Passage questions = passagesRepository.findById(id).orElseThrow(() -> new RecordNotFoundException("Passage not found with id " + id));
        questions.setStatus(Status.DELETED);
        passagesRepository.save(questions);
        return ResponseEntity.ok("SUCCESS");
    }

}
