package project.model.payme.json;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class AdditionalInfo {

    private Long orderId;

    private Integer orderSum;

    private String site = "test.assessmenttest.uz";

    public AdditionalInfo(Long orderId, Integer orderSum) {
        this.orderId = orderId;
        this.orderSum = orderSum;
    }
}
