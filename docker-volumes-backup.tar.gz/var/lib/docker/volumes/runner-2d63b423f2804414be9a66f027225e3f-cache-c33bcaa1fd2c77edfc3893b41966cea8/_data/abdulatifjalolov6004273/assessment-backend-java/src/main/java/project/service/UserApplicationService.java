package project.service;

import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import project.dto.*;
import project.exception.RecordBadRequestException;
import project.exception.RecordNotFoundException;
import project.model.Pagination;
import project.model.entity.File;
import project.model.entity.Session;
import project.model.entity.UserApplication;
import project.model.entity.UserApplicationAnswer;
import project.model.entity.system.User;
import project.model.enums.MyIdStatus;
import project.model.enums.PaymentStatus;
import project.repository.*;
import project.repository.speaking.SpeakingPartsRepository;
import project.repository.system.UserRepository;
import project.utility.PageWrapper;
import project.utility.Search;
import project.utility.Utils;

import javax.transaction.Transactional;
import java.text.SimpleDateFormat;
import java.util.*;

@Service
@RequiredArgsConstructor
public class UserApplicationService {

    private final UserApplicationRepository userApplicationRepository;
    private final UserRepository userRepository;
    private final SessionRepository sessionRepository;
    private final UserApplicationAnswerRepository userApplicationAnswerRepository;
    private final QuestionsRepository questionsRepository;

    private final FileRepository fileRepository;
    private final SpeakingPartsRepository speakingPartsRepository;


    public ResponseEntity<?> crete(UserApplicationDTO userApplicationDTO) {
        userApplicationRepository.findByUserAndSessionAndPaymentStatus(userApplicationDTO.getUserId(), userApplicationDTO.getSessionId())
                .ifPresent((ua) -> {
                    throw new RecordBadRequestException("UserApplication already exists");
                });
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(new Date());
        calendar.add(Calendar.HOUR, 5);
        return ResponseEntity.ok(
                new UserApplicationDTO(
                        userApplicationRepository.save(
                                UserApplication.builder()
                                        .user(userApplicationDTO.getUserId() != null ? userRepository.findByIdActive(userApplicationDTO.getUserId()) : null)
                                        .tempSessionId(userApplicationDTO.getSessionId())
                                        .createdDate(new SimpleDateFormat("dd-MM-yyyy hh:mm:ss").format(new Date()))
                                        .paymentTermDate(new SimpleDateFormat("dd-MM-yyyy hh:mm:ss").format(calendar.getTime()))
                                        .paymentStatus(PaymentStatus.UNPAID)
                                        .myIdStatus(MyIdStatus.REJECTED)
                                        .build()
                        )
                )
        );
    }

    public ResponseEntity<?> payApplication(Long applicationId) {
        UserApplication userApplication =
                userApplicationRepository.findByIdAndPaymentStatus(applicationId).orElseThrow(
                        () -> new RecordNotFoundException("UNPAID UserApplication not found with id " + applicationId)
                );
        userApplication.setPaymentStatus(PaymentStatus.PAID);
        userApplication.setSession(userApplication.getTempSessionId() != null ? sessionRepository.findById(userApplication.getTempSessionId()).orElse(null) : null);
        Session session = userApplication.getSession();
        if (session != null) {
            List<User> users = session.getUsers();
            users.add(userApplication.getUser());
            session.setUsers(users);
            sessionRepository.save(session);
        }
        return ResponseEntity.ok(
                new UserApplicationDTO(userApplicationRepository.save(userApplication))
        );
    }

    public ResponseEntity<?> get(Long id) {
        UserApplication userApplication =
                userApplicationRepository.findById(id).orElseThrow(() -> new RecordNotFoundException("UserApplication not found with id " + id));
        UserApplicationDTO userApplicationDTO = new UserApplicationDTO(userApplication, questionsRepository);
        userApplicationDTO.setSession(new SessionDTO(sessionRepository.findById(userApplicationDTO.getTempSessionId()).orElse(null)));
        return ResponseEntity.ok(userApplicationDTO);
    }


    public ResponseEntity<ResponseDto<PageWrapper>> search(Long userId, Pagination<Search> pagination) {
        Page<UserApplication> applicationPage;
        if (pagination.getSearch().getValue() != null && !pagination.getSearch().getValue().isEmpty()) {
            applicationPage = search(userId, pagination.getSearch().getValue().toLowerCase(), pagination);
        } else {
            applicationPage = search(userId, "", pagination);
        }
        List<UserApplicationDTO> userApplicationDTOS = new ArrayList<>();
        for (UserApplication userApplication : applicationPage.getContent()) {
            userApplicationDTOS.add(new UserApplicationDTO(userApplication, questionsRepository));
        }
        return ResponseEntity.ok(new ResponseDto<>(ResponseDto.States.SUCCESS, HttpStatus.OK, 200, null, PageWrapper.builder().list(userApplicationDTOS).total(applicationPage.getTotalElements()).build()));
    }

    public Page<UserApplication> search(Long userId, String value, Pagination<Search> pagination) {
        Pageable paging = Utils.getPageableFromPagination(pagination);
        Page<UserApplication> pagedResult;
        if (!value.isEmpty()) {
            pagedResult = userApplicationRepository.findAllBySearch(userId, PaymentStatus.valueOf(value.toUpperCase()), paging);
        } else {
            pagedResult = userApplicationRepository.findAllTestTypes(userId, paging);
        }
        return pagedResult;
    }


    @Scheduled(fixedRate = 15 * 60 * 1000)
    public void checkUnpaid() {
        for (UserApplication userApplication : userApplicationRepository.findAllByTermOfDateAndPaymentStatus(PaymentStatus.UNPAID)) {
            userApplication.setPaymentStatus(PaymentStatus.OUT_OF_TERM_DATE);
            userApplicationRepository.save(userApplication);
        }
    }

    @Transactional
    public ResponseEntity<?> attachListeningAnswers(Long id, List<UserApplicationAnswerRequestDTO> answers) {
        UserApplication userApplication = userApplicationRepository.findById(id).orElseThrow(() -> new RecordNotFoundException("UserApplication not found with id " + id));
        Set<UserApplicationAnswer> applicationAnswers = new HashSet<>();
        for (UserApplicationAnswerRequestDTO answer : answers) {
            applicationAnswers.add(
                    userApplicationAnswerRepository.save(
                            UserApplicationAnswer.builder()
                                    .questionId(answer.getQuestionId())
                                    .answers(answer.getAnswers())
                                    .listeningApplications(Set.of(userApplication))
                                    .build()
                    )
            );

        }
        userApplication.setListeningAnswers(applicationAnswers);
        return ResponseEntity.ok(new UserApplicationDTO(userApplicationRepository.save(userApplication)));
    }

    @Transactional
    public ResponseEntity<?> attachSpeakingAnswers(Long id, List<UserApplicationAnswerRequestDTO> answers) {
        UserApplication userApplication = userApplicationRepository.findById(id).orElseThrow(() -> new RecordNotFoundException("UserApplication not found with id " + id));
        Set<UserApplicationAnswer> applicationAnswers = new HashSet<>();
        for (UserApplicationAnswerRequestDTO answer : answers) {
            applicationAnswers.add(
                    userApplicationAnswerRepository.save(
                            UserApplicationAnswer.builder()
                                    .speakingPart(answer.getSpeakingPartId() != null ? speakingPartsRepository.findById(answer.getSpeakingPartId()).orElse(null) : null)
                                    .speakingAnswerFile(answer.getSpeakingAnswerFileId() != null ? fileRepository.findById(answer.getSpeakingAnswerFileId()).orElse(null) : null)
                                    .speakingApplications(Set.of(userApplication))
                                    .build()
                    )
            );

        }
        userApplication.setSpeakingAnswers(applicationAnswers);
        return ResponseEntity.ok(new UserApplicationDTO(userApplicationRepository.save(userApplication)));
    }

    @Transactional
    public ResponseEntity<?> attachReadingAnswers(Long id, List<UserApplicationAnswerRequestDTO> answers) {
        UserApplication userApplication = userApplicationRepository.findById(id).orElseThrow(() -> new RecordNotFoundException("UserApplication not found with id " + id));
        Set<UserApplicationAnswer> applicationAnswers = new HashSet<>();
        for (UserApplicationAnswerRequestDTO answer : answers) {
            applicationAnswers.add(
                    userApplicationAnswerRepository.save(
                            UserApplicationAnswer.builder()
                                    .questionId(answer.getQuestionId())
                                    .answers(answer.getAnswers())
                                    .readingApplications(Set.of(userApplication))
                                    .build()
                    )
            );

        }
        userApplication.setReadingAnswers(applicationAnswers);
        return ResponseEntity.ok(new UserApplicationDTO(userApplicationRepository.save(userApplication)));
    }

    @Transactional
    public ResponseEntity<?> attachWritingAnswers(Long id, List<UserApplicationAnswerRequestDTO> answers) {
        UserApplication userApplication = userApplicationRepository.findById(id).orElseThrow(() -> new RecordNotFoundException("UserApplication not found with id " + id));
        Set<UserApplicationAnswer> applicationAnswers = new HashSet<>();
        for (UserApplicationAnswerRequestDTO answer : answers) {
            applicationAnswers.add(
                    userApplicationAnswerRepository.save(
                            UserApplicationAnswer.builder()
                                    .questionId(answer.getQuestionId())
                                    .body(answer.getBody())
                                    .writingApplications(Set.of(userApplication))
                                    .build()
                    )
            );

        }
        userApplication.setWritingAnswers(applicationAnswers);
        return ResponseEntity.ok(new UserApplicationDTO(userApplicationRepository.save(userApplication)));
    }

    public ResponseEntity<?> attachListeningDegree(Long id, String listeningDegree) {
        UserApplication userApplication = userApplicationRepository.findById(id).orElseThrow(() -> new RecordNotFoundException("UserApplication not found with id " + id));
        userApplication.setListeningDegree(listeningDegree);
        return ResponseEntity.ok(new UserApplicationDTO(userApplicationRepository.save(userApplication)));
    }

    public ResponseEntity<?> attachReadingDegree(Long id, String readingDegree) {
        UserApplication userApplication = userApplicationRepository.findById(id).orElseThrow(() -> new RecordNotFoundException("UserApplication not found with id " + id));
        userApplication.setReadingDegree(readingDegree);
        return ResponseEntity.ok(new UserApplicationDTO(userApplicationRepository.save(userApplication)));
    }


    public ResponseEntity<?> attachSpeakingDegree(Long id, String speakingDegree) {
        UserApplication userApplication = userApplicationRepository.findById(id).orElseThrow(() -> new RecordNotFoundException("UserApplication not found with id " + id));
        userApplication.setSpeakingDegree(speakingDegree);
        return ResponseEntity.ok(new UserApplicationDTO(userApplicationRepository.save(userApplication)));
    }

    public ResponseEntity<?> attachWritingDegree(Long id, String readingDegree) {
        UserApplication userApplication = userApplicationRepository.findById(id).orElseThrow(() -> new RecordNotFoundException("UserApplication not found with id " + id));
        userApplication.setWritingDegree(readingDegree);
        return ResponseEntity.ok(new UserApplicationDTO(userApplicationRepository.save(userApplication)));
    }

    public ResponseEntity<?> attachDegree(Long id, String degree) {
        UserApplication userApplication = userApplicationRepository.findById(id).orElseThrow(() -> new RecordNotFoundException("UserApplication not found with id " + id));
        userApplication.setDegree(degree);
        return ResponseEntity.ok(new UserApplicationDTO(userApplicationRepository.save(userApplication)));
    }

    public ResponseEntity<?> attachCertificateFile(Long id, Long fileId) {
        UserApplication userApplication = userApplicationRepository.findById(id).orElseThrow(() -> new RecordNotFoundException("UserApplication not found with id " + id));
        File file = fileRepository.findById(fileId).orElseThrow(() -> new RecordNotFoundException("File not found with id " + fileId));
        userApplication.setCertificateFile(file);
        return ResponseEntity.ok(new UserApplicationDTO(userApplicationRepository.save(userApplication)));
    }

    public ResponseEntity<ResponseDto<PageWrapper>> listCertificates(Long userId, Pagination<Search> pagination) {
        Page<FileDto> certificatesPage;
        if (pagination.getSearch().getValue() != null && !pagination.getSearch().getValue().isEmpty()) {
            certificatesPage = listCertificates(userId, pagination.getSearch().getValue().toLowerCase(), pagination);
        } else {
            certificatesPage = listCertificates(userId, "", pagination);
        }
        return ResponseEntity.ok(new ResponseDto<>(ResponseDto.States.SUCCESS, HttpStatus.OK, 200, null, PageWrapper.builder().list(certificatesPage.getContent()).total(certificatesPage.getTotalElements()).build()));
    }

    public Page<FileDto> listCertificates(Long userId, String value, Pagination<Search> pagination) {
        Pageable paging = Utils.getPageableFromPagination(pagination);
        Page<FileDto> pagedResult;
        if (!value.isEmpty()) {
            pagedResult = userApplicationRepository.findAllCertificatesBySearch(userId, paging);
        } else {
            pagedResult = userApplicationRepository.findAllCertificates(userId, paging);
        }
        return pagedResult;
    }

    public ResponseEntity<?> changeMyIdStatus(Long id) {
        UserApplication userApplication = userApplicationRepository.findById(id).orElseThrow(() -> new RecordNotFoundException("UserApplication not found with id " + id));
        if (userApplication.getMyIdStatusOfUser() == null) {
            userApplication.setMyIdStatusOfUser(false);
            return ResponseEntity.ok(new UserApplicationDTO(userApplicationRepository.save(userApplication)));
        }
        userApplication.setMyIdStatusOfUser(!userApplication.getMyIdStatusOfUser());
        return ResponseEntity.ok(new UserApplicationDTO(userApplicationRepository.save(userApplication)));
    }
}
