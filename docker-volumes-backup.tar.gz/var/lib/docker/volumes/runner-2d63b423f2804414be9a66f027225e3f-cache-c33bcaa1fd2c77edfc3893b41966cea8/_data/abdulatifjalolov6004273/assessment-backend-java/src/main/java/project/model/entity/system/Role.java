package project.model.entity.system;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.*;
import project.dto.system.RoleDto;
import project.model.Auditable;
import project.model.enums.Type;
import project.model.enums.Status;

import javax.persistence.*;
import java.util.*;

import static javax.persistence.EnumType.STRING;
import static javax.persistence.FetchType.LAZY;
import static javax.persistence.GenerationType.SEQUENCE;

/**
 * Simple domain object that represents application user's role - ADMIN, USER, etc.
 */

@Getter
@Setter
@Entity
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Table(name = "sys_roles")
public class Role extends Auditable<String> {

    @Id
    @GeneratedValue(strategy = SEQUENCE, generator = "ROLE_SEQUENCE")
    @SequenceGenerator(sequenceName = "ROLE_SEQUENCE", allocationSize = 1, name = "ROLE_SEQUENCE")
    @Column(name = "id", nullable = false, updatable = false)
    private Long id;

    @Column(name = "name")
    private String name;

    @Column(name = "description")
    private String description;

    @Column(name = "code", unique = true)
    private String code;

    @Enumerated(STRING)
    @Column(name = "status")
    private Status status;

    @Enumerated(STRING)
    @Column(name = "type")
    private Type type;

    @Column(name = "is_get_all_permissions")
    private Boolean isGetAllPermissions;

    @ManyToMany(fetch = LAZY)
    @JoinTable(name = "role_permissions",
            joinColumns = {@JoinColumn(name = "role_id", referencedColumnName = "id")},
            inverseJoinColumns = {@JoinColumn(name = "permission_id", referencedColumnName = "id")})
    private Set<Permission> permissions = new HashSet<>();

    @ManyToMany(mappedBy = "roles")
    @JsonIgnore
    private List<User> users = new ArrayList<>();

    @JsonIgnore
    public static Role of(Role role, RoleDto roleDto) {
        role.setName(roleDto.getName());
        role.setDescription(roleDto.getDescription());
        role.setCode("ROLE_" + roleDto.getName().toUpperCase());
        role.setIsGetAllPermissions(roleDto.getIsGetAllPermissions());
        return role;
    }
}
