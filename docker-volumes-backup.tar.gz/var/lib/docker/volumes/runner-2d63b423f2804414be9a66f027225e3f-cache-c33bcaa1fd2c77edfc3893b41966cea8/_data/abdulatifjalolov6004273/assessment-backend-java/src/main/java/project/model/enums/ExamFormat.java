package project.model.enums;

public enum ExamFormat {
    COMPUTER, WRITE
}
