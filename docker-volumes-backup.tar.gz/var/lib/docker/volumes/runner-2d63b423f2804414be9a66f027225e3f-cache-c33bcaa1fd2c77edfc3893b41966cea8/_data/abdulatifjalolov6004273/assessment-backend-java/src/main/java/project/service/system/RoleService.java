package project.service.system;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.validation.annotation.Validated;
import project.dto.ResponseDto;
import project.dto.system.RoleDto;
import project.exception.RecordBadRequestException;
import project.exception.RecordNotFoundException;
import project.model.Pagination;
import project.model.entity.system.Permission;
import project.model.entity.system.Role;
import project.model.enums.Type;
import project.model.enums.Status;
import project.repository.system.PermissionRepository;
import project.repository.system.RoleRepository;
import project.utility.PageWrapper;
import project.utility.Search;
import project.utility.Utils;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

@Service
@Slf4j
@Validated
@RequiredArgsConstructor
public class RoleService {

    private final RoleRepository roleRepository;
    private final PermissionRepository permissionRepository;

    public List<String> findPermissionNames(List<Long> roleIds) {
        return roleRepository.findPermissionNames(roleIds);
    }

    public ResponseEntity<?> create(RoleDto roleDto) {
        Role byName = roleRepository.findByName(roleDto.getName());
        if (byName != null) {
            throw new RecordBadRequestException("Role " + roleDto.getName() + " already exists");
        }
        Role role = RoleDto.of(roleDto);
        if (roleDto.getRoleType().equals(Type.ADMINISTRATOR.name()))
            role.setType(Type.ADMINISTRATOR);
        else
            role.setType(Type.MONITORING);

        Set<Permission> permissions = new HashSet<>();
        if (roleDto.getIsGetAllPermissions()) {
            permissions = permissionRepository.findAllActive();
        } else {
            if (roleDto.getPermissionIds() != null) {
                for (Long permissionId : roleDto.getPermissionIds()) {
                    permissionRepository.findByIdActive(permissionId)
                            .ifPresent(permissions::add);
                }
            }
        }
        role.setPermissions(permissions);

        return ResponseEntity.ok(
                new RoleDto(roleRepository.save(role))
        );
    }

    public ResponseEntity<?> update(RoleDto roleDto, Long id) {
        Role role = roleRepository.findByIdActive(id);
        if (role == null) {
            throw new RecordNotFoundException("Not found");
        }

        Role newRole = Role.of(role, roleDto);

        if (roleDto.getRoleType().equals(Type.ADMINISTRATOR.name()))
            newRole.setType(Type.ADMINISTRATOR);
        else
            newRole.setType(Type.MONITORING);

        Set<Permission> permissions = new HashSet<>();
        if (roleDto.getIsGetAllPermissions()) {
            permissions = permissionRepository.findAllActive();
        } else {
            if (roleDto.getPermissionIds() != null) {
                for (Long permissionId : roleDto.getPermissionIds()) {
                    permissionRepository.findByIdActive(permissionId)
                            .ifPresent(permissions::add);
                }
            }
        }
        newRole.setPermissions(permissions);

        return ResponseEntity.ok(
                new RoleDto(roleRepository.save(newRole))
        );
    }

    public ResponseEntity<?> delete(Long id) {
        Role role = roleRepository.findByIdActive(id);
        if (role == null) {
            throw new RecordNotFoundException("Not found");
        }
        role.setStatus(Status.DELETED);
        roleRepository.save(role);
        return ResponseEntity.ok("SUCCESS");
    }

    public ResponseEntity<?> get(Long id) {
        Role role = roleRepository.findByIdActive(id);
        if (role == null) {
            throw new RecordNotFoundException("Not found");
        }
        return ResponseEntity.ok(new RoleDto(role));
    }

    public ResponseEntity<ResponseDto<PageWrapper>> search(Pagination<Search> pagination) {
        Page<Role> rolePage;
        if (pagination.getSearch().getValue() != null && !pagination.getSearch().getValue().isEmpty()) {
            rolePage = search(pagination.getSearch().getValue().toLowerCase(), pagination);
        } else {
            rolePage = search("", pagination);
        }
        List<RoleDto> roleDtos = rolePage.getContent().stream().map(RoleDto::new).toList();
        return ResponseEntity.ok(new ResponseDto<>(ResponseDto.States.SUCCESS, HttpStatus.OK, 200, null, PageWrapper.builder().list(roleDtos).total(rolePage.getTotalElements()).build()));
    }

    public Page<Role> search(String value, Pagination<Search> pagination) {
        Pageable paging = Utils.getPageableFromPagination(pagination);
        Page<Role> pagedResult;
        if (!value.isEmpty()) {
            pagedResult = roleRepository.findAllBySearch(value, paging);
        } else {
            pagedResult = roleRepository.findAllRoles(paging);
        }
        return pagedResult;
    }

}
