package project.model.enums;

public enum ExamRunType {

    OUR, APPLICATION, WEB

}
