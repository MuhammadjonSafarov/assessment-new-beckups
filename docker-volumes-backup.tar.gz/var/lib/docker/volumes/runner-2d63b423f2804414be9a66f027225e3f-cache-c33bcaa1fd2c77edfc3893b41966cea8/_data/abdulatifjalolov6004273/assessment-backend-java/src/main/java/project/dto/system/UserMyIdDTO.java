//package project.dto.system;
//
//import lombok.*;
//
//@Getter
//@Setter
//@NoArgsConstructor
//@AllArgsConstructor
//@Builder
//public class UserMyIdDTO {
//
//    public String responseId;
//    public String comparisonValue;
//    public String resultCode;
//    public String resultNote;
//    public Profile profile;
//
//    @Getter
//    @Setter
//    @NoArgsConstructor
//    @AllArgsConstructor
//    @Builder
//    public static class Profile {
//        public CommonData commonData;
//        public DocData docData;
//        public Contacts contacts;
//        public Address address;
//        public String authenticationMethod;
//    }
//
//    @Getter
//    @Setter
//    @NoArgsConstructor
//    @AllArgsConstructor
//    @Builder
//    public static class CommonData {
//        public String firstName;
//        public String middleName;
//        public String lastName;
//        public String firstNameEn;
//        public String lastNameEn;
//        public String pinfl;
//        public String gender;
//        public String birthPlace;
//        public String birthCountry;
//        public String birthCountryId;
//        public String birthCountryIdCbu;
//        public String birthDate;
//        public String nationality;
//        public String nationalityId;
//        public String nationalityIdCbu;
//        public String citizenship;
//        public String citizenshipId;
//        public String citizenshipIdCbu;
//        public String sdkHash;
//        public String lastUpdatePassData;
//        public String lastUpdateAddress;
//    }
//
//    @Getter
//    @Setter
//    @NoArgsConstructor
//    @AllArgsConstructor
//    @Builder
//    public static class DocData {
//        public String passData;
//        public String issuedBy;
//        public String issuedById;
//        public String issuedDate;
//        public String expiryDate;
//        public String docType;
//        public String docTypeId;
//        public String docTypeIdCbu;
//    }
//
//    @Getter
//    @Setter
//    @NoArgsConstructor
//    @AllArgsConstructor
//    @Builder
//    public static class Contacts {
//        public String phone;
//        public String email;
//    }
//
//    @Getter
//    @Setter
//    @NoArgsConstructor
//    @AllArgsConstructor
//    @Builder
//    public static class Address {
//        public String permanentAddress;
//        public String temporaryAddress;
//        public PermanentRegistration permanentRegistration;
//        public TemporaryRegistration temporaryRegistration;
//    }
//
//    @Getter
//    @Setter
//    @NoArgsConstructor
//    @AllArgsConstructor
//    @Builder
//    public static class PermanentRegistration {
//        public String region;
//        public String address;
//        public String country;
//        public String cadastre;
//        public String district;
//        public String regionId;
//        public String countryId;
//        public String districtId;
//        public String regionIdCbu;
//        public String countryIdCbu;
//        public String districtIdCbu;
//        public String registrationDate;
//    }
//
//    @Getter
//    @Setter
//    @NoArgsConstructor
//    @AllArgsConstructor
//    @Builder
//    public static class TemporaryRegistration {
//        public String region;
//        public String address;
//        public String country;
//        public String cadastre;
//        public String district;
//        public String dateFrom;
//        public String dateTill;
//        public String regionId;
//        public String countryId;
//        public String districtId;
//        public String regionIdCbu;
//        public String countryIdCbu;
//        public String districtIdCbu;
//    }
//}
//
