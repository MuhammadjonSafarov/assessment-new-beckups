package project.model.entity.speaking;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.*;
import project.model.entity.File;
import project.model.enums.Status;

import javax.persistence.*;
import java.util.HashSet;
import java.util.Set;

import static javax.persistence.GenerationType.SEQUENCE;

@AllArgsConstructor
@Getter
@Setter
@Entity
@NoArgsConstructor
@Builder
@Table(name = "speaking_parts")
public class SpeakingParts {

    @Id
    @GeneratedValue(strategy = SEQUENCE, generator = "SPEAKING_PARTS_SEQUENCE")
    @SequenceGenerator(sequenceName = "SPEAKING_PARTS_SEQUENCE", allocationSize = 1, name = "SPEAKING_PARTS_SEQUENCE")
    @Column(name = "id", nullable = false, updatable = false)
    private Long id;

    @OneToOne
    private File textAudio;

    private Long textSuggestedReadingTime;

    @Column(columnDefinition = "TEXT")
    private String text;

    @OneToOne
    private File photoAudio;

    @OneToOne
    private File photoFile;

    @Column(columnDefinition = "TEXT")
    private String question;

    @OneToOne
    private File questionAudio;

    private Long preparationTime;

    private Long responseTime;

    @Column(name = "order_number")
    private Long orderNumber;

    @ManyToMany(mappedBy = "speakingParts")
    @JsonIgnore
    private Set<Speaking> speakings = new HashSet<>();

    @Enumerated(EnumType.STRING)
    private Status status;

    private Double coefficient = 0.0;

    private Double score = 0.0;

}
