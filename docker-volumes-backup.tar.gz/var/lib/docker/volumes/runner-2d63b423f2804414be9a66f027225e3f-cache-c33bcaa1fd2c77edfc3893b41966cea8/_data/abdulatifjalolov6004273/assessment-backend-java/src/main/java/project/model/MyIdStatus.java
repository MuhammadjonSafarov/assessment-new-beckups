package project.model;

import lombok.*;

import javax.persistence.*;

import static javax.persistence.GenerationType.SEQUENCE;

@AllArgsConstructor
@Getter
@Setter
@Entity
@NoArgsConstructor
@Builder
@Table(name = "my_id_status")
public class MyIdStatus {

    @Id
    @GeneratedValue(strategy = SEQUENCE, generator = "MYIDSTATUS_SEQUENCE")
    @SequenceGenerator(sequenceName = "MYIDSTATUS_SEQUENCE", allocationSize = 1, name = "MYIDSTATUS_SEQUENCE")
    @Column(name = "id", nullable = false, updatable = false)
    private Long id;

    private Boolean active = false;

}
