package project.controller.speaking;

import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import project.dto.speaking.SpeakingPartsDTO;
import project.model.Pagination;
import project.service.speaking.SpeakingPartsService;
import project.utility.Search;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/v1/speaking-part")
@SecurityRequirement(name = "Bearer Authentication")
public class SpeakingPartsController {

    private final SpeakingPartsService speakingPartsService;

    @PostMapping
    @ResponseStatus(HttpStatus.OK)
    public ResponseEntity<?> create(
            @RequestBody SpeakingPartsDTO speakingPartsDTO
    ) {
        return speakingPartsService.create(speakingPartsDTO);
    }

    @PutMapping("/{id}")
    @ResponseStatus(HttpStatus.OK)
    public ResponseEntity<?> update(
            @RequestBody SpeakingPartsDTO speakingPartsDTO,
            @PathVariable Long id
    ) {
        return speakingPartsService.update(id, speakingPartsDTO);
    }

    @GetMapping("/{id}")
    @ResponseStatus(HttpStatus.OK)
    public ResponseEntity<?> get(
            @PathVariable Long id
    ) {
        return speakingPartsService.get(id);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.OK)
    public ResponseEntity<?> delete(
            @PathVariable Long id
    ) {
        return speakingPartsService.delete(id);
    }

    @PostMapping("/list-search")
    @ResponseStatus(HttpStatus.OK)
    public ResponseEntity<?> listSearch(
            @RequestBody Pagination<Search> pagination
    ) {
        return speakingPartsService.search(pagination);
    }


}
