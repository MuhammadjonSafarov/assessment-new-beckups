package project.dto.reading;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import project.dto.FileDto;
import project.dto.QuestionsDTO;
import project.model.entity.reading.Passage;
import project.model.enums.InnerTextType;
import project.repository.QuestionsRepository;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class PassageDTO {

    private Long id;

    private String name;

    private String body;

    private FileDto fileDto;

    private Boolean isParent;

    private Long fileId;

    private Long orderNumber;

    private InnerTextType innerTextType;

//    private Long beginIndex;
//
//    private Long endIndex;
//
//    private Long startIndex1;
//
//    private Long startIndex2;
//
//    private Long startIndex3;
//
//    private Long startIndex4;

    private List<QuestionsDTO> questions;

    private List<Long> questionIds;

    private List<Long> childrenIds;

    private List<PassageDTO> children;

    public PassageDTO(Passage passage, QuestionsRepository questionsRepository) {
        setId(passage.getId());
        setName(passage.getName());
        setBody(passage.getBody());
        setIsParent(passage.getIsParent());
        setInnerTextType(passage.getInnerTextType());
//        setBeginIndex(passage.getBeginIndex());
//        setEndIndex(passage.getEndIndex());
//        setStartIndex1(passage.getStartIndex1());
//        setStartIndex2(passage.getStartIndex2());
//        setStartIndex3(passage.getStartIndex3());
//        setStartIndex4(passage.getStartIndex4());
        setOrderNumber(passage.getOrderNumber());
        if (passage.getFile() != null)
            setFileDto(new FileDto(passage.getFile()));
        setQuestions(questionsRepository.finAllByPassageId(passage.getId()));
        if (passage.getChildren() != null && !passage.getChildren().isEmpty())
            setChildren(passage.getChildren().stream().map((ch) -> new PassageDTO(ch, questionsRepository)).toList());
    }

}
