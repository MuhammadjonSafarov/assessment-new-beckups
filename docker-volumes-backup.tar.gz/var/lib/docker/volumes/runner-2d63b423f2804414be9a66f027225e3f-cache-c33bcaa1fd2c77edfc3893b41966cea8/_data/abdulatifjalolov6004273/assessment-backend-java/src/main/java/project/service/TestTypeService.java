package project.service;


import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import project.dto.ResponseDto;
import project.dto.TestTypeDto;
import project.exception.RecordBadRequestException;
import project.exception.RecordNotFoundException;
import project.model.Pagination;
import project.model.entity.TestType;
import project.model.enums.ExamType;
import project.model.enums.Status;
import project.repository.FileRepository;
import project.repository.TestTypeRepository;
import project.utility.PageWrapper;
import project.utility.Search;
import project.utility.SearchSession;
import project.utility.Utils;

import java.util.List;

@Service
@RequiredArgsConstructor
public class TestTypeService {

    private final TestTypeRepository testTypeRepository;
    private final FileRepository fileRepository;

    public ResponseEntity<?> create(TestTypeDto testTypeDto) {
        if (testTypeRepository.findByTitleUzActive(testTypeDto.getTitleUz()) != null) {
            throw new RecordBadRequestException("TestType with title " + testTypeDto.getTitleUz() + " already exists");
        }
        TestType testType = TestTypeDto.of(testTypeDto);
        testType.setFile(testTypeDto.getFileId() != null ? fileRepository.findById(testTypeDto.getFileId()).orElse(null) : null);
        testType.setOfferFile(testTypeDto.getOfferFileId() != null ? fileRepository.findById(testTypeDto.getOfferFileId()).orElse(null) : null);
        return ResponseEntity.ok(
                new TestTypeDto(testTypeRepository.save(testType))
        );
    }

    public ResponseEntity<?> update(TestTypeDto testTypeDto, Long id) {
        TestType testType = testTypeRepository.findByIdActive(id).orElseThrow(
                () -> new RecordNotFoundException("Not found")
        );
        testType.setFile(testTypeDto.getFileId() != null ? fileRepository.findById(testTypeDto.getFileId()).orElse(null) : null);
        testType.setOfferFile(testTypeDto.getFileId() != null ? fileRepository.findById(testTypeDto.getOfferFileId()).orElse(null) : null);
        return ResponseEntity.ok(
                new TestTypeDto(testTypeRepository.save(TestType.of(testType, testTypeDto)))
        );
    }

    public ResponseEntity<?> delete(Long id) {
        TestType testType = testTypeRepository.findByIdActive(id).orElseThrow(
                () -> new RecordNotFoundException("Not found")
        );
        testType.setStatus(Status.DELETED);
        testTypeRepository.save(testType);
        return ResponseEntity.ok("SUCCESS");
    }

    public ResponseEntity<?> get(Long id) {
        TestType testType = testTypeRepository.findByIdActive(id).orElseThrow(
                () -> new RecordNotFoundException("Not found")
        );
        return ResponseEntity.ok(
                new TestTypeDto(testType)
        );
    }

    public ResponseEntity<ResponseDto<PageWrapper>> search(Pagination<Search> pagination) {
        Page<TestType> testTypePage;
        if (pagination.getSearch().getValue() != null && !pagination.getSearch().getValue().isEmpty()) {
            testTypePage = search(pagination.getSearch().getValue().toLowerCase(), pagination);
        } else {
            testTypePage = search("", pagination);
        }
        List<TestTypeDto> testTypeDtos = testTypePage.stream().map(TestTypeDto::new).toList();
        return ResponseEntity.ok(new ResponseDto<>(ResponseDto.States.SUCCESS, HttpStatus.OK, 200, null, PageWrapper.builder().list(testTypeDtos).total(testTypePage.getTotalElements()).build()));
    }

    public Page<TestType> search(String value, Pagination<Search> pagination) {
        Pageable paging = Utils.getPageableFromPagination(pagination);
        Page<TestType> pagedResult;
        if (!value.isEmpty()) {
            pagedResult = testTypeRepository.findAllBySearch(value, paging);
        } else {
            pagedResult = testTypeRepository.findAllTestTypes(paging);
        }
        return pagedResult;
    }

    public ResponseEntity<ResponseDto<PageWrapper>> searchGrTT(Pagination<SearchSession> pagination) {
        List<ExamType> examTypes = pagination.getSearch().getExamTypes();
        Page<TestType> sessionPage;
        if (pagination.getSearch().getValue() != null && !pagination.getSearch().getValue().isEmpty()) {
            sessionPage = searchGrTT(examTypes, pagination.getSearch().getValue().toLowerCase(), pagination);
        } else {
            sessionPage = searchGrTT(examTypes, "", pagination);
        }
        List<TestTypeDto> sessionDtos = sessionPage.stream().map(TestTypeDto::new).toList();
        return ResponseEntity.ok(new ResponseDto<>(ResponseDto.States.SUCCESS, HttpStatus.OK, 200, null, PageWrapper.builder().list(sessionDtos).total(sessionPage.getTotalElements()).build()));
    }

    public Page<TestType> searchGrTT(List<ExamType> examTypes, String value, Pagination<SearchSession> pagination) {
        if (examTypes == null || examTypes.isEmpty())
            examTypes = List.of(ExamType.EXAM, ExamType.RETAKE);
//        Pageable paging = Utils.getPageableFromPagination(pagination);
        Pageable paging = PageRequest.of(pagination.getPage(), pagination.getLimit(), Sort.by("tt.id"));
        Page<TestType> pagedResult;
        pagedResult = testTypeRepository.findAllGrTT(examTypes.stream().map(Enum::name).toList(), paging);
        return pagedResult;
    }

}
