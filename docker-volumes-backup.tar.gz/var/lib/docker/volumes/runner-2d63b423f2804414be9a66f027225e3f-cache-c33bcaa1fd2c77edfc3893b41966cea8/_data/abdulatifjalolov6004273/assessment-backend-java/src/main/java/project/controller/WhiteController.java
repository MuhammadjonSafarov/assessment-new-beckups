package project.controller;

import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;
import project.exception.RecordNotFoundException;
import project.model.Pagination;
import project.model.entity.system.User;
import project.repository.system.UserRepository;
import project.service.SessionService;
import project.service.TestTypeService;
import project.service.system.UserService;
import project.utility.SearchSession;

import java.text.ParseException;

@RestController
@RequestMapping("/api/v1/white")
@RequiredArgsConstructor
public class WhiteController {

    private final SessionService sessionService;
    private final UserService userService;
    private final UserRepository userRepository;
    private final TestTypeService testTypeService;

    @PostMapping("/session-list-search")
    @ResponseStatus(HttpStatus.OK)
    public ResponseEntity<?> listSearch(
            @RequestBody Pagination<SearchSession> pagination
    ) throws ParseException {
        return sessionService.search(pagination);
    }

    @PostMapping("/check-eskiz-code/{userId}/{code}")
    @ResponseStatus(HttpStatus.OK)
    public ResponseEntity<?> checkTmpCode(
            @PathVariable Long userId,
            @PathVariable String code
    ) {
        return userService.checkTmpCode(userId, code);
    }

    @PostMapping("/retry-eskiz-code/{userId}")
    @ResponseStatus(HttpStatus.OK)
    public ResponseEntity<?> getEskizCode(
            @PathVariable Long userId
    ) {
        User user = userService.getUserById(userId);
        if (user == null)
            throw new RecordNotFoundException("User not found with id " + userId);
        if (user.getPhone() == null)
            throw new RecordNotFoundException("Phone not found from user " + userId);
        String eskizCode = userService.getEskizCode(user.getPhone());
        user.setTmpCode(eskizCode);
        userRepository.save(user);
        return ResponseEntity.ok("SUCCESS");
    }


    @PostMapping("/test-type/list-search-group-tt")
    @ResponseStatus(HttpStatus.OK)
    public ResponseEntity<?> listSearchGrTT(
            @RequestBody Pagination<SearchSession> pagination
    ) {
        return testTypeService.searchGrTT(pagination);
    }


}
