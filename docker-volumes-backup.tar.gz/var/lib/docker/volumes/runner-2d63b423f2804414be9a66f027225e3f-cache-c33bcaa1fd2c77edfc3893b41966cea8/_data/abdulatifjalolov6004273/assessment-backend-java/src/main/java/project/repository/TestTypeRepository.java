package project.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.data.repository.query.QueryByExampleExecutor;
import project.model.entity.TestType;

import java.util.List;
import java.util.Optional;

public interface TestTypeRepository extends JpaRepository<TestType, Long>, PagingAndSortingRepository<TestType, Long>, QueryByExampleExecutor<TestType> {

    @Query("select s from TestType s where s.id = ?1 ")
    Optional<TestType> findByIdActive(Long id);

    @Query("select s from TestType s where s.status = 'ACTIVE' and s.titleUz = ?1 ")
    TestType findByTitleUzActive(String nameUz);

    @Query("select s from TestType s " +
            "where s.status = 'ACTIVE' " +
            "and (lower(s.titleUz) like %?1% " +
            "or lower(s.titleRu) like %?1% " +
            "or lower(s.titleEn) like %?1% " +
            "or lower(s.partnerUz) like %?1% " +
            "or lower(s.partnerEn) like %?1% " +
            "or lower(s.partnerRu) like %?1%) order by s.titleUz")
    Page<TestType> findAllBySearch(String value, Pageable pageable);

    @Query("select s from TestType s where s.status = 'ACTIVE' order by s.titleUz ")
    Page<TestType> findAllTestTypes(Pageable pageable);

    @Query(
            value = """
        select distinct
            tt.id,
            tt.created_date,
            tt.created_who,
            tt.last_modified_who,
            tt.last_modified_date,
            tt.default_payment_amount,
            tt.exam_run_type,
            tt.is_in_our_platform,
            tt.is_retake_available,
            tt.is_there_any_other_pavilion,
            tt.max_candidates,
            tt.other_pavilion_payment_amount,
            tt.partner_en,
            tt.partner_ru,
            tt.partner_uz,
            tt.phone,
            tt.reissue_amount,
            tt.retake_amount,
            tt.status,
            tt.telegram,
            tt.test_type,
            tt.title_en,
            tt.title_ru,
            tt.title_uz,
            tt.file_id,
            tt.offer_file_id
        from sessions s
                 left join test_types tt on s.test_type_id = tt.id
        where s.status = 'ACTIVE'
          and s.exam_type in ?1
        """,
            countQuery = """
        select count(distinct tt.id)
        from sessions s
                 left join test_types tt on s.test_type_id = tt.id
        where s.status = 'ACTIVE'
          and s.exam_type in ?1
        """,
            nativeQuery = true
    )
    Page<TestType> findAllGrTT(List<String> examTypes, Pageable pageable);



    @Query("select p.testType from Session p where p.status = 'ACTIVE' and p.examType in ?2 and " +
            "(lower(p.testType.titleUz) like %?1% or lower(p.testType.titleRu) like %?1% or lower(p.testType.titleEn) like %?1%) " +
            "group by p.testType")
    Page<TestType> findAllBySearchGrTT(String value, List<String> examTypes, Pageable pageable);

}
