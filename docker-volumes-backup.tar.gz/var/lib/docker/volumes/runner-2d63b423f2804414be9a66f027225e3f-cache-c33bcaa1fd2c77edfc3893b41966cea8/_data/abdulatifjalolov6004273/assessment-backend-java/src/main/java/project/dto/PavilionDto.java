package project.dto;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.*;
import project.model.entity.Pavilion;
import project.model.enums.Status;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)
public class PavilionDto {
    private Long id;

    private String nameUz;

    private String nameRu;

    private String nameEn;

    private String addressUz;

    private String addressRu;

    private String addressEn;

    private Boolean isRent;

    private String status;

    public PavilionDto(Pavilion pavilion) {
        setId(pavilion.getId());
        setNameUz(pavilion.getNameUz());
        setNameRu(pavilion.getNameRu());
        setNameEn(pavilion.getNameEn());
        setAddressUz(pavilion.getAddressUz());
        setAddressRu(pavilion.getAddressRu());
        setAddressEn(pavilion.getAddressEn());
        setIsRent(pavilion.getIsRent());
        setStatus(pavilion.getStatus().toString());
    }

    @JsonIgnore
    public static Pavilion of(PavilionDto pavilionDto) {
        return Pavilion.builder()
                .nameUz(pavilionDto.getNameUz())
                .nameRu(pavilionDto.getNameRu())
                .nameEn(pavilionDto.getNameEn())
                .addressUz(pavilionDto.getAddressUz())
                .addressRu(pavilionDto.getAddressRu())
                .addressEn(pavilionDto.getAddressEn())
                .isRent(pavilionDto.getIsRent() != null && pavilionDto.getIsRent())
                .status(Status.valueOf(pavilionDto.getStatus()))
                .build();
    }

}
