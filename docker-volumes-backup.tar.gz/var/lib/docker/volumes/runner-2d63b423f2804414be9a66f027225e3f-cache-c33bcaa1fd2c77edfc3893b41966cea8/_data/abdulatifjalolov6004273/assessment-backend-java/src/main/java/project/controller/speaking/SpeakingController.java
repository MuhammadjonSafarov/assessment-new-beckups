package project.controller.speaking;

import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import project.dto.speaking.SpeakingDTO;
import project.model.Pagination;
import project.service.speaking.SpeakingService;
import project.utility.Search;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/v1/speaking")
@SecurityRequirement(name = "Bearer Authentication")
public class SpeakingController {

    private final SpeakingService speakingService;

    @PostMapping
    @ResponseStatus(HttpStatus.OK)
    public ResponseEntity<?> create(
            @RequestBody SpeakingDTO speakingDTO
    ) {
        return speakingService.create(speakingDTO);
    }

    @PutMapping("/{id}")
    @ResponseStatus(HttpStatus.OK)
    public ResponseEntity<?> update(
            @RequestBody SpeakingDTO speakingDTO,
            @PathVariable Long id
    ) {
        return speakingService.update(id, speakingDTO);
    }

    @GetMapping("/{id}")
    @ResponseStatus(HttpStatus.OK)
    public ResponseEntity<?> get(
            @PathVariable Long id
    ) {
        return speakingService.get(id);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.OK)
    public ResponseEntity<?> delete(
            @PathVariable Long id
    ) {
        return speakingService.delete(id);
    }

    @PostMapping("/list-search")
    @ResponseStatus(HttpStatus.OK)
    public ResponseEntity<?> listSearch(
            @RequestBody Pagination<Search> pagination
    ) {
        return speakingService.search(pagination);
    }

}
