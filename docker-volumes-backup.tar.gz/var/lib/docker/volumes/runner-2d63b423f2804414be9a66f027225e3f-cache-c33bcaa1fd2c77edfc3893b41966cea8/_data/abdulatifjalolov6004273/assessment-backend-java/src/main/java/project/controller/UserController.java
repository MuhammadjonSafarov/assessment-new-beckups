package project.controller;


import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import project.dto.system.UserDTO;
import project.model.Pagination;
import project.service.system.UserService;
import project.utility.Search;

@RestController
@RequestMapping("/api/v1/user")
@RequiredArgsConstructor
@SecurityRequirement(name = "Bearer Authentication")
public class UserController {

    private final UserService userService;

    @PostMapping("/attach-my-id-data/{userId}/{sessionId}")
    @ResponseStatus(HttpStatus.OK)
    public ResponseEntity<?> attachMyIdDataToNomzod(
            @RequestBody(required = false) JsonNode content,
            @PathVariable Long userId,
            @PathVariable Long sessionId
    ) throws JsonProcessingException {
        return userService.attachMyIdDataToUser(userId, content, sessionId);
    }

    @GetMapping("/me")
    @ResponseStatus(HttpStatus.OK)
    public ResponseEntity<?> me() throws JsonProcessingException {
        return userService.me();
    }

    @PostMapping
    @ResponseStatus(HttpStatus.OK)
    public ResponseEntity<?> create(
            @RequestBody UserDTO userDto
    ) {
        return userService.create(userDto);
    }

    @PutMapping("/{id}")
    @ResponseStatus(HttpStatus.OK)
    public ResponseEntity<?> update(
            @RequestBody UserDTO userDto,
            @PathVariable Long id
    ) {
        return userService.update(userDto, id);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.OK)
    public ResponseEntity<?> delete(
            @PathVariable Long id
    ) {
        return userService.delete(id);
    }

    @GetMapping("/{id}")
    @ResponseStatus(HttpStatus.OK)
    public ResponseEntity<?> get(
            @PathVariable Long id
    ) throws JsonProcessingException {
        return userService.get(id);
    }


    @PostMapping("/list-search")
    @ResponseStatus(HttpStatus.OK)
    public ResponseEntity<?> listSearch(
            @RequestBody Pagination<Search> pagination,
            @RequestParam(required = false) Boolean isListOperators,
            @RequestParam(required = false) Boolean isListNomzod
    ) {
        return userService.search(isListNomzod, isListOperators, pagination);
    }

    @PostMapping(value = "/attach-file", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    @ResponseStatus(HttpStatus.OK)
    public ResponseEntity<?> attachFileToUser(
            @RequestParam MultipartFile file,
            @RequestParam Long id
    ) {
        return userService.attachFileToUser(file, id);
    }

    @PostMapping(value = "/attach-passport-file", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    @ResponseStatus(HttpStatus.OK)
    public ResponseEntity<?> attachPassportFileToUser(
            @RequestParam MultipartFile file,
            @RequestParam Long id
    ) {
        return userService.attachPassportFileToUser(file, id);
    }

    @PostMapping("/inactive/{id}")
    @ResponseStatus(HttpStatus.OK)
    public ResponseEntity<?> makeUserInactive(
            @PathVariable Long id
    ) {
        return userService.makeUserInactive(id);
    }


}
