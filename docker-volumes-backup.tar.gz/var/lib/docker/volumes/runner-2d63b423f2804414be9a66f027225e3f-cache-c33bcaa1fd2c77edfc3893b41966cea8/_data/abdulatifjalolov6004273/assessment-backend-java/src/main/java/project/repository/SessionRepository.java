package project.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.data.repository.query.QueryByExampleExecutor;
import project.model.entity.Session;
import project.model.entity.TestType;
import project.model.entity.system.User;
import project.model.enums.ExamType;

import java.util.List;

public interface SessionRepository extends JpaRepository<Session, Long>, PagingAndSortingRepository<Session, Long>, QueryByExampleExecutor<Session> {

    @Query("select p from Session p where p.status = 'ACTIVE' and p.examType in ?2 and " +
            "(lower(p.testType.titleUz) like ?1 or lower(p.testType.titleRu) like ?2 or lower(p.testType.titleEn) like ?2) ")
    Page<Session> findAllBySearch(String value, List<ExamType> examTypes, Pageable pageable);

    @Query("select p from Session p where p.status = 'ACTIVE' and p.examType in ?1 ")
    Page<Session> findAllSessions(List<ExamType> examTypes, Pageable pageable);

    @Query("select p from Session p where p.status = 'ACTIVE' and ?1 member of p.users ")
    Page<Session> findAllBySearch(User user, String value, Pageable pageable);

    @Query("select p from Session p where p.status = 'ACTIVE' and ?1 member of p.users ")
    Page<Session> findAllSessions(User user, Pageable pageable);

    @Query("select s from Session s " +
            "left join TestType tt on s.testType.id = tt.id " +
            "where tt.id = ?1 and s.pavilion.id = ?2 and s.examType = ?3 " +
            "and tt.status = 'ACTIVE' and s.status = 'ACTIVE' and s.pavilion.status = 'ACTIVE' " +
            "and to_timestamp(s.startDate, 'DD-MM-YYYY HH24:MI:SS') > current_timestamp")
    List<Session> findByTestTypeAndPavilion(Long testTypeId, Long pavilionId, ExamType examType);

}
