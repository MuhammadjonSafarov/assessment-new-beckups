package project.model.payme;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.*;
import project.model.Auditable;
import project.model.entity.UserApplication;
import project.model.entity.system.User;

import javax.persistence.*;

@Entity(name = "orders")
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class Order extends Auditable<String> {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(optional = false, fetch = FetchType.LAZY)
    private Client client;

    @Column(nullable = false)
    private Integer orderSum;

    private boolean cancelled;

    private boolean paid;

    private boolean delivered;

    @ManyToOne
    @JsonIgnore
    private User payer;

    @OneToOne
    private UserApplication userApplication;

}
