package project.service;

import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import project.dto.PavilionDto;
import project.dto.ResponseDto;
import project.exception.RecordBadRequestException;
import project.exception.RecordNotFoundException;
import project.model.Pagination;
import project.model.entity.Pavilion;
import project.model.enums.ExamType;
import project.model.enums.Status;
import project.repository.PavilionRepository;
import project.utility.PageWrapper;
import project.utility.Search;
import project.utility.Utils;

import javax.transaction.Transactional;
import java.util.List;

@Service
@RequiredArgsConstructor
public class PavilionService {

    private final PavilionRepository pavilionRepository;
    private final ComputerService computerService;

    @Transactional
    public ResponseEntity<?> create(PavilionDto pavilionDto) {
        if (pavilionRepository.findByNameUzActive(pavilionDto.getNameUz()) != null) {
            throw new RecordBadRequestException("Pavilion with name " + pavilionDto.getNameUz() + " already exists");
        }
        Pavilion pavilion = pavilionRepository.save(PavilionDto.of(pavilionDto));
        return ResponseEntity.ok(
                new PavilionDto(pavilion)
        );
    }

    public ResponseEntity<?> update(PavilionDto pavilionDto, Long id) {
        Pavilion pavilion = pavilionRepository.findByIdActive(id).orElseThrow(
                () -> new RecordNotFoundException("Not found")
        );
        return ResponseEntity.ok(
                new PavilionDto(pavilionRepository.save(Pavilion.of(pavilion, pavilionDto)))
        );
    }

    public ResponseEntity<?> delete(Long id) {
        Pavilion pavilion = pavilionRepository.findByIdActive(id).orElseThrow(
                () -> new RecordNotFoundException("Not found")
        );
        pavilion.setStatus(Status.DELETED);
        pavilionRepository.save(pavilion);
        return ResponseEntity.ok("SUCCESS");
    }

    public ResponseEntity<?> get(Long id) {
        Pavilion pavilion = pavilionRepository.findByIdActive(id).orElseThrow(
                () -> new RecordNotFoundException("Not found")
        );
        return ResponseEntity.ok(
                new PavilionDto(pavilion)
        );
    }

    public ResponseEntity<ResponseDto<PageWrapper>> search(Pagination<Search> pagination) {
        Page<Pavilion> pavilionPage;
        if (pagination.getSearch().getValue() != null && !pagination.getSearch().getValue().isEmpty()) {
            pavilionPage = search(pagination.getSearch().getValue().toLowerCase(), pagination);
        } else {
            pavilionPage = search("", pagination);
        }
        List<PavilionDto> pavilionDtos = pavilionPage.stream().map(PavilionDto::new).toList();
        return ResponseEntity.ok(new ResponseDto<>(ResponseDto.States.SUCCESS, HttpStatus.OK, 200, null, PageWrapper.builder().list(pavilionDtos).total(pavilionPage.getTotalElements()).build()));
    }

    public Page<Pavilion> search(String value, Pagination<Search> pagination) {
        Pageable paging = Utils.getPageableFromPagination(pagination);
        Page<Pavilion> pagedResult;
        if (!value.isEmpty()) {
            pagedResult = pavilionRepository.findAllBySearch(value, paging);
        } else {
            pagedResult = pavilionRepository.findAllPavilions(paging);
        }
        return pagedResult;
    }

    public ResponseEntity<?> getPavilionsByTestType(Long testTypeId, String examType) {
        List<PavilionDto> pavilionDTOs = pavilionRepository.findAllByTestType(testTypeId, ExamType.valueOf(examType))
                .stream().map(PavilionDto::new).toList();
        return ResponseEntity.ok(pavilionDTOs);
    }
}
