package project.repository.speaking;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.data.repository.query.QueryByExampleExecutor;
import project.model.entity.speaking.Speaking;

import java.util.Optional;

public interface SpeakingRepository extends JpaRepository<Speaking, Long>, PagingAndSortingRepository<Speaking, Long>, QueryByExampleExecutor<Speaking>  {

    @Query("select q from Speaking q where q.status = 'ACTIVE' and q.name = ?1 ")
    Optional<Speaking> findByName(String name);

    @Query("select p from Speaking p where p.status = 'ACTIVE' and p.name like %?1% order by p.id ")
    Page<Speaking> findAllBySearch(String value, Pageable pageable);

    @Query("select p from Speaking p where p.status = 'ACTIVE' order by p.id ")
    Page<Speaking> findAllSpeaking(Pageable pageable);

}
