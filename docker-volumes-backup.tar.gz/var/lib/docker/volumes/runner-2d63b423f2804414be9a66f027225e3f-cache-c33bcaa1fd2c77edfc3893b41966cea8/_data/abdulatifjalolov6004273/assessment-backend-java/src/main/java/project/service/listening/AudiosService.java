package project.service.listening;

import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import project.dto.ResponseDto;
import project.dto.listening.AudiosDTO;
import project.exception.RecordBadRequestException;
import project.exception.RecordNotFoundException;
import project.model.Pagination;
import project.model.entity.Questions;
import project.model.entity.listening.Audios;
import project.model.enums.Status;
import project.repository.FileRepository;
import project.repository.listening.AudiosRepository;
import project.repository.QuestionsRepository;
import project.utility.PageWrapper;
import project.utility.Search;
import project.utility.Utils;

import java.util.HashSet;
import java.util.List;

@Service
@RequiredArgsConstructor
public class AudiosService {

    private final AudiosRepository audiosRepository;
    private final QuestionsRepository questionsRepository;
    private final FileRepository fileRepository;

    public ResponseEntity<?> create(AudiosDTO audiosDTO) {
        audiosRepository.findByName(audiosDTO.getName()).ifPresent((answer) -> {
            throw new RecordBadRequestException("Audios already exists with " + audiosDTO.getName());
        });
        Audios audios = audiosRepository.save(
                Audios.builder()
                        .status(Status.ACTIVE)
                        .name(audiosDTO.getName())
                        .audioFile(audiosDTO.getAudioFileId() != null ? fileRepository.findById(audiosDTO.getAudioFileId()).orElse(null) : null)
                        .files((audiosDTO.getFileIds() != null && !audiosDTO.getFileIds().isEmpty()) ? new HashSet<>(fileRepository.findAllById(audiosDTO.getFileIds())) : new HashSet<>())
                        .orderNumber(audiosDTO.getOrderNumber())
                        .build());
        if (audiosDTO.getQuestionIds() != null && !audiosDTO.getQuestionIds().isEmpty()) {
            audiosDTO.getQuestionIds().forEach((questionId) -> questionsRepository.findById(questionId).ifPresent((questions) -> {
                questions.setAudios(audios);
                questionsRepository.save(questions);
            }));
        }
        return ResponseEntity.ok(new AudiosDTO(audiosRepository.save(audios), questionsRepository));
    }


    public ResponseEntity<?> update(Long id, AudiosDTO audiosDTO) {
        Audios audios = audiosRepository.findById(id).orElseThrow(() -> new RecordNotFoundException("Audios not found with id " + id));
        if (!audios.getName().equals(audiosDTO.getName())) {
            audiosRepository.findByName(audiosDTO.getName()).ifPresent((audio) -> {
                throw new RecordBadRequestException("Audios already exists with " + audiosDTO.getName());
            });
        }
        audios.setName(audiosDTO.getName());
        audios.setOrderNumber(audiosDTO.getOrderNumber());
        audios.setAudioFile(audiosDTO.getAudioFileId() != null ? fileRepository.findById(audiosDTO.getAudioFileId()).orElse(null) : null);
        audios.setFiles((audiosDTO.getFileIds() != null && !audiosDTO.getFileIds().isEmpty()) ? new HashSet<>(fileRepository.findAllById(audiosDTO.getFileIds())) : new HashSet<>());
        for (Questions questions : questionsRepository.finAllByAudio(audios.getId())) {
            questions.setAudios(null);
            questionsRepository.save(questions);
        }
        if (audiosDTO.getQuestionIds() != null && !audiosDTO.getQuestionIds().isEmpty()) {
            audiosDTO.getQuestionIds().forEach((questionId) -> questionsRepository.findById(questionId).ifPresent((questions) -> {
                questions.setAudios(audios);
                questionsRepository.save(questions);
            }));
        }
        return ResponseEntity.ok(new AudiosDTO(audiosRepository.save(audios), questionsRepository));

    }

    public ResponseEntity<?> get(Long id) {
        Audios questions = audiosRepository.findById(id).orElseThrow(() -> new RecordNotFoundException("Audios not found with id " + id));
        return ResponseEntity.ok((new AudiosDTO(audiosRepository.save(questions), questionsRepository)));
    }

    public ResponseEntity<ResponseDto<PageWrapper>> search(Pagination<Search> pagination) {
        Page<Audios> audiosPage;
        if (pagination.getSearch().getValue() != null && !pagination.getSearch().getValue().isEmpty()) {
            audiosPage = search(pagination.getSearch().getValue().toLowerCase(), pagination);
        } else {
            audiosPage = search("", pagination);
        }
        List<AudiosDTO> audiosDTOs = audiosPage.stream()
                .map(question -> new AudiosDTO(question, questionsRepository))
                .toList();
        return ResponseEntity.ok(new ResponseDto<>(ResponseDto.States.SUCCESS, HttpStatus.OK, 200, null, PageWrapper.builder().list(audiosDTOs).total(audiosPage.getTotalElements()).build()));
    }

    public Page<Audios> search(String value, Pagination<Search> pagination) {
        Pageable paging = Utils.getPageableFromPagination(pagination);
        Page<Audios> pagedResult;
        if (!value.isEmpty()) {
            pagedResult = audiosRepository.findAllBySearch(value, paging);
        } else {
            pagedResult = audiosRepository.findAllAudios(paging);
        }
        return pagedResult;
    }

    public ResponseEntity<?> delete(Long id) {
        Audios questions = audiosRepository.findById(id).orElseThrow(() -> new RecordNotFoundException("Audios not found with id " + id));
        questions.setStatus(Status.DELETED);
        audiosRepository.save(questions);
        return ResponseEntity.ok("SUCCESS");
    }


}
