package project.repository.listening;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.data.repository.query.QueryByExampleExecutor;
import project.model.entity.File;
import project.model.entity.listening.Audios;

import java.util.List;
import java.util.Optional;

public interface AudiosRepository extends JpaRepository<Audios, Long>, PagingAndSortingRepository<Audios, Long>, QueryByExampleExecutor<Audios> {

    @Query("select q from Audios q where q.status = 'ACTIVE' and q.name = ?1 ")
    Optional<Audios> findByName(String name);

    @Query("select p from Audios p where p.status = 'ACTIVE' and p.name like %?1% order by p.id ")
    Page<Audios> findAllBySearch(String value, Pageable pageable);

    @Query("select p from Audios p where p.status = 'ACTIVE' order by p.id ")
    Page<Audios> findAllAudios(Pageable pageable);

    @Query("SELECT a.audioFile FROM Audios a WHERE a.audioFile IS NOT NULL ")
    List<File> findAllLinkedAudioFiles();

    @Query("SELECT f FROM Audios a JOIN a.files f ")
    List<File> findAllLinkedFiles();


}
