package project.model.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.*;
import project.model.entity.system.User;
import project.model.enums.MyIdStatus;
import project.model.enums.PaymentStatus;

import javax.persistence.*;

import java.util.*;

import static javax.persistence.FetchType.LAZY;
import static javax.persistence.GenerationType.SEQUENCE;

@AllArgsConstructor
@Getter
@Setter
@Entity
@NoArgsConstructor
@Builder
@Table(name = "user_applications")
public class UserApplication {

    @Id
    @GeneratedValue(strategy = SEQUENCE, generator = "USER_APPLICATIONS_SEQUENCE")
    @SequenceGenerator(sequenceName = "USER_APPLICATIONS_SEQUENCE", allocationSize = 1, name = "USER_APPLICATIONS_SEQUENCE")
    @Column(name = "id", nullable = false, updatable = false)
    private Long id;

    @Column(name = "created_date")
    private String createdDate;

    @Column(name = "payment_term_date")
    private String paymentTermDate;

    @Enumerated(EnumType.STRING)
    private PaymentStatus paymentStatus;

    @ManyToOne
    private User user;

    private Long tempSessionId;

    @ManyToOne
    private Session session;

    @Enumerated(EnumType.STRING)
    private MyIdStatus myIdStatus;

    @ManyToOne
    private Computer computer;

    @ManyToMany(fetch = LAZY)
    @JoinTable(name = "application_listening_answers",
            joinColumns = {@JoinColumn(name = "application_id", referencedColumnName = "id")},
            inverseJoinColumns = {@JoinColumn(name = "answer_id", referencedColumnName = "id")})
    private Set<UserApplicationAnswer> listeningAnswers = new HashSet<>();

    @ManyToMany(fetch = LAZY)
    @JoinTable(name = "application_reading_answers",
            joinColumns = {@JoinColumn(name = "application_id", referencedColumnName = "id")},
            inverseJoinColumns = {@JoinColumn(name = "answer_id", referencedColumnName = "id")})
    private Set<UserApplicationAnswer> readingAnswers = new HashSet<>();

    @ManyToMany(fetch = LAZY)
    @JoinTable(name = "application_writing_answers",
            joinColumns = {@JoinColumn(name = "application_id", referencedColumnName = "id")},
            inverseJoinColumns = {@JoinColumn(name = "answer_id", referencedColumnName = "id")})
    private Set<UserApplicationAnswer> writingAnswers = new HashSet<>();

    @ManyToMany(fetch = LAZY)
    @JoinTable(name = "application_speaking_answers",
            joinColumns = {@JoinColumn(name = "application_id", referencedColumnName = "id")},
            inverseJoinColumns = {@JoinColumn(name = "answer_id", referencedColumnName = "id")})
    private Set<UserApplicationAnswer> speakingAnswers = new HashSet<>();

    private String listeningDegree;

    private String readingDegree;

    private String speakingDegree;

    private String writingDegree;

    private String degree;

    @OneToOne
    private File certificateFile;

    private Boolean myIdStatusOfUser = Boolean.TRUE;

}
