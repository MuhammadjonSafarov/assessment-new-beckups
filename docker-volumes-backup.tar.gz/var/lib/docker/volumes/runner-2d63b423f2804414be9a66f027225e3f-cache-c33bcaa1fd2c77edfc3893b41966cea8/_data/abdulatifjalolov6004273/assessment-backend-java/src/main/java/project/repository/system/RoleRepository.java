package project.repository.system;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.data.repository.query.QueryByExampleExecutor;
import org.springframework.stereotype.Repository;
import project.model.entity.Pavilion;
import project.model.entity.system.Role;

import java.util.List;
import java.util.Optional;

/**
 * Repository interface that extends {@link JpaRepository} for class {@link Role}.
 */

@Repository
public interface RoleRepository extends PagingAndSortingRepository<Role, Long>, JpaRepository<Role, Long>, QueryByExampleExecutor<Role> {
    @Query("select r from Role r where r.status = 'ACTIVE' and r.name = ?1 ")
    Role findByName(String name);

    Role findByCode(String code);

    @Query("select r from Role r where r.status = 'ACTIVE' and r.id = ?1 ")
    Role findByIdActive(Long id);

    @Query("SELECT p.name FROM Role r LEFT JOIN r.permissions p WHERE r.status = 'ACTIVE' and r.id IN(?1) ORDER BY p.name")
    List<String> findPermissionNames(List<Long> roleIds);

    @Query("SELECT p.id FROM Role r LEFT JOIN r.permissions p WHERE r.status = 'ACTIVE' and r.id = ?1 ORDER BY p.name")
    List<Long> findPermissionIds(Long roleId);

    @Query("select r from Role r " +
            "where r.status = 'ACTIVE' " +
            "and lower(r.name) like %?1% and r.name = ?2 order by r.name ")
    Page<Role> findAllBySearch(String value, Pageable pageable);

    @Query("select r from Role r where r.status = 'ACTIVE' order by r.name ")
    Page<Role> findAllRoles(Pageable pageable);
}
