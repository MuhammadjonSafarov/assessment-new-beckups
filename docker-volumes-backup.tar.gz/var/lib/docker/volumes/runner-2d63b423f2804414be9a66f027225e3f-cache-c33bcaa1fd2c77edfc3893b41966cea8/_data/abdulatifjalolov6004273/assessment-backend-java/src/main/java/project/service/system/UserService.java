package project.service.system;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.*;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.multipart.MultipartFile;
import project.dto.ResponseDto;
import project.dto.system.UserDTO;
import project.dto.system.UserMyIdDataResponseDTO;
import project.dto.system.UserRegisterDTO;
import project.exception.RecordBadRequestException;
import project.exception.RecordNotFoundException;
import project.model.Pagination;
import project.model.entity.*;
import project.model.entity.system.EskizToken;
import project.model.entity.system.Role;
import project.model.entity.system.User;
import project.model.entity.system.UserMyIdData;
import project.model.enums.MyIdStatus;
import project.model.enums.PaymentStatus;
import project.model.enums.Status;
import project.repository.ComputerRepository;
import project.repository.SessionRepository;
import project.repository.UserApplicationRepository;
import project.repository.QuestionsRepository;
import project.repository.system.EskizTokenRepository;
import project.repository.system.RoleRepository;
import project.repository.system.UserMyIdDataRepository;
import project.repository.system.UserRepository;
import project.service.FileService;
import project.utility.PageWrapper;
import project.utility.Search;
import project.utility.Utils;

import javax.transaction.Transactional;
import java.time.Instant;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.*;

/**
 * Implementation of {@link UserService} interface.
 * Wrapper for {@link UserRepository} + business logic.
 */

@Service
@Slf4j
@RequiredArgsConstructor
public class UserService {

    private final UserRepository userRepository;
    private final ObjectMapper objectMapper;
    private final BCryptPasswordEncoder passwordEncoder;
    private final RoleRepository roleRepository;
    private final UserMyIdDataRepository userMyIdDataRepository;
    private final FileService fileService;
    private final RestTemplate restTemplate;

    private final QuestionsRepository questionsRepository;
    private final EskizTokenRepository eskizTokenRepository;
    private final SessionRepository sessionRepository;
    private final UserApplicationRepository userApplicationRepository;
    private final ComputerRepository computerRepository;

    @Value("${eskiz.login}")
    private String eskizLogin;

    @Value("${eskiz.password}")
    private String eskizPassword;

    @Value("${eskiz.token.url}")
    private String eskizTokenUrl;

    @Value("${eskiz.send.sms.url}")
    private String eskizSendSmsUrl;

    public User findByUsername(String username) {
        User user = userRepository.findByUsername(username);
        if (user == null) throw new RecordNotFoundException("User with username: " + username + " not found");
        log.info("IN findByUsername - user: {} found by username: {}", user, username);
        return user;
    }

    public List<String> findRoleNames(Long userId) {
        return userRepository.findRoleNames(userId);
    }

    public List<Long> findRoleIds(Long userId) {
        return userRepository.findRoleIds(userId);
    }


    public ResponseEntity<?> create(UserDTO userDto) {
        if (userDto.getUsername() == null || userDto.getUsername().isBlank()) {
            throw new RecordBadRequestException("Username can not be null or blank");
        }
        User byUsername = userRepository.findByUsername(userDto.getUsername());
        if (byUsername != null) {
            throw new RecordBadRequestException("User " + userDto.getUsername() + " already exists");
        }
        User user = UserDTO.of(userDto);

        user.setLastActiveDate(new Date());
        user.setPassword(passwordEncoder.encode(userDto.getPassword()));

        if (userDto.getRoleIds() != null && !userDto.getRoleIds().isEmpty()) {
            List<Role> roles = new ArrayList<>();
            for (Long roleId : userDto.getRoleIds()) {
                Role role = roleRepository.findByIdActive(roleId);
                if (role != null)
                    roles.add(role);
            }
            user.setRoles(roles);
        }

        return ResponseEntity.ok(
                new UserDTO(userRepository.save(user))
        );
    }

    public ResponseEntity<?> update(UserDTO userDto, Long id) {
        User user = userRepository.findById(id).orElseThrow(
                () -> new RecordNotFoundException("Not found")
        );

        User newUser = User.of(user, userDto);

        if (userDto.getRoleIds() != null) {
            List<Role> roles = new ArrayList<>();
            for (Long roleId : userDto.getRoleIds()) {
                Role role = roleRepository.findByIdActive(roleId);
                if (role != null)
                    roles.add(role);
            }
            newUser.setRoles(roles);
        }

        return ResponseEntity.ok(
                new UserDTO(userRepository.save(newUser))
        );
    }

    public ResponseEntity<?> delete(Long id) {
        User user = userRepository.findById(id).orElseThrow(
                () -> new RecordNotFoundException("Not found")
        );
        user.setStatus(Status.DELETED);
        userRepository.save(user);
        return ResponseEntity.ok("SUCCESS");
    }

    public ResponseEntity<?> get(Long id) throws JsonProcessingException {
        User user = userRepository.findByIdActive(id);
        if (user == null) {
            throw new RecordNotFoundException("Not found");
        }
        UserMyIdData userMyIdData = userMyIdDataRepository.findByUserId(user.getId()).orElse(null);
        return ResponseEntity.ok(
                new UserDTO(user, userMyIdData, objectMapper)
        );
    }

    public User getUserById(Long id) {
        return userRepository.findById(id).orElse(null);
    }

    public ResponseEntity<ResponseDto<PageWrapper>> search(Boolean isListNomzod, Boolean isListOperators, Pagination<Search> pagination) {
        Page<User> userPage;
        if (pagination.getSearch().getValue() != null && !pagination.getSearch().getValue().isEmpty()) {
            userPage = search(isListNomzod, pagination.getSearch().getValue().toLowerCase(), isListOperators, pagination);
        } else {
            userPage = search(isListNomzod, "", isListOperators, pagination);
        }
        List<UserDTO> userDTOS = userPage.getContent().stream().map(UserDTO::new).toList();
        return ResponseEntity.ok(new ResponseDto<>(ResponseDto.States.SUCCESS, HttpStatus.OK, 200, null, PageWrapper.builder().list(userDTOS).total(userPage.getTotalElements()).build()));
    }

    public Page<User> search(Boolean isListNomzod, String value, Boolean isListOperators, Pagination<Search> pagination) {
        Pageable paging = Utils.getPageableFromPagination(pagination);
        Page<User> pagedResult;
        if (isListNomzod == null)
            isListNomzod = false;
        if (isListNomzod) {
            if (!value.isEmpty()) {
                pagedResult = userRepository.findAllNomzodBySearch(value, paging);
            } else {
                pagedResult = userRepository.findAllNomzodUsers(paging);
            }
        } else {
            if (isListOperators == null)
                isListOperators = false;
            if (isListOperators) {
                if (!value.isEmpty()) {
                    pagedResult = userRepository.findAllBySearch(value, "Оператор мониторинга", paging);
                } else {
                    pagedResult = userRepository.findAllUsers("Оператор мониторинга", paging);
                }
            } else {
                if (!value.isEmpty()) {
                    pagedResult = userRepository.findAllBySearch(value, paging);
                } else {
                    pagedResult = userRepository.findAllUsers(paging);
                }
            }
        }
        return pagedResult;
    }

    @Transactional
    public ResponseEntity<?> attachFileToUser(MultipartFile file, Long id) {
        User user = userRepository.findByIdActive(id);
        if (user == null) {
            throw new RecordNotFoundException("Not found");
        }
        File fileEntity = fileService.storeFile(file);
        user.setFile(fileEntity);
        userRepository.save(user);
        return ResponseEntity.ok(
                new UserDTO(user)
        );
    }

    @Transactional
    public ResponseEntity<?> attachPassportFileToUser(MultipartFile file, Long id) {
        User user = userRepository.findByIdActive(id);
        if (user == null) {
            throw new RecordNotFoundException("Not found");
        }
        File fileEntity = fileService.storeFile(file);
        user.setPassportFile(fileEntity);
        userRepository.save(user);
        return ResponseEntity.ok(
                new UserDTO(user)
        );
    }

    public ResponseEntity<?> makeUserInactive(Long id) {
        User user = userRepository.findByIdActive(id);
        if (user == null) {
            throw new RecordNotFoundException("Not found");
        }
        user.setStatus(Status.INACTIVE);
        userRepository.save(user);
        return ResponseEntity.ok("SUCCESS");
    }

    @Transactional
    public ResponseEntity<?> register(UserRegisterDTO userRegisterDTO) {
        if (userRegisterDTO.getUsername() != null && userRepository.findByUsernameAll(userRegisterDTO.getUsername()) != null)
            throw new RecordBadRequestException("User already exists with username " + userRegisterDTO.getUsername());
        if (userRegisterDTO.getPhone() != null && userRepository.findByPhone(userRegisterDTO.getPhone()) != null)
            throw new RecordBadRequestException("User already exists with phone " + userRegisterDTO.getPhone());
        String code = getEskizCode(userRegisterDTO.getPhone());
        return ResponseEntity.ok(
                new UserDTO(
                        userRepository.save(
                                User.builder()
                                        .username(userRegisterDTO.getUsername())
                                        .isNomzod(true)
                                        .phone(userRegisterDTO.getPhone())
                                        .tmpCode(code)
                                        .password(passwordEncoder.encode(userRegisterDTO.getPassword()))
                                        .status(Status.DELETED)
                                        .build()
                        )
                )
        );
    }

    @Transactional
    public ResponseEntity<?> attachData(Long id, UserRegisterDTO userRegisterDTO) {
        User user = userRepository.findById(id).orElseThrow(
                () -> new RecordNotFoundException("User not found with id " + id)
        );
        if (userRegisterDTO.getPassportSerial() != null && userRegisterDTO.getPassportNumber() != null &&
                userRepository.findByPassportSerialAndPassportNumber(userRegisterDTO.getPassportSerial().toLowerCase(), userRegisterDTO.getPassportNumber()) != null)
            throw new RecordBadRequestException("User already exists with passport " + userRegisterDTO.getPassportSerial() + userRegisterDTO.getPassportNumber());
        user.setFirstName(userRegisterDTO.getFirstName());
        user.setPassportSerial(userRegisterDTO.getPassportSerial());
        user.setPassportNumber(userRegisterDTO.getPassportNumber());
        user.setBirthDate(userRegisterDTO.getBirthDate());
        user.setLastName(userRegisterDTO.getLastName());
        user.setMiddleName(userRegisterDTO.getMiddleName());
        user.setEmail(userRegisterDTO.getEmail());
        return ResponseEntity.ok(
                new UserDTO(
                        userRepository.save(user)
                )
        );
    }

    public String getEskizCode(String phoneNumber) {
        String token = getEskizToken();
        if (token != null) {
            try {
                HttpHeaders headers = new HttpHeaders();
                headers.setContentType(MediaType.MULTIPART_FORM_DATA);
                headers.set("Authorization", "Bearer " + token);

                MultiValueMap<String, String> body = new LinkedMultiValueMap<>();
                body.add("mobile_phone", phoneNumber);
                int randomNumber = 100000 + new Random().nextInt(900000);
                body.add("message", "Assessment.uz saytida ro'yxatdan o'tish uchun tasdiqlash kodi:" + randomNumber);
                body.add("from", "4546");
                body.add("callback_url", "");

                HttpEntity<MultiValueMap<String, String>> requestEntity = new HttpEntity<>(body, headers);

                ResponseEntity<String> response = restTemplate.exchange(eskizSendSmsUrl, HttpMethod.POST, requestEntity, String.class);
                if (response.getStatusCode() == HttpStatus.OK) {
                    return String.valueOf(randomNumber);
                } else {
                    return null;
                }
            } catch (Exception e) {
                throw new RecordBadRequestException("Something went wrong");
            }
        }
        throw new RecordBadRequestException("Something went wrong");
    }

    @Transactional
    public String getEskizToken() {
        EskizToken eskizToken = eskizTokenRepository.findById(1L).orElse(null);
        if (eskizToken != null && !isTokenExpired(eskizToken.getToken()))
            return eskizToken.getToken();
        try {
            MultiValueMap<String, String> formData = new LinkedMultiValueMap<>();
            formData.add("email", eskizLogin);
            formData.add("password", eskizPassword);

            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.MULTIPART_FORM_DATA);

            ResponseEntity<String> response = restTemplate.postForEntity(eskizTokenUrl, new org.springframework.http.HttpEntity<>(formData, headers), String.class);

            if (response.getStatusCode() == HttpStatus.OK) {
                String token = objectMapper.readTree(response.getBody()).path("data").path("token").asText();
                if (eskizToken == null) {
                    eskizTokenRepository.save(EskizToken.builder().token(token).build());
                } else {
                    eskizToken.setToken(token);
                    eskizTokenRepository.save(eskizToken);
                }
                return token;
            } else {
                return null;
            }
        } catch (Exception e) {
            return null;
        }
    }

    @Transactional
    public Boolean isTokenExpired(String token) {
        try {
            String[] tokenParts = token.split("\\.");
            if (tokenParts.length != 3) {
                return true;
            }
            String payload = new String(Base64.getUrlDecoder().decode(tokenParts[1]));
            ObjectMapper objectMapper = new ObjectMapper();
            Map<String, Object> claims = objectMapper.readValue(payload, Map.class);
            if (claims.containsKey("exp")) {
                long exp = ((Number) claims.get("exp")).longValue();
                ZonedDateTime tokenExpiryTime = Instant.ofEpochSecond(exp).atZone(ZoneId.of("Asia/Tashkent"));
                ZonedDateTime currentTime = ZonedDateTime.now(ZoneId.of("Asia/Tashkent"));
                return tokenExpiryTime.isBefore(currentTime);
            }
        } catch (Exception e) {
            return true;
        }
        return true;
    }

    @Transactional
    public ResponseEntity<?> attachMyIdDataToUser(Long userId, JsonNode content, Long sessionId) throws JsonProcessingException {
        User user = userRepository.findByIdActive(userId);
        if (user == null)
            throw new RecordNotFoundException("User not found with id " + userId);
        Session session = sessionRepository.findById(sessionId).orElseThrow(
                () -> new RecordNotFoundException("Session not found with id " + sessionId)
        );
        UserMyIdData userMyIdData = userMyIdDataRepository.findByUserId(user.getId()).orElse(null);
        if (userMyIdData == null)
            userMyIdData = new UserMyIdData();
        userMyIdData.setMyIdData(content != null ? content.toString() : null);
        userMyIdData.setUser(user);
        UserApplication userApplication = userApplicationRepository.findByUserAndSession(user.getId(), session.getId()).orElseThrow(
                () -> new RecordNotFoundException("UserApplication not found")
        );
        if (!userApplication.getPaymentStatus().name().equals(PaymentStatus.PAID.name()))
            throw new RecordBadRequestException("Payment status " + userApplication.getPaymentStatus().name());
        userApplication.setMyIdStatus(MyIdStatus.ACCEPTED);
        Pavilion pavilion = session.getPavilion();
        if (pavilion == null)
            throw new RecordNotFoundException("Pavilion not found from session");
        attachRandomComputers(userApplication, session);
        return ResponseEntity.ok(new UserMyIdDataResponseDTO(userMyIdDataRepository.save(userMyIdData), objectMapper, userApplicationRepository.save(userApplication)));
    }

    private void attachRandomComputers(UserApplication userApplication, Session session) {
        List<Computer> availableComputers = computerRepository.findAllBySession(session.getId());
        List<Computer> usedComputers = userApplicationRepository.findAllUsedComputersBySession(session.getId());
        List<Computer> unusedComputers = availableComputers.stream()
                .filter(computer -> !usedComputers.contains(computer))
                .toList();

        if (!unusedComputers.isEmpty()) {
            Computer randomComputer = unusedComputers.get(new Random().nextInt(unusedComputers.size()));
            userApplication.setComputer(randomComputer);
            userApplicationRepository.save(userApplication);
        } else {
            throw new RecordBadRequestException("No available computers to assign for this application.");
        }
    }

    public User currentUser() {
        return userRepository.findByUsername(
                SecurityContextHolder.getContext().getAuthentication().getName()
        );
    }


    public ResponseEntity<?> me() throws JsonProcessingException {
        User user = currentUser();
        UserMyIdData userMyIdData = userMyIdDataRepository.findByUserId(user.getId()).orElse(null);
        return ResponseEntity.ok(
                new UserDTO(user, userMyIdData, objectMapper)
        );
    }


    public ResponseEntity<?> searchBySession(Long id, Pagination<Search> pagination) {
        Page<User> userPage;
        if (pagination.getSearch().getValue() != null && !pagination.getSearch().getValue().isEmpty()) {
            userPage = searchBySession(id, pagination.getSearch().getValue().toLowerCase(), pagination);
        } else {
            userPage = searchBySession(id, "", pagination);
        }
        List<UserDTO> userDTOS = new ArrayList<>();
        for (User user : userPage.getContent()) {
            userDTOS.add(
                    new UserDTO(userApplicationRepository.findByUserAndSession(user.getId(), id).orElse(null), questionsRepository)
            );
        }
        return ResponseEntity.ok(new ResponseDto<>(ResponseDto.States.SUCCESS, HttpStatus.OK, 200, null, PageWrapper.builder().list(userDTOS).total(userPage.getTotalElements()).build()));
    }

    public Page<User> searchBySession(Long sessionId, String value, Pagination<Search> pagination) {
        Pageable paging = Utils.getPageableFromPagination(pagination);
        Page<User> pagedResult;
        if (!value.isEmpty()) {
            pagedResult = userRepository.findAllBySessionAndSearch(value, sessionId, paging);
        } else {
            pagedResult = userRepository.findAllBySession(sessionId, paging);
        }
        return pagedResult;
    }

    public ResponseEntity<?> checkTmpCode(Long id, String code) {
        User user = userRepository.findById(id).orElseThrow(() -> new RecordNotFoundException("User not found with id " + id));
        if (user.getTmpCode() != null && user.getTmpCode().equals(code)) {
            user.setStatus(Status.ACTIVE);
            userRepository.save(user);
            return ResponseEntity.ok("SUCCESS");
        }
        throw new RecordBadRequestException("Codes doesn't match");
    }
}