package project.dto.payme;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class ResultFormCheckTransaction {

    @JsonProperty(value = "cancel_time")
    private Long cancelTime;

    @JsonProperty(value = "create_time")
    private Long createTime;

    @JsonProperty(value = "perform_time")
    private Long performTime;

    private Integer reason;

    private Integer state;

    private String transaction;

    public ResultFormCheckTransaction(Long cancelTime, Long createTime, Long performTime, Integer reason, Integer state, String transaction) {
        this.cancelTime = cancelTime;
        this.createTime = createTime;
        this.performTime = performTime;
        this.reason = reason;
        this.state = state;
        this.transaction = transaction;
    }

}
