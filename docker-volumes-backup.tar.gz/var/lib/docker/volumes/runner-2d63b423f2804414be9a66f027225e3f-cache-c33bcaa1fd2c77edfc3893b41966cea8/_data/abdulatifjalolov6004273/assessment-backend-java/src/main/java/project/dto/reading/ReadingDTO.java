package project.dto.reading;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import project.model.entity.reading.Reading;
import project.repository.QuestionsRepository;

import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ReadingDTO {

    private Long id;

    private String name;

    private Set<PassageDTO> passage;

    private List<Long> passageIds;

    private String time;

    public ReadingDTO(Reading reading, QuestionsRepository questionsRepository) {
        setId(reading.getId());
        setTime(reading.getTime());
        setName(reading.getName());
        setPassage(reading.getPassages().stream().map((a) -> new PassageDTO(a, questionsRepository)).collect(Collectors.toSet()));
    }
    public ReadingDTO(Reading reading) {
        setId(reading.getId());
        setTime(reading.getTime());
        setName(reading.getName());
    }

}
