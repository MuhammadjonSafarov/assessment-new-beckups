package project.dto.speaking;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import project.dto.FileDto;
import project.model.entity.speaking.Speaking;
import project.model.enums.Status;

import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class SpeakingDTO {

    private Long id;

    private String name;

    private FileDto file;

    private Long fileId;

    private Status status;

    private Set<SpeakingPartsDTO> speakingParts;

    private List<Long> speakingPartIds;

    public SpeakingDTO(Speaking speaking) {
        setId(speaking.getId());
        setName(speaking.getName());
        if (speaking.getFile() != null) {
            setFile(new FileDto(speaking.getFile()));
        }
        setStatus(speaking.getStatus());
        setSpeakingParts(speaking.getSpeakingParts().stream().map(SpeakingPartsDTO::new).collect(Collectors.toSet()));
    }

}
