package project.model.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.*;
import project.model.entity.speaking.SpeakingParts;

import javax.persistence.*;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import static javax.persistence.GenerationType.SEQUENCE;

@AllArgsConstructor
@Getter
@Setter
@Entity
@NoArgsConstructor
@Builder
@Table(name = "user_application_answers")
public class UserApplicationAnswer {

    @Id
    @GeneratedValue(strategy = SEQUENCE, generator = "USER_APPLICATION_ANSWER_SEQUENCE")
    @SequenceGenerator(sequenceName = "USER_APPLICATION_ANSWER_SEQUENCE", allocationSize = 1, name = "USER_APPLICATION_ANSWER_SEQUENCE")
    @Column(name = "id", nullable = false, updatable = false)
    private Long id;

    private Long questionId;

    @ElementCollection
    private List<Long> answers;

    @Column(columnDefinition = "TEXT")
    private String body;

    @OneToOne
    private SpeakingParts speakingPart;

    @OneToOne
    private File speakingAnswerFile;

    @ManyToMany(mappedBy = "listeningAnswers")
    @JsonIgnore
    private Set<UserApplication> listeningApplications = new HashSet<>();

    @ManyToMany(mappedBy = "readingAnswers")
    @JsonIgnore
    private Set<UserApplication> readingApplications = new HashSet<>();

    @ManyToMany(mappedBy = "writingAnswers")
    @JsonIgnore
    private Set<UserApplication> writingApplications = new HashSet<>();

    @ManyToMany(mappedBy = "speakingAnswers")
    @JsonIgnore
    private Set<UserApplication> speakingApplications = new HashSet<>();

}
