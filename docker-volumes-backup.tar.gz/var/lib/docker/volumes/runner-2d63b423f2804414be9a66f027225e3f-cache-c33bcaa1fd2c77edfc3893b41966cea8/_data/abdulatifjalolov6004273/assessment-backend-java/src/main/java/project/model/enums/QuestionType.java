package project.model.enums;

public enum QuestionType {

    LISTENING, READING, WRITING, SPEAKING

}
