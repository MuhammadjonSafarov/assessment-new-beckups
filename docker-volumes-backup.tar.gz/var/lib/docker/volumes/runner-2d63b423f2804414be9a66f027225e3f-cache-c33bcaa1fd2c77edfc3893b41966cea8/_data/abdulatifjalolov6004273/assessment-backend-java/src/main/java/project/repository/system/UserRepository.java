package project.repository.system;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.data.repository.query.QueryByExampleExecutor;
import org.springframework.stereotype.Repository;
import project.model.entity.File;
import project.model.entity.system.User;

import java.util.List;

/**
 * Repository interface that extends {@link JpaRepository} for class {@link User}.
 */
@Repository
public interface UserRepository extends JpaRepository<User, Long>, PagingAndSortingRepository<User, Long>, QueryByExampleExecutor<User> {

    @Query("select u from User u where u.status = 'ACTIVE' and u.username = ?1 ")
    User findByUsername(String name);

    @Query("select u from User u where u.username = ?1 ")
    User findByUsernameAll(String name);

    @Query("select u from User u where u.status = 'ACTIVE' and u.phone = ?1 ")
    User findByPhone(String phone);

    @Query("select u from User u where u.status = 'ACTIVE' and lower(u.passportSerial) = ?1 and u.passportNumber = ?2 ")
    User findByPassportSerialAndPassportNumber(String passportSerial, String passportNumber);

    @Query("select u from User u where u.status = 'ACTIVE' and u.id = ?1 ")
    User findByIdActive(Long id);

    @Query("SELECT r.name FROM User u LEFT JOIN u.roles r WHERE u.id = ?1 and u.status = 'ACTIVE' ORDER BY r.name")
    List<String> findRoleNames(Long userId);

    @Query("SELECT r.id FROM User u LEFT JOIN u.roles r WHERE u.id = ?1 and u.status = 'ACTIVE' ORDER BY r.name")
    List<Long> findRoleIds(Long userId);

    @Query("select u from User u " +
            "where u.status = 'ACTIVE' " +
            "and (lower(u.firstName) like %?1% " +
            "or lower(u.lastName) like %?1% " +
            "or lower(u.middleName) like %?1%) and (u.isNomzod = false or u.isNomzod is null) order by u.firstName ")
    Page<User> findAllBySearch(String value, Pageable pageable);

    @Query("select u from User u where u.status = 'ACTIVE' and (u.isNomzod = false or u.isNomzod is null) order by u.firstName ")
    Page<User> findAllUsers(Pageable pageable);

    @Query("select u from User u " +
            "where u.status = 'ACTIVE' " +
            "and (lower(u.firstName) like %?1% " +
            "or lower(u.lastName) like %?1% " +
            "or lower(u.middleName) like %?1%) and u.isNomzod = true order by u.firstName ")
    Page<User> findAllNomzodBySearch(String value, Pageable pageable);

    @Query("select u from User u where u.status = 'ACTIVE' and u.isNomzod = true order by u.firstName ")
    Page<User> findAllNomzodUsers(Pageable pageable);

    @Query("select u from User u " +
            "left join Role r on r member of u.roles " +
            "where u.status = 'ACTIVE' " +
            "and (u.isNomzod = false or u.isNomzod is null) " +
            "and r.name = ?2 " +
            "and (lower(u.firstName) like %?1% " +
            "or lower(u.lastName) like %?1% " +
            "or lower(u.middleName) like %?1%) order by u.firstName ")
    Page<User> findAllBySearch(String value, String roleName, Pageable pageable);

    @Query("select u from User u " +
            "left join Role r on r member of u.roles " +
            "where u.status = 'ACTIVE' and (u.isNomzod = false or u.isNomzod is null) and r.name = ?1 order by u.firstName ")
    Page<User> findAllUsers(String roleName, Pageable pageable);

    @Query("select u from User u " +
            "left join Session s on u member of s.users " +
            "where s.id = ?1 and s.status = 'ACTIVE' " +
            "and u.status = 'ACTIVE' ")
    Page<User> findAllBySession(Long sessionId, Pageable paging);

    @Query("select u from User u " +
            "left join Session s on u member of s.users " +
            "where s.id = ?2 and s.status = 'ACTIVE' " +
            "and u.status = 'ACTIVE' and " +
            "(lower(u.firstName) like %?1% or lower(u.lastName) like %?1% or lower(u.middleName) like %?1%) ")
    Page<User> findAllBySessionAndSearch(String value, Long sessionId, Pageable paging);

    @Query("SELECT u.file FROM User u WHERE u.file IS NOT NULL")
    List<File> findAllLinkedFiles();

    @Query("SELECT u.passportFile FROM User u WHERE u.passportFile IS NOT NULL")
    List<File> findAllLinkedPassportFiles();

}
