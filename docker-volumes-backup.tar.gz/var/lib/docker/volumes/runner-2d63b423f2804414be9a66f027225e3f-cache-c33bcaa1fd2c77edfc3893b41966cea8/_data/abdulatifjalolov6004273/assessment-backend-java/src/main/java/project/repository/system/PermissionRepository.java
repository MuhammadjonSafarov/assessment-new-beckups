package project.repository.system;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import project.model.entity.system.Permission;
import project.model.enums.Type;

import java.util.List;
import java.util.Optional;
import java.util.Set;

@Repository
public interface PermissionRepository extends CrudRepository<Permission, Long> {

    Permission findByName(String name);

    @Query(value = "SELECT p FROM Permission p WHERE p.id NOT IN (SELECT p.id FROM Permission p LEFT JOIN p.roles r WHERE r.id = ?1)")
    List<Permission> findNotInRole(Long roleId);

    @Query("select p from Permission p where p.status = 'ACTIVE' and p.id = ?1 ")
    Optional<Permission> findByIdActive(Long aLong);

    @Query("select p from Permission p where p.status = 'ACTIVE' order by p.name ")
    Set<Permission> findAllActive();

    @Query("select p from Permission p " +
            "where p.status = 'ACTIVE' " +
            "and lower(p.name) like %?1% and p.type in ?2 order by p.name ")
    Page<Permission> findAllBySearch(String value, List<Type> types, Pageable pageable);

    @Query("select p from Permission p where p.status = 'ACTIVE' and p.type in ?1 order by p.name ")
    Page<Permission> findAllPermissions(List<Type> types, Pageable pageable);
}
