package project.model.enums;

public enum ExamType {
    RETAKE, EXAM
}
