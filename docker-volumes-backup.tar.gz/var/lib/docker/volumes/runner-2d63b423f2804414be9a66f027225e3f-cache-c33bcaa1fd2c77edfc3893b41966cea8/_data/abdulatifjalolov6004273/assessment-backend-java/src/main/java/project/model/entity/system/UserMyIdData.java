package project.model.entity.system;

import lombok.*;

import javax.persistence.*;

import static javax.persistence.GenerationType.SEQUENCE;

@AllArgsConstructor
@Getter
@Setter
@Entity
@NoArgsConstructor
@Builder
@Table(name = "user_myid_datas")
public class UserMyIdData {

    @Id
    @GeneratedValue(strategy = SEQUENCE, generator = "USER_MYID_DATA_SEQUENCE")
    @SequenceGenerator(sequenceName = "USER_MYID_DATA_SEQUENCE", allocationSize = 1, name = "USER_MYID_DATA_SEQUENCE")
    @Column(name = "id", nullable = false, updatable = false)
    private Long id;

    @Column(columnDefinition = "TEXT")
    private String myIdData;

    @ManyToOne
    private User user;

}
