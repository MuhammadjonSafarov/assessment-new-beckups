package project.controller.listening;

import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import project.dto.listening.AudiosDTO;
import project.model.Pagination;
import project.service.listening.AudiosService;
import project.utility.Search;


@RestController
@RequiredArgsConstructor
@RequestMapping("/api/v1/audio")
@SecurityRequirement(name = "Bearer Authentication")
public class AudiosController {

    private final AudiosService audiosService;

    @PostMapping
    @ResponseStatus(HttpStatus.OK)
    public ResponseEntity<?> create(
            @RequestBody AudiosDTO audiosDTO
            ) {
        return audiosService.create(audiosDTO);
    }

    @PutMapping("/{id}")
    @ResponseStatus(HttpStatus.OK)
    public ResponseEntity<?> update(
            @RequestBody AudiosDTO audiosDTO,
            @PathVariable Long id
    ) {
        return audiosService.update(id, audiosDTO);
    }

    @GetMapping("/{id}")
    @ResponseStatus(HttpStatus.OK)
    public ResponseEntity<?> get(
            @PathVariable Long id
    ) {
        return audiosService.get(id);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.OK)
    public ResponseEntity<?> delete(
            @PathVariable Long id
    ) {
        return audiosService.delete(id);
    }

    @PostMapping("/list-search")
    @ResponseStatus(HttpStatus.OK)
    public ResponseEntity<?> listSearch(
            @RequestBody Pagination<Search> pagination
    ) {
        return audiosService.search(pagination);
    }

}
