package project.service.writing;

import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import project.dto.ResponseDto;
import project.dto.writing.WritingDTO;
import project.exception.RecordBadRequestException;
import project.exception.RecordNotFoundException;
import project.model.Pagination;
import project.model.entity.writing.Writing;
import project.model.enums.Status;
import project.repository.QuestionsRepository;
import project.repository.writing.WritingPartsRepository;
import project.repository.writing.WritingRepository;
import project.utility.PageWrapper;
import project.utility.Search;
import project.utility.Utils;

import java.util.HashSet;
import java.util.List;

@Service
@RequiredArgsConstructor
public class WritingService {

    private final WritingRepository writingRepository;
    private final WritingPartsRepository writingPartsRepository;
    private final QuestionsRepository questionsRepository;

    public ResponseEntity<?> create(WritingDTO writingDTO) {
        writingRepository.findByName(writingDTO.getName()).ifPresent((answer) -> {
            throw new RecordBadRequestException("Writing already exists with " + writingDTO.getName());
        });
        return ResponseEntity.ok(
                new WritingDTO(
                        writingRepository.save(
                                Writing.builder()
                                        .status(Status.ACTIVE)
                                        .time(writingDTO.getTime())
                                        .writingParts((writingDTO.getWritingPartIds() != null && !writingDTO.getWritingPartIds().isEmpty()) ? new HashSet<>(writingPartsRepository.findAllById(writingDTO.getWritingPartIds())) : new HashSet<>())
                                        .name(writingDTO.getName())
                                        .build()),
                        questionsRepository)
        );
    }


    public ResponseEntity<?> update(Long id, WritingDTO writingDTO) {
        Writing writing = writingRepository.findById(id).orElseThrow(() -> new RecordNotFoundException("Writing not found with id " + id));
        if (!writing.getName().equals(writingDTO.getName())) {
            writingRepository.findByName(writingDTO.getName()).ifPresent((answer) -> {
                throw new RecordBadRequestException("Writing already exists with " + writingDTO.getName());
            });
        }
        writing.setName(writingDTO.getName());
        writing.setTime(writingDTO.getTime());
        writing.setWritingParts((writingDTO.getWritingPartIds() != null && !writingDTO.getWritingPartIds().isEmpty()) ? new HashSet<>(writingPartsRepository.findAllById(writingDTO.getWritingPartIds())) : new HashSet<>());
        return ResponseEntity.ok(new WritingDTO(writingRepository.save(writing), questionsRepository));

    }

    public ResponseEntity<?> get(Long id) {
        Writing writing = writingRepository.findById(id).orElseThrow(() -> new RecordNotFoundException("Writing not found with id " + id));
        return ResponseEntity.ok(new WritingDTO(writing, questionsRepository));
    }

    public ResponseEntity<ResponseDto<PageWrapper>> search(Pagination<Search> pagination) {
        Page<Writing> writingPage;
        if (pagination.getSearch().getValue() != null && !pagination.getSearch().getValue().isEmpty()) {
            writingPage = search(pagination.getSearch().getValue().toLowerCase(), pagination);
        } else {
            writingPage = search("", pagination);
        }
        List<WritingDTO> writingDTOs = writingPage.stream()
                .map(writing -> new WritingDTO(writing, questionsRepository))
                .toList();
        return ResponseEntity.ok(new ResponseDto<>(ResponseDto.States.SUCCESS, HttpStatus.OK, 200, null, PageWrapper.builder().list(writingDTOs).total(writingPage.getTotalElements()).build()));
    }

    public Page<Writing> search(String value, Pagination<Search> pagination) {
        Pageable paging = Utils.getPageableFromPagination(pagination);
        Page<Writing> pagedResult;
        if (!value.isEmpty()) {
            pagedResult = writingRepository.findAllBySearch(value, paging);
        } else {
            pagedResult = writingRepository.findAllWriting(paging);
        }
        return pagedResult;
    }

    public ResponseEntity<?> delete(Long id) {
        Writing writing = writingRepository.findById(id).orElseThrow(() -> new RecordNotFoundException("Writing not found with id " + id));
        writing.setStatus(Status.DELETED);
        writingRepository.save(writing);
        return ResponseEntity.ok("SUCCESS");
    }

}
