package project.repository.writing;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.data.repository.query.QueryByExampleExecutor;
import project.model.entity.writing.WritingParts;

import java.util.Optional;

public interface WritingPartsRepository extends JpaRepository<WritingParts, Long>, PagingAndSortingRepository<WritingParts, Long>, QueryByExampleExecutor<WritingParts> {

    @Query("select q from WritingParts q where q.status = 'ACTIVE' and q.name = ?1 ")
    Optional<WritingParts> findByName(String name);

    @Query("select p from WritingParts p where p.status = 'ACTIVE' and p.name like %?1% order by p.id ")
    Page<WritingParts> findAllBySearch(String value, Pageable pageable);

    @Query("select p from WritingParts p where p.status = 'ACTIVE' order by p.id ")
    Page<WritingParts> findAllWritingParts(Pageable pageable);

}
