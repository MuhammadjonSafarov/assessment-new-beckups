package project.model.enums;

public enum InnerTextType {

    FROM_TO, SQUARE

}
