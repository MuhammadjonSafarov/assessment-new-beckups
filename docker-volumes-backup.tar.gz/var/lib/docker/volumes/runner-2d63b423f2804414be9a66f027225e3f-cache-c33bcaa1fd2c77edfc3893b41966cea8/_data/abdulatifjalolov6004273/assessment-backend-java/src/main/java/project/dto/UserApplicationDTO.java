package project.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import project.dto.system.UserDTO;
import project.model.entity.UserApplication;
import project.model.enums.MyIdStatus;
import project.model.enums.PaymentStatus;
import project.repository.QuestionsRepository;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)
public class UserApplicationDTO {

    private Long id;

    private String createdDate;

    private String paymentTermDate;

    private PaymentStatus paymentStatus;

    private Long userId;

    private UserDTO user;

    private Long sessionId;

    private Long tempSessionId;

    private MyIdStatus myIdStatus;

    private SessionDTO session;

    private Long computerNumber;

    private List<UserApplicationAnswerDTO> listeningAnswers;

    private List<UserApplicationAnswerDTO> readingAnswers;

    private List<UserApplicationAnswerDTO> writingAnswers;

    private List<UserApplicationAnswerDTO> speakingAnswers;

    private String listeningDegree;

    private String readingDegree;

    private String speakingDegree;

    private String writingDegree;

    private String degree;

    private FileDto certificateFileDto;

    private Long fileId;

    private Boolean myIdStatusOfUser;

    public UserApplicationDTO(UserApplication userApplication) {
        setId(userApplication.getId());
        setCreatedDate(userApplication.getCreatedDate());
        setMyIdStatus(userApplication.getMyIdStatus());
        setPaymentTermDate(userApplication.getPaymentTermDate());
        setPaymentStatus(userApplication.getPaymentStatus());
        if (userApplication.getUser() != null)
            setUser(new UserDTO(userApplication.getUser()));
        if (userApplication.getSession() != null)
            setSession(new SessionDTO(userApplication.getSession()));
        setTempSessionId(userApplication.getTempSessionId());
        setComputerNumber(userApplication.getComputer() != null ? userApplication.getComputer().getNumber() : null);
        if (userApplication.getListeningAnswers() != null)
            setListeningAnswers(userApplication.getListeningAnswers().stream().map(UserApplicationAnswerDTO::new).toList());
        if (userApplication.getReadingAnswers() != null)
            setReadingAnswers(userApplication.getReadingAnswers().stream().map(UserApplicationAnswerDTO::new).toList());
        if (userApplication.getWritingAnswers() != null)
            setWritingAnswers(userApplication.getWritingAnswers().stream().map(UserApplicationAnswerDTO::new).toList());
        if(userApplication.getSpeakingAnswers() != null)
            setSpeakingAnswers(userApplication.getSpeakingAnswers().stream().map(UserApplicationAnswerDTO::new).toList());
        setListeningDegree(userApplication.getListeningDegree());
        setSpeakingDegree(userApplication.getSpeakingDegree());
        setReadingDegree(userApplication.getReadingDegree());
        setWritingDegree(userApplication.getWritingDegree());
        setDegree(userApplication.getDegree());
        if (userApplication.getCertificateFile() != null)
            setCertificateFileDto(new FileDto(userApplication.getCertificateFile()));
        setMyIdStatusOfUser(userApplication.getMyIdStatusOfUser());
    }

    public UserApplicationDTO(UserApplication userApplication, Long userId) {
        setId(userApplication.getId());
        if (userApplication.getSession() != null)
            setSession(new SessionDTO(userApplication.getSession()));
        setListeningDegree(userApplication.getListeningDegree());
        setSpeakingDegree(userApplication.getSpeakingDegree());
        setReadingDegree(userApplication.getReadingDegree());
        setWritingDegree(userApplication.getWritingDegree());
        setDegree(userApplication.getDegree());
        if (userApplication.getCertificateFile() != null)
            setCertificateFileDto(new FileDto(userApplication.getCertificateFile()));
        setMyIdStatusOfUser(userApplication.getMyIdStatusOfUser());
    }

    public UserApplicationDTO(UserApplication userApplication, QuestionsRepository questionsRepository) {
        setId(userApplication.getId());
        setCreatedDate(userApplication.getCreatedDate());
        setMyIdStatus(userApplication.getMyIdStatus());
        setPaymentTermDate(userApplication.getPaymentTermDate());
        setPaymentStatus(userApplication.getPaymentStatus());
        if (userApplication.getUser() != null)
            setUser(new UserDTO(userApplication.getUser()));
        if (userApplication.getSession() != null)
            setSession(new SessionDTO(userApplication.getSession()));
        setTempSessionId(userApplication.getTempSessionId());
        setComputerNumber(userApplication.getComputer() != null ? userApplication.getComputer().getNumber() : null);
        if (userApplication.getListeningAnswers() != null)
            setListeningAnswers(userApplication.getListeningAnswers().stream().map((a) -> new UserApplicationAnswerDTO(a, questionsRepository)).toList());
        if (userApplication.getReadingAnswers() != null)
            setReadingAnswers(userApplication.getReadingAnswers().stream().map((a) -> new UserApplicationAnswerDTO(a, questionsRepository)).toList());
        if (userApplication.getWritingAnswers() != null)
            setWritingAnswers(userApplication.getWritingAnswers().stream().map((a) -> new UserApplicationAnswerDTO(a, questionsRepository)).toList());
        if(userApplication.getSpeakingAnswers() != null)
            setSpeakingAnswers(userApplication.getSpeakingAnswers().stream().map((a) -> new UserApplicationAnswerDTO(a, questionsRepository)).toList());
        setListeningDegree(userApplication.getListeningDegree());
        setReadingDegree(userApplication.getReadingDegree());
        setWritingDegree(userApplication.getWritingDegree());
        setSpeakingDegree(userApplication.getSpeakingDegree());
        setDegree(userApplication.getDegree());
        if (userApplication.getCertificateFile() != null)
            setCertificateFileDto(new FileDto(userApplication.getCertificateFile()));
        setMyIdStatusOfUser(userApplication.getMyIdStatusOfUser());
    }

}
