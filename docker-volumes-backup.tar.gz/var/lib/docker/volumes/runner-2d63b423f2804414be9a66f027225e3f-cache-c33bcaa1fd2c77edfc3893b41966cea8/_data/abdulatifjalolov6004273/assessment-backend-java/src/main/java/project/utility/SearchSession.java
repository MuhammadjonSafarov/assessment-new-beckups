package project.utility;

import lombok.Data;
import lombok.NoArgsConstructor;
import project.model.enums.ExamType;

import java.util.List;

@Data
@NoArgsConstructor
public class SearchSession {
    String value;
    List<ExamType> examTypes;
}
