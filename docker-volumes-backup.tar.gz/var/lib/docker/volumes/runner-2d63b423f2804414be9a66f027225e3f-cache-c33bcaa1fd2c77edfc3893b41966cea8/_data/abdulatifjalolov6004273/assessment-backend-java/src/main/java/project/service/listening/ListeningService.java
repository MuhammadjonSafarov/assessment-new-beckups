package project.service.listening;

import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import project.dto.ResponseDto;
import project.dto.listening.ListeningDTO;
import project.exception.RecordBadRequestException;
import project.exception.RecordNotFoundException;
import project.model.Pagination;
import project.model.entity.listening.Listening;
import project.model.enums.Status;
import project.repository.listening.AudiosRepository;
import project.repository.listening.ListeningRepository;
import project.repository.QuestionsRepository;
import project.utility.PageWrapper;
import project.utility.Search;
import project.utility.Utils;

import java.util.HashSet;
import java.util.List;

@Service
@RequiredArgsConstructor
public class ListeningService {

    private final ListeningRepository listeningRepository;
    private final AudiosRepository audiosRepository;
    private final QuestionsRepository questionsRepository;

    public ResponseEntity<?> create(ListeningDTO listeningDTO) {
        listeningRepository.findByName(listeningDTO.getName()).ifPresent((answer) -> {
            throw new RecordBadRequestException("Listening already exists with " + listeningDTO.getName());
        });
        return ResponseEntity.ok(
                new ListeningDTO(
                        listeningRepository.save(
                                Listening.builder()
                                        .status(Status.ACTIVE)
                                        .time(listeningDTO.getTime())
                                        .audios((listeningDTO.getAudioIds() != null && !listeningDTO.getAudioIds().isEmpty()) ? new HashSet<>(audiosRepository.findAllById(listeningDTO.getAudioIds())) : new HashSet<>())
                                        .name(listeningDTO.getName())
                                        .build()),
                        questionsRepository)
        );
    }


    public ResponseEntity<?> update(Long id, ListeningDTO listeningDTO) {
        Listening listening = listeningRepository.findById(id).orElseThrow(() -> new RecordNotFoundException("Listening not found with id " + id));
        if (!listening.getName().equals(listeningDTO.getName())) {
            listeningRepository.findByName(listeningDTO.getName()).ifPresent((answer) -> {
                throw new RecordBadRequestException("Listening already exists with " + listeningDTO.getName());
            });
        }
        listening.setName(listeningDTO.getName());
        listening.setTime(listeningDTO.getTime());
        listening.setAudios((listeningDTO.getAudioIds() != null && !listeningDTO.getAudioIds().isEmpty()) ? new HashSet<>(audiosRepository.findAllById(listeningDTO.getAudioIds())) : new HashSet<>());
        return ResponseEntity.ok(new ListeningDTO(listeningRepository.save(listening), questionsRepository));

    }

    public ResponseEntity<?> get(Long id) {
        Listening listening = listeningRepository.findById(id).orElseThrow(() -> new RecordNotFoundException("Listening not found with id " + id));
        return ResponseEntity.ok(new ListeningDTO(listening, questionsRepository));
    }

    public ResponseEntity<ResponseDto<PageWrapper>> search(Pagination<Search> pagination) {
        Page<Listening> listeningPage;
        if (pagination.getSearch().getValue() != null && !pagination.getSearch().getValue().isEmpty()) {
            listeningPage = search(pagination.getSearch().getValue().toLowerCase(), pagination);
        } else {
            listeningPage = search("", pagination);
        }
        List<ListeningDTO> listeningDTOs = listeningPage.stream()
                .map(listening -> new ListeningDTO(listening, questionsRepository))
                .toList();
        return ResponseEntity.ok(new ResponseDto<>(ResponseDto.States.SUCCESS, HttpStatus.OK, 200, null, PageWrapper.builder().list(listeningDTOs).total(listeningPage.getTotalElements()).build()));
    }

    public Page<Listening> search(String value, Pagination<Search> pagination) {
        Pageable paging = Utils.getPageableFromPagination(pagination);
        Page<Listening> pagedResult;
        if (!value.isEmpty()) {
            pagedResult = listeningRepository.findAllBySearch(value, paging);
        } else {
            pagedResult = listeningRepository.findAllListening(paging);
        }
        return pagedResult;
    }

    public ResponseEntity<?> delete(Long id) {
        Listening listening = listeningRepository.findById(id).orElseThrow(() -> new RecordNotFoundException("Listening not found with id " + id));
        listening.setStatus(Status.DELETED);
        listeningRepository.save(listening);
        return ResponseEntity.ok("SUCCESS");
    }
}
