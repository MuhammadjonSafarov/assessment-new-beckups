package project.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.data.repository.query.QueryByExampleExecutor;
import project.dto.QuestionsDTO;
import project.model.entity.Questions;
import project.model.enums.QuestionType;

import java.util.List;
import java.util.Optional;

public interface QuestionsRepository extends JpaRepository<Questions, Long>, PagingAndSortingRepository<Questions, Long>, QueryByExampleExecutor<Questions> {

    @Query("select q from Questions q where q.status = 'ACTIVE' and q.name = ?1 ")
    Optional<Questions> findByName(String name);

    @Query("select p from Questions p where p.status = 'ACTIVE' and p.name like %?1% and p.questionType = ?2 order by p.id ")
    Page<Questions> findAllBySearch(String value, QuestionType questionType, Pageable pageable);

    @Query("select p from Questions p where p.status = 'ACTIVE' and p.questionType = ?1 order by p.id ")
    Page<Questions> findAllQuestions(QuestionType questionType, Pageable pageable);

    @Query("select new project.dto.QuestionsDTO(q) from Questions q where q.status = 'ACTIVE' and q.audios.id = ?1 ")
    List<QuestionsDTO> finAllByAudioId(Long audioId);

    @Query("select q from Questions q where q.status = 'ACTIVE' and q.audios.id = ?1 ")
    List<Questions> finAllByAudio(Long audioId);

    @Query("select new project.dto.QuestionsDTO(q) from Questions q where q.status = 'ACTIVE' and q.passages.id = ?1 ")
    List<QuestionsDTO> finAllByPassageId(Long passageId);

    @Query("select q from Questions q where q.status = 'ACTIVE' and q.passages.id = ?1 ")
    List<Questions> finAllByPassage(Long passageId);

    @Query("select new project.dto.QuestionsDTO(q) from Questions q where q.status = 'ACTIVE' and q.writingParts.id = ?1 ")
    List<QuestionsDTO> finAllByWritingPartsId(Long writingPartsId);

    @Query("select q from Questions q where q.status = 'ACTIVE' and q.writingParts.id = ?1 ")
    List<Questions> finAllByWritingParts(Long writingPartsId);
}
