package project.model.entity.reading;


import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.*;
import project.model.Auditable;
import project.model.entity.File;
import project.model.enums.InnerTextType;
import project.model.enums.Status;

import javax.persistence.*;

import java.util.HashSet;
import java.util.Set;

import static javax.persistence.GenerationType.SEQUENCE;

@AllArgsConstructor
@Getter
@Setter
@Entity
@NoArgsConstructor
@Builder
@Table(name = "passages")
public class Passage extends Auditable<String> {

    @Id
    @GeneratedValue(strategy = SEQUENCE, generator = "PASSAGE_SEQUENCE")
    @SequenceGenerator(sequenceName = "PASSAGE_SEQUENCE", allocationSize = 1, name = "PASSAGE_SEQUENCE")
    @Column(name = "id", nullable = false, updatable = false)
    private Long id;

    private String name;

    @Column(columnDefinition = "TEXT")
    private String body;

    @OneToOne
    private File file;

    @Enumerated(EnumType.STRING)
    private InnerTextType innerTextType;

//    private Long beginIndex;
//
//    private Long endIndex;
//
//    private Long startIndex1;
//
//    private Long startIndex2;
//
//    private Long startIndex3;
//
//    private Long startIndex4;

    private Boolean isParent = Boolean.FALSE;

    @Column(name = "order_number")
    private Long orderNumber;

    @ManyToMany(mappedBy = "passages")
    @JsonIgnore
    private Set<Reading> readings = new HashSet<>();

    @Enumerated(EnumType.STRING)
    private Status status;

    @ManyToMany
    @JsonIgnore
    private Set<Passage> children = new HashSet<>();

}
