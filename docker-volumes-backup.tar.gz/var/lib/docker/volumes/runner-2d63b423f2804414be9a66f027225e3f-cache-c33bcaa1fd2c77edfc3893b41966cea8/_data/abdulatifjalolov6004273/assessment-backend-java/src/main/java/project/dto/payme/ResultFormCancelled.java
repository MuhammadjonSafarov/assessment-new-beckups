package project.dto.payme;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class ResultFormCancelled {

    @JsonProperty(value = "cancel_time")
    private Long cancelTime;

    private Integer state;

    private String transaction;

    public ResultFormCancelled(Long cancelTime, Integer state, String transaction) {
        this.cancelTime = cancelTime;
        this.state = state;
        this.transaction = transaction;
    }

}
