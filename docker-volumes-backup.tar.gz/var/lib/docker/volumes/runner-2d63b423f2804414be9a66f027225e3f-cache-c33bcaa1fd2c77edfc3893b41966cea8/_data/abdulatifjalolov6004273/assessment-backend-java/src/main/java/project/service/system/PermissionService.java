package project.service.system;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import project.dto.ResponseDto;
import project.dto.system.PermissionDto;
import project.exception.RecordBadRequestException;
import project.exception.RecordNotFoundException;
import project.model.Pagination;
import project.model.entity.system.Permission;
import project.model.enums.Status;
import project.model.enums.Type;
import project.repository.system.PermissionRepository;
import project.utility.PageWrapper;
import project.utility.Search;
import project.utility.Utils;

import java.util.ArrayList;
import java.util.List;

@Service
@Slf4j
@RequiredArgsConstructor
public class PermissionService {
    private final PermissionRepository permissionRepository;


    public void savePermission(Permission permission) {
        permissionRepository.save(permission);
        log.info("IN save - permission: {} successfully saved", permission);
    }

    public Permission getByPermissionId(Long id) {
        Permission permission = permissionRepository.findById(id).orElse(null);
        if (permission == null) {
            log.warn("IN findById - no permission found by id: {}", id);
            return null;
        }

        log.info("IN findById - permission: {} found by id: {}", permission, id);
        return permission;
    }

    public void deletePermission(Long id) {
        permissionRepository.deleteById(id);
        log.info("IN delete - permission with id: {} successfully deleted", id);
    }

    public Permission getPermissionByName(String name) {
        return permissionRepository.findByName(name);
    }

    public ResponseEntity<?> create(PermissionDto permissionDto) {
        if (permissionRepository.findByName(permissionDto.getName()) != null) {
            throw new RecordBadRequestException("Permission with name " + permissionDto.getName() + " already exists");
        }
        Permission permission = PermissionDto.of(permissionDto);
        if (permissionDto.getType().equals(Type.ADMINISTRATOR.name()))
            permission.setType(Type.ADMINISTRATOR);
        else
            permission.setType(Type.MONITORING);
        return ResponseEntity.ok(
                new PermissionDto(permissionRepository.save(permission))
        );
    }

    public ResponseEntity<?> update(PermissionDto permissionDto, Long id) {
        Permission permission = permissionRepository.findByIdActive(id).orElseThrow(
                () -> new RecordNotFoundException("Not found")
        );
        Permission newPermission = Permission.of(permission, permissionDto);
        if (permissionDto.getType().equals(Type.ADMINISTRATOR.name()))
            newPermission.setType(Type.ADMINISTRATOR);
        else
            newPermission.setType(Type.MONITORING);
        return ResponseEntity.ok(
                new PermissionDto(permissionRepository.save(newPermission))
        );
    }

    public ResponseEntity<?> delete(Long id) {
        Permission permission = permissionRepository.findByIdActive(id).orElseThrow(
                () -> new RecordNotFoundException("Not found")
        );
        permission.setStatus(Status.DELETED);
        permissionRepository.save(permission);
        return ResponseEntity.ok("SUCCESS");
    }

    public ResponseEntity<?> get(Long id) {
        Permission permission = permissionRepository.findByIdActive(id).orElseThrow(
                () -> new RecordNotFoundException("Not found")
        );
        return ResponseEntity.ok(
                new PermissionDto(permission)
        );
    }

    public ResponseEntity<ResponseDto<PageWrapper>> search(Pagination<Search> pagination, String type) {
        Page<Permission> permissionPage;
        if (pagination.getSearch().getValue() != null && !pagination.getSearch().getValue().isEmpty()) {
            permissionPage = search(pagination.getSearch().getValue().toLowerCase(), type, pagination);
        } else {
            permissionPage = search("", type, pagination);
        }
        List<PermissionDto> permissionDtos = permissionPage.getContent().stream().map(PermissionDto::new).toList();
        return ResponseEntity.ok(new ResponseDto<>(ResponseDto.States.SUCCESS, HttpStatus.OK, 200, null, PageWrapper.builder().list(permissionDtos).total(permissionPage.getTotalElements()).build()));
    }

    public Page<Permission> search(String value, String type, Pagination<Search> pagination) {
        List<Type> types = new ArrayList<>(List.of(Type.ADMINISTRATOR, Type.MONITORING));
        if (type.equals(Type.ADMINISTRATOR.name()))
            types.remove(Type.MONITORING);
        else if (type.equals(Type.MONITORING.name()))
            types.remove(Type.ADMINISTRATOR);
        Pageable paging = Utils.getPageableFromPagination(pagination);
        Page<Permission> pagedResult;
        if (!value.isEmpty()) {
            pagedResult = permissionRepository.findAllBySearch(value, types, paging);
        } else {
            pagedResult = permissionRepository.findAllPermissions(types, paging);
        }
        return pagedResult;
    }


}
