package project.model.entity.system;

import lombok.*;

import javax.persistence.*;

import static javax.persistence.GenerationType.SEQUENCE;

@AllArgsConstructor
@Getter
@Setter
@Entity
@NoArgsConstructor
@Builder
@Table(name = "eskiz_token")
public class EskizToken {

    @Id
    @GeneratedValue(strategy = SEQUENCE, generator = "ESKIZ_TOKEN_SEQUENCE")
    @SequenceGenerator(sequenceName = "ESKIZ_TOKEN_SEQUENCE", allocationSize = 1, name = "ESKIZ_TOKEN_SEQUENCE")
    @Column(name = "id", nullable = false, updatable = false)
    private Long id;

    @Column(columnDefinition = "TEXT")
    private String token;

}
