package project.controller.reading;

import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import project.dto.reading.ReadingDTO;
import project.model.Pagination;
import project.service.reading.ReadingService;
import project.utility.Search;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/v1/reading")
@SecurityRequirement(name = "Bearer Authentication")
public class ReadingController {

    private final ReadingService readingService;

    @PostMapping
    @ResponseStatus(HttpStatus.OK)
    public ResponseEntity<?> create(
            @RequestBody ReadingDTO readingDTO
    ) {
        return readingService.create(readingDTO);
    }

    @PutMapping("/{id}")
    @ResponseStatus(HttpStatus.OK)
    public ResponseEntity<?> update(
            @RequestBody ReadingDTO readingDTO,
            @PathVariable Long id
    ) {
        return readingService.update(id, readingDTO);
    }

    @GetMapping("/{id}")
    @ResponseStatus(HttpStatus.OK)
    public ResponseEntity<?> get(
            @PathVariable Long id
    ) {
        return readingService.get(id);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.OK)
    public ResponseEntity<?> delete(
            @PathVariable Long id
    ) {
        return readingService.delete(id);
    }

    @PostMapping("/list-search")
    @ResponseStatus(HttpStatus.OK)
    public ResponseEntity<?> listSearch(
            @RequestBody Pagination<Search> pagination
    ) {
        return readingService.search(pagination);
    }

}
