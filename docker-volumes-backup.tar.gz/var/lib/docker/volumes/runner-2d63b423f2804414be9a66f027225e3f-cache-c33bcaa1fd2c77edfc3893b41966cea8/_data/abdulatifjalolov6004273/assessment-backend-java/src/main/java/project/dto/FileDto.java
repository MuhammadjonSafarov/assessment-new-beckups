package project.dto;

import lombok.*;
import project.model.entity.File;


@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class FileDto {
    @Getter
    private Long id;

    @Getter
    private String name;

    @Getter
    private String contentType;

    @Getter
    private String absolutePath;

    @Getter
    private Long size;

    private String url;

    public String getUrl() {
        return url != null ? url.substring(1) : null;
    }

    public FileDto(File file) {
        if (file != null) {
            setId(file.getId());
            setName(file.getName());
            setContentType(file.getContentType());
            setAbsolutePath(file.getAbsolutePath());
            setSize(file.getSize());
            setUrl(file.getUrl());
        }
    }
}
