package project.controller.reading;

import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import project.dto.reading.PassageDTO;
import project.model.Pagination;
import project.service.reading.PassageService;
import project.utility.Search;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/v1/passsage")
@SecurityRequirement(name = "Bearer Authentication")
public class PassageController {

    private final PassageService passageService;

    @PostMapping
    @ResponseStatus(HttpStatus.OK)
    public ResponseEntity<?> create(
            @RequestBody PassageDTO passageDTO
    ) {
        return passageService.create(passageDTO);
    }

    @PutMapping("/{id}")
    @ResponseStatus(HttpStatus.OK)
    public ResponseEntity<?> update(
            @RequestBody PassageDTO passageDTO,
            @PathVariable Long id
    ) {
        return passageService.update(id, passageDTO);
    }

    @GetMapping("/{id}")
    @ResponseStatus(HttpStatus.OK)
    public ResponseEntity<?> get(
            @PathVariable Long id
    ) {
        return passageService.get(id);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.OK)
    public ResponseEntity<?> delete(
            @PathVariable Long id
    ) {
        return passageService.delete(id);
    }

    @PostMapping("/list-search")
    @ResponseStatus(HttpStatus.OK)
    public ResponseEntity<?> listSearch(
            @RequestBody Pagination<Search> pagination
    ) {
        return passageService.search(pagination, Boolean.TRUE);
    }

    @PostMapping("/list-search/children")
    @ResponseStatus(HttpStatus.OK)
    public ResponseEntity<?> listSearchChildren(
            @RequestBody Pagination<Search> pagination
    ) {
        return passageService.search(pagination, Boolean.FALSE);
    }

}
