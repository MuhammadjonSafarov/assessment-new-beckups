package project.model.entity.listening;

import lombok.*;
import project.model.Auditable;
import project.model.enums.Status;

import javax.persistence.*;

import java.util.HashSet;
import java.util.Set;

import static javax.persistence.FetchType.LAZY;
import static javax.persistence.GenerationType.SEQUENCE;

@AllArgsConstructor
@Getter
@Setter
@Entity
@NoArgsConstructor
@Builder
@Table(name = "listening")
public class Listening extends Auditable<String> {

    @Id
    @GeneratedValue(strategy = SEQUENCE, generator = "LISTENING_SEQUENCE")
    @SequenceGenerator(sequenceName = "LISTENING_SEQUENCE", allocationSize = 1, name = "LISTENING_SEQUENCE")
    @Column(name = "id", nullable = false, updatable = false)
    private Long id;

    private String name;

    @ManyToMany(fetch = LAZY)
    @JoinTable(name = "listening_audios",
            joinColumns = {@JoinColumn(name = "listening_id", referencedColumnName = "id")},
            inverseJoinColumns = {@JoinColumn(name = "audio_id", referencedColumnName = "id")})
    private Set<Audios> audios = new HashSet<>();

    private String time;

    @Enumerated(EnumType.STRING)
    private Status status;

}
