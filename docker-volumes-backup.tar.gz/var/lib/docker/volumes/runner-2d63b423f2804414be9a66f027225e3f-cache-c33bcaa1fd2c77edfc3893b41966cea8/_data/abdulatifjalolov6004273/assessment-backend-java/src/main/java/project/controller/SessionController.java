package project.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import project.dto.SessionDTO;
import project.model.Pagination;
import project.service.SessionService;
import project.service.system.UserService;
import project.utility.Search;
import project.utility.SearchSession;

import java.text.ParseException;

@RestController
@RequestMapping("/api/v1/session")
@RequiredArgsConstructor
@SecurityRequirement(name = "Bearer Authentication")
public class SessionController {

    private final SessionService sessionService;
    private final UserService userService;

    @PostMapping
    @ResponseStatus(HttpStatus.OK)
    public ResponseEntity<?> create(
            @RequestBody SessionDTO sessionDTO
    ) throws ParseException {
        return sessionService.create(sessionDTO);
    }

    @PutMapping("/{id}")
    @ResponseStatus(HttpStatus.OK)
    public ResponseEntity<?> update(
            @RequestBody SessionDTO sessionDTO,
            @PathVariable Long id
    ) throws ParseException {
        return sessionService.update(sessionDTO, id);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.OK)
    public ResponseEntity<?> delete(
            @PathVariable Long id
    ) {
        return sessionService.delete(id);
    }

    @GetMapping("/{id}")
    @ResponseStatus(HttpStatus.OK)
    public ResponseEntity<?> get(
            @PathVariable Long id
    ) throws ParseException {
        return sessionService.get(id);
    }


    @PostMapping("/list-search")
    @ResponseStatus(HttpStatus.OK)
    public ResponseEntity<?> listSearch(
            @RequestBody Pagination<SearchSession> pagination
    ) throws ParseException {
        return sessionService.search(pagination);
    }

    @GetMapping("/{testTypeId}/{pavilionId}/{examType}")
    @ResponseStatus(HttpStatus.OK)
    public ResponseEntity<?> getByTestTypeAndPavilion(
            @PathVariable Long testTypeId,
            @PathVariable Long pavilionId,
            @PathVariable String examType
            ) {
        return sessionService.getByTestTypeAndPavilion(testTypeId, pavilionId, examType);
    }

    @PostMapping("/user/{userId}")
    @ResponseStatus(HttpStatus.OK)
    public ResponseEntity<?> getAllByUser(
            @PathVariable Long userId,
            @RequestBody Pagination<Search> pagination
    ) throws ParseException {
        return sessionService.search(userId, pagination);
    }

    @PostMapping("/users/{id}")
    @ResponseStatus(HttpStatus.OK)
    public ResponseEntity<?> getUsersById(
            @PathVariable Long id,
            @RequestBody Pagination<Search> pagination
    ) {
        return userService.searchBySession(id, pagination);
    }

}
