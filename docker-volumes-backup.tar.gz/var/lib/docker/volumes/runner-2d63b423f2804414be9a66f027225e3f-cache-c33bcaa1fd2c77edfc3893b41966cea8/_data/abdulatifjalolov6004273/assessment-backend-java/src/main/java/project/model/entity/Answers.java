package project.model.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.*;
import project.model.Auditable;
import project.model.enums.Status;

import javax.persistence.*;

import java.util.HashSet;
import java.util.Set;

import static javax.persistence.GenerationType.SEQUENCE;

@AllArgsConstructor
@Getter
@Setter
@Entity
@NoArgsConstructor
@Builder
@Table(name = "answers")
public class Answers extends Auditable<String> {

    @Id
    @GeneratedValue(strategy = SEQUENCE, generator = "ANSWERS_SEQUENCE")
    @SequenceGenerator(sequenceName = "ANSWERS_SEQUENCE", allocationSize = 1, name = "ANSWERS_SEQUENCE")
    @Column(name = "id", nullable = false, updatable = false)
    private Long id;

    private String answer;

    private Boolean isCorrect = false;

    @ManyToMany(mappedBy = "answers")
    @JsonIgnore
    private Set<Questions> questions = new HashSet<>();

    @Enumerated(EnumType.STRING)
    private Status status;

}
