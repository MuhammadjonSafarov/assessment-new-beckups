package project.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.data.repository.query.QueryByExampleExecutor;
import project.model.MyIdStatus;

public interface MyIdStatusRepository extends JpaRepository<MyIdStatus, Long>, PagingAndSortingRepository<MyIdStatus, Long>, QueryByExampleExecutor<MyIdStatus> {

}
