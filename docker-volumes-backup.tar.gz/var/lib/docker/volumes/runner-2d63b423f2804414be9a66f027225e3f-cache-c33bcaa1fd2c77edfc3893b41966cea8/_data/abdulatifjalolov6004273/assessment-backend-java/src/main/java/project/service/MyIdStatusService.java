package project.service;

import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import project.exception.RecordNotFoundException;
import project.model.MyIdStatus;
import project.repository.MyIdStatusRepository;

import java.util.Optional;

@Service
@RequiredArgsConstructor
public class MyIdStatusService {

    private final MyIdStatusRepository myIdStatusRepository;

    public ResponseEntity<?> changeStatus() {
        Optional<MyIdStatus> optionalMyIdStatus = myIdStatusRepository.findById(1L);
        if (optionalMyIdStatus.isEmpty()) {
            return ResponseEntity.ok(
                    myIdStatusRepository.save(MyIdStatus.builder().active(false).build())
            );
        }
        MyIdStatus myIdStatus = optionalMyIdStatus.get();
        myIdStatus.setActive(!myIdStatus.getActive());
        return ResponseEntity.ok(myIdStatusRepository.save(myIdStatus));
    }

    public ResponseEntity<?> getMyIdStatus() {
        return ResponseEntity.ok(
                myIdStatusRepository.findById(1L).orElseThrow(() -> new RecordNotFoundException("Not found"))
        );
    }
}
