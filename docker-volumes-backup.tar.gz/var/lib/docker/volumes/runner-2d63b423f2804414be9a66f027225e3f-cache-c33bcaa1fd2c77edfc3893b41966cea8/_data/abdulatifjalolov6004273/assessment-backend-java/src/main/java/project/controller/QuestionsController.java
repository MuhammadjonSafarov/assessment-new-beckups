package project.controller;

import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import project.dto.QuestionsDTO;
import project.model.Pagination;
import project.model.enums.QuestionType;
import project.service.QuestionsService;
import project.utility.Search;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/v1/question")
@SecurityRequirement(name = "Bearer Authentication")
public class QuestionsController {

    private final QuestionsService questionsService;

    @PostMapping
    @ResponseStatus(HttpStatus.OK)
    public ResponseEntity<?> create(
            @RequestBody QuestionsDTO questionsDTO
    ) {
        return questionsService.create(questionsDTO);
    }

    @PutMapping("/{id}")
    @ResponseStatus(HttpStatus.OK)
    public ResponseEntity<?> update(
            @RequestBody QuestionsDTO questionsDTO,
            @PathVariable Long id
    ) {
        return questionsService.update(id, questionsDTO);
    }

    @GetMapping("/{id}")
    @ResponseStatus(HttpStatus.OK)
    public ResponseEntity<?> get(
            @PathVariable Long id
    ) {
        return questionsService.get(id);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.OK)
    public ResponseEntity<?> delete(
            @PathVariable Long id
    ) {
        return questionsService.delete(id);
    }

    @PostMapping("/list-search/{questionType}")
    @ResponseStatus(HttpStatus.OK)
    public ResponseEntity<?> listSearch(
            @RequestBody Pagination<Search> pagination,
            @PathVariable QuestionType questionType
    ) {
        return questionsService.search(questionType, pagination);
    }

}
