package project.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.*;
import project.model.entity.Computer;
import project.model.enums.Status;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ComputerDTO {

    private Long id;

    private Long number;

    private Status status;

    private JsonNode info;

//    private PavilionDto pavilion;

    private SessionDTO session;

    private Integer responseId;

    public ComputerDTO(Computer computer, ObjectMapper objectMapper) throws JsonProcessingException {
        setId(computer.getId());
        setNumber(computer.getNumber());
        setStatus(computer.getStatus());
        if (computer.getInfo() != null)
            setInfo(objectMapper.readTree(computer.getInfo()));
//        if (computer.getPavilion() != null)
//            setPavilion(new PavilionDto(computer.getPavilion()));
        if (computer.getSession() != null)
            setSession(new SessionDTO(computer.getSession()));
    }

}
