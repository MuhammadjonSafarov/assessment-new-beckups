package project.model.entity;

import lombok.*;
import project.model.enums.Status;

import javax.persistence.*;

import static javax.persistence.GenerationType.SEQUENCE;

@AllArgsConstructor
@Getter
@Setter
@Entity
@NoArgsConstructor
@Builder
@Table(name = "computers")
public class Computer {

    @Id
    @GeneratedValue(strategy = SEQUENCE, generator = "COMPUTER_SEQUENCE")
    @SequenceGenerator(sequenceName = "COMPUTER_SEQUENCE", allocationSize = 1, name = "COMPUTER_SEQUENCE")
    @Column(name = "id", nullable = false, updatable = false)
    private Long id;

    private Long number;

    @Column(columnDefinition = "TEXT")
    private String info;

    @Enumerated(EnumType.STRING)
    private Status status;

//    @ManyToOne
//    private Pavilion pavilion;

    @ManyToOne
    private Session session;

}
