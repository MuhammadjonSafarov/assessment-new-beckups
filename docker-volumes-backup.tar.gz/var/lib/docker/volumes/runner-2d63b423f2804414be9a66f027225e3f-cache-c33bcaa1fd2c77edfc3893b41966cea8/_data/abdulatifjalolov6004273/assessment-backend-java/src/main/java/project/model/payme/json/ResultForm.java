package project.model.payme.json;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class ResultForm {

    @JsonIgnore
    private Long id;

    @JsonProperty(value = "cancel_time")
    private Long cancelTime;

    @JsonProperty(value = "create_time")
    private Long createTime;

    @JsonProperty(value = "perform_time")
    private Long performTime;

    private Integer reason;

    private Integer state;

    private String transaction;


    //CREATE TRANACTION DA KETADI BIZDAN
    public ResultForm(Long createTime, Integer state, String transaction) {
        this.createTime = createTime;
        this.state = state;
        this.transaction = transaction;
    }

    public ResultForm(Long cancelTime, Long createTime, Long performTime, Integer reason, Integer state, String transaction) {
        this.cancelTime = cancelTime;
        this.createTime = createTime;
        this.performTime = performTime;
        this.reason = reason;
        this.state = state;
        this.transaction = transaction;
    }

    public ResultForm(Integer state, Long performTime, String transaction) {
        this.state = state;
        this.performTime = performTime;
        this.transaction = transaction;
    }

    public ResultForm(String transaction, Integer state, Long cancelTime) {
        this.state = state;
        this.cancelTime = cancelTime;
        this.transaction = transaction;
    }

    public ResultForm(String transaction, Integer state, Long cancelTime, Integer reason) {
        this.state = state;
        this.cancelTime = cancelTime;
        this.transaction = transaction;
        this.reason = reason;
    }

    public ResultForm(Long createTime, Long performTime, Long cancelTime, String transaction, Integer state, Integer reason) {
        this.createTime = createTime;
        this.performTime = performTime;
        this.cancelTime = cancelTime;
        this.transaction = transaction;
        this.state = state;
        this.reason = reason;
    }
}
