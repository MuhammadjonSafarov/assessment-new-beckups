package project.repository.payme;

import org.springframework.data.jpa.repository.JpaRepository;
import project.model.payme.Client;

import java.util.Optional;

public interface ClientRepository extends JpaRepository<Client, Integer> {

    Optional<Client> findByPhoneNumber(String username);

    boolean existsByPhoneNumber(String username);
}