package project.utility;

import lombok.AllArgsConstructor;
import org.springframework.stereotype.Component;
import project.service.system.UserService;

@Component
@AllArgsConstructor
public class UtilComponent {
    private final UserService userService;

    public static Integer calculateOffset(Integer page, Integer limit) {
        return (limit * (page + 1)) - limit;
    }

}
