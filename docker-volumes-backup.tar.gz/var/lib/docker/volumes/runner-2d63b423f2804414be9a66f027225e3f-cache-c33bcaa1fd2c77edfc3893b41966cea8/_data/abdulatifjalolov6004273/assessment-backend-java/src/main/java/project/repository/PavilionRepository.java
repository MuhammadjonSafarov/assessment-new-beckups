package project.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.data.repository.query.QueryByExampleExecutor;
import project.model.entity.Pavilion;
import project.model.enums.ExamType;

import java.util.List;
import java.util.Optional;

public interface PavilionRepository extends JpaRepository<Pavilion, Long>, PagingAndSortingRepository<Pavilion, Long>, QueryByExampleExecutor<Pavilion> {

    @Query("select p from Pavilion p where p.status = 'ACTIVE' and p.id = ?1 ")
    Optional<Pavilion> findByIdActive(Long id);

    @Query("select p from Pavilion p where p.status = 'ACTIVE' and p.nameUz = ?1 ")
    Pavilion findByNameUzActive(String nameUz);

    @Query("select p from Pavilion p " +
            "where p.status = 'ACTIVE' " +
            "and (lower(p.nameUz) like %?1% " +
            "or lower(p.nameRu) like %?1% " +
            "or lower(p.nameEn) like %?1% " +
            "or lower(p.addressUz) like %?1% " +
            "or lower(p.addressRu) like %?1% " +
            "or lower(p.addressEn) like %?1%) order by p.nameUz")
    Page<Pavilion> findAllBySearch(String value, Pageable pageable);

    @Query("select p from Pavilion p where p.status = 'ACTIVE' order by p.nameUz ")
    Page<Pavilion> findAllPavilions(Pageable pageable);

    @Query("select distinct p from Pavilion p " +
            "left join Session s on s.pavilion.id = p.id " +
            "where s.testType.id = ?1 and s.examType = ?2 " +
            "and p.status = 'ACTIVE' " +
            "and s.status = 'ACTIVE' " +
            "and s.testType.status = 'ACTIVE' " +
            "and to_timestamp(s.startDate, 'DD-MM-YYYY HH24:MI:SS') > current_timestamp")
    List<Pavilion> findAllByTestType(Long testTypeId, ExamType examType);


}
