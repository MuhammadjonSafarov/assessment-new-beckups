package project.model.entity.system;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.*;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import project.dto.system.UserDTO;
import project.model.Auditable;
import project.model.entity.File;
import project.model.entity.Session;
import project.model.enums.Status;

import javax.persistence.*;
import javax.validation.constraints.Email;
import java.util.*;

import static javax.persistence.EnumType.STRING;
import static javax.persistence.FetchType.LAZY;
import static javax.persistence.GenerationType.SEQUENCE;

/**
 * Simple domain object that represents application user.
 */

@AllArgsConstructor
@Getter
@Setter
@Entity
@NoArgsConstructor
@Builder
@Table(name = "sys_users")
public class User extends Auditable<String> implements UserDetails {
    @Id
    @GeneratedValue(strategy = SEQUENCE, generator = "USER_SEQUENCE")
    @SequenceGenerator(sequenceName = "USER_SEQUENCE", allocationSize = 1, name = "USER_SEQUENCE")
    @Column(name = "id", nullable = false, updatable = false)
    private Long id;

    @Column(name = "username", unique = true)
    private String username;

    @Column(name = "password")
    @JsonIgnore
    private String password;

    @Enumerated(STRING)
    @Column(name = "status")
    private Status status;

    @Column(name = "first_name")
    private String firstName;

    @Column(name = "last_name")
    private String lastName;

    @Column(name = "middle_name")
    private String middleName;

    @Column(name = "phone")
    private String phone;

    @Column(name = "email")
    private String email;

    private String passportNumber;

    private String passportSerial;

    private String birthDate;

    @OneToOne
    @JsonIgnore
    private File file;

    @OneToOne
    @JsonIgnore
    private File passportFile;

    private Boolean isNomzod = false;

    @Column(name = "last_active_date")
    private Date lastActiveDate;

    @JsonIgnore
    private String tmpCode;

    @ManyToMany(fetch = LAZY)
    @JoinTable(name = "sys_user_roles",
            joinColumns = {@JoinColumn(name = "user_id", referencedColumnName = "id")},
            inverseJoinColumns = {@JoinColumn(name = "role_id", referencedColumnName = "id")})
    private List<Role> roles = new ArrayList<>();

    @ManyToMany(mappedBy = "users")
    private List<Session> sessions = new ArrayList<>();

    @JsonIgnore
    public static User of(User user, UserDTO userDto) {
        user.setFirstName(userDto.getFirstName());
        user.setLastName(userDto.getLastName());
        user.setMiddleName(userDto.getMiddleName());
        user.setPassportSerial(userDto.getPassportSerial());
        user.setPassportNumber(userDto.getPassportNumber());
        user.setBirthDate(userDto.getBirthDate());
        user.setPhone(userDto.getPhone());
        user.setEmail(userDto.getEmail());
        return user;
    }


    public void setUsername(String username) {
        this.username = username.trim();
    }

    @Override
    public Collection<? extends GrantedAuthority> getAuthorities() {
        return null;
    }

    @Override
    public boolean isAccountNonExpired() {
        return false;
    }

    @Override
    public boolean isAccountNonLocked() {
        return false;
    }

    @Override
    public boolean isCredentialsNonExpired() {
        return false;
    }

    @Override
    public boolean isEnabled() {
        return false;
    }
}
