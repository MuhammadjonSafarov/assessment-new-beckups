package project.service;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.compress.utils.FileNameUtils;
import org.apache.commons.io.FilenameUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import project.exception.RecordNotFoundException;
import project.model.entity.File;
import project.model.enums.Status;
import project.repository.FileRepository;
import project.repository.listening.AudiosRepository;
import project.repository.system.UserRepository;

import java.io.FileOutputStream;
import java.io.IOException;
import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

@Service
@RequiredArgsConstructor
@Slf4j
public class FileService {

    private final FileRepository fileRepository;
    private final UserRepository userRepository;
    private final AudiosRepository audiosRepository;


    @Value("${file.path}")
    public String filePath;

    public File storeFile(MultipartFile file) {
        try {
            String extension = FilenameUtils.getExtension(file.getOriginalFilename());
            String fileName = UUID.randomUUID() + (extension != null && extension.isEmpty() ? "" : "." + extension); // UUID + extension

            java.io.File storeFile = new java.io.File(filePath + fileName);
            FileOutputStream fos = new FileOutputStream(storeFile);
            fos.write(file.getBytes());
            fos.close();

            return fileRepository.save(
                    File.builder()
                            .name(fileName)
                            .contentType(file.getContentType())
                            .status(Status.ACTIVE)
                            .absolutePath(filePath)
                            .size(file.getSize())
                            .url(filePath + fileName)
                            .build()
            );
        } catch (IOException e) {
            log.warn("Could not store file", e);
        }
        return null;
    }

    public void deleteFile(File file) {
        file.setStatus(Status.DELETED);
        fileRepository.save(file);
        try {
            java.io.File storeFile = new java.io.File(file.getUrl());
            if (storeFile.exists()) {
                storeFile.delete();
            }
        } catch (Exception e) {
            log.warn("Could not delete file", e);
        }

    }

    public ResponseEntity<?> delete(Long id) {
        File file = fileRepository.findById(id).orElseThrow(() -> new RecordNotFoundException("File not found with id: " + id));
        deleteFile(file);
        return ResponseEntity.ok("SUCCESS");
    }

    // delete unused files
//    @Scheduled(cron = "0 0 2 * * *")
//    public void deleteUnusedFiles() {
//        java.io.File directory = new java.io.File(filePath);
//        if (directory.exists() && directory.isDirectory()) {
//            java.io.File[] filesInDirectory = directory.listFiles();
//
//            Set<String> linkedFiles = new HashSet<>();
//            userRepository.findAllLinkedFiles().forEach(file -> linkedFiles.add(file.getUrl()));
//            userRepository.findAllLinkedPassportFiles().forEach(file -> linkedFiles.add(file.getUrl()));
//            audiosRepository.findAllLinkedFiles().forEach(file -> linkedFiles.add(file.getUrl()));
//            audiosRepository.findAllLinkedAudioFiles().forEach(file -> linkedFiles.add(file.getUrl()));
//
//            if (filesInDirectory != null) {
//                for (java.io.File file : filesInDirectory) {
//                    if (!linkedFiles.contains(filePath + file.getName())) {
//                        file.delete();
//                    }
//                }
//            }
//        }
//    }
}
