package project.model.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.*;
import project.dto.PavilionDto;
import project.model.Auditable;
import project.model.enums.Status;

import javax.persistence.*;

import static javax.persistence.EnumType.STRING;
import static javax.persistence.GenerationType.SEQUENCE;

@AllArgsConstructor
@Getter
@Setter
@Entity
@NoArgsConstructor
@Builder
@Table(name = "pavilions")
public class Pavilion extends Auditable<String> {

    @Id
    @GeneratedValue(strategy = SEQUENCE, generator = "PAVILION_SEQUENCE")
    @SequenceGenerator(sequenceName = "PAVILION_SEQUENCE", allocationSize = 1, name = "PAVILION_SEQUENCE")
    @Column(name = "id", nullable = false, updatable = false)
    private Long id;

    @Column(name = "name_uz")
    private String nameUz;

    @Column(name = "name_ru")
    private String nameRu;

    @Column(name = "name_en")
    private String nameEn;

    @Column(name = "address_uz")
    private String addressUz;

    @Column(name = "address_ru")
    private String addressRu;

    @Column(name = "address_en")
    private String addressEn;

    @Column(name = "is_rent")
    private Boolean isRent = false;

    @Enumerated(STRING)
    @Column(name = "status")
    private Status status;

    @JsonIgnore
    public static Pavilion of(Pavilion pavilion, PavilionDto pavilionDto) {
        pavilion.setAddressUz(pavilionDto.getAddressUz());
        pavilion.setAddressRu(pavilionDto.getAddressRu());
        pavilion.setAddressEn(pavilionDto.getAddressEn());
        pavilion.setIsRent(pavilionDto.getIsRent());
        pavilion.setStatus(Status.valueOf(pavilionDto.getStatus()));
        pavilion.setNameUz(pavilionDto.getNameUz());
        pavilion.setNameRu(pavilionDto.getNameRu());
        pavilion.setNameEn(pavilionDto.getNameEn());
        return pavilion;
    }

}
