package project.dto.system;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import project.model.entity.system.Role;
import project.model.enums.Status;

import java.text.SimpleDateFormat;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)
public class RoleDto {

    private Long id;
    private String name;
    private String code;
    private Status status;
    private String description;
    private Boolean isGetAllPermissions;
    private String roleType;
    List<Long> permissionIds;
    List<PermissionDto> permissions;
    private String createdDate;

    public RoleDto(Role role) {
        if (role.getId() != null)
            setId(role.getId());
        setName(role.getName());
        setCode(role.getCode());
        setIsGetAllPermissions(role.getIsGetAllPermissions());
        setDescription(role.getDescription());
        setRoleType(role.getType().name());
        setStatus(role.getStatus());
        if (role.getCreatedDate() != null)
            setCreatedDate(new SimpleDateFormat("dd-MM-yyyy hh:mm:ss").format(role.getCreatedDate()));
        if (role.getPermissions() != null) {
            setPermissions(
                    role.getPermissions()
                            .stream()
                            .map(PermissionDto::new)
                            .toList()
            );
        }
    }

    @JsonIgnore
    public static Role of(RoleDto roleDto) {
        return Role.builder()
                .code("ROLE_" + roleDto.getName().toUpperCase())
                .name(roleDto.getName())
                .status(Status.ACTIVE)
                .isGetAllPermissions(roleDto.getIsGetAllPermissions())
                .description(roleDto.description)
                .build();
    }
}
