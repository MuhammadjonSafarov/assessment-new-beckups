package project.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import project.model.entity.UserApplicationAnswer;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class UserApplicationAnswerRequestDTO {

    private Long questionId;

    private List<Long> answers;

    private String body;

    private Long speakingPartId;

    private Long speakingAnswerFileId;

}
