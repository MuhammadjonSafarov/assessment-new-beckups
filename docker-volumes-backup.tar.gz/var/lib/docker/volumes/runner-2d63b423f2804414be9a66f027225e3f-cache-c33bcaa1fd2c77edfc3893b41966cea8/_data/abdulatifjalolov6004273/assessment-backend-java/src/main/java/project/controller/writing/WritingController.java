package project.controller.writing;


import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import project.dto.writing.WritingDTO;
import project.model.Pagination;
import project.service.writing.WritingService;
import project.utility.Search;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/v1/writing")
@SecurityRequirement(name = "Bearer Authentication")
public class WritingController {

    private final WritingService writingService;

    @PostMapping
    @ResponseStatus(HttpStatus.OK)
    public ResponseEntity<?> create(
            @RequestBody WritingDTO writingDTO
    ) {
        return writingService.create(writingDTO);
    }

    @PutMapping("/{id}")
    @ResponseStatus(HttpStatus.OK)
    public ResponseEntity<?> update(
            @RequestBody WritingDTO writingDTO,
            @PathVariable Long id
    ) {
        return writingService.update(id, writingDTO);
    }

    @GetMapping("/{id}")
    @ResponseStatus(HttpStatus.OK)
    public ResponseEntity<?> get(
            @PathVariable Long id
    ) {
        return writingService.get(id);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.OK)
    public ResponseEntity<?> delete(
            @PathVariable Long id
    ) {
        return writingService.delete(id);
    }

    @PostMapping("/list-search")
    @ResponseStatus(HttpStatus.OK)
    public ResponseEntity<?> listSearch(
            @RequestBody Pagination<Search> pagination
    ) {
        return writingService.search(pagination);
    }

}

