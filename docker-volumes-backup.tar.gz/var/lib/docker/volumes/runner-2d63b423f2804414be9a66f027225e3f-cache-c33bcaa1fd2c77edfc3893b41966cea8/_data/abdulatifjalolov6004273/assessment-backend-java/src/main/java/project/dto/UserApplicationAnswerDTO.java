package project.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import project.dto.speaking.SpeakingPartsDTO;
import project.model.entity.File;
import project.model.entity.UserApplicationAnswer;
import project.model.entity.Answers;
import project.model.entity.Questions;
import project.repository.QuestionsRepository;

import javax.persistence.OneToOne;
import java.util.HashSet;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class UserApplicationAnswerDTO {

    private Long id;

    private Long questionId;

    private QuestionsDTO question;

    private List<Long> answers;

    private Long speakingPartId;

    private SpeakingPartsDTO speakingPart;

    private Long speakingAnswerFileId;

    private FileDto speakingAnswerFile;

    private Boolean isCorrect;

    private String body;

    public UserApplicationAnswerDTO(UserApplicationAnswer userApplicationAnswer, QuestionsRepository questionsRepository) {
        setId(userApplicationAnswer.getId());
        setQuestionId(userApplicationAnswer.getQuestionId());
        setAnswers(userApplicationAnswer.getAnswers());
        Questions question = userApplicationAnswer.getQuestionId() != null ? questionsRepository.findById(userApplicationAnswer.getQuestionId()).orElse(null) : null;
        if (question != null) {
            setQuestion(new QuestionsDTO(question));
            if (userApplicationAnswer.getBody() == null) {
                List<Long> correctAnswersIds = question.getAnswers().stream()
                        .filter(Answers::getIsCorrect)
                        .map(Answers::getId).toList();
                setIsCorrect(userApplicationAnswer.getAnswers().size() == correctAnswersIds.size()
                        && new HashSet<>(userApplicationAnswer.getAnswers()).containsAll(correctAnswersIds));
            }
        }
        setBody(userApplicationAnswer.getBody());
        if (userApplicationAnswer.getSpeakingPart() != null)
            setSpeakingPart(new SpeakingPartsDTO(userApplicationAnswer.getSpeakingPart()));
        if (userApplicationAnswer.getSpeakingAnswerFile() != null)
            setSpeakingAnswerFile(new FileDto(userApplicationAnswer.getSpeakingAnswerFile()));
    }

    public UserApplicationAnswerDTO(UserApplicationAnswer userApplicationAnswer) {
        setId(userApplicationAnswer.getId());
        setBody(userApplicationAnswer.getBody());
        setQuestionId(userApplicationAnswer.getQuestionId());
        setAnswers(userApplicationAnswer.getAnswers());
    }

}
