package project.service.reading;

import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import project.dto.ResponseDto;
import project.dto.reading.ReadingDTO;
import project.exception.RecordBadRequestException;
import project.exception.RecordNotFoundException;
import project.model.Pagination;
import project.model.entity.reading.Reading;
import project.model.enums.Status;
import project.repository.QuestionsRepository;
import project.repository.reading.PassageRepository;
import project.repository.reading.ReadingRepository;
import project.utility.PageWrapper;
import project.utility.Search;
import project.utility.Utils;

import java.util.HashSet;
import java.util.List;

@Service
@RequiredArgsConstructor
public class ReadingService {

    private final ReadingRepository readingRepository;
    private final PassageRepository passageRepository;
    private final QuestionsRepository questionsRepository;

    public ResponseEntity<?> create(ReadingDTO readingDTO) {
        readingRepository.findByName(readingDTO.getName()).ifPresent((answer) -> {
            throw new RecordBadRequestException("Reading already exists with " + readingDTO.getName());
        });
        return ResponseEntity.ok(
                new ReadingDTO(
                        readingRepository.save(
                                Reading.builder()
                                        .status(Status.ACTIVE)
                                        .time(readingDTO.getTime())
                                        .passages((readingDTO.getPassageIds() != null && !readingDTO.getPassageIds().isEmpty()) ? new HashSet<>(passageRepository.findAllById(readingDTO.getPassageIds())) : new HashSet<>())
                                        .name(readingDTO.getName())
                                        .build()),
                        questionsRepository)
        );
    }


    public ResponseEntity<?> update(Long id, ReadingDTO readingDTO) {
        Reading reading = readingRepository.findById(id).orElseThrow(() -> new RecordNotFoundException("Reading not found with id " + id));
        if (!reading.getName().equals(readingDTO.getName())) {
            readingRepository.findByName(readingDTO.getName()).ifPresent((answer) -> {
                throw new RecordBadRequestException("Reading already exists with " + readingDTO.getName());
            });
        }
        reading.setName(readingDTO.getName());
        reading.setTime(readingDTO.getTime());
        reading.setPassages((readingDTO.getPassageIds() != null && !readingDTO.getPassageIds().isEmpty()) ? new HashSet<>(passageRepository.findAllById(readingDTO.getPassageIds())) : new HashSet<>());
        return ResponseEntity.ok(new ReadingDTO(readingRepository.save(reading), questionsRepository));

    }

    public ResponseEntity<?> get(Long id) {
        Reading reading = readingRepository.findById(id).orElseThrow(() -> new RecordNotFoundException("Reading not found with id " + id));
        return ResponseEntity.ok(new ReadingDTO(reading, questionsRepository));
    }

    public ResponseEntity<ResponseDto<PageWrapper>> search(Pagination<Search> pagination) {
        Page<Reading> readingPage;
        if (pagination.getSearch().getValue() != null && !pagination.getSearch().getValue().isEmpty()) {
            readingPage = search(pagination.getSearch().getValue().toLowerCase(), pagination);
        } else {
            readingPage = search("", pagination);
        }
        List<ReadingDTO> readingDTOs = readingPage.stream()
                .map(reading -> new ReadingDTO(reading, questionsRepository))
                .toList();
        return ResponseEntity.ok(new ResponseDto<>(ResponseDto.States.SUCCESS, HttpStatus.OK, 200, null, PageWrapper.builder().list(readingDTOs).total(readingPage.getTotalElements()).build()));
    }

    public Page<Reading> search(String value, Pagination<Search> pagination) {
        Pageable paging = Utils.getPageableFromPagination(pagination);
        Page<Reading> pagedResult;
        if (!value.isEmpty()) {
            pagedResult = readingRepository.findAllBySearch(value, paging);
        } else {
            pagedResult = readingRepository.findAllReading(paging);
        }
        return pagedResult;
    }

    public ResponseEntity<?> delete(Long id) {
        Reading reading = readingRepository.findById(id).orElseThrow(() -> new RecordNotFoundException("Reading not found with id " + id));
        reading.setStatus(Status.DELETED);
        readingRepository.save(reading);
        return ResponseEntity.ok("SUCCESS");
    }

}
