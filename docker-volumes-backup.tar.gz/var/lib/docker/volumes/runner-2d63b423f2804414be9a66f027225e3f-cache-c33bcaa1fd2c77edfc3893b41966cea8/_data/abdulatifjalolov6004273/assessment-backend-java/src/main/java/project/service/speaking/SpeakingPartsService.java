package project.service.speaking;

import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import project.dto.ResponseDto;
import project.dto.speaking.SpeakingPartsDTO;
import project.exception.RecordNotFoundException;
import project.model.Pagination;
import project.model.entity.speaking.SpeakingParts;
import project.model.enums.Status;
import project.repository.FileRepository;
import project.repository.speaking.SpeakingPartsRepository;
import project.utility.PageWrapper;
import project.utility.Search;
import project.utility.Utils;

import java.util.List;

@Service
@RequiredArgsConstructor
public class SpeakingPartsService {

    private final SpeakingPartsRepository speakingPartsRepository;
    private final FileRepository fileRepository;

    public ResponseEntity<?> create(SpeakingPartsDTO speakingPartsDTO) {
        SpeakingParts speakingParts = speakingPartsRepository.save(
                SpeakingParts.builder()
                        .textAudio(speakingPartsDTO.getTextAudioFileId() != null ? fileRepository.findById(speakingPartsDTO.getTextAudioFileId()).orElse(null) : null)
                        .textSuggestedReadingTime(speakingPartsDTO.getTextSuggestedReadingTime())
                        .text(speakingPartsDTO.getText())
                        .photoAudio(speakingPartsDTO.getPhotoAudioFileId() != null ? fileRepository.findById(speakingPartsDTO.getPhotoAudioFileId()).orElse(null) : null)
                        .photoFile(speakingPartsDTO.getPhotoFileFileId() != null ? fileRepository.findById(speakingPartsDTO.getPhotoFileFileId()).orElse(null) : null)
                        .status(Status.ACTIVE)
                        .coefficient(speakingPartsDTO.getCoefficient())
                        .question(speakingPartsDTO.getQuestion())
                        .questionAudio(speakingPartsDTO.getQuestionAudioFileId() != null ? fileRepository.findById(speakingPartsDTO.getQuestionAudioFileId()).orElse(null) : null)
                        .preparationTime(speakingPartsDTO.getPreparationTime())
                        .responseTime(speakingPartsDTO.getResponseTime())
                        .orderNumber(speakingPartsDTO.getOrderNumber())
                        .build());
        return ResponseEntity.ok(new SpeakingPartsDTO(speakingPartsRepository.save(speakingParts)));
    }


    public ResponseEntity<?> update(Long id, SpeakingPartsDTO speakingPartsDTO) {
        SpeakingParts speakingParts = speakingPartsRepository.findById(id).orElseThrow(() -> new RecordNotFoundException("SpeakingParts not found with id " + id));
        speakingParts.setTextAudio(speakingPartsDTO.getTextAudioFileId() != null ? fileRepository.findById(speakingPartsDTO.getTextAudioFileId()).orElse(null) : null);
        speakingParts.setTextSuggestedReadingTime(speakingPartsDTO.getTextSuggestedReadingTime());
        speakingParts.setText(speakingPartsDTO.getText());
        speakingParts.setCoefficient(speakingPartsDTO.getCoefficient());
        speakingParts.setPhotoAudio(speakingPartsDTO.getPhotoAudioFileId() != null ? fileRepository.findById(speakingPartsDTO.getPhotoAudioFileId()).orElse(null) : null);
        speakingParts.setPhotoFile(speakingPartsDTO.getPhotoFileFileId() != null ? fileRepository.findById(speakingPartsDTO.getPhotoFileFileId()).orElse(null) : null);
        speakingParts.setQuestion(speakingPartsDTO.getQuestion());
        speakingParts.setQuestionAudio(speakingPartsDTO.getQuestionAudioFileId() != null ? fileRepository.findById(speakingPartsDTO.getQuestionAudioFileId()).orElse(null) : null);
        speakingParts.setPreparationTime(speakingPartsDTO.getPreparationTime());
        speakingParts.setResponseTime(speakingPartsDTO.getResponseTime());
        speakingParts.setOrderNumber(speakingPartsDTO.getOrderNumber());
        return ResponseEntity.ok(new SpeakingPartsDTO(speakingPartsRepository.save(speakingParts)));

    }

    public ResponseEntity<?> get(Long id) {
        SpeakingParts questions = speakingPartsRepository.findById(id).orElseThrow(() -> new RecordNotFoundException("SpeakingParts not found with id " + id));
        return ResponseEntity.ok((new SpeakingPartsDTO(speakingPartsRepository.save(questions))));
    }

    public ResponseEntity<ResponseDto<PageWrapper>> search(Pagination<Search> pagination) {
        Page<SpeakingParts> speakingPartsPage;
        if (pagination.getSearch().getValue() != null && !pagination.getSearch().getValue().isEmpty()) {
            speakingPartsPage = search(pagination.getSearch().getValue().toLowerCase(), pagination);
        } else {
            speakingPartsPage = search("", pagination);
        }
        List<SpeakingPartsDTO> speakingPartsDTOs = speakingPartsPage.stream()
                .map(SpeakingPartsDTO::new)
                .toList();
        return ResponseEntity.ok(new ResponseDto<>(ResponseDto.States.SUCCESS, HttpStatus.OK, 200, null, PageWrapper.builder().list(speakingPartsDTOs).total(speakingPartsPage.getTotalElements()).build()));
    }

    public Page<SpeakingParts> search(String value, Pagination<Search> pagination) {
        Pageable paging = Utils.getPageableFromPagination(pagination);
        Page<SpeakingParts> pagedResult;
        if (!value.isEmpty()) {
            pagedResult = speakingPartsRepository.findAllBySearch(value, paging);
        } else {
            pagedResult = speakingPartsRepository.findAllSpeakingParts(paging);
        }
        return pagedResult;
    }

    public ResponseEntity<?> delete(Long id) {
        SpeakingParts questions = speakingPartsRepository.findById(id).orElseThrow(() -> new RecordNotFoundException("SpeakingParts not found with id " + id));
        questions.setStatus(Status.DELETED);
        speakingPartsRepository.save(questions);
        return ResponseEntity.ok("SUCCESS");
    }

}
