package project.controller;

import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import project.service.MyIdStatusService;

@RestController
@RequestMapping("/api/v1/myid-status")
@RequiredArgsConstructor
@SecurityRequirement(name = "Bearer Authentication")
public class MyIdStatusController {

    private final MyIdStatusService myIdStatusService;

    @PutMapping
    @ResponseStatus(HttpStatus.OK)
    public ResponseEntity<?> changeStatus() {
        return myIdStatusService.changeStatus();
    }

    @GetMapping
    @ResponseStatus(HttpStatus.OK)
    public ResponseEntity<?> getMyIdStatus() {
        return myIdStatusService.getMyIdStatus();
    }

}
