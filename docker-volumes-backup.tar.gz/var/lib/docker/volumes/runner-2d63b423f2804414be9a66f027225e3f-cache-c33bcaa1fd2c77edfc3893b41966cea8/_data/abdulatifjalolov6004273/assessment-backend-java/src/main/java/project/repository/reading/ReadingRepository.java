package project.repository.reading;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.data.repository.query.QueryByExampleExecutor;
import project.model.entity.reading.Reading;

import java.util.Optional;

public interface ReadingRepository extends JpaRepository<Reading, Long>, PagingAndSortingRepository<Reading, Long>, QueryByExampleExecutor<Reading> {

    @Query("select q from Reading q where q.status = 'ACTIVE' and q.name = ?1 ")
    Optional<Reading> findByName(String name);

    @Query("select p from Reading p where p.status = 'ACTIVE' and p.name like %?1% order by p.id ")
    Page<Reading> findAllBySearch(String value, Pageable pageable);

    @Query("select p from Reading p where p.status = 'ACTIVE' order by p.id ")
    Page<Reading> findAllReading(Pageable pageable);

}
