package project.model.payme.json;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class Params {

    private String id;

    private Account account;

    private Integer amount;

    private Long time;

    private Integer reason;

    private Long from;

    private Long to;

    private String password;
}
