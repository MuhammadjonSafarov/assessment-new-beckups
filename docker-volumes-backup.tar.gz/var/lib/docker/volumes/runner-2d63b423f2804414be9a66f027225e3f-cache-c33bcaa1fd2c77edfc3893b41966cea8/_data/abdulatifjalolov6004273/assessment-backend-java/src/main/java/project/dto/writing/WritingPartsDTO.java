package project.dto.writing;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import project.dto.FileDto;
import project.dto.QuestionsDTO;
import project.model.entity.writing.WritingParts;
import project.repository.QuestionsRepository;

import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class WritingPartsDTO {

    private Long id;

    private String name;

    private String body;

    private Set<FileDto> fileDtos;

    private List<Long> fileIds;

    private Long orderNumber;

    private List<QuestionsDTO> questions;

    private List<Long> questionIds;

    public WritingPartsDTO(WritingParts writingParts, QuestionsRepository questionsRepository) {
        setId(writingParts.getId());
        setName(writingParts.getName());
        setBody(writingParts.getBody());
        setOrderNumber(writingParts.getOrderNumber());
        if (writingParts.getFiles() != null && !writingParts.getFiles().isEmpty())
            setFileDtos(writingParts.getFiles().stream().map(FileDto::new).collect(Collectors.toSet()));
        setQuestions(questionsRepository.finAllByWritingPartsId(writingParts.getId()));
    }

}
