package project.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.data.repository.query.QueryByExampleExecutor;
import project.model.entity.Computer;

import java.util.List;

public interface ComputerRepository extends PagingAndSortingRepository<Computer, Long>, JpaRepository<Computer, Long>, QueryByExampleExecutor<Computer> {

    @Query("select c from Computer c where c.session.id = ?1 order by c.number ")
    List<Computer> findAllBySession(Long sessionId);
}
