package project.model.entity.writing;

import lombok.*;
import project.model.enums.Status;

import javax.persistence.*;
import java.util.HashSet;
import java.util.Set;

import static javax.persistence.FetchType.LAZY;
import static javax.persistence.GenerationType.SEQUENCE;

@AllArgsConstructor
@Getter
@Setter
@Entity
@NoArgsConstructor
@Builder
@Table(name = "writings")
public class Writing {

    @Id
    @GeneratedValue(strategy = SEQUENCE, generator = "WRITING_SEQUENCE")
    @SequenceGenerator(sequenceName = "WRITING_SEQUENCE", allocationSize = 1, name = "WRITING_SEQUENCE")
    @Column(name = "id", nullable = false, updatable = false)
    private Long id;

    private String name;

    @ManyToMany(fetch = LAZY)
    @JoinTable(name = "writing_witing_parts",
            joinColumns = {@JoinColumn(name = "writing_id", referencedColumnName = "id")},
            inverseJoinColumns = {@JoinColumn(name = "writing_part_id", referencedColumnName = "id")})
    private Set<WritingParts> writingParts = new HashSet<>();

    private String time;

    @Enumerated(EnumType.STRING)
    private Status status;

}
