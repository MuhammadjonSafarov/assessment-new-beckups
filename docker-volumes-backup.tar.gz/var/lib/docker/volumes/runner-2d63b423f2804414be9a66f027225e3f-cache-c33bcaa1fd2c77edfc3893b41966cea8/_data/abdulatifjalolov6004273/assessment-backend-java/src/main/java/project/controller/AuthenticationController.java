package project.controller;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.*;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;
import project.dto.AuthenticationRequestDto;
import project.dto.ResponseDto;
import project.dto.UserApplicationDTO;
import project.dto.system.UserRegisterDTO;
import project.exception.RecordBadRequestException;
import project.exception.RecordNotFoundException;
import project.model.entity.Session;
import project.model.entity.UserApplication;
import project.model.entity.system.User;
import project.model.enums.MyIdStatus;
import project.repository.SessionRepository;
import project.repository.UserApplicationRepository;
import project.repository.system.UserRepository;
import project.security.jwt.JwtTokenProvider;
import project.service.system.RoleService;
import project.service.system.UserService;

import java.util.*;

/**
 * REST controller for authentication requests (login, logout, register, etc.)
 */

@Slf4j
@Transactional
@RestController
@RequiredArgsConstructor
@RequestMapping(value = "/api/v1")
public class AuthenticationController {

    private final RoleService roleService;
    private final UserService userService;
    private final JwtTokenProvider jwtTokenProvider;
    private final AuthenticationManager authenticationManager;
    private final BCryptPasswordEncoder passwordEncoder;
    private final UserRepository userRepository;
    private final UserApplicationRepository userApplicationRepository;
    private final SessionRepository sessionRepository;

    @PostMapping("/auth-payload")
    public ResponseEntity<ResponseDto<Map<String, Object>>> login(
            @RequestBody AuthenticationRequestDto requestDto
    ) {
        if (requestDto.getPassword() == null || requestDto.getPassword().isBlank() || requestDto.getUsername() == null || requestDto.getUsername().isBlank()) {
            throw new RecordBadRequestException("Username and Password cannot be null or blank");
        }
        User user = userService.findByUsername(requestDto.getUsername());
        if (user == null) {
            throw new RecordNotFoundException("User not found");
        }
        if (passwordEncoder.matches(requestDto.getPassword(), user.getPassword())) {
            authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(user.getUsername(), requestDto.getPassword()));
            List<String> roleNames = userService.findRoleNames(user.getId());
            String token = jwtTokenProvider.createToken(user.getUsername(), roleNames);
            List<String> permissionsDto = roleService.findPermissionNames(userService.findRoleIds(user.getId()));
            Map<String, Object> response = new LinkedHashMap<>();
            response.put("id", user.getId());
            response.put("token", token);
            response.put("username", user.getUsername());
            response.put("role", roleNames);
            response.put("permissions", permissionsDto);
            user.setLastActiveDate(new Date());
            userRepository.save(user);
            return ResponseEntity.ok(new ResponseDto<>(ResponseDto.States.SUCCESS, HttpStatus.OK, 200, null, response));
        } else {
            throw new RecordBadRequestException("Password does not match");
        }
    }

    @PostMapping("/auth-payload-nomzod/{sessionId}")
    public ResponseEntity<ResponseDto<Map<String, Object>>> loginNomzod(
            @RequestBody AuthenticationRequestDto requestDto,
            @PathVariable Long sessionId
    ) {
        if (requestDto.getPassword() == null || requestDto.getPassword().isBlank() || requestDto.getUsername() == null || requestDto.getUsername().isBlank()) {
            throw new RecordBadRequestException("Username and Password cannot be null or blank");
        }
        User user = userService.findByUsername(requestDto.getUsername());
        if (user == null)
            throw new RecordNotFoundException("User not found");
        Session session = sessionRepository.findById(sessionId).orElseThrow(
                () -> new RecordNotFoundException("Session not found with id " + sessionId)
        );
        UserApplication userApplication = userApplicationRepository.findByUserAndSession(user.getId(), session.getId()).orElseThrow(
                () -> new RecordNotFoundException("UserApplication not found")
        );
        if (!userApplication.getMyIdStatus().name().equals(MyIdStatus.ACCEPTED.name()))
            throw new RecordBadRequestException("MyIdStatus is not ACCEPTED");
        if (passwordEncoder.matches(requestDto.getPassword(), user.getPassword())) {
            authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(user.getUsername(), requestDto.getPassword()));
            List<String> roleNames = userService.findRoleNames(user.getId());
            String token = jwtTokenProvider.createToken(user.getUsername(), roleNames);
            List<String> permissionsDto = roleService.findPermissionNames(userService.findRoleIds(user.getId()));
            Map<String, Object> response = new LinkedHashMap<>();
            response.put("id", user.getId());
            response.put("token", token);
            response.put("username", user.getUsername());
            response.put("role", roleNames);
            response.put("permissions", permissionsDto);
            response.put("userApplication", new UserApplicationDTO(userApplication));
            user.setLastActiveDate(new Date());
            userRepository.save(user);
            return ResponseEntity.ok(new ResponseDto<>(ResponseDto.States.SUCCESS, HttpStatus.OK, 200, null, response));
        } else {
            throw new RecordBadRequestException("Password does not match");
        }
    }

    @PostMapping("/register")
    @ResponseStatus(HttpStatus.OK)
    public ResponseEntity<?> register(
            @RequestBody UserRegisterDTO userRegisterDTO
    ) {
        return userService.register(userRegisterDTO);
    }

    @PostMapping("/attach-data/{id}")
    @ResponseStatus(HttpStatus.OK)
    public ResponseEntity<?> attachData(
            @RequestBody UserRegisterDTO userRegisterDTO,
            @PathVariable Long id
    ) {
        return userService.attachData(id, userRegisterDTO);
    }
}
