package project.repository.system;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.data.repository.query.QueryByExampleExecutor;
import project.model.entity.system.EskizToken;

public interface EskizTokenRepository extends JpaRepository<EskizToken, Long>, PagingAndSortingRepository<EskizToken, Long>, QueryByExampleExecutor<EskizToken>  {
}
