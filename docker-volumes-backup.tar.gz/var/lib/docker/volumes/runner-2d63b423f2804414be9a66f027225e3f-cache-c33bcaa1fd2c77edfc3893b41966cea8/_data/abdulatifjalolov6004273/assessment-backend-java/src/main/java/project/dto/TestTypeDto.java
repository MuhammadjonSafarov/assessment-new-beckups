package project.dto;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.*;
import project.model.entity.TestType;
import project.model.enums.ExamRunType;
import project.model.enums.Status;

import java.math.BigDecimal;
import java.util.List;


@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)
public class TestTypeDto {

    private Long id;
    private String titleUz;
    private String titleRu;
    private String titleEn;
    private String partnerUz;
    private String partnerRu;
    private String partnerEn;
    private Boolean isInOurPlatform;
    private BigDecimal defaultPaymentAmount;
    private Boolean isThereAnyOtherPavilion;
    private BigDecimal otherPavilionPaymentAmount;
    private ExamRunType examRunType;
    private Status status;
    private BigDecimal retakeAmount;
    private Boolean isRetakeAvailable;
    private BigDecimal reissueAmount;
    private String phone;
    private String telegram;
    private Long maxCandidates;
    private List<String> resultOptions;
    private project.model.enums.TestType testType;
    private Long fileId;
    private FileDto fileDto;
    private Long offerFileId;
    private FileDto offerFileDto;

    public TestTypeDto(TestType testType) {
        setId(testType.getId());
        setTitleUz(testType.getTitleUz());
        setTitleRu(testType.getTitleRu());
        setTitleEn(testType.getTitleEn());
        setStatus(testType.getStatus());
        setPartnerUz(testType.getPartnerUz());
        setPartnerRu(testType.getPartnerRu());
        setPartnerEn(testType.getPartnerEn());
        setTestType(testType.getTestType());
        setIsInOurPlatform(testType.getIsInOurPlatform());
        setDefaultPaymentAmount(testType.getDefaultPaymentAmount());
        setOtherPavilionPaymentAmount(testType.getOtherPavilionPaymentAmount());
        setRetakeAmount(testType.getRetakeAmount());
        setReissueAmount(testType.getReissueAmount());
        setExamRunType(testType.getExamRunType());
        setIsThereAnyOtherPavilion(testType.getIsThereAnyOtherPavilion());
        setIsInOurPlatform(testType.getIsInOurPlatform());
        setIsRetakeAvailable(testType.getIsRetakeAvailable());
        setPhone(testType.getPhone());
        setTelegram(testType.getTelegram());
        setMaxCandidates(testType.getMaxCandidates());
        setResultOptions(testType.getResultOptions());
        if (testType.getFile() != null)
            setFileDto(new FileDto(testType.getFile()));
        if (testType.getOfferFile() != null)
            setOfferFileDto(new FileDto(testType.getOfferFile()));
    }

    @JsonIgnore
    public static TestType of(TestTypeDto testTypeDto) {
        return TestType.builder()
                .titleUz(testTypeDto.getTitleUz())
                .titleRu(testTypeDto.getTitleRu())
                .titleEn(testTypeDto.getTitleEn())
                .partnerUz(testTypeDto.getPartnerUz())
                .partnerRu(testTypeDto.getPartnerRu())
                .partnerEn(testTypeDto.getPartnerEn())
                .testType(testTypeDto.getTestType())
                .isInOurPlatform(testTypeDto.getIsInOurPlatform())
                .defaultPaymentAmount(testTypeDto.getDefaultPaymentAmount())
                .otherPavilionPaymentAmount(testTypeDto.getOtherPavilionPaymentAmount())
                .retakeAmount(testTypeDto.getRetakeAmount())
                .reissueAmount(testTypeDto.getReissueAmount())
                .examRunType(testTypeDto.getExamRunType())
                .isThereAnyOtherPavilion(testTypeDto.getIsThereAnyOtherPavilion())
                .isInOurPlatform(testTypeDto.getIsInOurPlatform())
                .isRetakeAvailable(testTypeDto.getIsRetakeAvailable())
                .phone(testTypeDto.getPhone())
                .telegram(testTypeDto.getTelegram())
                .maxCandidates(testTypeDto.getMaxCandidates())
                .resultOptions(testTypeDto.getResultOptions())
                .status(Status.ACTIVE)
                .build();
    }

}
