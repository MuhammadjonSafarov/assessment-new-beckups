package project.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.data.repository.query.QueryByExampleExecutor;
import project.model.entity.UserApplicationAnswer;

public interface UserApplicationAnswerRepository extends JpaRepository<UserApplicationAnswer, Long>, PagingAndSortingRepository<UserApplicationAnswer, Long>, QueryByExampleExecutor<UserApplicationAnswer> {
}
