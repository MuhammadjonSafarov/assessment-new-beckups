package project.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.data.repository.query.QueryByExampleExecutor;
import project.dto.FileDto;
import project.dto.UserApplicationDTO;
import project.model.entity.Computer;
import project.model.entity.UserApplication;
import project.model.enums.PaymentStatus;

import java.util.List;
import java.util.Optional;

public interface UserApplicationRepository extends JpaRepository<UserApplication, Long>, PagingAndSortingRepository<UserApplication, Long>, QueryByExampleExecutor<UserApplication> {

    @Query("select ua from UserApplication ua where ua.user.id = ?1 and ua.session.id = ?2 and ua.paymentStatus <> 'OUT_OF_TERM_DATE' ")
    Optional<UserApplication> findByUserAndSessionAndPaymentStatus(Long userId, Long sessionId);

    @Query("select ua from UserApplication ua where ua.user.id = ?1 and ua.session.id = ?2 ")
    Optional<UserApplication> findByUserAndSession(Long userId, Long sessionId);

    @Query("select s from UserApplication s " +
            "where s.user.id = ?1 " +
            "and s.paymentStatus = ?2 " +
            "order by s.createdDate ")
    Page<UserApplication> findAllBySearch(Long userId, PaymentStatus value, Pageable pageable);

    @Query("select s from UserApplication s where s.user.id = ?1 order by s.createdDate ")
    Page<UserApplication> findAllTestTypes(Long userId, Pageable pageable);

    @Query("select ua from UserApplication ua " +
            "where ua.paymentStatus = ?1 " +
            "and to_timestamp(ua.paymentTermDate, 'DD-MM-YYYY HH24:MI:SS') > current_timestamp")
    List<UserApplication> findAllByTermOfDateAndPaymentStatus(PaymentStatus paymentStatus);

    @Query("select ua from UserApplication ua where ua.id = ?1 and ua.paymentStatus = 'UNPAID' ")
    Optional<UserApplication> findByIdAndPaymentStatus(Long applicationId);

    @Query("select c from UserApplication ua " +
            "left join Computer c on c.id = ua.computer.id " +
            "left join Session s on s.id = c.session.id " +
            "where s.id = ?1 and c.status = 'ACTIVE' ")
    List<Computer> findAllUsedComputersBySession(Long id);

    @Query("select new project.dto.UserApplicationDTO(ua, ua.user.id) from UserApplication ua where ua.user.id = ?1 ")
    Page<FileDto> findAllCertificatesBySearch(Long userId, Pageable paging);

    @Query("select new project.dto.UserApplicationDTO(ua, ua.user.id) from UserApplication ua where ua.user.id = ?1 ")
    Page<FileDto> findAllCertificates(Long userId, Pageable paging);
}
