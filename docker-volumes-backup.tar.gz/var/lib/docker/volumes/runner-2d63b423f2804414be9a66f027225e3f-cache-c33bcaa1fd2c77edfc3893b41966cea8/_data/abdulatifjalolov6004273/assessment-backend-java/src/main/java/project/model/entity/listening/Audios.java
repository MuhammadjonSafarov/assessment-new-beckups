package project.model.entity.listening;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.*;
import project.model.Auditable;
import project.model.entity.File;
import project.model.enums.Status;

import javax.persistence.*;

import java.util.HashSet;
import java.util.Set;

import static javax.persistence.FetchType.LAZY;
import static javax.persistence.GenerationType.SEQUENCE;

@AllArgsConstructor
@Getter
@Setter
@Entity
@NoArgsConstructor
@Builder
@Table(name = "audios")
public class Audios extends Auditable<String> {

    @Id
    @GeneratedValue(strategy = SEQUENCE, generator = "AUDIOS_SEQUENCE")
    @SequenceGenerator(sequenceName = "AUDIOS_SEQUENCE", allocationSize = 1, name = "AUDIOS_SEQUENCE")
    @Column(name = "id", nullable = false, updatable = false)
    private Long id;

    private String name;

    @OneToOne
    private File audioFile;

    @ManyToMany(fetch = LAZY)
    @JoinTable(name = "audio_files")
    private Set<File> files = new HashSet<>();

    @Column(name = "order_number")
    private Long orderNumber;

    @ManyToMany(mappedBy = "audios")
    @JsonIgnore
    private Set<Listening> listenings = new HashSet<>();

    @Enumerated(EnumType.STRING)
    private Status status;

}
