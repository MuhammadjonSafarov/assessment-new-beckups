package project.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.*;
import lombok.extern.slf4j.Slf4j;
import project.dto.listening.ListeningDTO;
import project.dto.reading.ReadingDTO;
import project.dto.speaking.SpeakingDTO;
import project.dto.system.UserDTO;
import project.dto.writing.WritingDTO;
import project.model.entity.Pavilion;
import project.model.entity.Session;
import project.model.entity.TestType;
import project.model.enums.ExamFormat;
import project.model.enums.ExamType;

import java.math.BigDecimal;
import java.util.List;

@Slf4j
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)
public class SessionDTO {

    private Long id;

    private ExamType examType;

    private TestTypeDto testType;

    private Long testTypeId;

    private ExamFormat examFormat;

    private BigDecimal cost;

    private Long maxCountCandidate;

    private PavilionDto pavilion;

    private Long pavilionId;

    private String startDate;

    private Long listeningId;
    private Long readingId;
    private Long writingId;
    private Long speakingId;

    private ListeningDTO listeningDTO;
    private ReadingDTO readingDTO;
    private WritingDTO writingDTO;
    private SpeakingDTO speakingDTO;

    private List<UserDTO> users;

    private Double listeningScore;
    private Double readingScore;
    private Double speakingScore;
    private Double writingScore;

    public SessionDTO(Session session) {
        if (session != null) {
            this.id = session.getId();
            setListeningScore(session.getListeningScore());
            setReadingScore(session.getReadingScore());
            setSpeakingScore(session.getSpeakingScore());
            setWritingScore(session.getWritingScore());
            this.examType = session.getExamType();
            if (session.getTestType() != null)
                this.testType = new TestTypeDto(session.getTestType());
            this.cost = session.getCost();
            this.examFormat = session.getExamFormat();
            this.maxCountCandidate = session.getMaxCountCandidate();
            if (session.getPavilion() != null)
                this.pavilion = new PavilionDto(session.getPavilion());
            this.startDate = session.getStartDate();
            if (session.getUsers() != null)
                setUsers(session.getUsers().stream().map(UserDTO::new).toList());
            if (session.getListening() != null)
                setListeningDTO(new ListeningDTO(session.getListening()));
            if (session.getReading() != null)
                setReadingDTO(new ReadingDTO(session.getReading()));
            if (session.getSpeaking() != null)
                setSpeakingDTO(new SpeakingDTO(session.getSpeaking()));
            if (session.getWriting() != null)
                setWritingDTO(new WritingDTO(session.getWriting()));
        }
    }

}
