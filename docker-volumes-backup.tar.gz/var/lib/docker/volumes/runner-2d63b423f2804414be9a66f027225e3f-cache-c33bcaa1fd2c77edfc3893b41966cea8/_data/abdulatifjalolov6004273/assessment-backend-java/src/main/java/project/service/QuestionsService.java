package project.service;

import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import project.dto.ResponseDto;
import project.dto.QuestionsDTO;
import project.exception.RecordBadRequestException;
import project.exception.RecordNotFoundException;
import project.model.Pagination;
import project.model.entity.Answers;
import project.model.entity.Questions;
import project.model.enums.QuestionType;
import project.model.enums.Status;
import project.repository.AnswersRepository;
import project.repository.QuestionsRepository;
import project.utility.PageWrapper;
import project.utility.Search;
import project.utility.Utils;

import javax.transaction.Transactional;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.atomic.AtomicInteger;

@Service
@RequiredArgsConstructor
public class QuestionsService {

    private final QuestionsRepository questionsRepository;
    private final AnswersRepository answersRepository;

    @Transactional
    public ResponseEntity<?> create(QuestionsDTO questionsDTO) {
        questionsRepository.findByName(questionsDTO.getName()).ifPresent((answer) -> {
            throw new RecordBadRequestException("Question already exists with " + questionsDTO.getName());
        });
        Questions questions = questionsRepository.save(
                Questions.builder()
                        .status(Status.ACTIVE)
                        .name(questionsDTO.getName())
                        .innerTextType(questionsDTO.getInnerTextType() != null ? questionsDTO.getInnerTextType() : null)
                        .startIndex(questionsDTO.getStartIndex())
                        .endIndex(questionsDTO.getEndIndex())
                        .coefficient(questionsDTO.getCoefficient())
                        .questionType(questionsDTO.getQuestionType())
                        .innerTextType(questionsDTO.getInnerTextType() != null ? questionsDTO.getInnerTextType() : null)
                        .correctAnswersCount(questionsDTO.getCorrectAnswersCount())
                        .build());
        AtomicInteger correctAnswers = new AtomicInteger();
        Set<Answers> answers = new HashSet<>();
        if (questionsDTO.getAnswerIds() != null && !questionsDTO.getAnswerIds().isEmpty()) {
            questionsDTO.getAnswerIds().forEach((answerId) -> answersRepository.findById(answerId).ifPresent((answer) -> {
                if (answer.getIsCorrect())
                    correctAnswers.addAndGet(1);
                answers.add(answer);
            }));
            if (correctAnswers.get() > questionsDTO.getCorrectAnswersCount())
                throw new RecordBadRequestException("Correct answers count cannot be more than " + questionsDTO.getCorrectAnswersCount());
        }
        questions.setAnswers(answers);
        return ResponseEntity.ok(questionsRepository.save(questions));
    }


    @Transactional
    public ResponseEntity<?> update(Long id, QuestionsDTO questionsDTO) {
        Questions questions = questionsRepository.findById(id).orElseThrow(() -> new RecordNotFoundException("Question not found with id " + id));
        if (!questions.getName().equals(questionsDTO.getName())) {
            questionsRepository.findByName(questionsDTO.getName()).ifPresent((answer) -> {
                throw new RecordBadRequestException("Question already exists with " + questionsDTO.getName());
            });
        }
        AtomicInteger correctAnswers = new AtomicInteger();
        questions.setName(questionsDTO.getName());
        questions.setQuestionType(questionsDTO.getQuestionType());
        questions.setStartIndex(questionsDTO.getStartIndex());
        questions.setCoefficient(questionsDTO.getCoefficient());
        questions.setEndIndex(questionsDTO.getEndIndex());
        questions.setInnerTextType(questionsDTO.getInnerTextType() != null ? questionsDTO.getInnerTextType() : null);
        questions.setCorrectAnswersCount(questionsDTO.getCorrectAnswersCount());
        Set<Answers> answers = new HashSet<>();
        if (questionsDTO.getAnswerIds() != null && !questionsDTO.getAnswerIds().isEmpty()) {
            questionsDTO.getAnswerIds().forEach((answerId) -> answersRepository.findById(answerId).ifPresent((answer) -> {
                if (answer.getIsCorrect())
                    correctAnswers.addAndGet(1);
                answers.add(answer);
            }));
            if (correctAnswers.get() > questionsDTO.getCorrectAnswersCount())
                throw new RecordBadRequestException("Correct answers count cannot be more than " + questionsDTO.getCorrectAnswersCount());
        }
        questions.setAnswers(answers);
        return ResponseEntity.ok(new QuestionsDTO(questionsRepository.save(questions), answersRepository));

    }

    public ResponseEntity<?> get(Long id) {
        Questions questions = questionsRepository.findById(id).orElseThrow(() -> new RecordNotFoundException("Question not found with id " + id));
        return ResponseEntity.ok((new QuestionsDTO(questionsRepository.save(questions), answersRepository)));
    }

    public ResponseEntity<ResponseDto<PageWrapper>> search(QuestionType questionType, Pagination<Search> pagination) {
        Page<Questions> questionsPage;
        if (pagination.getSearch().getValue() != null && !pagination.getSearch().getValue().isEmpty()) {
            questionsPage = search(questionType, pagination.getSearch().getValue().toLowerCase(), pagination);
        } else {
            questionsPage = search(questionType, "", pagination);
        }
        List<QuestionsDTO> questionsDTOs = questionsPage.stream()
                .map(question -> new QuestionsDTO(question, answersRepository))
                .toList();
        return ResponseEntity.ok(new ResponseDto<>(ResponseDto.States.SUCCESS, HttpStatus.OK, 200, null, PageWrapper.builder().list(questionsDTOs).total(questionsPage.getTotalElements()).build()));
    }

    public Page<Questions> search(QuestionType questionType, String value, Pagination<Search> pagination) {
        Pageable paging = Utils.getPageableFromPagination(pagination);
        Page<Questions> pagedResult;
        if (!value.isEmpty()) {
            pagedResult = questionsRepository.findAllBySearch(value, questionType, paging);
        } else {
            pagedResult = questionsRepository.findAllQuestions(questionType, paging);
        }
        return pagedResult;
    }

    public ResponseEntity<?> delete(Long id) {
        Questions questions = questionsRepository.findById(id).orElseThrow(() -> new RecordNotFoundException("Question not found with id " + id));
        questions.setStatus(Status.DELETED);
        questionsRepository.save(questions);
        return ResponseEntity.ok("SUCCESS");
    }

}
