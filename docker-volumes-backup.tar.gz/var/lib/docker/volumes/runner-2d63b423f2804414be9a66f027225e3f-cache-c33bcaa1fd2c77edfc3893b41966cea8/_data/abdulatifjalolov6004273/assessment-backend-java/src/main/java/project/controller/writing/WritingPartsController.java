package project.controller.writing;

import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import project.dto.writing.WritingPartsDTO;
import project.model.Pagination;
import project.service.writing.WritingPartsService;
import project.utility.Search;


@RestController
@RequiredArgsConstructor
@RequestMapping("/api/v1/writingPart")
@SecurityRequirement(name = "Bearer Authentication")
public class WritingPartsController {

    private final WritingPartsService writingPartsService;

    @PostMapping
    @ResponseStatus(HttpStatus.OK)
    public ResponseEntity<?> create(
            @RequestBody WritingPartsDTO writingPartsDTO
            ) {
        return writingPartsService.create(writingPartsDTO);
    }

    @PutMapping("/{id}")
    @ResponseStatus(HttpStatus.OK)
    public ResponseEntity<?> update(
            @RequestBody WritingPartsDTO writingPartsDTO,
            @PathVariable Long id
    ) {
        return writingPartsService.update(id, writingPartsDTO);
    }

    @GetMapping("/{id}")
    @ResponseStatus(HttpStatus.OK)
    public ResponseEntity<?> get(
            @PathVariable Long id
    ) {
        return writingPartsService.get(id);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.OK)
    public ResponseEntity<?> delete(
            @PathVariable Long id
    ) {
        return writingPartsService.delete(id);
    }

    @PostMapping("/list-search")
    @ResponseStatus(HttpStatus.OK)
    public ResponseEntity<?> listSearch(
            @RequestBody Pagination<Search> pagination
    ) {
        return writingPartsService.search(pagination);
    }

}
