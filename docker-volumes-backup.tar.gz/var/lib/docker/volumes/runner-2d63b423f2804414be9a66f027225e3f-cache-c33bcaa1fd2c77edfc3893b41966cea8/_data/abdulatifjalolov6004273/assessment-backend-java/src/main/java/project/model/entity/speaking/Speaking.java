package project.model.entity.speaking;

import lombok.*;
import project.model.entity.File;
import project.model.enums.Status;

import javax.persistence.*;
import java.util.HashSet;
import java.util.Set;

import static javax.persistence.FetchType.LAZY;
import static javax.persistence.GenerationType.SEQUENCE;

@AllArgsConstructor
@Getter
@Setter
@Entity
@NoArgsConstructor
@Builder
@Table(name = "speaking")
public class Speaking {

    @Id
    @GeneratedValue(strategy = SEQUENCE, generator = "SPEAKING_SEQUENCE")
    @SequenceGenerator(sequenceName = "SPEAKING_SEQUENCE", allocationSize = 1, name = "SPEAKING_SEQUENCE")
    @Column(name = "id", nullable = false, updatable = false)
    private Long id;

    private String name;

    @OneToOne
    private File file;

    @Enumerated(EnumType.STRING)
    private Status status;

    @ManyToMany(fetch = LAZY)
    @JoinTable(name = "speaking_speaking_parts",
            joinColumns = {@JoinColumn(name = "speaking_id", referencedColumnName = "id")},
            inverseJoinColumns = {@JoinColumn(name = "speaking_part_id", referencedColumnName = "id")})
    private Set<SpeakingParts> speakingParts = new HashSet<>();

}
