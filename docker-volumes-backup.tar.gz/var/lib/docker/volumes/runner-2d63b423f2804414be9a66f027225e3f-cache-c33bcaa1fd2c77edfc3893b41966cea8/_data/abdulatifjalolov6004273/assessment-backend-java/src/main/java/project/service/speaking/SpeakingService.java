package project.service.speaking;

import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import project.dto.ResponseDto;
import project.dto.speaking.SpeakingDTO;
import project.exception.RecordBadRequestException;
import project.exception.RecordNotFoundException;
import project.model.Pagination;
import project.model.entity.speaking.Speaking;
import project.model.enums.Status;
import project.repository.FileRepository;
import project.repository.speaking.SpeakingPartsRepository;
import project.repository.speaking.SpeakingRepository;
import project.utility.PageWrapper;
import project.utility.Search;
import project.utility.Utils;

import java.util.HashSet;
import java.util.List;

@Service
@RequiredArgsConstructor
public class SpeakingService {

    private final SpeakingRepository speakingRepository;
    private final SpeakingPartsRepository speakingPartRepository;
    private final FileRepository fileRepository;

    public ResponseEntity<?> create(SpeakingDTO speakingDTO) {
        speakingRepository.findByName(speakingDTO.getName()).ifPresent((answer) -> {
            throw new RecordBadRequestException("Speaking already exists with " + speakingDTO.getName());
        });
        return ResponseEntity.ok(
                new SpeakingDTO(
                        speakingRepository.save(
                                Speaking.builder()
                                        .name(speakingDTO.getName())
                                        .file(speakingDTO.getFileId() != null ? fileRepository.findById(speakingDTO.getFileId()).orElse(null) : null)
                                        .status(Status.ACTIVE)
                                        .speakingParts((speakingDTO.getSpeakingPartIds() != null && !speakingDTO.getSpeakingPartIds().isEmpty()) ? new HashSet<>(speakingPartRepository.findAllById(speakingDTO.getSpeakingPartIds())) : new HashSet<>())
                                        .build())
                )
        );
    }


    public ResponseEntity<?> update(Long id, SpeakingDTO speakingDTO) {
        Speaking speaking = speakingRepository.findById(id).orElseThrow(() -> new RecordNotFoundException("Speaking not found with id " + id));
        if (!speaking.getName().equals(speakingDTO.getName())) {
            speakingRepository.findByName(speakingDTO.getName()).ifPresent((answer) -> {
                throw new RecordBadRequestException("Speaking already exists with " + speakingDTO.getName());
            });
        }
        speaking.setName(speakingDTO.getName());
        speaking.setFile(speakingDTO.getFileId() != null ? fileRepository.findById(speakingDTO.getFileId()).orElse(null) : null);
        speaking.setSpeakingParts((speakingDTO.getSpeakingPartIds() != null && !speakingDTO.getSpeakingPartIds().isEmpty()) ? new HashSet<>(speakingPartRepository.findAllById(speakingDTO.getSpeakingPartIds())) : new HashSet<>());
        return ResponseEntity.ok(new SpeakingDTO(speakingRepository.save(speaking)));

    }

    public ResponseEntity<?> get(Long id) {
        Speaking speaking = speakingRepository.findById(id).orElseThrow(() -> new RecordNotFoundException("Speaking not found with id " + id));
        return ResponseEntity.ok(new SpeakingDTO(speaking));
    }

    public ResponseEntity<ResponseDto<PageWrapper>> search(Pagination<Search> pagination) {
        Page<Speaking> speakingPage;
        if (pagination.getSearch().getValue() != null && !pagination.getSearch().getValue().isEmpty()) {
            speakingPage = search(pagination.getSearch().getValue().toLowerCase(), pagination);
        } else {
            speakingPage = search("", pagination);
        }
        List<SpeakingDTO> speakingDTOs = speakingPage.stream()
                .map(SpeakingDTO::new)
                .toList();
        return ResponseEntity.ok(new ResponseDto<>(ResponseDto.States.SUCCESS, HttpStatus.OK, 200, null, PageWrapper.builder().list(speakingDTOs).total(speakingPage.getTotalElements()).build()));
    }

    public Page<Speaking> search(String value, Pagination<Search> pagination) {
        Pageable paging = Utils.getPageableFromPagination(pagination);
        Page<Speaking> pagedResult;
        if (!value.isEmpty()) {
            pagedResult = speakingRepository.findAllBySearch(value, paging);
        } else {
            pagedResult = speakingRepository.findAllSpeaking(paging);
        }
        return pagedResult;
    }

    public ResponseEntity<?> delete(Long id) {
        Speaking speaking = speakingRepository.findById(id).orElseThrow(() -> new RecordNotFoundException("Speaking not found with id " + id));
        speaking.setStatus(Status.DELETED);
        speakingRepository.save(speaking);
        return ResponseEntity.ok("SUCCESS");
    }

}
