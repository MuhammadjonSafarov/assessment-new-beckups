package project.service.system;


import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import project.model.payme.Client;
import project.model.entity.system.Role;
import project.model.entity.system.User;
import project.model.enums.Status;
import project.model.enums.Type;
import project.repository.payme.ClientRepository;
import project.repository.system.RoleRepository;
import project.repository.system.UserRepository;

import javax.annotation.PostConstruct;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class InitialData {


    private final UserRepository userRepository;
    private final BCryptPasswordEncoder passwordEncoder;
    private final RoleRepository roleRepository;
    private final ClientRepository clientRepository;

    @Value("${paycom.username}")
    private String paycomUsername;

    @Value("${paycom.password}")
    private String paycomPassword;

    @Value("${paycom.client.username}")
    private String paycomClientUsername;

    @Value("${paycom.client.password}")
    private String paycomClientPassword;

    @PostConstruct
    public void init() {
        loadAdmin();
        loadRoles();
        loadPaymeDetails();
    }

    private void loadPaymeDetails() {
        Optional<Client> optionalClient = clientRepository.findByPhoneNumber(paycomUsername);
        if (optionalClient.isPresent()) {
            Client paycom = optionalClient.get();
            paycom.setPassword(passwordEncoder.encode(paycomPassword));
            clientRepository.save(paycom);
        } else {
            clientRepository.save(new Client(
                    paycomUsername,
                    passwordEncoder.encode(paycomPassword)
            ));
        }
        Optional<Client> optionalC = clientRepository.findByPhoneNumber(paycomClientUsername);
        if (optionalC.isPresent()) {
            Client c = optionalC.get();
            c.setPassword(passwordEncoder.encode(paycomClientPassword));
            clientRepository.save(c);
        } else {
            clientRepository.save(new Client(
                    paycomClientUsername,
                    passwordEncoder.encode(paycomClientPassword)
            ));
        }
    }

    private void loadRoles() {
        Role operator = roleRepository.findByName("Оператор мониторинга");
        if (operator == null) {
            roleRepository.save(
                    Role.builder()
                            .status(Status.ACTIVE)
                            .name("Оператор мониторинга")
                            .code("ROLE_ОПЕРАТОР МОНИТОРИНГА")
                            .description("Nomzodlarni nazorat qilish uchun")
                            .type(Type.MONITORING)
                            .isGetAllPermissions(false)
                            .build()
            );
        }
    }


    public void loadAdmin() {
        User admin = userRepository.findByUsername("admin");
        if (admin == null) {
            userRepository.save(
                    User.builder()
                            .status(Status.ACTIVE)
                            .username("admin")
                            .firstName("admin")
                            .password(passwordEncoder.encode("123"))
                            .build()
            );
        }
    }
}

