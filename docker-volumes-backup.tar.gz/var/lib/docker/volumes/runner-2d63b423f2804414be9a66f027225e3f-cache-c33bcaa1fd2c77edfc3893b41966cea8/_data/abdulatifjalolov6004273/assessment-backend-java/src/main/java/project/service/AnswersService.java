package project.service;

import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import project.dto.ResponseDto;
import project.dto.AnswersDTO;
import project.exception.RecordBadRequestException;
import project.exception.RecordNotFoundException;
import project.model.Pagination;
import project.model.entity.Answers;
import project.model.enums.Status;
import project.repository.AnswersRepository;
import project.utility.PageWrapper;
import project.utility.Search;
import project.utility.Utils;

import java.util.List;

@Service
@RequiredArgsConstructor
public class AnswersService {

    private final AnswersRepository answersRepository;

    public ResponseEntity<?> create(AnswersDTO answersDTO) {
//        answersRepository.findByAnswer(answersDTO.getAnswer()).ifPresent((answer) -> {
//            throw new RecordBadRequestException("Answer already exists with " + answersDTO.getAnswer());
//        });
        return ResponseEntity.ok(
                answersRepository.save(
                        Answers.builder()
                                .status(Status.ACTIVE)
                                .answer(answersDTO.getAnswer())
                                .isCorrect(answersDTO.getIsCorrect())
                                .build()));
    }


    public ResponseEntity<?> update(Long id, AnswersDTO answersDTO) {
        Answers answers = answersRepository.findById(id).orElseThrow(() -> new RecordNotFoundException("Answer not found with id " + id));
//        if (!answers.getAnswer().equals(answersDTO.getAnswer())) {
//            answersRepository.findByAnswer(answersDTO.getAnswer()).ifPresent((answer) -> {
//                throw new RecordBadRequestException("Answer already exists with " + answersDTO.getAnswer());
//            });
//        }
        answers.setAnswer(answersDTO.getAnswer());
        answers.setIsCorrect(answersDTO.getIsCorrect());
        return ResponseEntity.ok(answersRepository.save(answers));

    }

    public ResponseEntity<?> get(Long id) {
        Answers answers = answersRepository.findById(id).orElseThrow(() -> new RecordNotFoundException("Answer not found with id " + id));
        return ResponseEntity.ok(answers);
    }

    public ResponseEntity<ResponseDto<PageWrapper>> search(Pagination<Search> pagination) {
        Page<Answers> answersPage;
        if (pagination.getSearch().getValue() != null && !pagination.getSearch().getValue().isEmpty()) {
            answersPage = search(pagination.getSearch().getValue().toLowerCase(), pagination);
        } else {
            answersPage = search("", pagination);
        }
        List<AnswersDTO> answersDtos = answersPage.stream().map(AnswersDTO::new).toList();
        return ResponseEntity.ok(new ResponseDto<>(ResponseDto.States.SUCCESS, HttpStatus.OK, 200, null, PageWrapper.builder().list(answersDtos).total(answersPage.getTotalElements()).build()));
    }

    public Page<Answers> search(String value, Pagination<Search> pagination) {
        Pageable paging = Utils.getPageableFromPagination(pagination);
        Page<Answers> pagedResult;
        if (!value.isEmpty()) {
            pagedResult = answersRepository.findAllBySearch(value, paging);
        } else {
            pagedResult = answersRepository.findAllAnswers(paging);
        }
        return pagedResult;
    }

    public ResponseEntity<?> delete(Long id) {
        Answers answers = answersRepository.findById(id).orElseThrow(() -> new RecordNotFoundException("Answer not found with id " + id));
        answers.setStatus(Status.DELETED);
        answersRepository.save(answers);
        return ResponseEntity.ok("SUCCESS");
    }
}
