package project.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import project.model.enums.Status;
import project.service.ComputerService;

@RestController
@RequestMapping("/api/v1/computer")
@RequiredArgsConstructor
public class ComputerController {

    private final ComputerService computerService;

    @PutMapping("/{id}")
    @ResponseStatus(HttpStatus.OK)
    public ResponseEntity<?> update(
            @PathVariable Long id,
            @RequestBody JsonNode info
    ) throws JsonProcessingException {
        return computerService.update(id, info);
    }

    @GetMapping("/list-by-session/{sessionId}")
    @ResponseStatus(HttpStatus.OK)
    public ResponseEntity<?> listByPavilionId(
            @PathVariable Long sessionId
    ) {
        return computerService.listBySession(sessionId);
    }

    @PostMapping("/{id}/{status}")
    @ResponseStatus(HttpStatus.OK)
    public ResponseEntity<?> changeStatus(
            @PathVariable Status status,
            @PathVariable Long id
    ) throws JsonProcessingException {
        return computerService.changeStatus(status, id);
    }

    @GetMapping("/{id}")
    @ResponseStatus(HttpStatus.OK)
    public ResponseEntity<?> getById(
            @PathVariable Long id
    ) throws JsonProcessingException {
        return computerService.get(id);
    }


}
