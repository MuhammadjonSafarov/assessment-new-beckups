package project.controller;


import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import project.dto.TestTypeDto;
import project.model.Pagination;
import project.service.TestTypeService;
import project.utility.Search;
import project.utility.SearchSession;

import java.text.ParseException;

@RestController
@RequestMapping("/api/v1/test-type")
@RequiredArgsConstructor
@SecurityRequirement(name = "Bearer Authentication")
public class TestTypeController {

    private final TestTypeService testTypeService;

    @PostMapping
    @ResponseStatus(HttpStatus.OK)
    public ResponseEntity<?> create(
            @RequestBody TestTypeDto testTypeDto
    ) {
        return testTypeService.create(testTypeDto);
    }

    @PutMapping("/{id}")
    @ResponseStatus(HttpStatus.OK)
    public ResponseEntity<?> update(
            @RequestBody TestTypeDto testTypeDto,
            @PathVariable Long id
    ) {
        return testTypeService.update(testTypeDto, id);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.OK)
    public ResponseEntity<?> delete(
            @PathVariable Long id
    ) {
        return testTypeService.delete(id);
    }

    @GetMapping("/{id}")
    @ResponseStatus(HttpStatus.OK)
    public ResponseEntity<?> get(
            @PathVariable Long id
    ) {
        return testTypeService.get(id);
    }


    @PostMapping("/list-search")
    @ResponseStatus(HttpStatus.OK)
    public ResponseEntity<?> listSearch(
            @RequestBody Pagination<Search> pagination
    ) {
        return testTypeService.search(pagination);
    }

    @PostMapping("/list-search-group-tt")
    @ResponseStatus(HttpStatus.OK)
    public ResponseEntity<?> listSearchGrTT(
            @RequestBody Pagination<SearchSession> pagination
    ) {
        return testTypeService.searchGrTT(pagination);
    }
}
