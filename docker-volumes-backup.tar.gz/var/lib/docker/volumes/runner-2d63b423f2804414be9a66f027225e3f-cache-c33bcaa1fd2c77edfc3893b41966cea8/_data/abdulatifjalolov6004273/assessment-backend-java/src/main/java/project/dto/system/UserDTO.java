package project.dto.system;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.Data;
import lombok.NoArgsConstructor;
import project.dto.FileDto;
import project.dto.UserApplicationDTO;
import project.model.entity.UserApplication;
import project.model.entity.system.User;
import project.model.entity.system.UserMyIdData;
import project.model.enums.Status;
import project.repository.QuestionsRepository;

import java.text.SimpleDateFormat;
import java.util.List;
import java.util.stream.Collectors;

/**
 * DTO class for user requests by ROLE_USER
 */

@Data
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class UserDTO {
    private Long id;
    private String username;
    private String password;
    private Status status;
    private String firstName;
    private String lastName;
    private String middleName;
    private String email;
    private String phone;
    private FileDto file;
    private FileDto passportFile;
    private List<Long> roleIds;
    private List<Long> sessionIds;
    private List<RoleDto> roles;
    private String lastActiveDate;
    private String createdDate;
    private JsonNode userMyIdData;
    private String passportSerial;
    private String passportNumber;
    private String birthDate;
    private UserApplicationDTO userApplication;


    public UserDTO(User user) {
        if (user.getId() != null)
            setId(user.getId());
        setUsername(user.getUsername());
        setStatus(user.getStatus());
        setFirstName(user.getFirstName());
        setLastName(user.getLastName());
        setMiddleName(user.getMiddleName());
        setEmail(user.getEmail());
        setPassportSerial(user.getPassportSerial());
        setPassportNumber(user.getPassportNumber());
        setBirthDate(user.getBirthDate());
        setPhone(user.getPhone());
        setLastActiveDate(user.getLastActiveDate() != null ? new SimpleDateFormat("dd-MM-yyyy hh:mm:ss").format(user.getLastActiveDate()) : null);
        if (user.getCreatedDate() != null)
            setCreatedDate(new SimpleDateFormat("dd-MM-yyyy hh:mm:ss").format(user.getCreatedDate()));
        if (user.getRoles() != null) {
            setRoles(user.getRoles()
                    .stream()
                    .map(RoleDto::new)
                    .collect(Collectors.toList()));
        }
        if (user.getFile() != null) {
            setFile(new FileDto(user.getFile()));
        }
        if (user.getPassportFile() != null) {
            setPassportFile(new FileDto(user.getPassportFile()));
        }
    }

    public UserDTO(User user, UserMyIdData userMyIdData, ObjectMapper objectMapper) throws JsonProcessingException {
        if (user.getId() != null)
            setId(user.getId());
        setUsername(user.getUsername());
        setStatus(user.getStatus());
        setFirstName(user.getFirstName());
        setLastName(user.getLastName());
        setPassportSerial(user.getPassportSerial());
        setPassportNumber(user.getPassportNumber());
        setBirthDate(user.getBirthDate());
        setMiddleName(user.getMiddleName());
        setEmail(user.getEmail());
        setPhone(user.getPhone());
        setLastActiveDate(user.getLastActiveDate() != null ? new SimpleDateFormat("dd-MM-yyyy hh:mm:ss").format(user.getLastActiveDate()) : null);
        if (user.getCreatedDate() != null)
            setCreatedDate(new SimpleDateFormat("dd-MM-yyyy hh:mm:ss").format(user.getCreatedDate()));
        if (user.getRoles() != null) {
            setRoles(user.getRoles()
                    .stream()
                    .map(RoleDto::new)
                    .collect(Collectors.toList()));
        }
        if (user.getFile() != null) {
            setFile(new FileDto(user.getFile()));
        }
        if (user.getPassportFile() != null) {
            setPassportFile(new FileDto(user.getPassportFile()));
        }
        if (userMyIdData != null)
            setUserMyIdData(objectMapper.readTree(userMyIdData.getMyIdData()));
    }

    public UserDTO(UserApplication userApplication, QuestionsRepository questionsRepository) {
        if (userApplication != null)
            setUserApplication(new UserApplicationDTO(userApplication, questionsRepository));
    }

    @JsonIgnore
    public static User of(UserDTO userDto) {
        return User.builder()
                .firstName(userDto.getFirstName())
                .lastName(userDto.getLastName())
                .passportSerial(userDto.getPassportSerial())
                .passportNumber(userDto.getPassportNumber())
                .birthDate(userDto.getBirthDate())
                .middleName(userDto.getMiddleName())
                .status(Status.ACTIVE)
                .username(userDto.getUsername())
                .email(userDto.getEmail())
                .phone(userDto.getPhone())
                .build();
    }
}
