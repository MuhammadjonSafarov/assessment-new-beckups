package project.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import project.dto.ComputerDTO;
import project.dto.ResponseDto;
import project.exception.RecordNotFoundException;
import project.model.entity.Computer;
import project.model.entity.Session;
import project.model.enums.Status;
import project.repository.ComputerRepository;
import project.utility.PageWrapper;

import java.util.ArrayList;
import java.util.List;

@Slf4j
@Service
@RequiredArgsConstructor
public class ComputerService {

    private final ComputerRepository computerRepository;
    private final ObjectMapper objectMapper;

    public void createPavilionDefaultComputers(Session session) {
        for (int i = 0; i < 60; i++) {
            computerRepository.save(
                    Computer.builder()
                            .number((long) i)
                            .status(Status.INACTIVE)
                            .session(session)
                            .build()
            );
        }
    }

    public ResponseEntity<?> update(Long id, JsonNode info) throws JsonProcessingException {
        Computer computer = computerRepository.findById(id).orElseThrow(
                () -> new RecordNotFoundException("Computer not found with id " + id)
        );
        computer.setInfo(info.toString());
        computer.setStatus(Status.ACTIVE);
        return ResponseEntity.ok(new ComputerDTO(computerRepository.save(computer), objectMapper));
    }

    public ResponseEntity<?> listBySession(Long sessionId) {
        List<Computer> computers = computerRepository.findAllBySession(sessionId);

        List<ComputerDTO> computerDTOS = new ArrayList<>();

        for (int i = 0; i < computers.size(); i++) {
            try {
                ComputerDTO dto = new ComputerDTO(computers.get(i), objectMapper);
                dto.setResponseId(i + 1);
                computerDTOS.add(dto);
            } catch (JsonProcessingException e) {
                log.warn("JSON parse error");
            }
        }

        return ResponseEntity.ok(
                new ResponseDto<>(
                        ResponseDto.States.SUCCESS,
                        HttpStatus.OK,
                        200,
                        null,
                        PageWrapper.builder()
                                .list(computerDTOS)
                                .total(computerDTOS.size())
                                .build()
                )
        );
    }


    public ResponseEntity<?> changeStatus(Status status, Long id) throws JsonProcessingException {
        Computer computer = computerRepository.findById(id).orElseThrow(
                () -> new RecordNotFoundException("Computer not found with id " + id)
        );
        computer.setStatus(status);
        return ResponseEntity.ok(new ComputerDTO(computerRepository.save(computer), objectMapper));
    }

    public ResponseEntity<?> get(Long id) throws JsonProcessingException {
        Computer computer = computerRepository.findById(id).orElseThrow(
                () -> new RecordNotFoundException("Computer not found with id " + id)
        );
        return ResponseEntity.ok(new ComputerDTO(computer, objectMapper));
    }
}
