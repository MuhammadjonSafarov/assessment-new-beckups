package project.dto.listening;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import project.dto.FileDto;
import project.dto.QuestionsDTO;
import project.model.entity.listening.Audios;
import project.repository.QuestionsRepository;

import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class AudiosDTO {

    private Long id;

    private String name;

    private FileDto audiFileDto;

    private Long audioFileId;

    private Set<FileDto> fileDtos;

    private List<Long> fileIds;

    private Long orderNumber;

    private List<QuestionsDTO> questions;

    private List<Long> questionIds;

    public AudiosDTO(Audios audios, QuestionsRepository questionsRepository) {
        setId(audios.getId());
        setName(audios.getName());
        setOrderNumber(audios.getOrderNumber());
        if (audios.getAudioFile() != null)
            setAudiFileDto(new FileDto(audios.getAudioFile()));
        if (audios.getFiles() != null && !audios.getFiles().isEmpty())
            setFileDtos(audios.getFiles().stream().map(FileDto::new).collect(Collectors.toSet()));
        setQuestions(questionsRepository.finAllByAudioId(audios.getId()));
    }


}
