package project.service.payme;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import project.exception.RecordNotFoundException;
import project.model.entity.UserApplication;
import project.model.entity.system.User;
import project.model.payme.Client;
import project.model.payme.Order;
import project.repository.UserApplicationRepository;
import project.repository.payme.ClientRepository;
import project.repository.payme.OrderRepository;
import project.service.system.UserService;

import java.util.Optional;

@Service
@RequiredArgsConstructor
@Slf4j
public class OrderService {

    private final OrderRepository orderRepository;
    private final ClientRepository clientRepository;
    private final UserService userService;
    private final UserApplicationRepository userApplicationRepository;

    public ResponseEntity<?> createOrder(Long userApplicationId, Integer orderSum) {
        Optional<Client> optionalClient = clientRepository.findByPhoneNumber("+998998747555");
        if (optionalClient.isEmpty())
            throw new RecordNotFoundException("Client not found");
        User user = userService.currentUser();
        UserApplication userApplication =
                userApplicationRepository.findById(userApplicationId).orElseThrow(() -> new RecordNotFoundException("UserApplication not found with id " + userApplicationId));
        if (user == null)
            throw new RecordNotFoundException("User not found");
        return ResponseEntity.ok(
                orderRepository.save(
                        Order.builder()
                                .userApplication(userApplication)
                                .orderSum(orderSum)
                                .paid(false)
                                .payer(user)
                                .cancelled(false)
                                .delivered(false)
                                .client(optionalClient.get())
                                .build()
                )
        );
    }
}
