package project.dto.system;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Data;
import lombok.NoArgsConstructor;
import project.model.entity.system.Permission;
import project.model.enums.Status;

import java.text.SimpleDateFormat;

@Data
@NoArgsConstructor
public class PermissionDto {
    private Long id;
    private String name;
    private String type;
    private String createdDate;

    public PermissionDto(Permission permission) {
        setId(permission.getId());
        setName(permission.getName());
        setType(permission.getType().name());
        if (permission.getCreatedDate() != null) {
            setCreatedDate(new SimpleDateFormat("dd-MM-yyyy hh:mm:ss").format(permission.getCreatedDate()));
        }
    }

    @JsonIgnore
    public static Permission of(PermissionDto permissionDto) {
        return Permission.builder()
                .name(permissionDto.getName())
                .status(Status.ACTIVE)
                .build();
    }
}
