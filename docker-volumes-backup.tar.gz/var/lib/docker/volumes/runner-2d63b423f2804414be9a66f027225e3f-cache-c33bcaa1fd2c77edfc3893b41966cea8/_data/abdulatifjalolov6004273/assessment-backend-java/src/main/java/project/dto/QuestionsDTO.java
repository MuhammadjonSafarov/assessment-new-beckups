package project.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import project.model.entity.Questions;
import project.model.enums.InnerTextType;
import project.model.enums.QuestionType;
import project.repository.AnswersRepository;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class QuestionsDTO {

    private Long id;

    private String name;

    private List<AnswersDTO> answers;

    private List<Long> answerIds;

    private InnerTextType innerTextType;

    private Long startIndex;

    private Long endIndex;

    private Long correctAnswersCount;

    private QuestionType questionType;

    private Double coefficient;

    private Double score;

    public QuestionsDTO(Questions questions, AnswersRepository answersRepository) {
        setId(questions.getId());
        setName(questions.getName());
        setInnerTextType(questions.getInnerTextType());
        setStartIndex(questions.getStartIndex());
        setEndIndex(questions.getEndIndex());
        setQuestionType(questions.getQuestionType());
        setCorrectAnswersCount(questions.getCorrectAnswersCount());
        setCoefficient(questions.getCoefficient());
        setScore(questions.getScore());
        if (questions.getId() != null)
            setAnswers(answersRepository.findAllByQuestionsId(questions));
    }

    public QuestionsDTO(Questions questions) {
        if (questions != null) {
            setCoefficient(questions.getCoefficient());
            setScore(questions.getScore());
            setId(questions.getId());
            setInnerTextType(questions.getInnerTextType());
            setCorrectAnswersCount(questions.getCorrectAnswersCount());
            setStartIndex(questions.getStartIndex());
            setQuestionType(questions.getQuestionType());
            setEndIndex(questions.getEndIndex());
            setName(questions.getName());
            if (questions.getId() != null)
                setAnswers(questions.getAnswers().stream().map(AnswersDTO::new).toList());
        }
    }

}
