package project.model.entity;

import lombok.*;
import project.model.Auditable;
import project.model.entity.listening.Listening;
import project.model.entity.reading.Reading;
import project.model.entity.speaking.Speaking;
import project.model.entity.system.User;
import project.model.entity.writing.Writing;
import project.model.enums.ExamFormat;
import project.model.enums.ExamType;
import project.model.enums.Status;

import javax.persistence.*;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import static javax.persistence.EnumType.STRING;
import static javax.persistence.FetchType.LAZY;
import static javax.persistence.GenerationType.SEQUENCE;

@AllArgsConstructor
@Getter
@Setter
@Entity
@NoArgsConstructor
@Builder
@Table(name = "sessions")
public class Session extends Auditable<String> {

    @Id
    @GeneratedValue(strategy = SEQUENCE, generator = "SESSION_SEQUENCE")
    @SequenceGenerator(sequenceName = "SESSION_SEQUENCE", allocationSize = 1, name = "SESSION_SEQUENCE")
    @Column(name = "id", nullable = false, updatable = false)
    private Long id;

    @Enumerated(EnumType.STRING)
    @Column(name = "exam_type")
    private ExamType examType;

    @OneToOne
    private TestType testType;

    @Enumerated(EnumType.STRING)
    @Column(name = "exam_format")
    private ExamFormat examFormat;

    @Column(name = "max_count_candidate")
    private Long maxCountCandidate;

    @ManyToOne
    private Pavilion pavilion;

    private BigDecimal cost;

    private String startDate;

    @Enumerated(STRING)
    @Column(name = "status")
    private Status status;

    @OneToOne
    private Listening listening;

    @OneToOne
    private Reading reading;

    @OneToOne
    private Writing writing;

    @OneToOne
    private Speaking speaking;

    private Double listeningScore = 0.0;
    private Double readingScore = 0.0;
    private Double speakingScore = 0.0;
    private Double writingScore = 0.0;

    @ManyToMany(fetch = LAZY)
    @JoinTable(name = "sys_user_sessions",
            joinColumns = {@JoinColumn(name = "session_id", referencedColumnName = "id")},
            inverseJoinColumns = {@JoinColumn(name = "user_id", referencedColumnName = "id")})
    private List<User> users = new ArrayList<>();

}
