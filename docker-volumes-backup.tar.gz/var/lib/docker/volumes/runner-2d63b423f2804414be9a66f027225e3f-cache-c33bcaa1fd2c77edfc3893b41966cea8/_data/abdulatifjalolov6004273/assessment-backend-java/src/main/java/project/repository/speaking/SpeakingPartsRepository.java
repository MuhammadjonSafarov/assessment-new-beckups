package project.repository.speaking;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.data.repository.query.QueryByExampleExecutor;
import project.model.entity.speaking.SpeakingParts;

import java.util.Optional;

public interface SpeakingPartsRepository extends JpaRepository<SpeakingParts, Long>, PagingAndSortingRepository<SpeakingParts, Long>, QueryByExampleExecutor<SpeakingParts> {

    @Query("select q from SpeakingParts q where q.status = 'ACTIVE' ")
    Optional<SpeakingParts> findByName(String name);

    @Query("select p from SpeakingParts p where p.status = 'ACTIVE' order by p.id ")
    Page<SpeakingParts> findAllBySearch(String value, Pageable pageable);

    @Query("select p from SpeakingParts p where p.status = 'ACTIVE' order by p.id ")
    Page<SpeakingParts> findAllSpeakingParts(Pageable pageable);

}
